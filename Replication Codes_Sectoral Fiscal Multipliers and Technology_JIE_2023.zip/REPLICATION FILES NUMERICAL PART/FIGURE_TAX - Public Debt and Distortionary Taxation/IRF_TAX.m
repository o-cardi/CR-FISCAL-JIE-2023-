clc
clear


% Maximum duration for graphics
Tg = 10;
       
% Minimum duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;

FISC_IML_CAC_TOT_CES_TECH_TAX; 
%FISC_IML_CAC_TOT_CES_TECH_NORMALIZED;  

%time0    = [Tm:Tu:0];
%time1    = [0:Tu:Tg]; % span of time t = [0..100]
%timetemp = [time0 time1];

%%%%%%%%%%% Impulse functions %%%%%%%%%% 

%%%%% LP-GOV                                                                                                                                          
[xdata1]=xlsread('LP_LGOV.xlsx');   %scaling=[1 1 1];                                                                                                   
namvar= char('IRF_LGOV');  nbPVAR  = 1;                                                                                                                
                                                                                                                                                      
[obs nbvar1]=size(xdata1);                                                                                                                            
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=8)     
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)                                             
nvar1     = nbvar1/3;                       % number of variables included in VAR                                                                     
irf1      = xdata1(1:obs,nvar1+1:2*nvar1);    % IRF of variables                                                                                      
lowerb1   = xdata1(1:obs,1:nvar1);           % lower bound of IRF                                                                                     
upperb1   = xdata1(1:obs,2*nvar1+1:3*nvar1);  % upper bound of IRF                                                                                    
                                                                                                                                                      
%%%%% LP-TAUC
[xdata2]=xlsread('LP_LTAUL.xlsx');   %scaling=[1 1 1];              
namvar= char('IRF_LTAUL');  nbPVAR  = 2;

[obs nbvar2]=size(xdata2);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=8) 
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar2     = nbvar2/3;                       % number of variables included in VAR
irf2      = xdata2(1:obs,nvar2+1:2*nvar2);    % IRF of variables 
lowerb2   = xdata2(1:obs,1:nvar2);           % lower bound of IRF
upperb2   = xdata2(1:obs,2*nvar2+1:3*nvar2);  % upper bound of IRF

%%%%% LP-L
[xdata3]=xlsread('LP_LTAUC.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LTAUC');  nbPVAR  = 1;

[obs nbvar3]=size(xdata3);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=8)
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar3     = nbvar3/3;                       % number of variables included in VAR
irf3      = xdata3(1:obs,nvar3+1:2*nvar3);    % IRF of variables
lowerb3   = xdata3(1:obs,1:nvar3);           % lower bound of IRF
upperb3   = xdata3(1:obs,2*nvar3+1:3*nvar3);  % upper bound of IRF

%%%%% LP-INV
[xdata4]=xlsread('LP_LDEBT.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LDEBT');  nbPVAR  = 1;

[obs nbvar4]=size(xdata4);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=8)
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar4     = nbvar4/3;                       % number of variables included in VAR
irf4      = xdata4(1:obs,nvar4+1:2*nvar4);    % IRF of variables
lowerb4   = xdata4(1:obs,1:nvar4);           % lower bound of IRF
upperb4   = xdata4(1:obs,2*nvar4+1:3*nvar4);  % upper bound of IRF

%%%%% LP-WPC
[xdata5]=xlsread('LP_LNETTAX.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LNETTAX');  nbPVAR  = 1;

[obs nbvar5]=size(xdata5);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=8)
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar5     = nbvar5/3;                       % number of variables included in VAR
irf5      = xdata5(1:obs,nvar5+1:2*nvar5);    % IRF of variables
lowerb5   = xdata5(1:obs,1:nvar5);           % lower bound of IRF
upperb5   = xdata5(1:obs,2*nvar5+1:3*nvar5);  % upper bound of IRF

%%%%%%%%%%% Impulse functions %%%%%%%%%% 

figure(1)
%subplot(3,2,1)
hold on
%plot(timetemp(2:12),pathdGY_endo(2:12),'-ks','LineWidth',5);
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb1(1:11,1)',fliplr(lowerb1(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdGY_tax(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf1(1:11,1)','blue','LineWidth',3);
%plot(timetemp(2:12),lowerb1(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb1(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
title('Government consumption');

figure(2)
%subplot(3,2,2)
hold on
%plot(timetemp(2:12),pathdtauL_endo(2:12),'-ks','LineWidth',5);
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb2(1:11,1)',fliplr(lowerb2(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdtauL_tax(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf2(1:11,1)','blue','LineWidth',3);
%plot(timetemp(2:12),lowerb2(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb2(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation in % of initial steady-state');  
title('Labor tax rate'); 


figure(3)
%subplot(3,2,3)
hold on
%plot(timetemp(2:12),pathdtauC_endo(2:12),'-ks','LineWidth',5);
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb3(1:11,1)',fliplr(lowerb3(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdtauC_tax(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf3(1:11,1)','blue','LineWidth',3);
%plot(timetemp(2:12),lowerb3(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb3(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation in % of steady-state');  %title('Aggregate Hours Worked, L=LT+LN'); 
title('Consumption tax rate'); 

figure(4)
%subplot(3,2,3)
hold on
%plot(timetemp(2:12),pathdDY_endo(2:12),'-ks','LineWidth',5);
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb4(1:11,1)',fliplr(lowerb4(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdDY_tax(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf4(1:11,1)','blue','LineWidth',3);
%plot(timetemp(2:12),lowerb4(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb4(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation in % of steady-state');  %title('Investment'); 
title('Public debt in % of GDP');

figure(5)
%subplot(3,2,3)
hold on
%plot(timetemp(2:12),pathdTY_endo(2:12),'-ks','LineWidth',5);
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb5(1:11,1)',fliplr(lowerb5(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdTY_tax(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf5(1:11,1)','blue','LineWidth',3);
%plot(timetemp(2:12),lowerb5(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb5(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation in % of steady-state');  %title('Real Consumption Wage'); 
title('Net total tax revenues');


clear

