function g = IML_CAC_TOT_CES_TAX_temp(x)

global sigmaC phi varphi rho varphiH
global phiI iota rhoI iotaH 
global ex nuX
global epsilon vartheta 
global gammaL sigmaL 
global r deltaK kappa
global omegaGN omegaGH GH GN GF
global BH BN AH AN gammaH gammaN sigmaH sigmaN
global N0 K0 Y_0 AH_0 BH_0 AN_0 BN_0 
global barg baraH barbH baraN barbN xi chi xiAH chiAH xiBH chiBH xiAN chiAN xiBN chiBN
global xi1H xi1N xi2H xi2N chi2H chi2N 
global tauL tauC tL xiL chiL phiG phiD deltaD omegaL_0 omegaC_0 DBT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kH      = x(3)  ; % Capital-labor ratio in sector H
WH      = x(4)  ; % Wage rate in sector H
WN      = x(5)  ; % Wage rate in sector N
W       = x(6)  ; % Aggregate wage index
kN      = x(7)  ; % Capital-labor ratio in sector N
PN      = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
PH      = x(10) ; % Terms of trade : PH/PF with PF = numeraire
N       = x(11) ; % Stock of Traded Bonds
alphaL  = x(12) ; % Output per worker in sector N 
PC      = x(13) ; % Aggregate consumption price index
PT      = x(14) ; % Consumption price index for tradables
CN      = x(15) ; % Consumption in non tradables 
CH      = x(16) ; % Consumption in tradables 
CF      = x(17) ; % Consumption goods imports
PI      = x(18) ; % Aggregate investment price index
PIT     = x(19) ; % Investment price index for tradables
IN      = x(20) ; % Non tradable investment
IH      = x(21) ; % Investment in home goods
IF      = x(22) ; % Investment in foreign goods
LH      = x(23) ; % Labor in sector H
LN      = x(24) ; % Labor in sector N 
yH      = x(25) ; % Output of home traded goods per worker
YH      = x(26) ; % Output of home traded goods
yN      = x(27) ; % Output of non traded goods per worker
YN      = x(28) ; % Output of non traded goods
XH      = x(29) ; % Exports of home traded goods
MF      = x(30) ; % Imports of foreign goods
TR      = x(31) ; % Public Debt
lambda  = x(32) ; % Marginal utility of wealth lambda
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Aggregate Consumption - C
g(1)= (C^(-1/sigmaC)) - (PC*(1+tauC)*lambda);

% Aggregate labor supply - L
g(2)= gammaL*(L^(1/sigmaL)) - (lambda*W*(1-tauL));

% equality of marginal product of capital across the two sectors - kH and
% kN
g(3)= PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((yH/kH)^(1/sigmaH)) - PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((yN/kN)^(1/sigmaN)); 

% Wage rate in sector H - WH
g(4)= PH*gammaH*(AH^((sigmaH-1)/sigmaH))*(yH^(1/sigmaH)) - WH;

% Wage rate in sector N - WN
g(5)= PN*gammaN*(AN^((sigmaN-1)/sigmaN))*(yN^(1/sigmaN)) - WN;

% Aggregate wage index - W
g(6)= W - ((vartheta*(WH)^(epsilon+1)) + ((1-vartheta)*(WN)^(epsilon+1)))^(1/(epsilon+1));

% sectoral capital allocation - kH and kN - 
g(7)= (LH*kH) + (LN*kN) - K;

% equality of marginal product of capital in the non traded sector to the world interest rate - PN 
g(8)= PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((yN/kN)^(1/sigmaN)) - (deltaK + r)*PI;

% Non traded market good market clearing condition - K 
g(9)= YN - CN - IN - GN;

% Homme good market clearing condition - PH
g(10)= YH - CH - IH - GH - XH;

% Traded good market clearing condition - B
g(11)= (r*N) + (PH*XH) - MF;

% Labor compensation share of tradables - alphaL 
g(12)= alphaL - (vartheta*(WH)^(epsilon+1))/( vartheta*(WH)^(epsilon+1) + (1-vartheta)*(WN)^(epsilon+1) );

% Consumption price index - PC=PC(PT,PN)
g(13)= PC - (varphi*(PT^(1-phi))+(1-varphi)*(PN^(1-phi)))^(1/(1-phi));

% Consumption price index for tradables - PT=PT(PH)
g(14)= PT - (varphiH*(PH^(1-rho))+(1-varphiH))^(1/(1-rho));

% Consumption in non tradables - CN
g(15)= CN - C*(1-varphi)*((PN/PC)^(-phi));

% Consumption in home goods - CH
g(16)= CH - C*varphi*((PT/PC)^(-phi))*varphiH*((PH/PT)^(-rho));

% Consumption in foreign goods - CF
g(17)= CF - C*varphi*((PT/PC)^(-phi))*(1-varphiH)*((1/PT)^(-rho));

% Investment price index - PI=PI(PT,PN)
g(18)= PI - (iota*(PIT^(1-phiI))+(1-iota)*(PN^(1-phiI)))^(1/(1-phiI));

% Investment price index for tradables - PIT=PIT(PH)
g(19)= PIT - (iotaH*(PH^(1-rhoI))+(1-iotaH))^(1/(1-rhoI));

% Investment in non tradables - IN
g(20)= IN - (deltaK*K)*(1-iota)*((PN/PI)^(-phiI));

% Investment in home goods - IH
g(21)= IH - (deltaK*K)*iota*((PIT/PI)^(-phiI))*iotaH*((PH/PIT)^(-rhoI));

% Investment in foreign goods - IF
g(22)= IF - (deltaK*K)*iota*((PIT/PI)^(-phiI))*(1-iotaH)*((1/PIT)^(-rhoI));

% Employment in the traded sector - LH
g(23)= LH - L*(vartheta*(WH/W)^epsilon); 

% Employment in the non traded sector - LN
g(24)= LN - L*((1-vartheta)*(WN/W)^epsilon); 

% Output in the home good sector - YH
% Output per worker in the home traded sector - kH,yH - and Labor
% income share in sector H, sLH
g(25)= yH - ( gammaH*(AH^((sigmaH-1)/sigmaH)) + (1-gammaH)*((BH*kH)^((sigmaH-1)/sigmaH)) )^(sigmaH/(sigmaH-1));  
g(26)= YH  - (LH*yH); 

% Output per worker in the non traded sector - kN,yN - and Labor
% income share in sector N, sLN
g(27)= yN  - ( gammaN*(AN)^((sigmaN-1)/sigmaN) + (1-gammaN)*((BN*kN)^((sigmaN-1)/sigmaN)) )^(sigmaN/(sigmaN-1)); 
g(28)= YN  - (LN*yN); 

% Export of home goods - XH
g(29)= XH - ex*(PH)^(-nuX);

% Import of foreign goods - MF
g(30)= MF - (CF+IF+GF);

% Government Debt - D
TL  = (tauL*W*L); 
TC  = (tauC*PC*C);
Tax = TL + TC; 
G = (PH*GH) + (PN*GN) + GF; 
g(31)= TR - (Tax - G - (r*DBT)); 

% Non tradable shares of consumption, investment, labor compensation, labor
% income share
I       = deltaK*K;
alphaC  = varphi*(PT/PC)^(1-phi);
alphaH  = varphiH*(PH/PT)^(1-rho);
alphaI  = iota*(PIT/PI)^(1-phiI);
alphaIH = iotaH*(PH/PIT)^(1-rhoI);
sLH     = gammaH*(AH/yH)^((sigmaH-1)/sigmaH);
sLN     = gammaN*(AN/yN)^((sigmaN-1)/sigmaN);
KH      = kH*LH; 
KN      = kN*LN;

% LHj = partial Lj/partial Wj
% LHj = partial Lj/partial Wj: Lj=Lj(WH,WN,uZH,uZN,tauL)
LH_WH    = (LH/WH)*( epsilon*(1-alphaL) + (sigmaL*alphaL) );
LH_1uZH  = LH*( epsilon*(1-alphaL) + (sigmaL*alphaL) );
LH_WN    = (LH/WN)*(1-alphaL)*(sigmaL-epsilon); 
LH_1uZN  = LH*(1-alphaL)*(sigmaL-epsilon); 
LH_1tauL = -sigmaL*LH/(1-tauL); 

LN_WH   = (LN/WH)*alphaL*(sigmaL-epsilon); 
LN_1uZH = LN*alphaL*(sigmaL-epsilon);
LN_WN   = (LN/WN)*( (epsilon*alphaL) + sigmaL*(1-alphaL) );  
LN_1uZN = LN*( (epsilon*alphaL) + sigmaL*(1-alphaL) ); 
LN_1tauL = -sigmaL*LN/(1-tauL); 

% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH)
CN_PN = - (CN/PN)*( (alphaC*phi) + sigmaC*(1-alphaC) ); 
CN_PH = (CN/PH)*alphaC*alphaH*(phi-sigmaC); 
CN_1tauC = -sigmaC*CN/(1+tauC);

CH_PN = (CH/PN)*(phi-sigmaC)*(1-alphaC); 
CH_PH = -(CH/PH)*( rho*(1-alphaH) + alphaH*( phi*(1-alphaC) + (sigmaC*alphaC) ) );
CH_1tauC = -sigmaC*CH/(1+tauC);

CF_PN = (CF/PN)*(1-alphaC)*(phi-sigmaC); 
CF_PH = (CF/PH)*alphaH*(rho - (phi*(1-alphaC)+(sigmaC*alphaC))); 
CF_1tauC = -sigmaC*CF/(1+tauC);

% Solving for kH, kN, WH, WN as functions of (PH, PN, K, uKH, uKN, uZH, uZN,
% AH, BH, AN, BN)
Psi_WH   = ( (kH*LH_WH) + (kN*LN_WH) );
Psi_WN   = ( (kH*LH_WN) + (kN*LN_WN) );
Psi_uZH  = ((kH*LH_1uZH) + (kN*LN_1uZH)); 
Psi_uZN  = ((kH*LH_1uZN) + (kN*LN_1uZN)); 
Psi_tauL = ( (kH*LH_1tauL) + (kN*LN_1tauL) );

d11 = -(1/sigmaH)*(sLH/kH); 
d12 = (1/sigmaN)*(sLN/kN);
d13 = 0;
d14 = 0;
d21 = (1/sigmaH)*((1-sLH)/kH); 
d22 = 0;  
d23 = -(1/WH); 
d24 = 0; 
d31 = 0; 
d32 = (1/sigmaN)*((1-sLN)/kN);
d33 = 0; 
d34 = -(1/WN);
d41 = LH; 
d42 = LN; 
d43 = Psi_WH; 
d44 = Psi_WN; 

% PN, PH, K, uKH, uKN, uZH, uZN, AH, BH, AN, BN, lambda
e11  = (1/PN); 
e12  = -(1/PH);
e13  = 0;
e14  = (sLH/sigmaH); 
e15  = -(sLN/sigmaN); 
e16  = 0;
e17  = 0;
e18  = -(1/sigmaH)*(sLH/AH); 
e19  = -(1/sigmaH)*((sigmaH-sLH)/BH);
e110 = (1/sigmaN)*(sLN/AN); 
e111 = (1/sigmaN)*((sigmaN-sLN)/BN);
e112 = 0; 

e21  = 0; 
e22  = -(1/PH); 
e23  = 0;
e24  = -((1-sLH)/sigmaH);
e25  = 0;
e26  = 0;
e27  = 0;
e28 = -(1/sigmaH)*(((sigmaH-1)+sLH)/AH); 
e29 = -(1/sigmaH)*((1-sLH)/BH); 
e210 = 0;
e211 = 0; 
e212 = 0; 

e31  = -(1/PN); 
e32  = 0; 
e33  = 0;
e34  = 0;
e35  = -((1-sLN)/sigmaN);
e36  = 0;
e37  = 0;
e38  = 0; 
e39  = 0; 
e310 = -(1/sigmaN)*(((sigmaN-1)+sLN)/AN); 
e311 = -(1/sigmaN)*((1-sLN)/BN); 
e312 = 0; 
 
e41  = 0; 
e42  = 0; 
e43  = 1;
e44  = 0; 
e45  = 0;
e46  = -Psi_uZH; 
e47  = -Psi_uZN;
e48  = 0; 
e49  = 0;
e410 = 0;
e411 = 0; 
e412 = -Psi_tauL;
    
M1 = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X1 = [e11 e12 e13 e14 e15 e16 e17 e18 e19 e110 e111 e112; e21 e22 e23 e24 e25 e26 e27 e28 e29 e210 e211 e212; e31 e32 e33 e34 e35 e36 e37 e38 e39 e310 e311 e312; e41 e42 e43 e44 e45 e46 e47 e48 e49 e410 e411 e412];
JST1 = inv(M1);
MST1 = JST1*X1;
kH_1PN = MST1(1,1); kH_1PH = MST1(1,2); kH_1K = MST1(1,3); kH_uKH = MST1(1,4); kH_uKN = MST1(1,5); kH_uZH = MST1(1,6); kH_uZN = MST1(1,7); kH_1AH = MST1(1,8); kH_1BH = MST1(1,9); kH_1AN = MST1(1,10); kH_1BN = MST1(1,11); kH_1tauL = MST1(1,12); 
kN_1PN = MST1(2,1); kN_1PH = MST1(2,2); kN_1K = MST1(2,3); kN_uKH = MST1(2,4); kN_uKN = MST1(2,5); kN_uZH = MST1(2,6); kN_uZN = MST1(2,7); kN_1AH = MST1(2,8); kN_1BH = MST1(2,9); kN_1AN = MST1(2,10); kN_1BN = MST1(2,11); kN_1tauL = MST1(2,12); 
WH_1PN = MST1(3,1); WH_1PH = MST1(3,2); WH_1K = MST1(3,3); WH_uKH = MST1(3,4); WH_uKN = MST1(3,5); WH_uZH = MST1(3,6); WH_uZN = MST1(3,7); WH_1AH = MST1(3,8); WH_1BH = MST1(3,9); WH_1AN = MST1(3,10); WH_1BN = MST1(3,11); WH_1tauL = MST1(3,12); 
WN_1PN = MST1(4,1); WN_1PH = MST1(4,2); WN_1K = MST1(4,3); WN_uKH = MST1(4,4); WN_uKN = MST1(4,5); WN_uZH = MST1(4,6); WN_uZN = MST1(4,7); WN_1AH = MST1(4,8); WN_1BH = MST1(4,9); WN_1AN = MST1(4,10); WN_1BN = MST1(4,11); WN_1tauL = MST1(4,12);     

% Solving for sectoral labor and sectoral output - Lj,yj,Yj,Kj(PN,PH,K,uKj,uZj)
LH_1PN = (LH_WH*WH_1PN) + (LH_WN*WN_1PN);
LH_1PH = (LH_WH*WH_1PH) + (LH_WN*WN_1PH);
LH_1K  = (LH_WH*WH_1K)  + (LH_WN*WN_1K);
LH_uKH = (LH_WH*WH_uKH) + (LH_WN*WN_uKH);
LH_uKN = (LH_WH*WH_uKN) + (LH_WN*WN_uKN);
LH_uZH = LH_1uZH + (LH_WH*WH_uZH) + (LH_WN*WN_uZH);
LH_uZN = LH_1uZN + (LH_WH*WH_uZN) + (LH_WN*WN_uZN);
LH_1AH = (LH_WH*WH_1AH) + (LH_WN*WN_1AH);
LH_1BH = (LH_WH*WH_1BH) + (LH_WN*WN_1BH);
LH_1AN = (LH_WH*WH_1AN) + (LH_WN*WN_1AN);
LH_1BN = (LH_WH*WH_1BN) + (LH_WN*WN_1BN);
LH_2tauL = LH_1tauL + (LH_WH*WH_1tauL) + (LH_WN*WN_1tauL);

LN_1PN = (LN_WH*WH_1PN) + (LN_WN*WN_1PN);
LN_1PH = (LN_WH*WH_1PH) + (LN_WN*WN_1PH);
LN_1K  = (LN_WH*WH_1K)  + (LN_WN*WN_1K);
LN_uKH = (LN_WH*WH_uKH) + (LN_WN*WN_uKH);
LN_uKN = (LN_WH*WH_uKN) + (LN_WN*WN_uKN);
LN_uZH = LN_1uZH + (LN_WH*WH_uZH) + (LN_WN*WN_uZH);
LN_uZN = LN_1uZN + (LN_WH*WH_uZN) + (LN_WN*WN_uZN);
LN_1AH = (LN_WH*WH_1AH) + (LN_WN*WN_1AH);
LN_1BH = (LN_WH*WH_1BH) + (LN_WN*WN_1BH);
LN_1AN = (LN_WH*WH_1AN) + (LN_WN*WN_1AN);
LN_1BN = (LN_WH*WH_1BN) + (LN_WN*WN_1BN);
LN_2tauL = LN_1tauL + (LN_WH*WH_1tauL) + (LN_WN*WN_1tauL);

yH_1PN = (yH/kH)*(1-sLH)*kH_1PN;
yH_1PH = (yH/kH)*(1-sLH)*kH_1PH;
yH_1K  = (yH/kH)*(1-sLH)*kH_1K;
yH_uKH = yH*(1-sLH) + (yH/kH)*(1-sLH)*kH_uKH;
yH_uKN = (yH/kH)*(1-sLH)*kH_uKN;
yH_uZH = (yH/kH)*(1-sLH)*kH_uZH;
yH_uZN = (yH/kH)*(1-sLH)*kH_uZN;
yH_1AH = (yH/AH)*sLH + (yH/kH)*(1-sLH)*kH_1AH; 
yH_1BH =  yH*(1-sLH)*( (1/BH) + (kH_1BH/kH) );  
yH_1AN =  (yH/kH)*(1-sLH)*kH_1AN;
yH_1BN =  (yH/kH)*(1-sLH)*kH_1BN;
yH_1tauL = (yH/kH)*(1-sLH)*kH_1tauL;

yN_1PN = (yN/kN)*(1-sLN)*kN_1PN;
yN_1PH = (yN/kN)*(1-sLN)*kN_1PH;
yN_1K  = (yN/kN)*(1-sLN)*kN_1K;
yN_uKH = (yN/kN)*(1-sLN)*kN_uKH;
yN_uKN = yN*(1-sLN) + (yN/kN)*(1-sLN)*kN_uKN;
yN_uZH = (yN/kN)*(1-sLN)*kN_uZH;
yN_uZN = (yN/kN)*(1-sLN)*kN_uZN;
yN_1AH = (yN/kN)*(1-sLN)*kN_1AH;
yN_1BH = (yN/kN)*(1-sLN)*kN_1BH;
yN_1AN = (yN/AN)*sLN + (yN/kN)*(1-sLN)*kN_1AN;
yN_1BN =  yN*(1-sLN)*( (1/BN) + (kN_1BN/kN) ); 
yN_1tauL = (yN/kN)*(1-sLN)*kN_1tauL;

YH_1PN = (LH*yH_1PN) + (yH*LH_1PN);
YH_1PH = (LH*yH_1PH) + (yH*LH_1PH);
YH_1K  = (LH*yH_1K) + (yH*LH_1K);
YH_uKH = (LH*yH_uKH) + (yH*LH_uKH);
YH_uKN = (LH*yH_uKN) + (yH*LH_uKN);
YH_uZH = (LH*yH_uZH) + (yH*LH_uZH);
YH_uZN = (LH*yH_uZN) + (yH*LH_uZN);
YH_1AH = (LH*yH_1AH) + (yH*LH_1AH);
YH_1BH = (LH*yH_1BH) + (yH*LH_1BH);
YH_1AN = (LH*yH_1AN) + (yH*LH_1AN);
YH_1BN = (LH*yH_1BN) + (yH*LH_1BN);
YH_1tauL = (LH*yH_1tauL) + (yH*LH_2tauL);

YN_1PN = (LN*yN_1PN) + (yN*LN_1PN);
YN_1PH = (LN*yN_1PH) + (yN*LN_1PH);
YN_1K  = (LN*yN_1K) + (yN*LN_1K);
YN_uKH = (LN*yN_uKH) + (yN*LN_uKH);
YN_uKN = (LN*yN_uKN) + (yN*LN_uKN);
YN_uZH = (LN*yN_uZH) + (yN*LN_uZH);
YN_uZN = (LN*yN_uZN) + (yN*LN_uZN);
YN_1AH = (LN*yN_1AH) + (yN*LN_1AH);
YN_1BH = (LN*yN_1BH) + (yN*LN_1BH);
YN_1AN = (LN*yN_1AN) + (yN*LN_1AN);
YN_1BN = (LN*yN_1BN) + (yN*LN_1BN);
YN_1tauL = (LN*yN_1tauL) + (yN*LN_2tauL);

KH_1PN = (LH*kH_1PN) + (kH*LH_1PN);
KH_1PH = (LH*kH_1PH) + (kH*LH_1PH);
KH_1K  = (LH*kH_1K) + (kH*LH_1K);
KH_uKH = (LH*kH_uKH) + (kH*LH_uKH);
KH_uKN = (LH*kH_uKN) + (kH*LH_uKN);
KH_uZH = (LH*kH_uZH) + (kH*LH_uZH);
KH_uZN = (LH*kH_uZN) + (kH*LH_uZN);
KH_1AH = (LH*kH_1AH) + (kH*LH_1AH);             
KH_1BH = (LH*kH_1BH) + (kH*LH_1BH);             
KH_1AN = (LH*kH_1AN) + (kH*LH_1AN);             
KH_1BN = (LH*kH_1BN) + (kH*LH_1BN);    
KH_1tauL = (LH*kH_1tauL) + (kH*LH_2tauL);

KN_1PN = (LN*kN_1PN) + (kN*LN_1PN);
KN_1PH = (LN*kN_1PH) + (kN*LN_1PH);
KN_1K  = (LN*kN_1K) + (kN*LN_1K);
KN_uKH = (LN*kN_uKH) + (kN*LN_uKH);
KN_uKN = (LN*kN_uKN) + (kN*LN_uKN);
KN_uZH = (LN*kN_uZH) + (kN*LN_uZH);
KN_uZN = (LN*kN_uZN) + (kN*LN_uZN);
KN_1AH = (LN*kN_1AH) + (kN*LN_1AH);                   
KN_1BH = (LN*kN_1BH) + (kN*LN_1BH);                   
KN_1AN = (LN*kN_1AN) + (kN*LN_1AN);                   
KN_1BN = (LN*kN_1BN) + (kN*LN_1BN);  
KN_1tauL  = (LN*kN_1tauL) + (kN*LN_2tauL); 

LISH_1PH   = sLH*( (WH_1PH/WH) + (LH_1PH/LH) - (1/PH) - (YH_1PH/YH) );                 
LISH_1PN   = sLH*( (WH_1PN/WH) + (LH_1PN/LH) - (YH_1PN/YH) );                          
LISH_1K    = sLH*( (WH_1K/WH) + (LH_1K/LH) - (YH_1K/YH) );                             
LISH_uKH   = sLH*( (WH_uKH/WH) + (LH_uKH/LH) - (YH_uKH/YH) );                          
LISH_uKN   = sLH*( (WH_uKN/WH) + (LH_uKN/LH) - (YH_uKN/YH) );                          
LISH_uZH   = sLH*( (WH_uZH/WH) + (LH_uZH/LH) - (YH_uZH/YH) );                          
LISH_uZN   = sLH*( (WH_uZN/WH) + (LH_uZN/LH) - (YH_uZN/YH) );                          
LISH_1AH   = sLH*( (WH_1AH/WH) + (LH_1AH/LH) - (YH_1AH/YH) );                          
LISH_1BH   = sLH*( (WH_1BH/WH) + (LH_1BH/LH) - (YH_1BH/YH) );                          
LISH_1AN   = sLH*( (WH_1AN/WH) + (LH_1AN/LH) - (YH_1AN/YH) );                          
LISH_1BN   = sLH*( (WH_1BN/WH) + (LH_1BN/LH) - (YH_1BN/YH) );                          
LISH_1tauL = sLH*( (WH_1tauL/WH) + (LH_2tauL/LH) - (YH_1tauL/YH) );                              
                                                                                       
LISN_1PH   = sLN*( (WN_1PH/WH) + (LN_1PH/LN) - (YN_1PH/YN) );                          
LISN_1PN   = sLN*( (WN_1PN/WH) + (LN_1PN/LN) - (1/PN) - (YN_1PN/YN) );                 
LISN_1K    = sLN*( (WN_1K/WH) + (LN_1K/LN) - (YN_1K/YN) );                             
LISN_uKH   = sLN*( (WN_uKH/WH) + (LN_uKH/LN) - (YN_uKH/YN) );                          
LISN_uKN   = sLN*( (WN_uKN/WH) + (LN_uKN/LN) - (YN_uKN/YN) );                          
LISN_uZH   = sLN*( (WN_uZH/WH) + (LN_uZH/LN) - (YN_uZH/YN) );                          
LISN_uZN   = sLN*( (WN_uZN/WH) + (LN_uZN/LN) - (YN_uZN/YN) );                          
LISN_1AH   = sLN*( (WN_1AH/WH) + (LN_1AH/LN) - (YN_1AH/YN) );                          
LISN_1BH   = sLN*( (WN_1BH/WH) + (LN_1BH/LN) - (YN_1BH/YN) );                          
LISN_1AN   = sLN*( (WN_1AN/WH) + (LN_1AN/LN) - (YN_1AN/YN) );                          
LISN_1BN   = sLN*( (WN_1BN/WH) + (LN_1BN/LN) - (YN_1BN/YN) );                          
LISN_1tauL = sLN*( (WN_1tauL/WH) + (LN_2tauL/LH) - (YN_1tauL/YN) );                     

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_K  = deltaK; 
J_Q  = K*v_1Q; 
J_PN = K*v_PN; 
J_PH = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q) 
JN_PN  = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH  = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K  = (IN/I)*J_K; 
JN_1Q  = (IN/I)*J_Q; 

JH_PN  =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH  = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_K; 
JH_1Q  = (IH/I)*J_Q; 

JF_PN  = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH  = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_K; 
JF_1Q  = (IF/I)*J_Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH  = -(XH/PH)*nuX; 

% Solving for capital and technology utilization rates: uKH, uKN, uZH, uZN, uKj,uZj(PN,PH,K,Aj,Bj,tauL)
f11 = ((xi2H/xi1H) + (sLH/sigmaH)) + (sLH/sigmaH)*(kH_uKH/kH);
f12 = (sLH/sigmaH)*(kH_uKN/kH);
f13 = ((sLH/sigmaH)*(kH_uZH/kH)-1);
f14 = (sLH/sigmaH)*(kH_uZN/kH);
f21 = (sLN/sigmaN)*(kN_uKH/kN);
f22 = ((xi2N/xi1N) + (sLN/sigmaN)) + (sLN/sigmaN)*(kN_uKN/kN);
f23 = (sLN/sigmaN)*(kN_uZH/kN);
f24 = ((sLN/sigmaN)*(kN_uZN/kN)-1);

f31 = -( (1-tauL*sLH)*YH_uKH - YH*tauL*LISH_uKH );          
f32 = -( (1-tauL*sLH)*YH_uKN - YH*tauL*LISH_uKN );          
f33 = chi2H -( (1-tauL*sLH)*YH_uZH - YH*tauL*LISH_uZH );    
f34 = -( (1-tauL*sLH)*YH_uZN - YH*tauL*LISH_uZN );          
f41 = -( (1-tauL*sLN)*YN_uKH - YN*tauL*LISN_uKH );          
f42 = -( (1-tauL*sLN)*YN_uKN - YN*tauL*LISN_uKN );          
f43 = -( (1-tauL*sLN)*YN_uZH - YN*tauL*LISN_uZH );          
f44 = chi2N -( (1-tauL*sLN)*YN_uZN - YN*tauL*LISN_uZN );    

% PN, PH, K, AH, BH, AN, BN, tauL
g11 = -(sLH/sigmaH)*(kH_1PN/kH);
g12 = -(sLH/sigmaH)*(kH_1PH/kH);
g13 = -(sLH/sigmaH)*(kH_1K/kH);
g14 = (sLH/sigmaH)*( (1/AH) - (kH_1AH/kH) ); 
g15 = (1/sigmaH)*( ((sigmaH-sLH)/BH) - sLH*(kH_1BH/kH) );
g16 = -(sLH/sigmaH)*(kH_1AN/kH);
g17 = -(sLH/sigmaH)*(kH_1BN/kH);
g18 = -(sLH/sigmaH)*(kH_1tauL/kH);

g21 = -(sLN/sigmaN)*(kN_1PN/kN);
g22 = -(sLN/sigmaN)*(kN_1PH/kN);
g23 = -(sLN/sigmaN)*(kN_1K/kN);
g24 = -(sLN/sigmaN)*(kN_1AH/kN);
g25 = -(sLN/sigmaN)*(kN_1BH/kN);
g26 = (sLN/sigmaN)*( (1/AN) - (kN_1AN/kN) ); 
g27 = (1/sigmaN)*( ((sigmaN-sLN)/BN) - sLN*(kN_1BN/kN) );
g28 = -(sLN/sigmaN)*(kN_1tauL/kN);

g31 = ( (1-tauL*sLH)*YH_1PN - YH*tauL*LISH_1PN );                   
g32 = ( (1-tauL*sLH)*YH_1PH - YH*tauL*LISH_1PH );                   
g33 = ( (1-tauL*sLH)*YH_1K - YH*tauL*LISH_1K );                     
g34 = ( (1-tauL*sLH)*YH_1AH - YH*tauL*LISH_1AH );                   
g35 = ( (1-tauL*sLH)*YH_1BH - YH*tauL*LISH_1BH );                   
g36 = ( (1-tauL*sLH)*YH_1AN - YH*tauL*LISH_1AN );                   
g37 = ( (1-tauL*sLH)*YH_1BN - YH*tauL*LISH_1BN );                   
g38 = ( (1-tauL*sLH)*YH_1tauL - YH*tauL*LISH_1tauL - YH*sLH);               
                                                                    
g41 = ( (1-tauL*sLN)*YN_1PN - YN*tauL*LISN_1PN );                   
g42 = ( (1-tauL*sLN)*YN_1PH - YN*tauL*LISN_1PH );                   
g43 = ( (1-tauL*sLN)*YN_1K - YN*tauL*LISN_1K );                     
g44 = ( (1-tauL*sLN)*YN_1AH - YN*tauL*LISN_1AH );                   
g45 = ( (1-tauL*sLN)*YN_1BH - YN*tauL*LISN_1BH );                   
g46 = ( (1-tauL*sLN)*YN_1AN - YN*tauL*LISN_1AN );                   
g47 = ( (1-tauL*sLN)*YN_1BN - YN*tauL*LISN_1BN );                   
g48 = ( (1-tauL*sLN)*YN_1tauL - YN*tauL*LISN_1tauL - YN*sLN);                 

M2 = [f11 f12 f13 f14; f21 f22 f23 f24; f31 f32 f33 f34; f41 f42 f43 f44];
X2 = [g11 g12 g13 g14 g15 g16 g17 g18; g21 g22 g23 g24 g25 g26 g27 g28; g31 g32 g33 g34 g35 g36 g37 g38; g41 g42 g43 g44 g45 g46 g47 g48];
JST2 = inv(M2);
MST2 = JST2*X2;

uKH_PN = MST2(1,1); uKH_PH = MST2(1,2); uKH_1K = MST2(1,3); uKH_1AH = MST2(1,4); uKH_1BH = MST2(1,5); uKH_1AN = MST2(1,6); uKH_1BN = MST2(1,7); uKH_1tauL = MST2(1,8); 
uKN_PN = MST2(2,1); uKN_PH = MST2(2,2); uKN_1K = MST2(2,3); uKN_1AH = MST2(2,4); uKN_1BH = MST2(2,5); uKN_1AN = MST2(2,6); uKN_1BN = MST2(2,7); uKN_1tauL = MST2(2,8); 
uZH_PN = MST2(3,1); uZH_PH = MST2(3,2); uZH_1K = MST2(3,3); uZH_1AH = MST2(3,4); uZH_1BH = MST2(3,5); uZH_1AN = MST2(3,6); uZH_1BN = MST2(3,7); uZH_1tauL = MST2(3,8); 
uZN_PN = MST2(4,1); uZN_PH = MST2(4,2); uZN_1K = MST2(4,3); uZN_1AH = MST2(4,4); uZN_1BH = MST2(4,5); uZN_1AN = MST2(4,6); uZN_1BN = MST2(4,7); uZN_1tauL = MST2(4,8); 

% Solving for sectoral labor and sectoral output - kj,Wj,Lj,yj,Yj,Kj(lambda,K,PH,PN,AH,BH,AN,BN) 
kH_2K  = kH_1K + (kH_uKH*uKH_1K) + (kH_uKN*uKN_1K) + (kH_uZH*uZH_1K) + (kH_uZN*uZN_1K); 
kH_PH  = kH_1PH + (kH_uKH*uKH_PH) + (kH_uKN*uKN_PH) + (kH_uZH*uZH_PH) + (kH_uZN*uZN_PH);
kH_PN  = kH_1PN + (kH_uKH*uKH_PN) + (kH_uKN*uKN_PN) + (kH_uZH*uZH_PN) + (kH_uZN*uZN_PN);
kH_2AH = kH_1AH + (kH_uKH*uKH_1AH) + (kH_uKN*uKN_1AH) + (kH_uZH*uZH_1AH) + (kH_uZN*uZN_1AH); 
kH_2BH = kH_1BH + (kH_uKH*uKH_1BH) + (kH_uKN*uKN_1BH) + (kH_uZH*uZH_1BH) + (kH_uZN*uZN_1BH); 
kH_2AN = kH_1AN + (kH_uKH*uKH_1AN) + (kH_uKN*uKN_1AN) + (kH_uZH*uZH_1AN) + (kH_uZN*uZN_1AN); 
kH_2BN = kH_1BN + (kH_uKH*uKH_1BN) + (kH_uKN*uKN_1BN) + (kH_uZH*uZH_1BN) + (kH_uZN*uZN_1BN); 
kH_2tauL = kH_1tauL + (kH_uKH*uKH_1tauL) + (kH_uKN*uKN_1tauL) + (kH_uZH*uZH_1tauL) + (kH_uZN*uZN_1tauL);

kN_2K  = kN_1K + (kN_uKH*uKH_1K) + (kN_uKN*uKN_1K) + (kN_uZH*uZH_1K) + (kN_uZN*uZN_1K);     
kN_PH  = kN_1PH + (kN_uKH*uKH_PH) + (kN_uKN*uKN_PH) + (kN_uZH*uZH_PH) + (kN_uZN*uZN_PH);
kN_PN  = kN_1PN + (kN_uKH*uKH_PN) + (kN_uKN*uKN_PN) + (kN_uZH*uZH_PN) + (kN_uZN*uZN_PN);
kN_2AH = kN_1AH + (kN_uKH*uKH_1AH) + (kN_uKN*uKN_1AH) + (kN_uZH*uZH_1AH) + (kN_uZN*uZN_1AH); 
kN_2BH = kN_1BH + (kN_uKH*uKH_1BH) + (kN_uKN*uKN_1BH) + (kN_uZH*uZH_1BH) + (kN_uZN*uZN_1BH); 
kN_2AN = kN_1AN + (kN_uKH*uKH_1AN) + (kN_uKN*uKN_1AN) + (kN_uZH*uZH_1AN) + (kN_uZN*uZN_1AN); 
kN_2BN = kN_1BN + (kN_uKH*uKH_1BN) + (kN_uKN*uKN_1BN) + (kN_uZH*uZH_1BN) + (kN_uZN*uZN_1BN); 
kN_2tauL = kN_1tauL + (kN_uKH*uKH_1tauL) + (kN_uKN*uKN_1tauL) + (kN_uZH*uZH_1tauL) + (kN_uZN*uZN_1tauL);
 
WH_2K  = WH_1K + (WH_uKH*uKH_1K) + (WH_uKN*uKN_1K) + (WH_uZH*uZH_1K) + (WH_uZN*uZN_1K);  
WH_PH  = WH_1PH + (WH_uKH*uKH_PH) + (WH_uKN*uKN_PH) + (WH_uZH*uZH_PH) + (WH_uZN*uZN_PH); 
WH_PN  = WH_1PN + (WH_uKH*uKH_PN) + (WH_uKN*uKN_PN) + (WH_uZH*uZH_PN) + (WH_uZN*uZN_PN);
WH_2AH = WH_1AH + (WH_uKH*uKH_1AH) + (WH_uKN*uKN_1AH) + (WH_uZH*uZH_1AH) + (WH_uZN*uZN_1AH);
WH_2BH = WH_1BH + (WH_uKH*uKH_1BH) + (WH_uKN*uKN_1BH) + (WH_uZH*uZH_1BH) + (WH_uZN*uZN_1BH);
WH_2AN = WH_1AN + (WH_uKH*uKH_1AN) + (WH_uKN*uKN_1AN) + (WH_uZH*uZH_1AN) + (WH_uZN*uZN_1AN);
WH_2BN = WH_1BN + (WH_uKH*uKH_1BN) + (WH_uKN*uKN_1BN) + (WH_uZH*uZH_1BN) + (WH_uZN*uZN_1BN);
WH_2tauL  = WH_1tauL + (WH_uKH*uKH_1tauL) + (WH_uKN*uKN_1tauL) + (WH_uZH*uZH_1tauL) + (WH_uZN*uZN_1tauL);

WN_2K = WN_1K + (WN_uKH*uKH_1K) + (WN_uKN*uKN_1K) + (WN_uZH*uZH_1K) + (WN_uZN*uZN_1K);  
WN_PH = WN_1PH + (WN_uKH*uKH_PH) + (WN_uKN*uKN_PH) + (WN_uZH*uZH_PH) + (WN_uZN*uZN_PH); 
WN_PN = WN_1PN + (WN_uKH*uKH_PN) + (WN_uKN*uKN_PN) + (WN_uZH*uZH_PN) + (WN_uZN*uZN_PN);
WN_2AH = WN_1AH + (WN_uKH*uKH_1AH) + (WN_uKN*uKN_1AH) + (WN_uZH*uZH_1AH) + (WN_uZN*uZN_1AH);                          
WN_2BH = WN_1BH + (WN_uKH*uKH_1BH) + (WN_uKN*uKN_1BH) + (WN_uZH*uZH_1BH) + (WN_uZN*uZN_1BH);                          
WN_2AN = WN_1AN + (WN_uKH*uKH_1AN) + (WN_uKN*uKN_1AN) + (WN_uZH*uZH_1AN) + (WN_uZN*uZN_1AN);                          
WN_2BN = WN_1BN + (WN_uKH*uKH_1BN) + (WN_uKN*uKN_1BN) + (WN_uZH*uZH_1BN) + (WN_uZN*uZN_1BN);       
WN_2tauL = WN_1tauL + (WN_uKH*uKH_1tauL) + (WN_uKN*uKN_1tauL) + (WN_uZH*uZH_1tauL) + (WN_uZN*uZN_1tauL);

LH_2K = LH_1K + (LH_uKH*uKH_1K) + (LH_uKN*uKN_1K) + (LH_uZH*uZH_1K) + (LH_uZN*uZN_1K);  
LH_PH = LH_1PH + (LH_uKH*uKH_PH) + (LH_uKN*uKN_PH) + (LH_uZH*uZH_PH) + (LH_uZN*uZN_PH); 
LH_PN = LH_1PN + (LH_uKH*uKH_PN) + (LH_uKN*uKN_PN) + (LH_uZH*uZH_PN) + (LH_uZN*uZN_PN);   
LH_2AH = LH_1AH + (LH_uKH*uKH_1AH) + (LH_uKN*uKN_1AH) + (LH_uZH*uZH_1AH) + (LH_uZN*uZN_1AH);                          
LH_2BH = LH_1BH + (LH_uKH*uKH_1BH) + (LH_uKN*uKN_1BH) + (LH_uZH*uZH_1BH) + (LH_uZN*uZN_1BH);                          
LH_2AN = LH_1AN + (LH_uKH*uKH_1AN) + (LH_uKN*uKN_1AN) + (LH_uZH*uZH_1AN) + (LH_uZN*uZN_1AN);                          
LH_2BN = LH_1BN + (LH_uKH*uKH_1BN) + (LH_uKN*uKN_1BN) + (LH_uZH*uZH_1BN) + (LH_uZN*uZN_1BN);  
LH_3tauL = LH_2tauL + (LH_uKH*uKH_1tauL) + (LH_uKN*uKN_1tauL) + (LH_uZH*uZH_1tauL) + (LH_uZN*uZN_1tauL);

LN_2K = LN_1K + (LN_uKH*uKH_1K) + (LN_uKN*uKN_1K) + (LN_uZH*uZH_1K) + (LN_uZN*uZN_1K);  
LN_PH = LN_1PH + (LN_uKH*uKH_PH) + (LN_uKN*uKN_PH) + (LN_uZH*uZH_PH) + (LN_uZN*uZN_PH); 
LN_PN = LN_1PN + (LN_uKH*uKH_PN) + (LN_uKN*uKN_PN) + (LN_uZH*uZH_PN) + (LN_uZN*uZN_PN);
LN_2AH = LN_1AH + (LN_uKH*uKH_1AH) + (LN_uKN*uKN_1AH) + (LN_uZH*uZH_1AH) + (LN_uZN*uZN_1AH);                         
LN_2BH = LN_1BH + (LN_uKH*uKH_1BH) + (LN_uKN*uKN_1BH) + (LN_uZH*uZH_1BH) + (LN_uZN*uZN_1BH);                         
LN_2AN = LN_1AN + (LN_uKH*uKH_1AN) + (LN_uKN*uKN_1AN) + (LN_uZH*uZH_1AN) + (LN_uZN*uZN_1AN);                         
LN_2BN = LN_1BN + (LN_uKH*uKH_1BN) + (LN_uKN*uKN_1BN) + (LN_uZH*uZH_1BN) + (LN_uZN*uZN_1BN);       
LN_3tauL = LN_2tauL + (LN_uKH*uKH_1tauL) + (LN_uKN*uKN_1tauL) + (LN_uZH*uZH_1tauL) + (LN_uZN*uZN_1tauL);

YH_2K = YH_1K + (YH_uKH*uKH_1K) + (YH_uKN*uKN_1K) + (YH_uZH*uZH_1K) + (YH_uZN*uZN_1K);   
YH_PH = YH_1PH + (YH_uKH*uKH_PH) + (YH_uKN*uKN_PH) + (YH_uZH*uZH_PH) + (YH_uZN*uZN_PH);  
YH_PN = YH_1PN + (YH_uKH*uKH_PN) + (YH_uKN*uKN_PN) + (YH_uZH*uZH_PN) + (YH_uZN*uZN_PN); 
YH_2AH = YH_1AH + (YH_uKH*uKH_1AH) + (YH_uKN*uKN_1AH) + (YH_uZH*uZH_1AH) + (YH_uZN*uZN_1AH);                         
YH_2BH = YH_1BH + (YH_uKH*uKH_1BH) + (YH_uKN*uKN_1BH) + (YH_uZH*uZH_1BH) + (YH_uZN*uZN_1BH);                         
YH_2AN = YH_1AN + (YH_uKH*uKH_1AN) + (YH_uKN*uKN_1AN) + (YH_uZH*uZH_1AN) + (YH_uZN*uZN_1AN);                         
YH_2BN = YH_1BN + (YH_uKH*uKH_1BN) + (YH_uKN*uKN_1BN) + (YH_uZH*uZH_1BN) + (YH_uZN*uZN_1BN);         
YH_2tauL = YH_1tauL + (YH_uKH*uKH_1tauL) + (YH_uKN*uKN_1tauL) + (YH_uZH*uZH_1tauL) + (YH_uZN*uZN_1tauL);

YN_2K = YN_1K + (YN_uKH*uKH_1K) + (YN_uKN*uKN_1K) + (YN_uZH*uZH_1K) + (YN_uZN*uZN_1K);   
YN_PH = YN_1PH + (YN_uKH*uKH_PH) + (YN_uKN*uKN_PH) + (YN_uZH*uZH_PH) + (YN_uZN*uZN_PH);  
YN_PN = YN_1PN + (YN_uKH*uKH_PN) + (YN_uKN*uKN_PN) + (YN_uZH*uZH_PN) + (YN_uZN*uZN_PN); 
YN_2AH = YN_1AH + (YN_uKH*uKH_1AH) + (YN_uKN*uKN_1AH) + (YN_uZH*uZH_1AH) + (YN_uZN*uZN_1AH);                        
YN_2BH = YN_1BH + (YN_uKH*uKH_1BH) + (YN_uKN*uKN_1BH) + (YN_uZH*uZH_1BH) + (YN_uZN*uZN_1BH);                        
YN_2AN = YN_1AN + (YN_uKH*uKH_1AN) + (YN_uKN*uKN_1AN) + (YN_uZH*uZH_1AN) + (YN_uZN*uZN_1AN);                        
YN_2BN = YN_1BN + (YN_uKH*uKH_1BN) + (YN_uKN*uKN_1BN) + (YN_uZH*uZH_1BN) + (YN_uZN*uZN_1BN); 
YN_2tauL = YN_1tauL + (YN_uKH*uKH_1tauL) + (YN_uKN*uKN_1tauL) + (YN_uZH*uZH_1tauL) + (YN_uZN*uZN_1tauL);

KH_2K = KH_1K + (KH_uKH*uKH_1K) + (KH_uKN*uKN_1K) + (KH_uZH*uZH_1K) + (KH_uZN*uZN_1K);  
KH_PH = KH_1PH + (KH_uKH*uKH_PH) + (KH_uKN*uKN_PH) + (KH_uZH*uZH_PH) + (KH_uZN*uZN_PH); 
KH_PN = KH_1PN + (KH_uKH*uKH_PN) + (KH_uKN*uKN_PN) + (KH_uZH*uZH_PN) + (KH_uZN*uZN_PN);   
KH_2AH = KH_1AH + (KH_uKH*uKH_1AH) + (KH_uKN*uKN_1AH) + (KH_uZH*uZH_1AH) + (KH_uZN*uZN_1AH);                        
KH_2BH = KH_1BH + (KH_uKH*uKH_1BH) + (KH_uKN*uKN_1BH) + (KH_uZH*uZH_1BH) + (KH_uZN*uZN_1BH);                        
KH_2AN = KH_1AN + (KH_uKH*uKH_1AN) + (KH_uKN*uKN_1AN) + (KH_uZH*uZH_1AN) + (KH_uZN*uZN_1AN);                        
KH_2BN = KH_1BN + (KH_uKH*uKH_1BN) + (KH_uKN*uKN_1BN) + (KH_uZH*uZH_1BN) + (KH_uZN*uZN_1BN);  
KH_2tauL = KH_1tauL + (KH_uKH*uKH_1tauL) + (KH_uKN*uKN_1tauL) + (KH_uZH*uZH_1tauL) + (KH_uZN*uZN_1tauL);

KN_2K = KN_1K + (KN_uKH*uKH_1K) + (KN_uKN*uKN_1K) + (KN_uZH*uZH_1K) + (KN_uZN*uZN_1K);  
KN_PH = KN_1PH + (KN_uKH*uKH_PH) + (KN_uKN*uKN_PH) + (KN_uZH*uZH_PH) + (KN_uZN*uZN_PH); 
KN_PN = KN_1PN + (KN_uKH*uKH_PN) + (KN_uKN*uKN_PN) + (KN_uZH*uZH_PN) + (KN_uZN*uZN_PN); 
KN_2AH = KN_1AH + (KN_uKH*uKH_1AH) + (KN_uKN*uKN_1AH) + (KN_uZH*uZH_1AH) + (KN_uZN*uZN_1AH);                        
KN_2BH = KN_1BH + (KN_uKH*uKH_1BH) + (KN_uKN*uKN_1BH) + (KN_uZH*uZH_1BH) + (KN_uZN*uZN_1BH);                        
KN_2AN = KN_1AN + (KN_uKH*uKH_1AN) + (KN_uKN*uKN_1AN) + (KN_uZH*uZH_1AN) + (KN_uZN*uZN_1AN);                        
KN_2BN = KN_1BN + (KN_uKH*uKH_1BN) + (KN_uKN*uKN_1BN) + (KN_uZH*uZH_1BN) + (KN_uZN*uZN_1BN); 
KN_2tauL = KN_1tauL + (KN_uKH*uKH_1tauL) + (KN_uKN*uKN_1tauL) + (KN_uZH*uZH_1tauL) + (KN_uZN*uZN_1tauL);

% Partial Derivatives Gj=Gj(G) 
GN_G   = omegaGN/PN; 
GH_G   = (1-omegaGN)*(omegaGH/PH);
GF_G   = (1-omegaGN)*(1-omegaGH);

% Solving for traded and non-traded prices: PH,PN(K,Q,G,AH,BH,AN,BN,tauL,tauC)     
h11 = (YN_PH - CN_PH - JN_PH) + (YN*tauL*sLN*uZN_PH) - (KN*xi1N*uKN_PH);           
h12 = (YN_PN - CN_PN - JN_PN) + (YN*tauL*sLN*uZN_PN) - (KN*xi1N*uKN_PN);           
h21 = (YH_PH - CH_PH - JH_PH - XH_PH) + (YH*tauL*sLH*uZH_PH) - (KH*xi1H*uKH_PH);   
h22 = (YH_PN - CH_PN - JH_PN) + (YH*tauL*sLH*uZH_PN) - (KH*xi1H*uKH_PN);        
                                                            
% K,Q,G,AH,BH,AN,BN,tauL,tauC                                                       
k11 = -(YN_2K + (YN*tauL*sLN*uZN_1K) - JN_1K - (KN*xi1N*uKN_1K));                  
k12 = JN_1Q;    
k13 = GN_G;
k14 = -(YN_2AH + (YN*tauL*sLN*uZN_1AH) - (KN*xi1N*uKN_1AH));                        
k15 = -(YN_2BH + (YN*tauL*sLN*uZN_1BH) - (KN*xi1N*uKN_1BH));                        
k16 = -(YN_2AN + (YN*tauL*sLN*uZN_1AN) - (KN*xi1N*uKN_1AN));                        
k17 = -(YN_2BN + (YN*tauL*sLN*uZN_1BN) - (KN*xi1N*uKN_1BN)); 
k18 = -(YN_2tauL + (YN*tauL*sLN*uZN_1tauL) - (KN*xi1N*uKN_1tauL));
k19 = CN_1tauC;

k21 = -(YH_2K + (YH*tauL*sLH*uZH_1K) - JH_1K - (KH*xi1H*uKH_1K));                          
k22 = JH_1Q;                                                                               
k23 = GH_G;                                                                                
k24 = -(YH_2AH + (YH*tauL*sLH*uZH_1AH) - (KH*xi1H*uKH_1AH));                               
k25 = -(YH_2BH + (YH*tauL*sLH*uZH_1BH) - (KH*xi1H*uKH_1BH));                               
k26 = -(YH_2AN + (YH*tauL*sLH*uZH_1AN) - (KH*xi1H*uKH_1AN));                               
k27 = -(YH_2BN + (YH*tauL*sLH*uZH_1BN) - (KH*xi1H*uKH_1BN));                               
k28 = -(YH_2tauL + (YH*tauL*sLH*uZH_1tauL) - (KH*xi1H*uKH_1tauL));                         
k29 = CH_1tauC;  
                                                            
M3 = [h11 h12; h21 h22];                                    
X3 = [k11 k12 k13 k14 k15 k16 k17 k18 k19; k21 k22 k23 k24 k25 k26 k27 k28 k29];                                    
JST3 = inv(M3);                                             
MST3 = JST3*X3;                                             
                                                            
PH_K = MST3(1,1); PH_Q = MST3(1,2); PH_G = MST3(1,3); PH_AH = MST3(1,4); PH_BH = MST3(1,5); PH_AN = MST3(1,6); PH_BN = MST3(1,7); PH_tauL = MST3(1,8); PH_tauC = MST3(1,9); 
PN_K = MST3(2,1); PN_Q = MST3(2,2); PN_G = MST3(2,3); PN_AH = MST3(2,4); PN_BH = MST3(2,5); PN_AN = MST3(2,6); PN_BN = MST3(2,7); PN_tauL = MST3(2,8); PN_tauC = MST3(2,9);                       

% Solving for capital-labor ratios kj=kj(K,Q,G,Aj,Bj) - 
% sectoral labor Lj=Lj(K,Q,G,Aj,Bj) - sectoral output 
% Yj=Yj(K,Q,G,Aj,Bj) - Final Solutions
kH_K = kH_2K + (kH_PH*PH_K) + (kH_PN*PN_K); 
kH_Q = (kH_PH*PH_Q) + (kH_PN*PN_Q);
kH_G = (kH_PH*PH_G) + (kH_PN*PN_G);
kH_AH = kH_2AH + (kH_PH*PH_AH) + (kH_PN*PN_AH);
kH_BH = kH_2BH + (kH_PH*PH_BH) + (kH_PN*PN_BH);
kH_AN = kH_2AN + (kH_PH*PH_AN) + (kH_PN*PN_AN);
kH_BN = kH_2BN + (kH_PH*PH_BN) + (kH_PN*PN_BN);
kH_tauL = kH_2tauL + (kH_PH*PH_tauL) + (kH_PN*PN_tauL); 
kH_tauC = (kH_PH*PH_tauC) + (kH_PN*PN_tauC);

kN_K = kN_2K + (kN_PH*PH_K) + (kN_PN*PN_K);
kN_Q = (kN_PH*PH_Q) + (kN_PN*PN_Q); 
kN_G = (kN_PH*PH_G) + (kN_PN*PN_G);
kN_AH = kN_2AH + (kN_PH*PH_AH) + (kN_PN*PN_AH);
kN_BH = kN_2BH + (kN_PH*PH_BH) + (kN_PN*PN_BH);
kN_AN = kN_2AN + (kN_PH*PH_AN) + (kN_PN*PN_AN); 
kN_BN = kN_2BN + (kN_PH*PH_BN) + (kN_PN*PN_BN); 
kN_tauL = kN_2tauL + (kN_PH*PH_tauL) + (kN_PN*PN_tauL); 
kN_tauC = (kN_PH*PH_tauC) + (kN_PN*PN_tauC);

LH_K  = LH_2K + (LH_PH*PH_K) + (LH_PN*PN_K); 
LH_Q  = (LH_PH*PH_Q) + (LH_PN*PN_Q); 
LH_G  = (LH_PH*PH_G) + (LH_PN*PN_G);
LH_AH = LH_2AH + (LH_PH*PH_AH) + (LH_PN*PN_AH); 
LH_BH = LH_2BH + (LH_PH*PH_BH) + (LH_PN*PN_BH);
LH_AN = LH_2AN + (LH_PH*PH_AN) + (LH_PN*PN_AN); 
LH_BN = LH_2BN + (LH_PH*PH_BN) + (LH_PN*PN_BN); 
LH_tauL  = LH_3tauL + (LH_PH*PH_tauL) + (LH_PN*PN_tauL); 
LH_tauC  = (LH_PH*PH_tauC) + (LH_PN*PN_tauC);

LN_K = LN_2K + (LN_PH*PH_K) + (LN_PN*PN_K);
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);
LN_G = (LN_PH*PH_G) + (LN_PN*PN_G); 
LN_AH = LN_2AH + (LN_PH*PH_AH) + (LN_PN*PN_AH); 
LN_BH = LN_2BH + (LN_PH*PH_BH) + (LN_PN*PN_BH);
LN_AN = LN_2AN + (LN_PH*PH_AN) + (LN_PN*PN_AN); 
LN_BN = LN_2BN + (LN_PH*PH_BN) + (LN_PN*PN_BN);
LN_tauL = LN_3tauL + (LN_PH*PH_tauL) + (LN_PN*PN_tauL);
LN_tauC = (LN_PH*PH_tauC) + (LN_PN*PN_tauC); 

YH_K = YH_2K + (YH_PH*PH_K) + (YH_PN*PN_K); 
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q); 
YH_G = (YH_PH*PH_G) + (YH_PN*PN_G);
YH_AH = YH_2AH + (YH_PH*PH_AH) + (YH_PN*PN_AH);
YH_BH = YH_2BH + (YH_PH*PH_BH) + (YH_PN*PN_BH);
YH_AN = YH_2AN + (YH_PH*PH_AN) + (YH_PN*PN_AN);
YH_BN = YH_2BN + (YH_PH*PH_BN) + (YH_PN*PN_BN);
YH_tauL = YH_2tauL + (YH_PH*PH_tauL) + (YH_PN*PN_tauL); 
YH_tauC = (YH_PH*PH_tauC) + (YH_PN*PN_tauC);

YN_K = YN_2K + (YN_PH*PH_K) + (YN_PN*PN_K);
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);
YN_G = (YN_PH*PH_G) + (YN_PN*PN_G);
YN_AH = YN_2AH + (YN_PH*PH_AH) + (YN_PN*PN_AH);
YN_BH = YN_2BH + (YN_PH*PH_BH) + (YN_PN*PN_BH);
YN_AN = YN_2AN + (YN_PH*PH_AN) + (YN_PN*PN_AN);
YN_BN = YN_2BN + (YN_PH*PH_BN) + (YN_PN*PN_BN);
YN_tauL = YN_2tauL + (YN_PH*PH_tauL) + (YN_PN*PN_tauL);
YN_tauC = (YN_PH*PH_tauC) + (YN_PN*PN_tauC);

KH_K  = KH_2K + (KH_PH*PH_K) + (KH_PN*PN_K);                     
KH_Q  = (KH_PH*PH_Q) + (KH_PN*PN_Q);                             
KH_G  = (KH_PH*PH_G) + (KH_PN*PN_G);                             
KH_AH = KH_2AH + (KH_PH*PH_AH) + (KH_PN*PN_AH);                  
KH_BH = KH_2BH + (KH_PH*PH_BH) + (KH_PN*PN_BH);                  
KH_AN = KH_2AN + (KH_PH*PH_AN) + (KH_PN*PN_AN);                  
KH_BN = KH_2BN + (KH_PH*PH_BN) + (KH_PN*PN_BN);    
KH_tauL  = KH_2tauL + (KH_PH*PH_tauL) + (KH_PN*PN_tauL);  
KH_tauC  = (KH_PH*PH_tauC) + (KH_PN*PN_tauC);  
                                                                 
KN_K = KN_2K + (KN_PH*PH_K) + (KN_PN*PN_K);                      
KN_Q = (KN_PH*PH_Q) + (KN_PN*PN_Q);                              
KN_G = (KN_PH*PH_G) + (KN_PN*PN_G);                              
KN_AH = KN_2AH + (KN_PH*PH_AH) + (KN_PN*PN_AH);                  
KN_BH = KN_2BH + (KN_PH*PH_BH) + (KN_PN*PN_BH);                  
KN_AN = KN_2AN + (KN_PH*PH_AN) + (KN_PN*PN_AN);                  
KN_BN = KN_2BN + (KN_PH*PH_BN) + (KN_PN*PN_BN); 
KN_tauL = KN_2tauL + (KN_PH*PH_tauL) + (KN_PN*PN_tauL);  
KN_tauC = (KN_PH*PH_tauC) + (KN_PN*PN_tauC);  

uKH_K  = uKH_1K + (uKH_PH*PH_K) + (uKH_PN*PN_K);                     
uKH_Q  = (uKH_PH*PH_Q) + (uKH_PN*PN_Q);                              
uKH_G  = (uKH_PH*PH_G) + (uKH_PN*PN_G);                              
uKH_AH = uKH_1AH + (uKH_PH*PH_AH) + (uKH_PN*PN_AH);                  
uKH_BH = uKH_1BH + (uKH_PH*PH_BH) + (uKH_PN*PN_BH);                  
uKH_AN = uKH_1AN + (uKH_PH*PH_AN) + (uKH_PN*PN_AN);                  
uKH_BN = uKH_1BN + (uKH_PH*PH_BN) + (uKH_PN*PN_BN);  
uKH_tauL  = uKH_1tauL + (uKH_PH*PH_tauL) + (uKH_PN*PN_tauL); 
uKH_tauC  = (uKH_PH*PH_tauC) + (uKH_PN*PN_tauC);
                                                                     
uKN_K = uKN_1K + (uKN_PH*PH_K) + (uKN_PN*PN_K);                      
uKN_Q = (uKN_PH*PH_Q) + (uKN_PN*PN_Q);                               
uKN_G = (uKN_PH*PH_G) + (uKN_PN*PN_G);                               
uKN_AH = uKN_1AH + (uKN_PH*PH_AH) + (uKN_PN*PN_AH);                  
uKN_BH = uKN_1BH + (uKN_PH*PH_BH) + (uKN_PN*PN_BH);                  
uKN_AN = uKN_1AN + (uKN_PH*PH_AN) + (uKN_PN*PN_AN);                  
uKN_BN = uKN_1BN + (uKN_PH*PH_BN) + (uKN_PN*PN_BN);       
uKN_tauL = uKN_1tauL + (uKN_PH*PH_tauL) + (uKN_PN*PN_tauL); 
uKN_tauC = (uKN_PH*PH_tauC) + (uKN_PN*PN_tauC);

uZH_K  = uZH_1K + (uZH_PH*PH_K) + (uZH_PN*PN_K);                         
uZH_Q  = (uZH_PH*PH_Q) + (uZH_PN*PN_Q);                                  
uZH_G  = (uZH_PH*PH_G) + (uZH_PN*PN_G);                                  
uZH_AH = uZH_1AH + (uZH_PH*PH_AH) + (uZH_PN*PN_AH);                      
uZH_BH = uZH_1BH + (uZH_PH*PH_BH) + (uZH_PN*PN_BH);                      
uZH_AN = uZH_1AN + (uZH_PH*PH_AN) + (uZH_PN*PN_AN);                      
uZH_BN = uZH_1BN + (uZH_PH*PH_BN) + (uZH_PN*PN_BN);   
uZH_tauL  = uZH_1tauL + (uZH_PH*PH_tauL) + (uZH_PN*PN_tauL);  
uZH_tauC  = (uZH_PH*PH_tauC) + (uZH_PN*PN_tauC); 
                                                                         
uZN_K = uZN_1K + (uZN_PH*PH_K) + (uZN_PN*PN_K);                          
uZN_Q = (uZN_PH*PH_Q) + (uZN_PN*PN_Q);                                   
uZN_G = (uZN_PH*PH_G) + (uZN_PN*PN_G);                                   
uZN_AH = uZN_1AH + (uZN_PH*PH_AH) + (uZN_PN*PN_AH);                      
uZN_BH = uZN_1BH + (uZN_PH*PH_BH) + (uZN_PN*PN_BH);                      
uZN_AN = uZN_1AN + (uZN_PH*PH_AN) + (uZN_PN*PN_AN);                      
uZN_BN = uZN_1BN + (uZN_PH*PH_BN) + (uZN_PN*PN_BN);  
uZN_tauL = uZN_1tauL + (uZN_PH*PH_tauL) + (uZN_PN*PN_tauL);
uZN_tauC = (uZN_PH*PH_tauC) + (uZN_PN*PN_tauC);

% Solving for consumption Cj=Cj(lambda,K,Q,GH,GN), investment inputs 
% Jj=Jj(K,Q,GH,GN), imports MF=MF(lambda,K,Q,GH,GN), exports 
%XH=XH(lambda,K,Q,GH,GN)- Final Solutions
CH_K      = (CH_PH*PH_K) + (CH_PN*PN_K);
CH_Q      = (CH_PH*PH_Q) + (CH_PN*PN_Q);
CH_G      = (CH_PH*PH_G) + (CH_PN*PN_G);
CH_AH     = (CH_PH*PH_AH) + (CH_PN*PN_AH);
CH_BH     = (CH_PH*PH_BH) + (CH_PN*PN_BH);
CH_AN     = (CH_PH*PH_AN) + (CH_PN*PN_AN);
CH_BN     = (CH_PH*PH_BN) + (CH_PN*PN_BN);
CH_tauL   = (CH_PH*PH_tauL) + (CH_PN*PN_tauL);
CH_tauC   = CH_1tauC + (CH_PH*PH_tauC) + (CH_PN*PN_tauC);

CN_K      = (CN_PH*PH_K) + (CN_PN*PN_K);
CN_Q      = (CN_PH*PH_Q) + (CN_PN*PN_Q);
CN_G      = (CN_PH*PH_G) + (CN_PN*PN_G);
CN_AH     = (CN_PH*PH_AH) + (CN_PN*PN_AH);
CN_BH     = (CN_PH*PH_BH) + (CN_PN*PN_BH);
CN_AN     = (CN_PH*PH_AN) + (CN_PN*PN_AN);   
CN_BN     = (CN_PH*PH_BN) + (CN_PN*PN_BN);
CN_tauL   = (CN_PH*PH_tauL) + (CN_PN*PN_tauL);
CN_tauC   = CN_1tauC + (CN_PH*PH_tauC) + (CN_PN*PN_tauC);

CF_K      = (CF_PH*PH_K) + (CF_PN*PN_K);
CF_Q      = (CF_PH*PH_Q) + (CF_PN*PN_Q);
CF_G      = (CF_PH*PH_G) + (CF_PN*PN_G);
CF_AH     = (CF_PH*PH_AH) + (CF_PN*PN_AH);
CF_BH     = (CF_PH*PH_BH) + (CF_PN*PN_BH);
CF_AN     = (CF_PH*PH_AN) + (CF_PN*PN_AN); 
CF_BN     = (CF_PH*PH_BN) + (CF_PN*PN_BN);
CF_tauL   = (CF_PH*PH_tauL) + (CF_PN*PN_tauL);
CF_tauC   = CF_1tauC + (CF_PH*PH_tauC) + (CF_PN*PN_tauC);

JH_K       = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K);
JH_Q       = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q);
JH_G       = (JH_PH*PH_G) + (JH_PN*PN_G);
JH_AH      = (JH_PH*PH_AH) + (JH_PN*PN_AH);
JH_BH      = (JH_PH*PH_BH) + (JH_PN*PN_BH);
JH_AN      = (JH_PH*PH_AN) + (JH_PN*PN_AN);
JH_BN      = (JH_PH*PH_BN) + (JH_PN*PN_BN);
JH_tauL    = (JH_PH*PH_tauL) + (JH_PN*PN_tauL);
JH_tauC    = (JH_PH*PH_tauC) + (JH_PN*PN_tauC);

JN_K       = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K);
JN_Q       = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q);
JN_G       = (JN_PH*PH_G) + (JN_PN*PN_G);
JN_AH      = (JN_PH*PH_AH) + (JN_PN*PN_AH); 
JN_BH      = (JN_PH*PH_BH) + (JN_PN*PN_BH);
JN_AN      = (JN_PH*PH_AN) + (JN_PN*PN_AN);   
JN_BN      = (JN_PH*PH_BN) + (JN_PN*PN_BN);
JN_tauL    = (JN_PH*PH_tauL) + (JN_PN*PN_tauL);
JN_tauC    = (JN_PH*PH_tauC) + (JN_PN*PN_tauC);

JF_K       = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K);
JF_Q       = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q);
JF_G       = (JF_PH*PH_G) + (JF_PN*PN_G);
JF_AH      = (JF_PH*PH_AH) + (JF_PN*PN_AH);   
JF_BH      = (JF_PH*PH_BH) + (JF_PN*PN_BH);
JF_AN      = (JF_PH*PH_AN) + (JF_PN*PN_AN);   
JF_BN      = (JF_PH*PH_BN) + (JF_PN*PN_BN); 
JF_tauL    = (JF_PH*PH_tauL) + (JF_PN*PN_tauL);
JF_tauC    = (JF_PH*PH_tauC) + (JF_PN*PN_tauC);

XH_K      = XH_PH*PH_K;
XH_Q      = XH_PH*PH_Q;
XH_G      = XH_PH*PH_G;
XH_AH     = XH_PH*PH_AH;
XH_BH     = XH_PH*PH_BH;
XH_AN     = XH_PH*PH_AN;
XH_BN     = XH_PH*PH_BN;
XH_tauL   = XH_PH*PH_tauL;
XH_tauC   = XH_PH*PH_tauC;

MF_K      = (CF_K + JF_K);
MF_Q      = (CF_Q + JF_Q);
MF_G      = (CF_G + JF_G);
MF_AH     = (CF_AH + JF_AH);
MF_BH     = (CF_BH + JF_BH);
MF_AN     = (CF_AN + JF_AN); 
MF_BN     = (CF_BN + JF_BN);
MF_tauL   = (CF_tauL + JF_tauL);
MF_tauC   = (CF_tauC + JF_tauC);

% Marginal revenue of capital R = PH*partial YH/partial KH.
% R=R(K,Q,G,Aj,Bj,lambda)
RK   = PI*(r+deltaK); 
R_K  = (RK/PH)*PH_K - (RK/kH)*(sLH/sigmaH)*kH_K - RK*(sLH/sigmaH)*uKH_K; 
R_Q  = (RK/PH)*PH_Q - (RK/kH)*(sLH/sigmaH)*kH_Q - RK*(sLH/sigmaH)*uKH_Q;
R_G  = (RK/PH)*PH_G - (RK/kH)*(sLH/sigmaH)*kH_G - RK*(sLH/sigmaH)*uKH_G;
R_AH = (RK/PH)*PH_AH - (RK/kH)*(sLH/sigmaH)*kH_AH - RK*(sLH/sigmaH)*uKH_AH + (RK/AH)*(sLH/sigmaH);
R_BH = (RK/PH)*PH_BH - (RK/kH)*(sLH/sigmaH)*kH_BH - RK*(sLH/sigmaH)*uKH_BH + (RK/BH)*((sigmaH-sLH)/sigmaH);
R_AN = (RK/PH)*PH_AN - (RK/kH)*(sLH/sigmaH)*kH_AN - RK*(sLH/sigmaH)*uKH_AN; 
R_BN = (RK/PH)*PH_BN - (RK/kH)*(sLH/sigmaH)*kH_BN - RK*(sLH/sigmaH)*uKH_BN;
R_tauL = (RK/PH)*PH_tauL - (RK/kH)*(sLH/sigmaH)*kH_tauL - RK*(sLH/sigmaH)*uKH_tauL;
R_tauC = (RK/PH)*PH_tauC - (RK/kH)*(sLH/sigmaH)*kH_tauC - RK*(sLH/sigmaH)*uKH_tauC;
                       
% Solving for investment function I/K = v(Q/PI)+delta_K -     
% v=v(lambda,K,Q,G) final solution                  
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q);                      
v_K  = (v_PN*PN_K) + (v_PH*PH_K);                             
v_G  = (v_PN*PN_G) + (v_PH*PH_G);   
v_AH = (v_PN*PN_AH) + (v_PH*PH_AH); 
v_BH = (v_PN*PN_BH) + (v_PH*PH_BH); 
v_AN = (v_PN*PN_AN) + (v_PH*PH_AN);
v_BN = (v_PN*PN_BN) + (v_PH*PH_BN);
v_tauL = (v_PN*PN_tauL) + (v_PH*PH_tauL);
v_tauC = (v_PN*PN_tauC) + (v_PH*PH_tauC);

% Eigenvalues and Eigenvectors 
% Elements of the Jacobian Matrix 
Upsilon_K = (I/IN)*(YN_K+(YN*tauL*sLN*uZN_K)-CN_K-(KN*xi1N*uKN_K)) - deltaK + alphaI*phiI*I*( (PN_K/PN) - (alphaIH/PH)*PH_K );                                                                        
Upsilon_Q = (I/IN)*(YN_Q+(YN*tauL*sLN*uZN_Q)-CN_Q-(KN*xi1N*uKN_Q)) + alphaI*phiI*I*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );
Sigma_K   = -(R_K-(RK/K)+(RK/K)*((KH*uKH_K)+(KN*uKN_K)+(KH*uZH_K)+(KN*uZN_K)+(KH_K+KN_K))-(PH*KH/K)*xi1H*uKH_K-(PN*KN/K)*xi1N*uKN_K + (PI*kappa*v_K*deltaK) ); 
Sigma_Q   = (r+deltaK)-( R_Q+(RK/K)*((KH*uKH_Q)+(KN*uKN_Q)+(KH*uZH_Q)+(KN*uZN_Q)+(KH_Q+KN_Q))-(PH*KH/K)*xi1H*uKH_Q-(PN*KN/K)*xi1N*uKN_Q + (PI*kappa*v_Q*deltaK) ); 

x11   = Upsilon_K;                                                                         
x12   = Upsilon_Q;     
x21   = Sigma_K;                        
x22   = Sigma_Q;
J = [x11 x12; x21 x22];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[mu order] = sort(diag(mu),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1); 
nu_2 = nu_sorted(2,2); 
omega_11 = V_sorted(1,1)/V_sorted(1,1); 
omega_21 = V_sorted(2,1)/V_sorted(1,1); 
omega_12 = V_sorted(1,2)/V_sorted(1,2); 
omega_22 = V_sorted(2,2)/V_sorted(1,2); 

% Elements of general solutions for capital K(t) and the relative price P(t)
% K(t) -K = X1(t)+X2(t); P(t)-P = omega21*X1(t)+omega22*X2(t)
% X1(t) = (K0-K)*exp(nu1*t)+Gamma2*exp(nu1*t) - Gamma1*(exp(nu1*t)-exp(-xi*t)); 
% X2(t) = -Gamma2*exp(-xi*t); 
Upsilon_G  = (I/IN)*(YN_G+(YN*tauL*sLN*uZN_G)-CN_G-GN_G-(KN*xi1N*uKN_G)) + (alphaI*phiI*I)*( (PN_G/PN) - (alphaIH/PH)*PH_G );
Upsilon_AH = (I/IN)*(YN_AH+(YN*tauL*sLN*uZN_AH)-CN_AH-(KN*xi1N*uKN_AH)) + (alphaI*phiI*I)*( (PN_AH/PN) - (alphaIH/PH)*PH_AH );
Upsilon_BH = (I/IN)*(YN_BH+(YN*tauL*sLN*uZN_BH)-CN_BH-(KN*xi1N*uKN_BH)) + (alphaI*phiI*I)*( (PN_BH/PN) - (alphaIH/PH)*PH_BH );
Upsilon_AN = (I/IN)*(YN_AN+(YN*tauL*sLN*uZN_AN)-CN_AN-(KN*xi1N*uKN_AN)) + (alphaI*phiI*I)*( (PN_AN/PN) - (alphaIH/PH)*PH_AN );
Upsilon_BN = (I/IN)*(YN_BN+(YN*tauL*sLN*uZN_BN)-CN_BN-(KN*xi1N*uKN_BN)) + (alphaI*phiI*I)*( (PN_BN/PN) - (alphaIH/PH)*PH_BN );
Sigma_G    = -( R_G+(RK/K)*((KH*uKH_G)+(KN*uKN_G)+(KH*uZH_G)+(KN*uZN_G)+(KH_G+KN_G))-(PH*KH/K)*xi1H*uKH_G-(PN*KN/K)*xi1N*uKN_G + (PI*kappa*v_G*deltaK) ); 
Sigma_AH    = -( R_AH+(RK/K)*((KH*uKH_AH)+(KN*uKN_AH)+(KH*uZH_AH)+(KN*uZN_AH)+(KH_AH+KN_AH))-(PH*KH/K)*xi1H*uKH_AH-(PN*KN/K)*xi1N*uKN_AH + (PI*kappa*v_AH*deltaK) );
Sigma_BH    = -( R_BH+(RK/K)*((KH*uKH_BH)+(KN*uKN_BH)+(KH*uZH_BH)+(KN*uZN_BH)+(KH_BH+KN_BH))-(PH*KH/K)*xi1H*uKH_BH-(PN*KN/K)*xi1N*uKN_BH + (PI*kappa*v_BH*deltaK) );
Sigma_AN    = -( R_AN+(RK/K)*((KH*uKH_AN)+(KN*uKN_AN)+(KH*uZH_AN)+(KN*uZN_AN)+(KH_AN+KN_AN))-(PH*KH/K)*xi1H*uKH_AN-(PN*KN/K)*xi1N*uKN_AN + (PI*kappa*v_AN*deltaK) );
Sigma_BN    = -( R_BN+(RK/K)*((KH*uKH_BN)+(KN*uKN_BN)+(KH*uZH_BN)+(KN*uZN_BN)+(KH_BN+KN_BN))-(PH*KH/K)*xi1H*uKH_BN-(PN*KN/K)*xi1N*uKN_BN + (PI*kappa*v_BN*deltaK) );

Upsilon_tauL  = (I/IN)*(YN_tauL+(YN*tauL*sLN*uZN_tauL)-CN_tauL-(KN*xi1N*uKN_tauL)) + (alphaI*phiI*I)*( (PN_tauL/PN) - (alphaIH/PH)*PH_tauL );                                                            
Upsilon_tauC  = (I/IN)*(YN_tauC+(YN*tauL*sLN*uZN_tauC)-CN_tauC-(KN*xi1N*uKN_tauC)) + (alphaI*phiI*I)*( (PN_tauC/PN) - (alphaIH/PH)*PH_tauC );                                                                                                                                                                                                                                                     
Sigma_tauL    = -( R_tauL+(RK/K)*((KH*uKH_tauL)+(KN*uKN_tauL)+(KH*uZH_tauL)+(KN*uZN_tauL)+(KH_tauL+KN_tauL))-(PH*KH/K)*xi1H*uKH_tauL-(PN*KN/K)*xi1N*uKN_tauL + (PI*kappa*v_tauL*deltaK) );
Sigma_tauC    = -( R_tauC+(RK/K)*((KH*uKH_tauC)+(KN*uKN_tauC)+(KH*uZH_tauC)+(KN*uZN_tauC)+(KH_tauC+KN_tauC))-(PH*KH/K)*xi1H*uKH_tauC-(PN*KN/K)*xi1N*uKN_tauC + (PI*kappa*v_tauC*deltaK) );

PhiG_1     = (x11-nu_2)*Upsilon_G + (x12*Sigma_G); 
PhiG_2     = (x11-nu_1)*Upsilon_G + (x12*Sigma_G);
ThetaG_1   = (1-barg)*((nu_1+xi)/(nu_1+chi)); 
ThetaG_2   = (1-barg)*((nu_2+xi)/(nu_2+chi));
GammaG_1   = -((PhiG_1*Y_0)/(nu_1-nu_2))*(1/(nu_1+xi));
GammaG_2   = -((PhiG_2*Y_0)/(nu_1-nu_2))*(1/(nu_2+xi));  

PhiAH_1     = (x11-nu_2)*Upsilon_AH + (x12*Sigma_AH); 
PhiAH_2     = (x11-nu_1)*Upsilon_AH + (x12*Sigma_AH);
ThetaAH_1   = (1-baraH)*((nu_1+xiAH)/(nu_1+chiAH)); 
ThetaAH_2   = (1-baraH)*((nu_2+xiAH)/(nu_2+chiAH));
GammaAH_1   = -((PhiAH_1*AH_0)/(nu_1-nu_2))*(1/(nu_1+xiAH));
GammaAH_2   = -((PhiAH_2*AH_0)/(nu_1-nu_2))*(1/(nu_2+xiAH)); 

PhiBH_1     = (x11-nu_2)*Upsilon_BH + (x12*Sigma_BH);        
PhiBH_2     = (x11-nu_1)*Upsilon_BH + (x12*Sigma_BH);       
ThetaBH_1   = (1-barbH)*((nu_1+xiBH)/(nu_1+chiBH));           
ThetaBH_2   = (1-barbH)*((nu_2+xiBH)/(nu_2+chiBH));           
GammaBH_1   = -((PhiBH_1*BH_0)/(nu_1-nu_2))*(1/(nu_1+xiBH));
GammaBH_2   = -((PhiBH_2*BH_0)/(nu_1-nu_2))*(1/(nu_2+xiBH)); 

PhiAN_1     = (x11-nu_2)*Upsilon_AN + (x12*Sigma_AN);       
PhiAN_2     = (x11-nu_1)*Upsilon_AN + (x12*Sigma_AN);      
ThetaAN_1   = (1-baraN)*((nu_1+xiAN)/(nu_1+chiAN));          
ThetaAN_2   = (1-baraN)*((nu_2+xiAN)/(nu_2+chiAN));          
GammaAN_1   = -((PhiAN_1*AN_0)/(nu_1-nu_2))*(1/(nu_1+xiAN));
GammaAN_2   = -((PhiAN_2*AN_0)/(nu_1-nu_2))*(1/(nu_2+xiAN));

PhiBN_1     = (x11-nu_2)*Upsilon_BN + (x12*Sigma_BN);         
PhiBN_2     = (x11-nu_1)*Upsilon_BN + (x12*Sigma_BN);        
ThetaBN_1   = (1-barbN)*((nu_1+xiBN)/(nu_1+chiBN));            
ThetaBN_2   = (1-barbN)*((nu_2+xiBN)/(nu_2+chiBN));            
GammaBN_1   = -((PhiBN_1*BN_0)/(nu_1-nu_2))*(1/(nu_1+xiBN));  
GammaBN_2   = -((PhiBN_2*BN_0)/(nu_1-nu_2))*(1/(nu_2+xiBN)); 

PhiTL_1     = (x11-nu_2)*Upsilon_tauL + (x12*Sigma_tauL); 
PhiTL_2     = (x11-nu_1)*Upsilon_tauL + (x12*Sigma_tauL);
ThetaTL_1   = (1-tL)*((nu_1+xiL)/(nu_1+chiL)); 
ThetaTL_2   = (1-tL)*((nu_2+xiL)/(nu_2+chiL));
GammaTL_1   = -(PhiTL_1/(nu_1-nu_2))*(1/(nu_1+xiL));
GammaTL_2   = -(PhiTL_2/(nu_1-nu_2))*(1/(nu_2+xiL));  

ThetaD      = (1-phiG)*( (1/(xi+r-phiD)) - ((1-barg)/(chi+r-phiD)) ); 
ThetaD_1    = (1-phiG)/(xi+r-phiD); 
ThetaD_2    = (1-phiG)/(chi+r-phiD); 
OmegaD      = phiD*( ThetaD ); 
OmegaD_1    = ((ThetaD_1*phiD)-phiG); 
OmegaD_2    = ((ThetaD_2*phiD)-phiG); 

PhiTC_1    = (x11-nu_2)*Upsilon_tauC + (x12*Sigma_tauC); 
PhiTC_2    = (x11-nu_1)*Upsilon_tauC + (x12*Sigma_tauC);
GammaTCD_1 = -(PhiTC_1/(nu_1-nu_2))*(1/(nu_1+deltaD))*(OmegaD/omegaC_0);
GammaTCD_2 = -(PhiTC_2/(nu_1-nu_2))*(1/(nu_2+deltaD))*(OmegaD/omegaC_0); 
GammaTCG_1 = -(PhiTC_1/(nu_1-nu_2))*(1/(nu_1+xi))*(1/omegaC_0);
GammaTCG_2 = -(PhiTC_2/(nu_1-nu_2))*(1/(nu_2+xi))*(1/omegaC_0); 
GammaTCL_1 = -(PhiTC_1/(nu_1-nu_2))*(1/(nu_1+xiL))*(omegaL_0/omegaC_0);
GammaTCL_2 = -(PhiTC_2/(nu_1-nu_2))*(1/(nu_2+xiL))*(omegaL_0/omegaC_0); 

X20       = -GammaG_2*(1-ThetaG_2) - GammaAH_2*(1-ThetaAH_2) - GammaBH_2*(1-ThetaBH_2) - GammaAN_2*(1-ThetaAN_2) - GammaBN_2*(1-ThetaBN_2) - (GammaTL_2-GammaTCL_2)*(1-ThetaTL_2) - GammaTCD_2 + GammaTCG_2*(OmegaD_1 - (OmegaD_2*ThetaG_2));
X10       = (K0-K) - X20;
X11       = X10 - GammaG_1*(1-ThetaG_1) - GammaAH_1*(1-ThetaAH_1) - GammaBH_1*(1-ThetaBH_1) - GammaAN_1*(1-ThetaAN_1) - GammaBN_1*(1-ThetaBN_1) - (GammaTL_1-GammaTCL_1)*(1-ThetaTL_1) - GammaTCD_1 + GammaTCG_1*(OmegaD_1 - (OmegaD_2*ThetaG_1));

% Intertemporal solvency condition - lambda                                                                                                                                
N_K          = (PH_K*XH) + (PH*XH_K) - MF_K;                                                                                                                              
N_Q          = (PH_Q*XH) + (PH*XH_Q) - MF_Q;                                                                                                                              
N_G          = (PH_G*XH) + (PH*XH_G) - MF_G;                                                                                                                              
N_AH         = (PH_AH*XH) + (PH*XH_AH) - MF_AH;                                                                                                                           
N_BH         = (PH_BH*XH) + (PH*XH_BH) - MF_BH;                                                                                                                           
N_AN         = (PH_AN*XH) + (PH*XH_AN) - MF_AN;                                                                                                                           
N_BN         = (PH_BN*XH) + (PH*XH_BN) - MF_BN;                                                                                                                           
N_tauL       = (PH_tauL*XH) + (PH*XH_tauL) - MF_tauL;                                                                                                                     
N_tauC       = (PH_tauC*XH) + (PH*XH_tauC) - MF_tauC;                                                                                                                     
N1           = (N_K + (N_Q*omega_21));                                                                                                                                    
N2           = (N_K + (N_Q*omega_22));                                                                                                                                    
ThetaG_prime  = (1-barg)*((xi+r)/(chi+r));                                                                                                                                
ThetaG_1prime = ThetaG_1*((xi+r)/(chi+r));                                                                                                                                
ThetaG_2prime = ThetaG_2*((xi+r)/(chi+r));                                                                                                                                
ThetaAH_prime  = (1-baraH)*((xiAH+r)/(chiAH+r));                                                                                                                          
ThetaAH_1prime = ThetaAH_1*((xiAH+r)/(chiAH+r));                                                                                                                          
ThetaAH_2prime = ThetaAH_2*((xiAH+r)/(chiAH+r));                                                                                                                          
ThetaBH_prime  = (1-barbH)*((xiBH+r)/(chiBH+r));                                                                                                                          
ThetaBH_1prime = ThetaBH_1*((xiBH+r)/(chiBH+r));                                                                                                                          
ThetaBH_2prime = ThetaBH_2*((xiBH+r)/(chiBH+r));                                                                                                                          
ThetaAN_prime  = (1-baraN)*((xiAN+r)/(chiAN+r));                                                                                                                          
ThetaAN_1prime = ThetaAN_1*((xiAN+r)/(chiAN+r));                                                                                                                          
ThetaAN_2prime = ThetaAN_2*((xiAN+r)/(chiAN+r));                                                                                                                          
ThetaBN_prime  = (1-barbN)*((xiBN+r)/(chiBN+r));                                                                                                                          
ThetaBN_1prime = ThetaBN_1*((xiBN+r)/(chiBN+r));                                                                                                                          
ThetaBN_2prime = ThetaBN_2*((xiBN+r)/(chiBN+r));                                                                                                                          
                                                                                                                                                                          
ThetaTL_prime  = (1-tL)*((xiL+r)/(chiL+r));                                                                                                                               
ThetaTL_1prime = ThetaTL_1*((xiL+r)/(chiL+r));                                                                                                                            
ThetaTL_2prime = ThetaTL_2*((xiL+r)/(chiL+r));                                                                                                                            
                                                                                                                                                                          
wN1           = N1*X11;                                                                                                                                                   
wNG2          = N_G*Y_0*(1-ThetaG_prime) + N1*GammaG_1*(1-ThetaG_1prime) - N2*GammaG_2*(1-ThetaG_2prime);                                                                 
wNAH2         = N_AH*AH_0*(1-ThetaAH_prime) + N1*GammaAH_1*(1-ThetaAH_1prime) - N2*GammaAH_2*(1-ThetaAH_2prime);                                                          
wNBH2         = N_BH*BH_0*(1-ThetaBH_prime) + N1*GammaBH_1*(1-ThetaBH_1prime) - N2*GammaBH_2*(1-ThetaBH_2prime);                                                          
wNAN2         = N_AN*AN_0*(1-ThetaAN_prime) + N1*GammaAN_1*(1-ThetaAN_1prime) - N2*GammaAN_2*(1-ThetaAN_2prime);                                                          
wNBN2         = N_BN*BN_0*(1-ThetaBN_prime) + N1*GammaBN_1*(1-ThetaBN_1prime) - N2*GammaBN_2*(1-ThetaBN_2prime);                                                          
wNTL2         = (N_tauL - N_tauC*(omegaL_0/omegaC_0))*(1-ThetaTL_prime) + N1*(GammaTL_1-GammaTCL_1)*(1-ThetaTL_1prime) - N2*(GammaTL_2-GammaTCL_2)*(1-ThetaTL_2prime);            
wNTCG2        = -(N_tauC/omegaC_0)*(OmegaD_1 - (OmegaD_2*ThetaG_prime)) - N1*GammaTCG_1*(OmegaD_1 - (OmegaD_2*ThetaG_1prime)) + N2*GammaTCG_2*(OmegaD_1 - (OmegaD_2*ThetaG_2prime));                  
wNTCD2        = (N_tauC*OmegaD/omegaC_0) + (N1*GammaTCD_1) - (N2*GammaTCD_2);                                                                                                      
                                                                                                                                                                          
g(32)    = (N-N0)-( (wN1/(r-nu_1))+(wNG2/(xi+r))+(wNAH2/(xiAH+r))+(wNBH2/(xiBH+r))+(wNAN2/(xiAN+r))+(wNBN2/(xiBN+r))+(wNTL2/(xiL+r))+(wNTCG2/(xi+r))+(wNTCD2/(deltaD+r)) );
