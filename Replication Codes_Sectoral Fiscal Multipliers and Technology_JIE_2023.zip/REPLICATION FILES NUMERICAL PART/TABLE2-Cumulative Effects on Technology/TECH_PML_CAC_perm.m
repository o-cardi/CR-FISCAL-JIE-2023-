function g = TECH_PML_CAC_perm(x)

global sigma phi varphi 
global gammaL sigmaL phiI varphiI
global r deltaK 
global ZT ZN thetaT thetaN kappa 
global B0 K0 GT GN omegaGN 
global Y_0 barg xi chi
global xi1T xi2T xi1N xi2N chi1T chi2T chi1N chi2N 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kT      = x(3)  ; % Capital-labor ratio in sector T
kN      = x(4)  ; % Capital-labor ratio in sector N
W       = x(5)  ; % Aggregate wage index
LT      = x(6) ; % Labor in sector T
LN      = x(7) ; % Labor in sector N 
P       = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
B       = x(10) ; % Stock of Traded Bonds
CN      = x(11) ; % Consumption in non tradables 
CT      = x(12) ; % Consumption in tradables 
PC      = x(13) ; % Consumption price index
IN      = x(14) ; % Non tradable investment
IT      = x(15) ; % Tradable investment 
PI      = x(16) ; % Investment price index
YT      = x(17) ; % Labor in sector T
YN      = x(18) ; % Labor in sector N  
VL      = x(19) ; % Labor disutility
lambda  = x(20) ; % Marginal utility of wealth lambda
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Aggregate Consumption -  C
g(1)= C^(-1) - (PC*lambda);

% Aggregate labor supply - L
g(2)= gammaL*(L^(1/sigmaL)) - (lambda*W);

% equality of marginal product of capital across the two sectors  - kT and
% kN
g(3)= ZT*(1-thetaT)*(kT^(-thetaT)) -  P*ZN*(1-thetaN)*(kN^(-thetaN));

% Wage rate in sector T  - kT and kN
g(4)= ZT*thetaT*(kT^(1-thetaT)) - P*ZN*thetaN*(kN^(1-thetaN));

% Aggregate wage index  - W
g(5)= W - ZT*thetaT*(kT^(1-thetaT));

% sectoral labor allocation  - LT and LN 
g(6)= (LT+LN) - L;

% sectoral capital allocation  -  LT and LN - 
g(7)= (LT*kT) + (LN*kN) - K;

% equality of marginal product of capital in the non traded sector to the world interest rate  
g(8)= P*ZN*(1-thetaN)*(kN^(-thetaN)) - (deltaK + r)*PI;

% Non traded market good market clearing condition - K 
g(9)= YN - CN - GN - IN;

% Traded good market clearing condition - B
g(10)= (r*B) + YT - CT - GT - IT;

% Consumption in non tradables - CN
g(11)= CN - C*(1-varphi)*(P/PC)^(-phi);

% Consumption in tradables - CT 
g(12)= CT - C*varphi*(1/PC)^(-phi);

% Consumption price index - PC
g(13)= PC - ((varphi+(1-varphi)*P^(1-phi))^(1/(1-phi)));

% Non tradable Investment - IN
g(14)= IN - (deltaK*K)*(1-varphiI)*((P/PI)^(-phiI));

% Tradable Investment - IT 
g(15)= IT - (deltaK*K)*varphiI*((1/PI)^(-phiI));

% Investment price index - PI
g(16)= PI - (varphiI+(1-varphiI)*P^(1-phiI))^(1/(1-phiI));

% Output per worker in the traded sector - YT
g(17)= YT - ZT*LT*(kT^(1-thetaT)); 

% Output per worker in the non traded sector - YN
g(18)= YN - ZN*LN*(kN^(1-thetaN));

% Desutility from labor
g(19)= VL - ( 1 + (sigma-1)*gammaL*(sigmaL/(1+sigmaL))*L^((1+sigmaL)/sigmaL) ); % Desutility labor

% Non tradable shares of consumption, investment, labor compensation
alphaC = (varphi*(1/PC)^(1-phi));
alphaI = (varphiI*(1/PI)^(1-phiI));
alphaL = LT/L; 
RK = ZT*(1-thetaT)*(kT^(-thetaT));
KT = kT*LT; 
KN = kN*LN; 
 
% Sep preferences
C_1P = -(1-alphaC)*(C/P);  
C_W      = 0; 
C_1uZT   = 0; 
C_1uZN   = 0; 
L_W      = sigmaL*(L/W); 
L_1P     = 0; 
L_1uZT   = sigmaL*L*alphaL; 
L_1uZN   = sigmaL*L*(1-alphaL);

% Intermediate solution for CN, CT - Cj=Cj(lambda,P,W)
CN_1P = -(CN/P)*(alphaC*phi) + (CN/C)*C_1P;
CN_W  = (CN/C)*C_W;
CN_1uZT  = (CN/C)*C_1uZT;
CN_1uZN  = (CN/C)*C_1uZN;

CT_1P = (CT/P)*phi*(1-alphaC) + (CT/C)*C_1P;
CT_W  = (CT/C)*C_W;
CT_1uZT  = (CT/C)*C_1uZT;
CT_1uZN  = (CT/C)*C_1uZN;

% Solutions for kj=kj(P,Zj)
d11 = -(thetaT/kT);
d12 = (thetaN/kN);
d21 = (1-thetaT)/kT;
d22 = -(1-thetaN)/kN;

% P, uKT, uKN
e11 = (1/P);
e12 = thetaT;
e13 = -thetaN;

e21 = (1/P);
e22 = -(1-thetaT);
e23 = (1-thetaN);

M2 = [d11 d12; d21 d22];
X2 = [e11 e12 e13; e21 e22 e23];
JST2 = inv(M2);
MST2 = JST2*X2;
kT_1P = MST2(1,1); kT_uKT = MST2(1,2); kT_uKN = MST2(1,3);
kN_1P = MST2(2,1); kN_uKT = MST2(2,2); kN_uKN = MST2(2,3);

% Solution for W=W(P,uKT,uKN),
W_1P  = (1-thetaT)*(W/kT)*kT_1P;
W_uKT = (1-thetaT)*(W/kT)*kT_uKT + (1-thetaT)*W;
W_uKN = (1-thetaT)*(W/kT)*kT_uKN;

% Solution for ,C(lambda,P,uKT,uKN,uZT,uZN)
L_2P  = L_1P + (L_W*W_1P);
L_uKT = (L_W*W_uKT);
L_uKN = (L_W*W_uKN);
L_uZT = L_1uZT;
L_uZN = L_1uZN;

% Solution for Cj(lambda,P,uKT,uKN,uZT,uZN)
CN_2P  = CN_1P + (CN_W*W_1P);
CN_uKT = (CN_W*W_uKT);
CN_uKN = (CN_W*W_uKN);
CN_uZT = CN_1uZT;
CN_uZN = CN_1uZN;

CT_2P  = CT_1P + (CT_W*W_1P);
CT_uKT = (CT_W*W_uKT);
CT_uKN = (CT_W*W_uKN);
CT_uZT = CT_1uZT;
CT_uZN = CT_1uZN;

% Solutions for Lj=Lj(K,P,uKT,uKN,uZT,uZN,lambda)
Psi_P   = ( (LT*kT_1P) + (LN*kN_1P) );
Psi_uKT = ( (LT*kT_uKT) + (LN*kN_uKT) );
Psi_uKN = ( (LT*kT_uKN) + (LN*kN_uKN) );

f11 = 1;             % LT
f12 = 1;             % LN
f21 = kT;            % LT
f22 = kN;            % LN

% K, P, uKT, uKN, uZT, uZN, lambda
g11 = 0;             % K
g12 = L_2P;          % P
g13 = L_uKT;         % uKT
g14 = L_uKN;         % uKN
g15 = L_uZT;         % uZT
g16 = L_uZN;         % uZN

g21 = 1;             % K
g22 = -Psi_P;        % P
g23 = -Psi_uKT;      % uKT
g24 = -Psi_uKN;      % uKN
g25 = 0;             % uZT
g26 = 0;             % uZN

M3 = [f11 f12; f21 f22];
X3 = [g11 g12 g13 g14 g15 g16; g21 g22 g23 g24 g25 g26];
JST3 = inv(M3);
MST3 = JST3*X3;
LT_1K = MST3(1,1); LT_1P = MST3(1,2); LT_uKT = MST3(1,3); LT_uKN = MST3(1,4); LT_uZT = MST3(1,5); LT_uZN = MST3(1,6);
LN_1K = MST3(2,1); LN_1P = MST3(2,2); LN_uKT = MST3(2,3); LN_uKN = MST3(2,4); LN_uZT = MST3(2,5); LN_uZN = MST3(2,6);

% Solutions for sectoral sectoral output Yj=Yj(K,P,uKT,uKN,uZT,uZN,lambda)
YT_1P  = YT*( (LT_1P/LT) + (1-thetaT)*(kT_1P/kT) );
YT_1K  = YT*(LT_1K/LT);
YT_uKT = YT*( (LT_uKT/LT) + (1-thetaT)*(kT_uKT/kT) + (1-thetaT) );
YT_uKN = YT*( (LT_uKN/LT) + (1-thetaT)*(kT_uKN/kT) );
YT_uZT = YT*(LT_uZT/LT);
YT_uZN = YT*(LT_uZN/LT);

YN_1P  = YN*( (LN_1P/LN) + (1-thetaN)*(kN_1P/kN) );
YN_1K  = YN*(LN_1K/LN);
YN_uKT = YN*( (LN_uKT/LN) + (1-thetaN)*(kN_uKT/kN) );
YN_uKN = YN*( (LN_uKN/LN) + (1-thetaN)*(kN_uKN/kN) + (1-thetaN) );
YN_uZT = YN*(LN_uZT/LN);
YN_uZN = YN*(LN_uZN/LN);

% Solving for capital and technology utilization rates: uKT, uKN, uZT, uZN; uKj,uZj(P,K,lambda)
f11 = ((xi2T/xi1T) + thetaT) + thetaT*(kT_uKT/kT);
f12 = thetaT*(kT_uKN/kT);
f13 = -1;
f14 = 0;
f21 = thetaN*(kN_uKT/kN);
f22 = ((xi2N/xi1N) + thetaN) + thetaN*(kN_uKN/kN);
f23 = 0;
f24 = -1;
f31 = -YT_uKT/YT;
f32 = -YT_uKN/YT;
f33 = (chi2T/chi1T)-(YT_uZT/YT);
f34 = -YT_uZN/YT;
f41 = -YN_uKT/YN;
f42 = -YN_uKN/YN;
f43 = -YN_uZT/YN;
f44 = (chi2N/chi1N)-(YN_uZN/YN);

% P, K, lambda
g11 = -thetaT*(kT_1P/kT);
g12 = 0;

g21 = -thetaN*(kN_1P/kN);
g22 = 0;

g31 = YT_1P/YT;
g32 = YT_1K/YT;

g41 = YN_1P/YN;
g42 = YN_1K/YN;

M4 = [f11 f12 f13 f14; f21 f22 f23 f24; f31 f32 f33 f34; f41 f42 f43 f44];
X4 = [g11 g12; g21 g22; g31 g32; g41 g42];
JST4 = inv(M4);
MST4 = JST4*X4;

uKT_P = MST4(1,1); uKT_1K = MST4(1,2);
uKN_P = MST4(2,1); uKN_1K = MST4(2,2);
uZT_P = MST4(3,1); uZT_1K = MST4(3,2);
uZN_P = MST4(4,1); uZN_1K = MST4(4,2);

% Solving for sectoral labor and sectoral output - kj,Lj,yj,Yj,Kj(lambda,K,P)
kT_1K = (kT_uKT*uKT_1K) + (kT_uKN*uKN_1K);
kT_P  = kT_1P + (kT_uKT*uKT_P) + (kT_uKN*uKN_P);

kN_1K = (kN_uKT*uKT_1K) + (kN_uKN*uKN_1K);
kN_P  = kN_1P + (kN_uKT*uKT_P) + (kN_uKN*uKN_P);

LT_2K = LT_1K + (LT_uKT*uKT_1K) + (LT_uKN*uKN_1K) + (LT_uZT*uZT_1K) + (LT_uZN*uZN_1K);
LT_P  = LT_1P + (LT_uKT*uKT_P) + (LT_uKN*uKN_P) + (LT_uZT*uZT_P) + (LT_uZN*uZN_P);

LN_2K = LN_1K + (LN_uKT*uKT_1K) + (LN_uKN*uKN_1K) + (LN_uZT*uZT_1K) + (LN_uZN*uZN_1K);
LN_P  = LN_1P + (LN_uKT*uKT_P) + (LN_uKN*uKN_P) + (LN_uZT*uZT_P) + (LN_uZN*uZN_P);

YT_2K = YT_1K + (YT_uKT*uKT_1K) + (YT_uKN*uKN_1K) + (YT_uZT*uZT_1K) + (YT_uZN*uZN_1K);
YT_P  = YT_1P + (YT_uKT*uKT_P) + (YT_uKN*uKN_P) + (YT_uZT*uZT_P) + (YT_uZN*uZN_P);

YN_2K = YN_1K + (YN_uKT*uKT_1K) + (YN_uKN*uKN_1K) + (YN_uZT*uZT_1K) + (YN_uZN*uZN_1K);
YN_P  = YN_1P + (YN_uKT*uKT_P) + (YN_uKN*uKN_P) + (YN_uZT*uZT_P) + (YN_uZN*uZN_P);

CT_1K = (CT_uKT*uKT_1K) + (CT_uKN*uKN_1K) + (CT_uZT*uZT_1K) + (CT_uZN*uZN_1K);
CT_P  = CT_2P + (CT_uKT*uKT_P) + (CT_uKN*uKN_P) + (CT_uZT*uZT_P) + (CT_uZN*uZN_P);

CN_1K = (CN_uKT*uKT_1K) + (CN_uKN*uKN_1K) + (CN_uZT*uZT_1K) + (CN_uZN*uZN_1K);
CN_P  = CN_2P + (CN_uKT*uKT_P) + (CN_uKN*uKN_P) + (CN_uZT*uZT_P) + (CN_uZN*uZN_P);

% Sectoral Capital stock Kj(lambda,K,P)              
KT_1K = (LT_2K*kT) + (LT*kT_1K);                     
KT_P  = (LT_P*kT) + (LT*kT_P);                            
                                                     
KN_1K = (LN_2K*kN) + (LN*kN_1K);                     
KN_P  = (LN_P*kN) + (LN*kN_P);               

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI);
v_P  = - (1-alphaI)/(kappa*P);

% Solution for J = J(K,Q,PN,PH)
J_1K = deltaK;
J_1Q = K*v_1Q;
J_P = K*v_P;

% Solution for JN, JT - Jj=Jj(P,K,Q)
I     = deltaK*K;
JN_P  = -(IN/P)*(phiI*alphaI) + (IN/I)*J_P;
JN_1K = (IN/I)*J_1K;
JN_1Q = (IN/I)*J_1Q;

JT_P  =  (IT/P)*phiI*(1-alphaI) + (IT/I)*J_P;
JT_1K = (IT/I)*J_1K;
JT_1Q = (IT/I)*J_1Q;

% R=R(lambda,K,P)
R_1K  = -RK*thetaT*(uKT_1K + (kT_1K/kT));
R_P   = -RK*thetaT*(uKT_P + (kT_P/kT));

% Partial Derivatives Gj=Gj(G)
GN_G   = omegaGN/P;
GT_G   = (1-omegaGN);

% Solving for the relative price P=P(lambda,K,Q,G)
DeltaP   = (YN_P - CN_P - JN_P) - (KN*xi1N*uKN_P);
P_K      = -(1/DeltaP)*(YN_2K - CN_1K - JN_1K - (KN*xi1N*uKN_1K));
P_Q      = (JN_1Q/DeltaP);
P_G      = GN_G/DeltaP;

% Solving for capital-labor ratios kj=kj(K,Q,G,Aj,Bj) -
% sectoral labor Lj=Lj(K,Q,G,Aj,Bj) - sectoral output
% Yj=Yj(K,Q,G,Aj,Bj) - Final Solutions
kT_K = kT_1K + (kT_P*P_K);
kT_Q = (kT_P*P_Q);
kT_G = (kT_P*P_G);

kN_K = kN_1K + (kN_P*P_K);
kN_Q = (kN_P*P_Q) ;
kN_G = (kN_P*P_G);

LT_K  = LT_2K + (LT_P*P_K);
LT_Q  = (LT_P*P_Q);
LT_G  = (LT_P*P_G);

LN_K = LN_2K + (LN_P*P_K);
LN_Q = (LN_P*P_Q);
LN_G = (LN_P*P_G);

YT_K = YT_2K + (YT_P*P_K);
YT_Q = (YT_P*P_Q);
YT_G = (YT_P*P_G);

YN_K = YN_2K + (YN_P*P_K);
YN_Q = (YN_P*P_Q) ;
YN_G = (YN_P*P_G) ;

uKT_K  = uKT_1K + (uKT_P*P_K);
uKT_Q  = (uKT_P*P_Q);
uKT_G  = (uKT_P*P_G);

uKN_K = uKN_1K + (uKN_P*P_K);
uKN_Q = (uKN_P*P_Q);
uKN_G = (uKN_P*P_G);

uZT_K  = uZT_1K + (uZT_P*P_K);
uZT_Q  = (uZT_P*P_Q);
uZT_G  = (uZT_P*P_G);

uZN_K = uZN_1K + (uZN_P*P_K);
uZN_Q = (uZN_P*P_Q);
uZN_G = (uZN_P*P_G);

% Solving for consumption Cj=Cj(lambda,K,Q,G), investment inputs
% Jj=Jj(K,Q,G)
CT_K = CT_1K + (CT_P*P_K);                    
CT_Q = (CT_P*P_Q);                            
CT_G = (CT_P*P_G);                            
                                              
CN_K = CN_1K + (CN_P*P_K);                    
CN_Q =(CN_P*P_Q);                             
CN_G = (CN_P*P_G);                            
                                              
JT_K = JT_1K + (JT_P*P_K);                    
JT_Q = JT_1Q + (JT_P*P_Q);                    
JT_G = (JT_P*P_G);                            
                                              
JN_K = JN_1K + (JN_P*P_K);                    
JN_Q = JN_1Q + (JN_P*P_Q);                    
JN_G = (JN_P*P_G);                            
                                              
v_K  = (v_P*P_K);                             
v_Q  = v_1Q + (v_P*P_Q);                      
v_G  = (v_P*P_G);                             
                                              
R_K  = R_1K + (R_P*P_K);                      
R_Q  = (R_P*P_Q);                            
R_G  = (R_P*P_G); 

KT_K = KT_1K + (KT_P*P_K);
KT_Q = (KT_P*P_Q);
KT_G = (KT_P*P_G);

KN_K = KN_1K + (KN_P*P_K);
KN_Q = (KN_P*P_Q);
KN_G = (KN_P*P_G);

% Elements of the Jacobian Matrix
Upsilon_K = (I/IN)*(YN_K-CN_K-(KN*xi1N*uKN_K)) - deltaK + alphaI*phiI*I*(P_K/P);
Upsilon_Q = (I/IN)*(YN_Q-CN_Q-(KN*xi1N*uKN_Q)) + alphaI*phiI*I*(P_Q/P);
Sigma_K   = -(R_K-(RK/K)+(RK/K)*((KT*uKT_K)+(KN*uKN_K)+(KT*uZT_K)+(KN*uZN_K)+(KT_K+KN_K))-(KT/K)*xi1T*uKT_K-(P*KN/K)*xi1N*uKN_K + (PI*kappa*v_K*deltaK) );
Sigma_Q   = (r+deltaK)-( R_Q+(RK/K)*((KT*uKT_Q)+(KN*uKN_Q))+(RK/K)*((KT*uZT_Q)+(KN*uZN_Q))+(RK/K)*(KT_Q+KN_Q)-(KT/K)*xi1T*uKT_Q-(P*KN/K)*xi1N*uKN_Q + (PI*kappa*v_Q*deltaK) );

x11 = Upsilon_K;
x12 = Upsilon_Q;
x21 = Sigma_K;
x22 = Sigma_Q;

J = [x11 x12; x21 x22];
[V,nu]=eig(J);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1);
nu_2 = nu_sorted(2,2);
omega_11 = V_sorted(1,1)/V_sorted(1,1);
omega_21 = V_sorted(2,1)/V_sorted(1,1);
omega_12 = V_sorted(1,2)/V_sorted(1,2);
omega_22 = V_sorted(2,2)/V_sorted(1,2);

% Elements of general solutions for capital K(t) and the relative price P(t)
% K(t) -K = X1(t)+X2(t); P(t)-P = omega21*X1(t)+omega22*X2(t)
% X1(t) = (K0-K)*exp(nu1*t)+Gamma2*exp(nu1*t) - Gamma1*(exp(nu1*t)-exp(-xi*t));
% X2(t) = -Gamma2*exp(-xi*t);
Upsilon_G  = (I/IN)*(YN_G-CN_G-GN_G-(KN*xi1N*uKN_G)) + (alphaI*phiI*I)*(P_G/P);
Sigma_G    = -( R_G+(RK/K)*((KT*uKT_G)+(KN*uKN_G)+(KT*uZT_G)+(KN*uZN_G)+(KT_G+KN_G))-(KT/K)*xi1T*uKT_G-(P*KN/K)*xi1N*uKN_G + (PI*kappa*v_G*deltaK) );

%%%%%%%%%%%%%%%%%% Solutions for Permanent Shocks %%%%%%%%%%%%%%%%%%%%
Vnorm = [omega_11 omega_12; omega_21 omega_22];
Vinv   = inv(Vnorm);
u11    = Vinv(1,1);
u12    = Vinv(1,2);
u21    = Vinv(2,1);
u22    = Vinv(2,2);

s11   = (u11*Upsilon_G) + (u12*Sigma_G);
s21   = (u21*Upsilon_G) + (u22*Sigma_G);

DeltaG_1   = - s11*Y_0*(1/(nu_1+xi));
DeltaG_2   = s21*Y_0*(1/(nu_2+xi));

ThetaG_1   = (1-barg)*((nu_1+xi)/(nu_1+chi));
ThetaG_2   = (1-barg)*((nu_2+xi)/(nu_2+chi));

X20 = - DeltaG_2*(1-ThetaG_2);
X10 = (K0-K) - X20;
X11 = X10 - DeltaG_1*(1-ThetaG_1);

% Intertemporal solvency condition - lambda
B_K   = (YT_K - CT_K - JT_K) - (KT*xi1T*uKT_K);
B_Q   = (YT_Q - CT_Q - JT_Q) - (KT*xi1T*uKT_Q);
B_G   = (YT_G - CT_G - GT_G - JT_G) - (KT*xi1T*uKT_G);

N1           = (B_K + (B_Q*omega_21));
N2           = (B_K + (B_Q*omega_22));

ThetaG_prime   = (1-barg)*((xi+r)/(chi+r));
ThetaG_1prime  = ThetaG_1*((xi+r)/(chi+r));
ThetaG_2prime  = ThetaG_2*((xi+r)/(chi+r));

wB1   = N1*X11;
wBG2  = B_G*Y_0*(1-ThetaG_prime) + N1*DeltaG_1*(1-ThetaG_1prime) - N2*DeltaG_2*(1-ThetaG_2prime); 
                                                                                                                             
g(20) = (B-B0)-( (wB1/(r-nu_1)) + (wBG2/(xi+r)) );                                                       


