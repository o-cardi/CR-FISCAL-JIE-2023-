%clc
%clear


% Maxim duration for graphics
Tg = 100;
       
% Minim duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;

PML_NOCAC_NOTECH;
PML_CAC_NOTECH;
PML_CAC_nocaput;
PML_CAC;
IML_CAC;
FISC_IML_CAC_TOT_CD;
FISC_IML_CAC_TOT_nocaput_CD;
FISC_IML_CAC_TOT_CES_FBTC_nocaput;
FISC_IML_CAC_TOT_CES_FBTC;
%%%%%%%%%% Table of Results %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Aggregate Effects: cumul t=0..5');
disp(sprintf('dGYcum               |%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|',dGYcum_pmlnocac,dGYcum_pmlnotech,dGYcum_pmlnocaput,dGYcum_pmltech,dGYcum_imlcac,dGYcum_CD,dGYcum_CDnocaput,dGYcum_fbtcnocaput,dGYcum_fbtc));
disp(sprintf('dLcum                |%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|',dLcum_pmlnocac,dLcum_pmlnotech,dLcum_pmlnocaput,dLcum_pmltech,dLcum_imlcac,dLcum_CD,dLcum_CDnocaput,dLcum_fbtcnocaput,dLcum_fbtc));
disp(sprintf('dtildeYRcum          |%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|',dtildeYRcum_pmlnocac,dtildeYRcum_pmlnotech,dtildeYRcum_pmlnocaput,dtildeYRcum_pmltech,dtildeYRcum_imlcac,dtildeYRcum_CD,dtildeYRcum_CDnocaput,dtildeYRcum_fbtcnocaput,dtildeYRcum_fbtc));

disp('Sectoral Value added Effects: cumul t=0..5');
disp(sprintf('dtildeYHcum          |%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|',dtildeYTcum_pmlnocac,dtildeYTcum_pmlnotech,dtildeYTcum_pmlnocaput,dtildeYTcum_pmltech,dtildeYTcum_imlcac,dtildeYHcum_CD,dtildeYHcum_CDnocaput,dtildeYHcum_fbtcnocaput,dtildeYHcum_fbtc));
disp(sprintf('dtildeYNcum          |%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|',dtildeYNcum_pmlnocac,dtildeYNcum_pmlnotech,dtildeYNcum_pmlnocaput,dtildeYNcum_pmltech,dtildeYNcum_imlcac,dtildeYNcum_CD,dtildeYNcum_CDnocaput,dtildeYNcum_fbtcnocaput,dtildeYNcum_fbtc));
disp(sprintf('dtildeYNScum         |%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|',dtildeYNScum_pmlnocac,dtildeYNScum_pmlnotech,dtildeYNScum_pmlnocaput,dtildeYNScum_pmltech,dtildeYNScum_imlcac,dtildeYNScum_CD,dtildeYNScum_CDnocaput,dtildeYNScum_fbtcnocaput,dtildeYNScum_fbtc));

disp('Technology: cumul t=0..5');
disp(sprintf('duZHcum              |%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|',dtildeZTcum_pmlnocac,dtildeZTcum_pmlnotech,dtildeZTcum_pmlnocaput,dtildeZTcum_pmltech,dtildeZTcum_imlcac,dtildeZHcum_CD,dtildeZHcum_CDnocaput,dtildeZHcum_fbtcnocaput,dtildeZHcum_fbtc));
disp(sprintf('duZNcum              |%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|',dtildeZNcum_pmlnocac,dtildeZNcum_pmlnotech,dtildeZNcum_pmlnocaput,dtildeZNcum_pmltech,dtildeZNcum_imlcac,dtildeZNcum_CD,dtildeZNcum_CDnocaput,dtildeZNcum_fbtcnocaput,dtildeZNcum_fbtc));

disp('CUMULATIVE EFFECTS - Current Account');
disp(sprintf('dCAcum               |%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|',dCAYcum_pmlnocac,dCAYcum_pmlnotech,dCAYcum_pmlnocaput,dCAYcum_pmltech,dCAYcum_imlcac,dCAYcum_CD,dCAYcum_CDnocaput,dCAYcum_fbtcnocaput,dCAYcum_fbtc));

disp('LIS: cumul t=0..5');
disp(sprintf('dLISHcum             |%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|',dLISTcum_pmlnocac,dLISTcum_pmlnotech,dLISTcum_pmlnocaput,dLISTcum_pmltech,dLISTcum_imlcac,dLISHcum_CD,dLISHcum_CDnocaput,dLISHcum_fbtcnocaput,dLISHcum_fbtc));
disp(sprintf('dLISNcum             |%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|%10.2f|',dLISNcum_pmlnocac,dLISNcum_pmlnotech,dLISNcum_pmlnocaput,dLISNcum_pmltech,dLISNcum_imlcac,dLISNcum_CD,dLISNcum_CDnocaput,dLISNcum_fbtcnocaput,dLISNcum_fbtc));
disp('');
disp('');
