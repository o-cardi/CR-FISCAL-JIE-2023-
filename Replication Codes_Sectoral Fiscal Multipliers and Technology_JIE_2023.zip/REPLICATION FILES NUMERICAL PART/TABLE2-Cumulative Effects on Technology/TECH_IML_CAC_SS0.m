function g = TECH_IML_CAC_SS0(x)

global sigma phi varphi 
global gammaL sigmaL phiI varphiI
global epsilon vartheta 
global r deltaK omegaG omegaGN
global ZT ZN thetaT thetaN kappa
global B0 K0  
global xi2T xi2N chi2T chi2N 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%                    VARAIABLES of the MODEL                      %%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C       = x(1)  ; % Consumption                                                                                                      
L       = x(2)  ; % Labor supply                                                                                                     
kT      = x(3)  ; % Capital-labor ratio in sector T                                                                                  
WT      = x(4)  ; % Wage rate in sector T                                                                                            
WN      = x(5)  ; % Wage rate in sector N                                                                                            
W       = x(6)  ; % Aggregate wage index                                                                                             
kN      = x(7)  ; % Capital-labor ratio in sector N                                                                                  
P       = x(8)  ; % Relative price of non tradables                                                                                  
K       = x(9)  ; % Stock of capital                                                                                                 
B       = x(10) ; % Stock of Traded Bonds                                                                                            
alphaL  = x(11) ; % Labor compensation share of tradables                                                                                    
CN      = x(12) ; % Consumption in non tradables                                                                                     
CT      = x(13) ; % Consumption in tradables                                                                                         
PC      = x(14) ; % Consumption price index                                                                                          
alphaC  = x(15) ; % Tradable share of consumption - alphaC                                                                           
IN      = x(16) ; % Non tradable investment                                                                                          
IT      = x(17) ; % Tradable investment                                                                                              
PI      = x(18) ; % Investment price index                                                                                           
alphaI  = x(19) ; % Tradable share of investment    
LT      = x(20) ; % Labor in sector H
LN      = x(21) ; % Labor in sector N 
GT      = x(22) ; % Government spending in tradables                                                                                 
GN      = x(23) ; % Government spending in non tradables                                                                             
YT      = x(24) ; % Output in sector T                                                                                               
YN      = x(25) ; % Output in sector N                                                                                               
VL      = x(26) ; % Labor disutility                                                                                                 
RK      = x(27) ; % Return on capital                                                                                                
xi1T    = x(28) ; % Parameter of traded capital utilization cost function: xi1H*(uKH-1)+(xi2H/2)*(uKH-1)^2                           
xi1N    = x(29) ; % Parameter of non-traded capital utilization cost function                                                        
chi1T   = x(30) ; % Parameter of traded technology utilization cost function: chi1H*(uZH-1)+(chi2H/2)*(uZH-1)^2                      
chi1N   = x(31) ; % Parameter of non-traded technology utilization cost function                                                     
lambda  = x(32) ; % Intertemporal Solvency Condition                                                                                 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                              
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%                    STEADY STATE of the MODEL                    %%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
% Aggregate Consumption -  C
g(1)= C^(-1) - (PC*lambda);

% Aggregate labor supply - L
g(2)= gammaL*(L^(1/sigmaL)) - (lambda*W);

% equality of marginal product of capital across the two sectors  - kT and
% kN
g(3)= ZT*(1-thetaT)*(kT^(-thetaT)) -  P*ZN*(1-thetaN)*(kN^(-thetaN));

% Wage rate in sector T - WT
g(4)= ZT*thetaT*(kT^(1-thetaT)) - WT;

% Wage rate in sector N - WN
g(5)= P*ZN*thetaN*(kN^(1-thetaN)) - WN;

% Aggregate wage index  - W
g(6)=  W - ((vartheta*(WT)^(epsilon+1)) + ((1-vartheta)*(WN)^(epsilon+1)))^(1/(epsilon+1));

% sectoral capital allocation  -  kT and kN 
g(7)= (LT*kT) + (LN*kN) - K;

% MRPK sector N equal to capital cost  - P
g(8)= P*ZN*(1-thetaN)*(kN^(-thetaN)) - (deltaK + r)*PI;

% Non traded market good market clearing condition - K 
g(9)= YN - CN - GN - IN;

% Traded good market clearing condition - B
g(10)= (r*B) + YT - CT - GT - IT;

% Non tradable share of labor income - alphaL 
g(11)= alphaL - (vartheta*(WT)^(epsilon+1))/( vartheta*(WT)^(epsilon+1) + (1-vartheta)*(WN)^(epsilon+1) ); 

% Consumption in non tradables - CN
g(12)= CN - C*(1-varphi)*(P/PC)^(-phi);

% Consumption in tradables - CT 
g(13)= CT - C*varphi*(1/PC)^(-phi);

% Consumption price index - PC
g(14)= PC - (varphi+(1-varphi)*P^(1-phi))^(1/(1-phi));

% Tradable share of consumption - alphaC
g(15)= alphaC - (varphi*(1/PC)^(1-phi));

% Non tradable Investment - IN
g(16)= IN - (deltaK*K)*(1-varphiI)*((P/PI)^(-phiI));

% Tradable Investment - IT 
g(17)= IT - (deltaK*K)*varphiI*((1/PI)^(-phiI));

% Investment price index - PI
g(18)= PI - (varphiI+(1-varphiI)*P^(1-phiI))^(1/(1-phiI));

% Tradable share of investment - alphaI
g(19)= alphaI - (varphiI*(1/PI)^(1-phiI));

% Employment in the traded sector - LH
g(20)= LT - L*(vartheta*(WT/W)^epsilon); 

% Employment in the non traded sector - LN
g(21)= LN - L*((1-vartheta)*(WN/W)^epsilon); 

% Total government spending - GT
g(22)= (GT+(P*GN)) - omegaG*(YT + (P*YN)); 

% Non tradable share of government spending 
g(23)= (P*GN) - omegaGN*(GT+(P*GN)); 

% Output per worker in the traded sector - YT
g(24)= YT - ZT*LT*(kT^(1-thetaT)); 

% Output per worker in the non traded sector - YN
g(25)= YN - ZN*LN*(kN^(1-thetaN));

% Desutility from labor
g(26)= VL - ( 1 + (sigma-1)*gammaL*(sigmaL/(1+sigmaL))*L^((1+sigmaL)/sigmaL) ); % Desutility labor

% Return on capital - R
g(27)= RK - ZT*(1-thetaT)*(kT^(-thetaT)); 

% Capital and technology utilzation rates parameters - xi1j, chi1j
g(28)= xi1T - RK; 
g(29)= xi1N - (RK/P);
g(30)= chi1T - YT;
g(31)= chi1N - YN;

% Non Sep preferences Shimer (2009)
alphaL    = LT/L; 
KT = kT*LT; 
KN = kN*LN; 
yT = YT/LT; 
yN = YN/LN; 

% tildeW(WT,WN,uZT,uZN)
tildeW_WT  = alphaL*(W/WT);
tildeW_WN  = (1-alphaL)*(W/WN);
tildeW_uZT = alphaL*W;
tildeW_uZN = (1-alphaL)*W;

%  L(WT,WN,uZT,uZN,lambda)
L_WT   = sigmaL*(L/W)*tildeW_WT;
L_WN   = sigmaL*(L/W)*tildeW_WN;
L_1uZT = sigmaL*(L/W)*tildeW_uZT;
L_1uZN = sigmaL*(L/W)*tildeW_uZN;
L_1P   = 0;

% Solutions LT,LN(lambda,WT,WN,uZT,uZN)
LT_WT   =  (LT/WT)*epsilon*(1-alphaL) + (LT/L)*L_WT;
LT_WN   = -(LT/WN)*epsilon*(1-alphaL) + (LT/L)*L_WN;
LT_1uZT =  LT*epsilon*(1-alphaL) + (LT/L)*L_1uZT;
LT_1uZN = -LT*epsilon*(1-alphaL) + (LT/L)*L_1uZN;

LN_WT  = -(LN/WT)*epsilon*alphaL + (LN/L)*L_WT;
LN_WN  =  (LN/WN)*epsilon*alphaL + (LN/L)*L_WN;
LN_1uZT = -LN*epsilon*alphaL + (LN/L)*L_1uZT;
LN_1uZN =  LN*epsilon*alphaL + (LN/L)*L_1uZN;

% C(P,lambda)
C_P       = -(1-alphaC)*(C/P);
C_W       = 0;
C_1uZT    = 0;
C_1uZN    = 0;

% Intermediate solution for CN, CT - Cj=Cj(lambda,P,W)
CN_P     = -(CN/P)*(alphaC*phi) + (CN/C)*C_P;
CN_W     = (CN/C)*C_W;
CN_1uZT  = (CN/C)*C_1uZT;
CN_1uZN  = (CN/C)*C_1uZN;

CT_P     = (CT/P)*phi*(1-alphaC) + (CT/C)*C_P;
CT_W     = (CT/C)*C_W;
CT_1uZT  = (CT/C)*C_1uZT;
CT_1uZN  = (CT/C)*C_1uZN;

% Solving for kT, kN, WT, WN as functions of P, K, uKT, uKN, uZT, uZN:
d11 = -(thetaT/kT);
d12 = (thetaN/kN);
d13 = 0;
d14 = 0;
d21 = ((1-thetaT)/kT);
d22 = 0;
d23 = -(1/WT);
d24 = 0;
d31 = 0;
d32 = ((1-thetaN)/kN);
d33 = 0;
d34 = -(1/WN);
d41 = LT;
d42 = LN;
d43 = (kT*LT_WT) + (kN*LN_WT);
d44 = (kT*LT_WN) + (kN*LN_WN);

% P, K, uKT, uKN, uZT, uZN, lambda
e11 = (1/P);
e12 = 0;
e13 = thetaT;
e14 = -thetaN;
e15 = 0;
e16 = 0;

e21 = 0;
e22 = 0;
e23 = -(1-thetaT);
e24 = 0;
e25 = 0;
e26 = 0;

e31 = -(1/P);
e32 = 0;
e33 = 0;
e34 = -(1-thetaN);
e35 = 0;
e36 = 0;

e41 = 0;
e42 = 1;
e43 = 0;
e44 = 0;
e45 = -((kT*LT_1uZT) + (kN*LN_1uZT));
e46 = -((kT*LT_1uZN) + (kN*LN_1uZN));

M2 = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X2 = [e11 e12 e13 e14 e15 e16; e21 e22 e23 e24 e25 e26; e31 e32 e33 e34 e35 e36; e41 e42 e43 e44 e45 e46];
JST2 = inv(M2);
MST2 = JST2*X2;
kT_1P = MST2(1,1); kT_1K = MST2(1,2); kT_uKT = MST2(1,3); kT_uKN = MST2(1,4); kT_uZT = MST2(1,5); kT_uZN = MST2(1,6);
kN_1P = MST2(2,1); kN_1K = MST2(2,2); kN_uKT = MST2(2,3); kN_uKN = MST2(2,4); kN_uZT = MST2(2,5); kN_uZN = MST2(2,6);
WT_1P = MST2(3,1); WT_1K = MST2(3,2); WT_uKT = MST2(3,3); WT_uKN = MST2(3,4); WT_uZT = MST2(3,5); WT_uZN = MST2(3,6);
WN_1P = MST2(4,1); WN_1K = MST2(4,2); WN_uKT = MST2(4,3); WN_uKN = MST2(4,4); WN_uZT = MST2(4,5); WN_uZN = MST2(4,6);

% Solving for sectoral labor and sectoral output - Lj,yj,Yj,Kj(P,K,uKj,uZj)
LT_1P  = (LT_WT*WT_1P) + (LT_WN*WN_1P);
LT_1K  = (LT_WT*WT_1K)  + (LT_WN*WN_1K);
LT_uKT = (LT_WT*WT_uKT) + (LT_WN*WN_uKT);
LT_uKN = (LT_WT*WT_uKN) + (LT_WN*WN_uKN);
LT_uZT = LT_1uZT + (LT_WT*WT_uZT) + (LT_WN*WN_uZT);
LT_uZN = LT_1uZN + (LT_WT*WT_uZN) + (LT_WN*WN_uZN);

LN_1P  = (LN_WT*WT_1P) + (LN_WN*WN_1P);
LN_1K  = (LN_WT*WT_1K)  + (LN_WN*WN_1K);
LN_uKT = (LN_WT*WT_uKT) + (LN_WN*WN_uKT);
LN_uKN = (LN_WT*WT_uKN) + (LN_WN*WN_uKN);
LN_uZT = LN_1uZT + (LN_WT*WT_uZT) + (LN_WN*WN_uZT);
LN_uZN = LN_1uZN + (LN_WT*WT_uZN) + (LN_WN*WN_uZN);

yT_1P  = (yT/kT)*(1-thetaT)*kT_1P;
yT_1K  = (yT/kT)*(1-thetaT)*kT_1K;
yT_uKT = yT*(1-thetaT) + (yT/kT)*(1-thetaT)*kT_uKT;
yT_uKN = (yT/kT)*(1-thetaT)*kT_uKN;
yT_uZT = (yT/kT)*(1-thetaT)*kT_uZT;
yT_uZN = (yT/kT)*(1-thetaT)*kT_uZN;

yN_1P  = (yN/kN)*(1-thetaN)*kN_1P;
yN_1K  = (yN/kN)*(1-thetaN)*kN_1K;
yN_uKT = (yN/kN)*(1-thetaN)*kN_uKT;
yN_uKN = yN*(1-thetaN) + (yN/kN)*(1-thetaN)*kN_uKN;
yN_uZT = (yN/kN)*(1-thetaN)*kN_uZT;
yN_uZN = (yN/kN)*(1-thetaN)*kN_uZN;

YT_1P  = (LT*yT_1P) + (yT*LT_1P);
YT_1K  = (LT*yT_1K) + (yT*LT_1K);
YT_uKT = (LT*yT_uKT) + (yT*LT_uKT);
YT_uKN = (LT*yT_uKN) + (yT*LT_uKN);
YT_uZT = (LT*yT_uZT) + (yT*LT_uZT);
YT_uZN = (LT*yT_uZN) + (yT*LT_uZN);

YN_1P  = (LN*yN_1P) + (yN*LN_1P);
YN_1K  = (LN*yN_1K) + (yN*LN_1K);
YN_uKT = (LN*yN_uKT) + (yN*LN_uKT);
YN_uKN = (LN*yN_uKN) + (yN*LN_uKN);
YN_uZT = (LN*yN_uZT) + (yN*LN_uZT);
YN_uZN = (LN*yN_uZN) + (yN*LN_uZN);

KT_1P = (LT*kT_1P) + (kT*LT_1P);
KT_1K  = (LT*kT_1K) + (kT*LT_1K);
KT_uKT = (LT*kT_uKT) + (kT*LT_uKT);
KT_uKN = (LT*kT_uKN) + (kT*LT_uKN);
KT_uZT = (LT*kT_uZT) + (kT*LT_uZT);
KT_uZN = (LT*kT_uZN) + (kT*LT_uZN);

KN_1P = (LN*kN_1P) + (kN*LN_1P);
KN_1K  = (LN*kN_1K) + (kN*LN_1K);
KN_uKT = (LN*kN_uKT) + (kN*LN_uKT);
KN_uKN = (LN*kN_uKN) + (kN*LN_uKN);
KN_uZT = (LN*kN_uZT) + (kN*LN_uZT);
KN_uZN = (LN*kN_uZN) + (kN*LN_uZN);

% L=L(P,K,uKT,uKN,uZT,uZN,lambda)
L_1P  = (L_WT*WT_1P) + (L_WN*WN_1P);
L_1K  = (L_WT*WT_1K)  + (L_WN*WN_1K);
L_uKT = (L_WT*WT_uKT) + (L_WN*WN_uKT);
L_uKN = (L_WT*WT_uKN) + (L_WN*WN_uKN);
L_uZT = L_1uZT + (L_WT*WT_uZT) + (L_WN*WN_uZT);
L_uZN = L_1uZN + (L_WT*WT_uZN) + (L_WN*WN_uZN);

% Solving for capital and technology utilization rates: uKT, uKN, uZT, uZN; uKj,uZj(P,K,lambda)
f11 = ((xi2T/xi1T) + thetaT) + thetaT*(kT_uKT/kT);
f12 = thetaT*(kT_uKN/kT);
f13 = thetaT*(kT_uZT/kT)-1;
f14 = thetaT*(kT_uZN/kT);
f21 = thetaN*(kN_uKT/kN);
f22 = ((xi2N/xi1N) + thetaN) + thetaN*(kN_uKN/kN);
f23 = thetaN*(kN_uZT/kN);
f24 = thetaN*(kN_uZN/kN)-1;
f31 = -YT_uKT/YT;
f32 = -YT_uKN/YT;
f33 = (chi2T/chi1T)-(YT_uZT/YT);
f34 = -YT_uZN/YT;
f41 = -YN_uKT/YN;
f42 = -YN_uKN/YN;
f43 = -YN_uZT/YN;
f44 = (chi2N/chi1N)-(YN_uZN/YN);

% P, K, lambda
g11 = -thetaT*(kT_1P/kT);
g12 = -thetaT*(kT_1K/kT);

g21 = -thetaN*(kN_1P/kN);
g22 = -thetaN*(kN_1K/kN);

g31 = YT_1P/YT;
g32 = YT_1K/YT;

g41 = YN_1P/YN;
g42 = YN_1K/YN;

M3 = [f11 f12 f13 f14; f21 f22 f23 f24; f31 f32 f33 f34; f41 f42 f43 f44];
X3 = [g11 g12; g21 g22; g31 g32; g41 g42];
JST3 = inv(M3);
MST3 = JST3*X3;

uKT_P = MST3(1,1); uKT_1K = MST3(1,2);
uKN_P = MST3(2,1); uKN_1K = MST3(2,2);
uZT_P = MST3(3,1); uZT_1K = MST3(3,2);
uZN_P = MST3(4,1); uZN_1K = MST3(4,2);

% Solving for sectoral labor and sectoral output - kj,Lj,yj,Yj,Kj(lambda,K,P)
kT_2K =  kT_1K + (kT_uKT*uKT_1K) + (kT_uKN*uKN_1K) + (kT_uZT*uZT_1K) + (kT_uZN*uZN_1K);
kT_P  =  kT_1P + (kT_uKT*uKT_P) + (kT_uKN*uKN_P) + (kT_uZT*uZT_P) + (kT_uZN*uZN_P);

kN_2K =  kN_1K + (kN_uKT*uKT_1K) + (kN_uKN*uKN_1K) + (kN_uZT*uZT_1K) + (kN_uZN*uZN_1K);   
kN_P  =  kN_1P + (kN_uKT*uKT_P) + (kN_uKN*uKN_P) + (kN_uZT*uZT_P) + (kN_uZN*uZN_P);       

LT_2K = LT_1K + (LT_uKT*uKT_1K) + (LT_uKN*uKN_1K) + (LT_uZT*uZT_1K) + (LT_uZN*uZN_1K);
LT_P  = LT_1P + (LT_uKT*uKT_P) + (LT_uKN*uKN_P) + (LT_uZT*uZT_P) + (LT_uZN*uZN_P);

LN_2K = LN_1K + (LN_uKT*uKT_1K) + (LN_uKN*uKN_1K) + (LN_uZT*uZT_1K) + (LN_uZN*uZN_1K);
LN_P  = LN_1P + (LN_uKT*uKT_P) + (LN_uKN*uKN_P) + (LN_uZT*uZT_P) + (LN_uZN*uZN_P);

YT_2K = YT_1K + (YT_uKT*uKT_1K) + (YT_uKN*uKN_1K) + (YT_uZT*uZT_1K) + (YT_uZN*uZN_1K);
YT_P  = YT_1P + (YT_uKT*uKT_P) + (YT_uKN*uKN_P) + (YT_uZT*uZT_P) + (YT_uZN*uZN_P);

YN_2K = YN_1K + (YN_uKT*uKT_1K) + (YN_uKN*uKN_1K) + (YN_uZT*uZT_1K) + (YN_uZN*uZN_1K);
YN_P  = YN_1P + (YN_uKT*uKT_P) + (YN_uKN*uKN_P) + (YN_uZT*uZT_P) + (YN_uZN*uZN_P);

KT_2K =  KT_1K + (KT_uKT*uKT_1K) + (KT_uKN*uKN_1K) + (KT_uZT*uZT_1K) + (KT_uZN*uZN_1K);
KT_P  =  KT_1P + (KT_uKT*uKT_P) + (KT_uKN*uKN_P) + (KT_uZT*uZT_P) + (KT_uZN*uZN_P);

KN_2K =  KN_1K + (KN_uKT*uKT_1K) + (KN_uKN*uKN_1K) + (KN_uZT*uZT_1K) + (KN_uZN*uZN_1K);    
KN_P  =  KN_1P + (KN_uKT*uKT_P) + (KN_uKN*uKN_P) + (KN_uZT*uZT_P) + (KN_uZN*uZN_P);        

WT_2K = WT_1K + (WT_uKT*uKT_1K) + (WT_uKN*uKN_1K) + (WT_uZT*uZT_1K) + (WT_uZN*uZN_1K);
WT_P  = WT_1P + (WT_uKT*uKT_P) + (WT_uKN*uKN_P) + (WT_uZT*uZT_P) + (WT_uZN*uZN_P);

WN_2K = WN_1K + (WN_uKT*uKT_1K) + (WN_uKN*uKN_1K) + (WN_uZT*uZT_1K) + (WN_uZN*uZN_1K);
WN_P  = WN_1P + (WN_uKT*uKT_P) + (WN_uKN*uKN_P) + (WN_uZT*uZT_P) + (WN_uZN*uZN_P);

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI);
v_P  = - (1-alphaI)/(kappa*P);

% Solution for J = J(K,Q,PN,PH)
J_1K = deltaK;
J_1Q = K*v_1Q;
J_P  = K*v_P;

% Solution for JN, JT - Jj=Jj(P,K,Q)
I     = deltaK*K;
JN_P  = -(IN/P)*(phiI*alphaI) + (IN/I)*J_P;
JN_1K = (IN/I)*J_1K;
JN_1Q = (IN/I)*J_1Q;

JT_P  =  (IT/P)*phiI*(1-alphaI) + (IT/I)*J_P;
JT_1K = (IT/I)*J_1K;
JT_1Q = (IT/I)*J_1Q;

% R=R(lambda,K,P)
R_1K  = -RK*thetaT*(uKT_1K + (kT_2K/kT));
R_P   = -RK*thetaT*(uKT_P + (kT_P/kT));

% Partial Derivatives Gj=Gj(G)
GN_G   = omegaGN/P;
GT_G   = (1-omegaGN);

% Solving for the relative price P=P(lambda,K,Q,G)
DeltaP   = (YN_P - CN_P - JN_P) - (KN*xi1N*uKN_P);
P_K      = -(1/DeltaP)*(YN_2K - JN_1K - (KN*xi1N*uKN_1K));
P_Q      = (JN_1Q/DeltaP);
P_G      = GN_G/DeltaP;

% Solving for capital-labor ratios kj=kj(K,Q,G,Aj,Bj) -
% sectoral labor Lj=Lj(K,Q,G,Aj,Bj) - sectoral output
% Yj=Yj(K,Q,G,Aj,Bj) - Final Solutions
kT_K = kT_2K + (kT_P*P_K);
kT_Q = (kT_P*P_Q);
kT_G = (kT_P*P_G);

kN_K = kN_2K + (kN_P*P_K);
kN_Q = (kN_P*P_Q) ;
kN_G = (kN_P*P_G);

LT_K  = LT_2K + (LT_P*P_K);
LT_Q  = (LT_P*P_Q);
LT_G  = (LT_P*P_G);

LN_K = LN_2K + (LN_P*P_K);
LN_Q = (LN_P*P_Q);
LN_G = (LN_P*P_G);

YT_K = YT_2K + (YT_P*P_K);
YT_Q = (YT_P*P_Q);
YT_G = (YT_P*P_G);

YN_K = YN_2K + (YN_P*P_K);
YN_Q = (YN_P*P_Q) ;
YN_G = (YN_P*P_G) ;

uKT_K  = uKT_1K + (uKT_P*P_K);
uKT_Q  = (uKT_P*P_Q);
uKT_G  = (uKT_P*P_G);

uKN_K = uKN_1K + (uKN_P*P_K);
uKN_Q = (uKN_P*P_Q);
uKN_G = (uKN_P*P_G);

uZT_K  = uZT_1K + (uZT_P*P_K);
uZT_Q  = (uZT_P*P_Q);
uZT_G  = (uZT_P*P_G);

uZN_K = uZN_1K + (uZN_P*P_K);
uZN_Q = (uZN_P*P_Q);
uZN_G = (uZN_P*P_G);

% Solving for consumption Cj=Cj(lambda,K,Q,G), investment inputs
% Jj=Jj(K,Q,G)
CT_K      = (CT_P*P_K);
CT_Q      = (CT_P*P_Q);
CT_G      = (CT_P*P_G);

CN_K      = (CN_P*P_K);
CN_Q      = (CN_P*P_Q);
CN_G      = (CN_P*P_G);

JT_K       = JT_1K + (JT_P*P_K);
JT_Q       = JT_1Q + (JT_P*P_Q);
JT_G       = (JT_P*P_G);

JN_K       = JN_1K + (JN_P*P_K);
JN_Q       = JN_1Q + (JN_P*P_Q);
JN_G       = (JN_P*P_G);

% KT,KN,WT,WN(K,P,G,lambda)
KT_K = KT_2K + (KT_P*P_K);
KT_Q = (KT_P*P_Q);
KT_G = (KT_P*P_G);

KN_K = KN_2K + (KN_P*P_K);
KN_Q = (KN_P*P_Q) ;
KN_G = (KN_P*P_G);

WT_K = WT_2K + (WT_P*P_K);
WT_Q = (WT_P*P_Q);
WT_G = (WT_P*P_G);

WN_K = WN_2K + (WN_P*P_K);
WN_Q = (WN_P*P_Q) ;
WN_G = (WN_P*P_G);

% R,v(K,P,G,lambda)
R_K = R_1K + (R_P*P_K);
R_Q = (R_P*P_Q);
R_G = (R_P*P_G);

v_K        = (v_P*P_K);
v_Q        = v_1Q + (v_P*P_Q);
v_G        = (v_P*P_G);
           
% Elements of the Jacobian Matrix
Upsilon_K = (I/IN)*(YN_K-CN_K-(KN*xi1N*uKN_K)) - deltaK + alphaI*phiI*I*(P_K/P);
Upsilon_Q = (I/IN)*(YN_Q-CN_Q-(KN*xi1N*uKN_Q)) + alphaI*phiI*I*(P_Q/P);
Sigma_K   = -(R_K-(RK/K)+(RK/K)*((KT*uKT_K)+(KN*uKN_K)+(KT*uZT_K)+(KN*uZN_K)+(KT_K+KN_K))-(KT/K)*xi1T*uKT_K-(P*KN/K)*xi1N*uKN_K + (PI*kappa*v_K*deltaK) );
Sigma_Q   = (r+deltaK)-( R_Q+(RK/K)*((KT*uKT_Q)+(KN*uKN_Q))+(RK/K)*((KT*uZT_Q)+(KN*uZN_Q))+(RK/K)*(KT_Q+KN_Q)-(KT/K)*xi1T*uKT_Q-(P*KN/K)*xi1N*uKN_Q + (PI*kappa*v_Q*deltaK) );

x11 = Upsilon_K;
x12 = Upsilon_Q;
x21 = Sigma_K;
x22 = Sigma_Q;

J = [x11 x12; x21 x22];
[V,nu]=eig(J);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1);
nu_2 = nu_sorted(2,2);
omega_11 = V_sorted(1,1)/V_sorted(1,1);
omega_21 = V_sorted(2,1)/V_sorted(1,1);
omega_12 = V_sorted(1,2)/V_sorted(1,2);
omega_22 = V_sorted(2,2)/V_sorted(1,2);

% Intertemporal solvency condition - lambda
B_K   = (YT_K - CT_K - JT_K) - (KT*xi1T*uKT_K);
B_Q   = (YT_Q - CT_Q - JT_Q) - (KT*xi1T*uKT_Q);
N1    = (B_K + (B_Q*omega_21));
H1    = N1/(nu_1-r);

g(32) = (B - B0) - H1*(K-K0);


