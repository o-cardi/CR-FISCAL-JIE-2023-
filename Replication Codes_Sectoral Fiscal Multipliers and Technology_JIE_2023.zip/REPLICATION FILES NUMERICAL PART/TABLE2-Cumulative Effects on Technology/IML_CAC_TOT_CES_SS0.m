function g = IML_CAC_TOT_CES_SS0(x) 
global sigmaC phi varphi rho varphiH
global phiI iota rhoI iotaH 
global ex nuX
global epsilon vartheta 
global gammaL sigmaL 
global r deltaK kappa
global omegaG omegaGN omegaGH 
global BH BN AH AN gammaH gammaN sigmaH sigmaN
global xi2H xi2N chi2H chi2N
global B0 K0 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%                    VARAIABLES of the MODEL                      %%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kH      = x(3)  ; % Capital-labor ratio in sector H
WH      = x(4)  ; % Wage rate in sector H
WN      = x(5)  ; % Wage rate in sector N
W       = x(6)  ; % Aggregate wage index
kN      = x(7)  ; % Capital-labor ratio in sector N
PN      = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
PH      = x(10) ; % Terms of trade : PH/PF with PF = numeraire
B       = x(11) ; % Stock of Traded Bonds
alphaL  = x(12) ; % Output per worker in sector N 
PC      = x(13) ; % Aggregate consumption price index
PT      = x(14) ; % Consumption price index for tradables
CN      = x(15) ; % Consumption in non tradables 
CH      = x(16) ; % Consumption in tradables 
CF      = x(17) ; % Consumption goods imports
alphaC  = x(18) ; % Tradable content of consumption expenditure 
alphaH  = x(19) ; % Home goods content of consumption expenditure on traded goods
PI      = x(20) ; % Aggregate investment price index
PIT     = x(21) ; % Investment price index for tradables
IN      = x(22) ; % Non tradable investment
IH      = x(23) ; % Investment in home goods
IF      = x(24) ; % Investment in foreign goods
alphaI  = x(25) ; % Tradable content of investment expenditure
alphaIH = x(26) ; % Home goods content of investment expenditure
LH      = x(27) ; % Labor in sector H
LN      = x(28) ; % Labor in sector N 
GF      = x(29) ; % Government spending in foreign goods
GN      = x(30) ; % Government spending in non tradables 
GH      = x(31) ; % Government spending in home traded goods
yH      = x(32) ; % Output of home traded goods per worker
YH      = x(33) ; % Output of home traded goods
yN      = x(34) ; % Output of non traded goods per worker
YN      = x(35) ; % Output of non traded goods
XH      = x(36) ; % Exports of home traded goods
MF      = x(37) ; % Imports of foreign goods
RK      = x(38) ; % Return on capital
xi1H    = x(39) ; % Parameter of traded capital utilization cost function: xi1H*(uKH-1)+(xi2H/2)*(uKH-1)^2
xi1N    = x(40) ; % Parameter of non-traded capital utilization cost function
chi1H   = x(41) ; % Parameter of traded technology utilization cost function: chi1H*(uZH-1)+(chi2H/2)*(uZH-1)^2
chi1N   = x(42) ; % Parameter of non-traded technology utilization cost function
lambda  = x(43) ; % Intertemporal Solvency Condition     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%                    STEADY STATE of the MODEL                    %%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      

% Aggregate Consumption - C
g(1)= (C^(-1/sigmaC)) - (PC*lambda);

% Aggregate labor supply - L
g(2)= gammaL*(L^(1/sigmaL)) - (lambda*W);

% equality of marginal product of capital across the two sectors - kH and
% kN
g(3)= PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((yH/kH)^(1/sigmaH)) - PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((yN/kN)^(1/sigmaN)); 

% Wage rate in sector H - WH
g(4)= PH*gammaH*(AH^((sigmaH-1)/sigmaH))*(yH^(1/sigmaH)) - WH;

% Wage rate in sector N - WN
g(5)= PN*gammaN*(AN^((sigmaN-1)/sigmaN))*(yN^(1/sigmaN)) - WN;

% Aggregate wage index - W
g(6)= W - ((vartheta*(WH)^(epsilon+1)) + ((1-vartheta)*(WN)^(epsilon+1)))^(1/(epsilon+1));

% sectoral capital allocation - kH and kN - 
g(7)= (LH*kH) + (LN*kN) - K;

% equality of marginal product of capital in the non traded sector to the world interest rate - PN 
g(8)= PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((yH/kH)^(1/sigmaH)) - (deltaK + r)*PI;

% Non traded market good market clearing condition - K 
g(9)= YN - CN - IN - GN;

% Homme good market clearing condition - PH
g(10)= YH - CH - IH - GH - XH;

% Traded good market clearing condition - B
g(11)= (r*B) + (PH*XH) - MF;

% Labor compensation share of tradables - alphaL 
g(12)= alphaL - (vartheta*(WH)^(epsilon+1))/( vartheta*(WH)^(epsilon+1) + (1-vartheta)*(WN)^(epsilon+1) ); 

% Consumption price index - PC=PC(PT,PN)
g(13)= PC - (varphi*(PT^(1-phi))+(1-varphi)*(PN^(1-phi)))^(1/(1-phi));

% Consumption price index for tradables - PT=PT(PH)
g(14)= PT - (varphiH*(PH^(1-rho))+(1-varphiH))^(1/(1-rho));

% Consumption in non tradables - CN
g(15)= CN - C*(1-varphi)*((PN/PC)^(-phi));

% Consumption in home goods - CH
g(16)= CH - C*varphi*((PT/PC)^(-phi))*varphiH*((PH/PT)^(-rho));

% Consumption in foreign goods - CF
g(17)= CF - C*varphi*((PT/PC)^(-phi))*(1-varphiH)*((1/PT)^(-rho));

% Tradable content of consumption expenditure - alphaC
g(18)= alphaC - varphi*(PT/PC)^(1-phi);

% Home goods content of consumption expenditure - alphaH
g(19)= alphaH - varphiH*(PH/PT)^(1-rho);

% Investment price index - PI=PI(PT,PN)
g(20)= PI - (iota*(PIT^(1-phiI))+(1-iota)*(PN^(1-phiI)))^(1/(1-phiI));

% Investment price index for tradables - PIT=PIT(PH)
g(21)= PIT - (iotaH*(PH^(1-rhoI))+(1-iotaH))^(1/(1-rhoI));

% Investment in non tradables - IN
g(22)= IN - (deltaK*K)*(1-iota)*((PN/PI)^(-phiI));

% Investment in home goods - IH
g(23)= IH - (deltaK*K)*iota*((PIT/PI)^(-phiI))*iotaH*((PH/PIT)^(-rhoI));

% Investment in foreign goods - IF
g(24)= IF - (deltaK*K)*iota*((PIT/PI)^(-phiI))*(1-iotaH)*((1/PIT)^(-rhoI));

% Tradable of investment expenditure - alphaI
g(25)= alphaI - iota*(PIT/PI)^(1-phiI);

% Home goods content of investment expenditure - alphaIH
g(26)= alphaIH - iotaH*(PH/PIT)^(1-rhoI);

% Employment in the traded sector - LH
g(27)= LH - L*(vartheta*(WH/W)^epsilon); 

% Employment in the non traded sector - LN
g(28)= LN - L*((1-vartheta)*(WN/W)^epsilon); 

% Total government spending - G
g(29)= ((PH*GH) + GF + (PN*GN)) - omegaG*( (PH*YH) + (PN*YN) ); 

% Non tradable share of government spending  - GN
g(30)= (PN*GN) - omegaGN*( (PH*GH) + GF + (PN*GN) ); 

% Home goods content of government spending  - GH
g(31)= (PH*GH) - omegaGH*( (PH*GH) + GF ); 

% Output in the home good sector - YH
% Output per worker in the home traded sector - kH,yH - and Labor
% income share in sector H, sLH
g(32)= yH - ( gammaH*(AH^((sigmaH-1)/sigmaH)) + (1-gammaH)*((BH*kH)^((sigmaH-1)/sigmaH)) )^(sigmaH/(sigmaH-1));  
g(33)= YH  - (LH*yH); 

% Output per worker in the non traded sector - kN,yN - and Labor
% income share in sector N, sLN
g(34)= yN  - ( gammaN*(AN)^((sigmaN-1)/sigmaN) + (1-gammaN)*((BN*kN)^((sigmaN-1)/sigmaN)) )^(sigmaN/(sigmaN-1)); 
g(35)= YN  - (LN*yN); 

% Export of home goods - XH
g(36)= XH - ex*(PH)^(-nuX);

% Import of foreign goods - MF
g(37)= MF - (CF+IF+GF); 

% Return on capital - R
g(38)= RK - PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((yH/kH)^(1/sigmaH)); 

% Capital and technology utilzation rates parameters - xi1j, chi1j
g(39)= xi1H - (RK/PH); 
g(40)= xi1N - (RK/PN);
g(41)= chi1H - YH;
g(42)= chi1N - YN;

% LHj = partial Lj/partial Wj
LH_WH   = (LH/WH)*( epsilon*(1-alphaL) + (sigmaL*alphaL) );
LH_1uZH = LH*( epsilon*(1-alphaL) + (sigmaL*alphaL) );
LH_WN   = (LH/WN)*(1-alphaL)*(sigmaL-epsilon); 
LH_1uZN = LH*(1-alphaL)*(sigmaL-epsilon); 
LN_WH   = (LN/WH)*alphaL*(sigmaL-epsilon); 
LN_1uZH = LN*alphaL*(sigmaL-epsilon);
LN_WN   = (LN/WN)*( (epsilon*alphaL) + sigmaL*(1-alphaL) );  
LN_1uZN = LN*( (epsilon*alphaL) + sigmaL*(1-alphaL) ); 

% Labor income share in the home traded good and non traded good sector
sLH    = gammaH*(AH/yH)^((sigmaH-1)/sigmaH);
sLN    = gammaN*(AN/yN)^((sigmaN-1)/sigmaN); 
KH     = kH*LH; 
KN     = kN*LN;

% Solving for kH, kN, WH, WN as functions of PH, PN, K, uKH, uKN, uZH, uZN: 
d11 = -(1/sigmaH)*(sLH/kH); 
d12 = (1/sigmaN)*(sLN/kN);
d13 = 0;
d14 = 0;
d21 = (1/sigmaH)*((1-sLH)/kH); 
d22 = 0;  
d23 = -(1/WH); 
d24 = 0; 
d31 = 0; 
d32 = (1/sigmaN)*((1-sLN)/kN);
d33 = 0; 
d34 = -(1/WN);
d41 = LH; 
d42 = LN; 
d43 = (kH*LH_WH) + (kN*LN_WH); 
d44 = (kH*LH_WN) + (kN*LN_WN); 

% PN, PH, K, uKH, uKN, uZH, uZN
e11 = (1/PN); 
e12 = -(1/PH);
e13 = 0;
e14 = (sLH/sigmaH); 
e15 = -(sLN/sigmaN); 
e16 = 0;
e17 = 0;
e21 = 0; 
e22 = -(1/PH); 
e23 = 0;
e24 = -((1-sLH)/sigmaH);
e25 = 0;
e26 = 0;
e27 = 0;
e31 = -(1/PN); 
e32 = 0; 
e33 = 0; 
e34 = 0;
e35 = -((1-sLN)/sigmaN);
e36 = 0;
e37 = 0;
e41 = 0; 
e42 = 0; 
e43 = 1; 
e44 = 0; 
e45 = 0;
e46 = -((kH*LH_1uZH) + (kN*LN_1uZH)); 
e47 = -((kH*LH_1uZN) + (kN*LN_1uZN));

M1 = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X1 = [e11 e12 e13 e14 e15 e16 e17; e21 e22 e23 e24 e25 e26 e27; e31 e32 e33 e34 e35 e36 e37; e41 e42 e43 e44 e45 e46 e47];
JST1 = inv(M1);
MST1 = JST1*X1;
kH_1PN = MST1(1,1); kH_1PH = MST1(1,2); kH_1K = MST1(1,3); kH_uKH = MST1(1,4); kH_uKN = MST1(1,5); kH_uZH = MST1(1,6); kH_uZN = MST1(1,7);
kN_1PN = MST1(2,1); kN_1PH = MST1(2,2); kN_1K = MST1(2,3); kN_uKH = MST1(2,4); kN_uKN = MST1(2,5); kN_uZH = MST1(2,6); kN_uZN = MST1(2,7);
WH_1PN = MST1(3,1); WH_1PH = MST1(3,2); WH_1K = MST1(3,3); WH_uKH = MST1(3,4); WH_uKN = MST1(3,5); WH_uZH = MST1(3,6); WH_uZN = MST1(3,7);
WN_1PN = MST1(4,1); WN_1PH = MST1(4,2); WN_1K = MST1(4,3); WN_uKH = MST1(4,4); WN_uKN = MST1(4,5); WN_uZH = MST1(4,6); WN_uZN = MST1(4,7);

% Solving for sectoral labor and sectoral output - Lj,yj,Yj,Kj(PN,PH,K,uKj,uZj)
LH_1PN = (LH_WH*WH_1PN) + (LH_WN*WN_1PN);
LH_1PH = (LH_WH*WH_1PH) + (LH_WN*WN_1PH);
LH_1K  = (LH_WH*WH_1K)  + (LH_WN*WN_1K);
LH_uKH = (LH_WH*WH_uKH) + (LH_WN*WN_uKH);
LH_uKN = (LH_WH*WH_uKN) + (LH_WN*WN_uKN);
LH_uZH = LH_1uZH + (LH_WH*WH_uZH) + (LH_WN*WN_uZH);
LH_uZN = LH_1uZN + (LH_WH*WH_uZN) + (LH_WN*WN_uZN);

LN_1PN = (LN_WH*WH_1PN) + (LN_WN*WN_1PN);
LN_1PH = (LN_WH*WH_1PH) + (LN_WN*WN_1PH);
LN_1K  = (LN_WH*WH_1K)  + (LN_WN*WN_1K);
LN_uKH = (LN_WH*WH_uKH) + (LN_WN*WN_uKH);
LN_uKN = (LN_WH*WH_uKN) + (LN_WN*WN_uKN);
LN_uZH = LN_1uZH + (LN_WH*WH_uZH) + (LN_WN*WN_uZH);
LN_uZN = LN_1uZN + (LN_WH*WH_uZN) + (LN_WN*WN_uZN);

yH_1PN = (yH/kH)*(1-sLH)*kH_1PN;
yH_1PH = (yH/kH)*(1-sLH)*kH_1PH;
yH_1K  = (yH/kH)*(1-sLH)*kH_1K;
yH_uKH = yH*(1-sLH) + (yH/kH)*(1-sLH)*kH_uKH;
yH_uKN = (yH/kH)*(1-sLH)*kH_uKN;
yH_uZH = (yH/kH)*(1-sLH)*kH_uZH;
yH_uZN = (yH/kH)*(1-sLH)*kH_uZN;

yN_1PN = (yN/kN)*(1-sLN)*kN_1PN;
yN_1PH = (yN/kN)*(1-sLN)*kN_1PH;
yN_1K  = (yN/kN)*(1-sLN)*kN_1K;
yN_uKH = (yN/kN)*(1-sLN)*kN_uKH;
yN_uKN = yN*(1-sLN) + (yN/kN)*(1-sLN)*kN_uKN;
yN_uZH = (yN/kN)*(1-sLN)*kN_uZH;
yN_uZN = (yN/kN)*(1-sLN)*kN_uZN;

YH_1PN = (LH*yH_1PN) + (yH*LH_1PN);
YH_1PH = (LH*yH_1PH) + (yH*LH_1PH);
YH_1K  = (LH*yH_1K) + (yH*LH_1K);
YH_uKH = (LH*yH_uKH) + (yH*LH_uKH);
YH_uKN = (LH*yH_uKN) + (yH*LH_uKN);
YH_uZH = (LH*yH_uZH) + (yH*LH_uZH);
YH_uZN = (LH*yH_uZN) + (yH*LH_uZN);

YN_1PN = (LN*yN_1PN) + (yN*LN_1PN);
YN_1PH = (LN*yN_1PH) + (yN*LN_1PH);
YN_1K  = (LN*yN_1K) + (yN*LN_1K);
YN_uKH = (LN*yN_uKH) + (yN*LN_uKH);
YN_uKN = (LN*yN_uKN) + (yN*LN_uKN);
YN_uZH = (LN*yN_uZH) + (yN*LN_uZH);
YN_uZN = (LN*yN_uZN) + (yN*LN_uZN);

KH_1PN = (LH*kH_1PN) + (kH*LH_1PN);
KH_1PH = (LH*kH_1PH) + (kH*LH_1PH);
KH_1K  = (LH*kH_1K) + (kH*LH_1K);
KH_uKH = (LH*kH_uKH) + (kH*LH_uKH);
KH_uKN = (LH*kH_uKN) + (kH*LH_uKN);
KH_uZH = (LH*kH_uZH) + (kH*LH_uZH);
KH_uZN = (LH*kH_uZN) + (kH*LH_uZN);

KN_1PN = (LN*kN_1PN) + (kN*LN_1PN);
KN_1PH = (LN*kN_1PH) + (kN*LN_1PH);
KN_1K  = (LN*kN_1K) + (kN*LN_1K);
KN_uKH = (LN*kN_uKH) + (kN*LN_uKH);
KN_uKN = (LN*kN_uKN) + (kN*LN_uKN);
KN_uZH = (LN*kN_uZH) + (kN*LN_uZH);
KN_uZN = (LN*kN_uZN) + (kN*LN_uZN);

% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH)
CN_PN = - (CN/PN)*( (alphaC*phi) + sigmaC*(1-alphaC) ); 
CN_PH = (CN/PH)*alphaC*alphaH*(phi-sigmaC); 
CH_PN = (CH/PN)*(phi-sigmaC)*(1-alphaC); 
CH_PH = -(CH/PH)*( rho*(1-alphaH) + alphaH*( phi*(1-alphaC) + (sigmaC*alphaC) ) ); 
CF_PN = (CF/PN)*(1-alphaC)*(phi-sigmaC); 
CF_PH = (CF/PH)*alphaH*(rho - (phi*(1-alphaC)+(sigmaC*alphaC))); 

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_K  = deltaK; 
J_Q  = K*v_1Q; 
J_PN = K*v_PN; 
J_PH = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q)
I     = deltaK*K; 
JN_PN = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K = (IN/I)*J_K; 
JN_1Q = (IN/I)*J_Q; 

JH_PN =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_K; 
JH_1Q  = (IH/I)*J_Q; 

JF_PN = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_K; 
JF_1Q  = (IF/I)*J_Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH = -(XH/PH)*nuX; 

% Solving for capital and technology utilization rates: uKH, uKN, uZH, uZN; uKj,uZj(PN,PH,K)
f11 = ((xi2H/xi1H) + (sLH/sigmaH)) + (sLH/sigmaH)*(kH_uKH/kH);
f12 = (sLH/sigmaH)*(kH_uKN/kH);
f13 = ((sLH/sigmaH)*(kH_uZH/kH)-1);
f14 = (sLH/sigmaH)*(kH_uZN/kH);
f21 = (sLN/sigmaN)*(kN_uKH/kN);
f22 = ((xi2N/xi1N) + (sLN/sigmaN)) + (sLN/sigmaN)*(kN_uKN/kN);
f23 = (sLN/sigmaN)*(kN_uZH/kN);
f24 = ((sLN/sigmaN)*(kN_uZN/kN)-1);
f31 = -(YH_uKH/YH);
f32 = -(YH_uKN/YH);
f33 = ((chi2H/chi1H)-(YH_uZH/YH));
f34 = -(YH_uZN/YH);
f41 = -(YN_uKH/YN);
f42 = -(YN_uKN/YN);
f43 = -(YN_uZH/YN);
f44 = ((chi2N/chi1N)-(YN_uZN/YN));

% PN, PH, K
g11 = -(sLH/sigmaH)*(kH_1PN/kH);
g12 = -(sLH/sigmaH)*(kH_1PH/kH);
g13 = -(sLH/sigmaH)*(kH_1K/kH);
g21 = -(sLN/sigmaN)*(kN_1PN/kN);
g22 = -(sLN/sigmaN)*(kN_1PH/kN);
g23 = -(sLN/sigmaN)*(kN_1K/kN);
g31 = (YH_1PN/YH);
g32 = (YH_1PH/YH);
g33 = (YH_1K/YH);
g41 = (YN_1PN/YN);
g42 = (YN_1PH/YN);
g43 = (YN_1K/YN);

M2 = [f11 f12 f13 f14; f21 f22 f23 f24; f31 f32 f33 f34; f41 f42 f43 f44];
X2 = [g11 g12 g13; g21 g22 g23; g31 g32 g33; g41 g42 g43];
JST2 = inv(M2);
MST2 = JST2*X2;

uKH_PN = MST2(1,1); uKH_PH = MST2(1,2); uKH_1K = MST2(1,3);  
uKN_PN = MST2(2,1); uKN_PH = MST2(2,2); uKN_1K = MST2(2,3);  
uZH_PN = MST2(3,1); uZH_PH = MST2(3,2); uZH_1K = MST2(3,3);  
uZN_PN = MST2(4,1); uZN_PH = MST2(4,2); uZN_1K = MST2(4,3);  

% Solving for sectoral labor and sectoral output - kj,Wj,Lj,yj,Yj,Kj(PN,PH,K) 
kH_2K = kH_1K + (kH_uKH*uKH_1K) + (kH_uKN*uKN_1K) + (kH_uZH*uZH_1K) + (kH_uZN*uZN_1K); 
kH_PH = kH_1PH + (kH_uKH*uKH_PH) + (kH_uKN*uKN_PH) + (kH_uZH*uZH_PH) + (kH_uZN*uZN_PH);
kH_PN = kH_1PN + (kH_uKH*uKH_PN) + (kH_uKN*uKN_PN) + (kH_uZH*uZH_PN) + (kH_uZN*uZN_PN);
kN_2K = kN_1K + (kN_uKH*uKH_1K) + (kN_uKN*uKN_1K) + (kN_uZH*uZH_1K) + (kN_uZN*uZN_1K);     
kN_PH = kN_1PH + (kN_uKH*uKH_PH) + (kN_uKN*uKN_PH) + (kN_uZH*uZH_PH) + (kN_uZN*uZN_PH);
kN_PN = kN_1PN + (kN_uKH*uKH_PN) + (kN_uKN*uKN_PN) + (kN_uZH*uZH_PN) + (kN_uZN*uZN_PN);

WH_2K = WH_1K + (WH_uKH*uKH_1K) + (WH_uKN*uKN_1K) + (WH_uZH*uZH_1K) + (WH_uZN*uZN_1K);  
WH_PH = WH_1PH + (WH_uKH*uKH_PH) + (WH_uKN*uKN_PH) + (WH_uZH*uZH_PH) + (WH_uZN*uZN_PH); 
WH_PN = WH_1PN + (WH_uKH*uKH_PN) + (WH_uKN*uKN_PN) + (WH_uZH*uZH_PN) + (WH_uZN*uZN_PN);                                                                                     
WN_2K = WN_1K + (WN_uKH*uKH_1K) + (WN_uKN*uKN_1K) + (WN_uZH*uZH_1K) + (WN_uZN*uZN_1K);  
WN_PH = WN_1PH + (WN_uKH*uKH_PH) + (WN_uKN*uKN_PH) + (WN_uZH*uZH_PH) + (WN_uZN*uZN_PH); 
WN_PN = WN_1PN + (WN_uKH*uKH_PN) + (WN_uKN*uKN_PN) + (WN_uZH*uZH_PN) + (WN_uZN*uZN_PN); 

LH_2K = LH_1K + (LH_uKH*uKH_1K) + (LH_uKN*uKN_1K) + (LH_uZH*uZH_1K) + (LH_uZN*uZN_1K);  
LH_PH = LH_1PH + (LH_uKH*uKH_PH) + (LH_uKN*uKN_PH) + (LH_uZH*uZH_PH) + (LH_uZN*uZN_PH); 
LH_PN = LH_1PN + (LH_uKH*uKH_PN) + (LH_uKN*uKN_PN) + (LH_uZH*uZH_PN) + (LH_uZN*uZN_PN);                                                                                       
LN_2K = LN_1K + (LN_uKH*uKH_1K) + (LN_uKN*uKN_1K) + (LN_uZH*uZH_1K) + (LN_uZN*uZN_1K);  
LN_PH = LN_1PH + (LN_uKH*uKH_PH) + (LN_uKN*uKN_PH) + (LN_uZH*uZH_PH) + (LN_uZN*uZN_PH); 
LN_PN = LN_1PN + (LN_uKH*uKH_PN) + (LN_uKN*uKN_PN) + (LN_uZH*uZH_PN) + (LN_uZN*uZN_PN); 

YH_2K = YH_1K + (YH_uKH*uKH_1K) + (YH_uKN*uKN_1K) + (YH_uZH*uZH_1K) + (YH_uZN*uZN_1K);   
YH_PH = YH_1PH + (YH_uKH*uKH_PH) + (YH_uKN*uKN_PH) + (YH_uZH*uZH_PH) + (YH_uZN*uZN_PH);  
YH_PN = YH_1PN + (YH_uKH*uKH_PN) + (YH_uKN*uKN_PN) + (YH_uZH*uZH_PN) + (YH_uZN*uZN_PN);                                                                                         
YN_2K = YN_1K + (YN_uKH*uKH_1K) + (YN_uKN*uKN_1K) + (YN_uZH*uZH_1K) + (YN_uZN*uZN_1K);   
YN_PH = YN_1PH + (YN_uKH*uKH_PH) + (YN_uKN*uKN_PH) + (YN_uZH*uZH_PH) + (YN_uZN*uZN_PH);  
YN_PN = YN_1PN + (YN_uKH*uKH_PN) + (YN_uKN*uKN_PN) + (YN_uZH*uZH_PN) + (YN_uZN*uZN_PN); 

KH_2K = KH_1K + (KH_uKH*uKH_1K) + (KH_uKN*uKN_1K) + (KH_uZH*uZH_1K) + (KH_uZN*uZN_1K);  
KH_PH = KH_1PH + (KH_uKH*uKH_PH) + (KH_uKN*uKN_PH) + (KH_uZH*uZH_PH) + (KH_uZN*uZN_PH); 
KH_PN = KH_1PN + (KH_uKH*uKH_PN) + (KH_uKN*uKN_PN) + (KH_uZH*uZH_PN) + (KH_uZN*uZN_PN);                                                                                         
KN_2K = KN_1K + (KN_uKH*uKH_1K) + (KN_uKN*uKN_1K) + (KN_uZH*uZH_1K) + (KN_uZN*uZN_1K);  
KN_PH = KN_1PH + (KN_uKH*uKH_PH) + (KN_uKN*uKN_PH) + (KN_uZH*uZH_PH) + (KN_uZN*uZN_PH); 
KN_PN = KN_1PN + (KN_uKH*uKH_PN) + (KN_uKN*uKN_PN) + (KN_uZH*uZH_PN) + (KN_uZN*uZN_PN); 

% Solving for traded and non-traded prices: PH,PN(K,Q)     
h11 = (YN_PH - CN_PH - JN_PH) - (KN*xi1N*uKN_PH);           
h12 = (YN_PN - CN_PN - JN_PN) - (KN*xi1N*uKN_PN);           
h21 = (YH_PH - CH_PH - JH_PH - XH_PH) - (KH*xi1H*uKH_PH);   
h22 = (YH_PN - CH_PN - JH_PN) - (KH*xi1H*uKH_PN);           
                                                            
% K,Q                                                       
k11 = -(YN_2K - JN_1K - (KN*xi1N*uKN_1K));                  
k12 = JN_1Q;                                                
k21 = -(YH_2K - JH_1K - (KH*xi1H*uKH_1K));                  
k22 = JH_1Q;                                                
                                                            
M3 = [h11 h12; h21 h22];                                    
X3 = [k11 k12; k21 k22];                                    
JST3 = inv(M3);                                             
MST3 = JST3*X3;                                             
                                                            
PH_K = MST3(1,1); PH_Q = MST3(1,2);                         
PN_K = MST3(2,1); PN_Q = MST3(2,2);                         

% Solving for capital-labor ratios kj=kj(K,Q) - 
% sectoral labor Lj=Lj(K,Q) - sectoral output 
% Yj=Yj(K,Q) - Final Solutions
kH_K = kH_2K + (kH_PH*PH_K) + (kH_PN*PN_K); 
kH_Q = (kH_PH*PH_Q) + (kH_PN*PN_Q); 
kN_K = kN_2K + (kN_PH*PH_K) + (kN_PN*PN_K);
kN_Q = (kN_PH*PH_Q) + (kN_PN*PN_Q); 

LH_K = LH_2K + (LH_PH*PH_K) + (LH_PN*PN_K); 
LH_Q = (LH_PH*PH_Q) + (LH_PN*PN_Q); 
LN_K = LN_2K + (LN_PH*PH_K) + (LN_PN*PN_K);
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);

YH_K = YH_2K + (YH_PH*PH_K) + (YH_PN*PN_K); 
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q); 
YN_K = YN_2K + (YN_PH*PH_K) + (YN_PN*PN_K);
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);

KH_K = KH_2K + (KH_PH*PH_K) + (KH_PN*PN_K); 
KH_Q = (KH_PH*PH_Q) + (KH_PN*PN_Q);         
KN_K = KN_2K + (KN_PH*PH_K) + (KN_PN*PN_K); 
KN_Q = (KN_PH*PH_Q) + (KN_PN*PN_Q);  

uKH_K = uKH_1K + (uKH_PH*PH_K) + (uKH_PN*PN_K);    
uKH_Q = (uKH_PH*PH_Q) + (uKH_PN*PN_Q);             
uKN_K = uKN_1K + (uKN_PH*PH_K) + (uKN_PN*PN_K);    
uKN_Q = (uKN_PH*PH_Q) + (uKN_PN*PN_Q);             
                                                   
uZH_K = uZH_1K + (uZH_PH*PH_K) + (uZH_PN*PN_K);    
uZH_Q = (uZH_PH*PH_Q) + (uZH_PN*PN_Q);             
uZN_K = uZN_1K + (uZN_PH*PH_K) + (uZN_PN*PN_K);    
uZN_Q = (uZN_PH*PH_Q) + (uZN_PN*PN_Q);             

% Solving for consumption Cj=Cj(lambda,K,Q,ZH,ZN), investment inputs 
% Jj=Jj(K,Q,ZH,ZN), imports MF=MF(lambda,K,Q,ZH,ZN), exports 
%XH=XH(lambda,K,Q,ZH,ZN)- Final Solutions
CH_K = (CH_PH*PH_K) + (CH_PN*PN_K); 
CH_Q = (CH_PH*PH_Q) + (CH_PN*PN_Q); 
CN_K = (CN_PH*PH_K) + (CN_PN*PN_K); 
CN_Q = (CN_PH*PH_Q) + (CN_PN*PN_Q); 
CF_K = (CF_PH*PH_K) + (CF_PN*PN_K); 
CF_Q = (CF_PH*PH_Q) + (CF_PN*PN_Q); 

JH_K  = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K); 
JH_Q  = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q); 
JN_K  = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K); 
JN_Q  = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q); 
JF_K  = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K); 
JF_Q  = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q); 

XH_K = XH_PH*PH_K; 
XH_Q = XH_PH*PH_Q; 
MF_K = (CF_K + JF_K); 
MF_Q = (CF_Q + JF_Q); 

% Marginal revenue of capital R = PH*partial YH/partial KH
R_K = (RK/PH)*PH_K - (RK/kH)*(sLH/sigmaH)*kH_K - RK*(sLH/sigmaH)*uKH_K; 
R_Q = (RK/PH)*PH_Q - (RK/kH)*(sLH/sigmaH)*kH_Q - RK*(sLH/sigmaH)*uKH_Q;  

% Solving for investment function I/K = v(Q/PI)+delta_K - final solution
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q); 
v_K  = (v_PN*PN_K) + (v_PH*PH_K); 

% Elements of the Jacobian Matrix 
Upsilon_K = (I/IN)*(YN_K-CN_K-(KN*xi1N*uKN_K)) - deltaK + alphaI*phiI*I*( (PN_K/PN) - (alphaIH/PH)*PH_K );                                                                        
Upsilon_Q = (I/IN)*(YN_Q-CN_Q-(KN*xi1N*uKN_Q)) + alphaI*phiI*I*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );
Sigma_K   = -(R_K-(RK/K)+(RK/K)*((KH*uKH_K)+(KN*uKN_K)+(KH*uZH_K)+(KN*uZN_K)+(KH_K+KN_K))-(PH*KH/K)*xi1H*uKH_K-(PN*KN/K)*xi1N*uKN_K + (PI*kappa*v_K*deltaK) ); 
Sigma_Q   = (r+deltaK)-( R_Q+(RK/K)*((KH*uKH_Q)+(KN*uKN_Q))+(RK/K)*((KH*uZH_Q)+(KN*uZN_Q))+(RK/K)*(KH_Q+KN_Q)-(PH*KH/K)*xi1H*uKH_Q-(PN*KN/K)*xi1N*uKN_Q + (PI*kappa*v_Q*deltaK) ); 
 
x11 = Upsilon_K;                                                                         
x12 = Upsilon_Q;                                                                                                                                                                                                                     
x21 = Sigma_K;                        
x22 = Sigma_Q;    
                                                                      
J = [x11 x12; x21 x22];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[ order] = sort(diag(),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1); 
nu_2 = nu_sorted(2,2); 
omega_11 = V_sorted(1,1)/V_sorted(1,1); 
omega_21 = V_sorted(2,1)/V_sorted(1,1); 
 
% Intertemporal solvency condition - lambda 
B_K   = (PH_K*XH) + (PH*XH_K) - MF_K; 
B_Q   = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
N1    = (B_K + (B_Q*omega_21));
H1    = N1/(nu_1-r); 
g(43) = (B - B0) - H1*(K-K0);



