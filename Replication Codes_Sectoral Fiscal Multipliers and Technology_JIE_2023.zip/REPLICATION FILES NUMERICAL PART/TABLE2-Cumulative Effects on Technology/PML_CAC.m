%clc
%clear

global sigma phi varphi beta
global gammaL sigmaL phiI varphiI
global r deltaK omegaG omegaGN
global ZT ZN ZT_0 ZN_0 thetaT thetaN kappa
global B0 K0 GT GN sigmaT sigmaN
global Y_0 barg xi chi
global xi1T xi2T xi1N xi2N chi1T chi2T chi1N chi2N 

% Maxim duration for graphics
Tg = 10;
       
% Minim duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% PML CAC kT>kN                                           %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ZT_0         = 1.00;  
ZN_0         = 1.00;
omegaG       = 0.191; 
omegaGN      = 0.8; 
thetaT_0     = 0.631; 
thetaN_0     = 0.687; 
sigmaL_0     = 1; 
gammaL       = 1; 
sigma        = 1.01; 
phi_0        = 0.77; 
varphi_0     = 0.463;                   
phiI_0       = 1.00001;                    
varphiI_0    = 0.31;   
kappa_0      = 17; 
  
r            = 0.03; 
beta         = r; 
deltaK       = 0.078;

B0           = 5; %13
K0           = 0;

ZT           = ZT_0;       
ZN           = ZN_0;       
thetaT       = thetaT_0;   
thetaN       = thetaN_0;    
sigmaL       = sigmaL_0;   
phi          = phi_0 ;     
varphi       = varphi_0;  
phiI         = phiI_0;    
varphiI      = varphiI_0; 
kappa        = kappa_0; 

sigmaT       = 1; 
sigmaN       = 1; 
                                                                                                                                                                                                                                 
chi2T    = 0.8; %0.7 technology utilization adjustment cost in the traded sector                                                                                                                          
chi2N    = 2.85;  % 4 technology utilization adjustment cost in the non-traded sector                                                                                                                         
xi2T     = 0.27;  %0.27 capital utilization adustment costs in the traded sector                                                                                                                              
xi2N     = 0.03;  % 0.02 capital utilization adustment costs in the non-traded sector
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C_ini        = 1.091   ; % Consumption                                                                                       
L_ini        = 1.083   ; % Labor supply                                                                                      
kT_ini       = 6.309   ; % Capital-labor ratio in sector T                                                                   
kN_ini       = 4.915   ; % Capital-labor ratio in sector N                                                                   
W_ini        = 1.245   ; % Aggregate wage index                                                                              
LT_ini       = 0.370   ; % Labor in sector T                                                                                 
LN_ini       = 0.730   ; % Labor in sector N                                                                                 
P_ini        = 1.101   ; % Relative price of non tradables                                                                   
K_ini        = 5.91   ; % Stock of capital                                                                                   
B_ini        = 0.11   ; % Stock of Traded Bonds                                                                            
CN_ini       = 0.518   ; % Consumption in non tradables                                                                      
CT_ini       = 0.558   ; % Consumption in tradables                                                                          
PC_ini       = 1.053   ; % Consumption price index                                                                           
alphaC_ini   = 0.460   ; % Tradables share of consumption expenditure                                                        
IN_ini       = 0.309   ; % Non traded investment                                                                             
IT_ini       = 0.153   ; % Traded investment    
PI_ini       = 1.069   ; % Investment price index 
alphaI_ini   = 0.32   ; % Tradable share of investment expenditure                                                                                                                                      
GT_ini       = 0.03    ; % Government spending in tradables                                                                  
GN_ini       = 0.21    ; % Government spending in non tradables                                                              
YT_ini       = 0.727   ; % Output per worker in sector T                                                                     
YN_ini       = 1.202   ; % Output per worker in sector N                                                                     
VL_ini       = 1.41   ; % Desutility labor                                                                                   
RK_ini       = 0.115  ; % Return on capital                                                                                  
xi1T_ini     = 0.1337 ; % Parameter of traded capital utilization cost function: xi1H*(uKH-1)+(xi2H/2)*(uKH-1)^2             
xi1N_ini     = 0.1065 ; % Parameter of non-traded capital utilization cost function                                          
chi1T_ini    = 0.752  ; % Parameter of traded technology utilization cost function: chi1H*(uZH-1)+(chi2H/2)*(uZH-1)^2        
chi1N_ini    = 1.153  ; % Parameter of non-traded technology utilization cost function                                       
lambda_ini   = 0.868   ; % Intertemporal Solvency Condition                                                                  
                                                          
x0 =[C_ini L_ini kT_ini kN_ini W_ini LT_ini LN_ini P_ini K_ini B_ini CN_ini CT_ini PC_ini alphaC_ini IN_ini IT_ini PI_ini alphaI_ini GT_ini GN_ini YT_ini YN_ini VL_ini RK_ini xi1T_ini xi1N_ini chi1T_ini chi1N_ini lambda_ini];
[x,fval,exitflag]=fsolve('TECH_PML_CAC_SS0',x0,optimset('display','off','TolFun',1e-011));

C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kT      = x(3)  ; % Capital-labor ratio in sector T
kN      = x(4)  ; % Capital-labor ratio in sector N
W       = x(5)  ; % Aggregate wage index
LT      = x(6) ; % Labor in sector T
LN      = x(7) ; % Labor in sector N 
P       = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
B       = x(10) ; % Stock of Traded Bonds
CN      = x(11) ; % Consumption in non tradables 
CT      = x(12) ; % Consumption in tradables 
PC      = x(13) ; % Consumption price index
alphaC  = x(14) ; % Non tradable share of consumption - alphaC
IN      = x(15) ; % Non tradable investment
IT      = x(16) ; % Tradable investment 
PI      = x(17) ; % Investment price index
alphaI  = x(18) ; % Non tradable share of investment 
GT      = x(19) ; % Government spending in tradables
GN      = x(20) ; % Government spending in non tradables 
YT      = x(21) ; % Output in sector T 
YN      = x(22) ; % Output in sector N 
VL      = x(23) ; % Labor disutility
RK      = x(24) ; % Return on capital
xi1T    = x(25) ; % Parameter of traded capital utilization cost function: xi1H*(uKH-1)+(xi2H/2)*(uKH-1)^2
xi1N    = x(26) ; % Parameter of non-traded capital utilization cost function
chi1T   = x(27) ; % Parameter of traded technology utilization cost function: chi1H*(uZH-1)+(chi2H/2)*(uZH-1)^2
chi1N   = x(28) ; % Parameter of non-traded technology utilization cost function
lambda  = x(29) ; % Intertemporal Solvency Condition    

% Shares
alphaC_check = (varphi*(1/PC)^(1-phi));
alphaI_check = (varphiI*(1/PI)^(1-phiI));
alphaL = (W*LT)/(W*L); 

% Sectoral outputs and sectoral profits   
PT = 1; 
KT  = LT*kT;  
RK_check  = (1-thetaT)*(YT/KT);
WT  = thetaT*(YT/LT); 
PiT = YT - (RK*KT) - (WT*LT);
  
KN  = LN*kN;  
WN  = P*thetaN*(YN/LN);
PiN = (P*YN) - (RK*KN) - (WN*LN);

% Labor income share in the traded good and non traded good sector
sLT = WT*LT/(YT);
sLN = WN*LN/(P*YN); 
Y   = YT + (P*YN); 
sL  = W*L/Y; 
k   = K/L; 

% Technology
omegaYT = YT/Y; 
ZA  = (ZT^omegaYT)*(ZN^(1-omegaYT));

% Capital Rental Rates
RKT = (1-thetaT)*(YT/KT);
RKN = P*(1-thetaN)*(YN/KN);

% Sep preferences
C_1P = -(1-alphaC)*(C/P); 
C_1lambda = -(C/lambda); 
C_W      = 0; 
C_1uZT   = 0; 
C_1uZN   = 0; 
L_W      = sigmaL*(L/W); 
L_1P     = 0; 
L_1uZT   = sigmaL*L*alphaL; 
L_1uZN   = sigmaL*L*(1-alphaL);
L_1lambda = sigmaL*(L/lambda); 
U_C      = C^(-1); 
U_L      = -gammaL*(L^(1/sigmaL)); 

% Intermediate solution for CN, CT - Cj=Cj(lambda,P,W)
CN_1P = -(CN/P)*(alphaC*phi) + (CN/C)*C_1P;
CN_W  = (CN/C)*C_W;
CN_1uZT  = (CN/C)*C_1uZT;
CN_1uZN  = (CN/C)*C_1uZN;
CN_1lambda = (CN/C)*C_1lambda;

CT_1P = (CT/P)*phi*(1-alphaC) + (CT/C)*C_1P;
CT_W  = (CT/C)*C_W;
CT_1uZT  = (CT/C)*C_1uZT;
CT_1uZN  = (CT/C)*C_1uZN;
CT_1lambda = (CT/C)*C_1lambda;

% Solutions for kj=kj(P,Zj)
d11 = -(thetaT/kT);
d12 = (thetaN/kN);
d21 = (1-thetaT)/kT;
d22 = -(1-thetaN)/kN;

% P, uKT, uKN
e11 = (1/P);
e12 = thetaT;
e13 = -thetaN;

e21 = (1/P);
e22 = -(1-thetaT);
e23 = (1-thetaN);

M2 = [d11 d12; d21 d22];
X2 = [e11 e12 e13; e21 e22 e23];
JST2 = inv(M2);
MST2 = JST2*X2;
kT_1P = MST2(1,1); kT_uKT = MST2(1,2); kT_uKN = MST2(1,3);
kN_1P = MST2(2,1); kN_uKT = MST2(2,2); kN_uKN = MST2(2,3);

% Solution for W=W(P,uKT,uKN),
W_1P  = (1-thetaT)*(W/kT)*kT_1P;
W_uKT = (1-thetaT)*(W/kT)*kT_uKT + (1-thetaT)*W;
W_uKN = (1-thetaT)*(W/kT)*kT_uKN;

% Solution for ,C(lambda,P,uKT,uKN,uZT,uZN)
L_2P  = L_1P + (L_W*W_1P);
L_uKT = (L_W*W_uKT);
L_uKN = (L_W*W_uKN);
L_uZT = L_1uZT;
L_uZN = L_1uZN;

% Consumption C(lambda,K,P)
C_2P  = C_1P + (C_W*W_1P);
C_uKT = (C_W*W_uKT);
C_uKN = (C_W*W_uKN);
C_uZT = C_1uZT;
C_uZN = C_1uZN;

% Solution for Cj(lambda,P,uKT,uKN,uZT,uZN)
CN_2P  = CN_1P + (CN_W*W_1P);
CN_uKT = (CN_W*W_uKT);
CN_uKN = (CN_W*W_uKN);
CN_uZT = CN_1uZT;
CN_uZN = CN_1uZN;

CT_2P  = CT_1P + (CT_W*W_1P);
CT_uKT = (CT_W*W_uKT);
CT_uKN = (CT_W*W_uKN);
CT_uZT = CT_1uZT;
CT_uZN = CT_1uZN;

% Solutions for Lj=Lj(K,P,uKT,uKN,uZT,uZN,lambda)
Psi_P   = ( (LT*kT_1P) + (LN*kN_1P) );
Psi_uKT = ( (LT*kT_uKT) + (LN*kN_uKT) );
Psi_uKN = ( (LT*kT_uKN) + (LN*kN_uKN) );

f11 = 1;             % LT
f12 = 1;             % LN
f21 = kT;            % LT
f22 = kN;            % LN

% K, P, uKT, uKN, uZT, uZN, lambda
g11 = 0;             % K
g12 = L_2P;          % P
g13 = L_uKT;         % uKT
g14 = L_uKN;         % uKN
g15 = L_uZT;         % uZT
g16 = L_uZN;         % uZN
g17 = L_1lambda;     % lambda

g21 = 1;             % K
g22 = -Psi_P;        % P
g23 = -Psi_uKT;      % uKT
g24 = -Psi_uKN;      % uKN
g25 = 0;             % uZT
g26 = 0;             % uZN
g27 = 0;             % lambda

M3 = [f11 f12; f21 f22];
X3 = [g11 g12 g13 g14 g15 g16 g17; g21 g22 g23 g24 g25 g26 g27];
JST3 = inv(M3);
MST3 = JST3*X3;
LT_1K = MST3(1,1); LT_1P = MST3(1,2); LT_uKT = MST3(1,3); LT_uKN = MST3(1,4); LT_uZT = MST3(1,5); LT_uZN = MST3(1,6); LT_1lambda = MST3(1,7);
LN_1K = MST3(2,1); LN_1P = MST3(2,2); LN_uKT = MST3(2,3); LN_uKN = MST3(2,4); LN_uZT = MST3(2,5); LN_uZN = MST3(2,6); LN_1lambda = MST3(2,7);

% Solutions for sectoral sectoral output Yj=Yj(K,P,uKT,uKN,uZT,uZN,lambda)
YT_1P  = YT*( (LT_1P/LT) + (1-thetaT)*(kT_1P/kT) );
YT_1K  = YT*(LT_1K/LT);
YT_uKT = YT*( (LT_uKT/LT) + (1-thetaT)*(kT_uKT/kT) + (1-thetaT) );
YT_uKN = YT*( (LT_uKN/LT) + (1-thetaT)*(kT_uKN/kT) );
YT_uZT = YT*(LT_uZT/LT);
YT_uZN = YT*(LT_uZN/LT);
YT_1lambda = YT*(LT_1lambda/LT);

YN_1P  = YN*( (LN_1P/LN) + (1-thetaN)*(kN_1P/kN) );
YN_1K  = YN*(LN_1K/LN);
YN_uKT = YN*( (LN_uKT/LN) + (1-thetaN)*(kN_uKT/kN) );
YN_uKN = YN*( (LN_uKN/LN) + (1-thetaN)*(kN_uKN/kN) + (1-thetaN) );
YN_uZT = YN*(LN_uZT/LN);
YN_uZN = YN*(LN_uZN/LN);
YN_1lambda = YN*(LN_1lambda/LN);

% Solving for capital and technology utilization rates: uKT, uKN, uZT, uZN; uKj,uZj(P,K,lambda)
f11 = ((xi2T/xi1T) + thetaT) + thetaT*(kT_uKT/kT);
f12 = thetaT*(kT_uKN/kT);
f13 = -1;
f14 = 0;
f21 = thetaN*(kN_uKT/kN);
f22 = ((xi2N/xi1N) + thetaN) + thetaN*(kN_uKN/kN);
f23 = 0;
f24 = -1;
f31 = -YT_uKT/YT;
f32 = -YT_uKN/YT;
f33 = (chi2T/chi1T)-(YT_uZT/YT);
f34 = -YT_uZN/YT;
f41 = -YN_uKT/YN;
f42 = -YN_uKN/YN;
f43 = -YN_uZT/YN;
f44 = (chi2N/chi1N)-(YN_uZN/YN);

% P, K, lambda
g11 = -thetaT*(kT_1P/kT);
g12 = 0;
g13 = 0;

g21 = -thetaN*(kN_1P/kN);
g22 = 0;
g23 = 0;

g31 = YT_1P/YT;
g32 = YT_1K/YT;
g33 = YT_1lambda/YT;

g41 = YN_1P/YN;
g42 = YN_1K/YN;
g43 = YN_1lambda/YN;

M4 = [f11 f12 f13 f14; f21 f22 f23 f24; f31 f32 f33 f34; f41 f42 f43 f44];
X4 = [g11 g12 g13; g21 g22 g23; g31 g32 g33; g41 g42 g43];
JST4 = inv(M4);
MST4 = JST4*X4;

uKT_P = MST4(1,1); uKT_1K = MST4(1,2); uKT_1lambda = MST4(1,3);
uKN_P = MST4(2,1); uKN_1K = MST4(2,2); uKN_1lambda = MST4(2,3);
uZT_P = MST4(3,1); uZT_1K = MST4(3,2); uZT_1lambda = MST4(3,3);
uZN_P = MST4(4,1); uZN_1K = MST4(4,2); uZN_1lambda = MST4(4,3);

% Solving for sectoral labor and sectoral output - kj,Lj,yj,Yj,Kj(lambda,K,P)
kT_1K = (kT_uKT*uKT_1K) + (kT_uKN*uKN_1K);
kT_P  = kT_1P + (kT_uKT*uKT_P) + (kT_uKN*uKN_P);
kT_1lambda = (kT_uKT*uKT_1lambda) + (kT_uKN*uKN_1lambda);

kN_1K = (kN_uKT*uKT_1K) + (kN_uKN*uKN_1K);
kN_P  = kN_1P + (kN_uKT*uKT_P) + (kN_uKN*uKN_P);
kN_1lambda = (kN_uKT*uKT_1lambda) + (kN_uKN*uKN_1lambda);

LT_2K = LT_1K + (LT_uKT*uKT_1K) + (LT_uKN*uKN_1K) + (LT_uZT*uZT_1K) + (LT_uZN*uZN_1K);
LT_P  = LT_1P + (LT_uKT*uKT_P) + (LT_uKN*uKN_P) + (LT_uZT*uZT_P) + (LT_uZN*uZN_P);
LT_2lambda = LT_1lambda + (LT_uKT*uKT_1lambda) + (LT_uKN*uKN_1lambda) + (LT_uZT*uZT_1lambda) + (LT_uZN*uZN_1lambda);

LN_2K = LN_1K + (LN_uKT*uKT_1K) + (LN_uKN*uKN_1K) + (LN_uZT*uZT_1K) + (LN_uZN*uZN_1K);
LN_P  = LN_1P + (LN_uKT*uKT_P) + (LN_uKN*uKN_P) + (LN_uZT*uZT_P) + (LN_uZN*uZN_P);
LN_2lambda = LN_1lambda + (LN_uKT*uKT_1lambda) + (LN_uKN*uKN_1lambda) + (LN_uZT*uZT_1lambda) + (LN_uZN*uZN_1lambda);

YT_2K = YT_1K + (YT_uKT*uKT_1K) + (YT_uKN*uKN_1K) + (YT_uZT*uZT_1K) + (YT_uZN*uZN_1K);
YT_P = YT_1P + (YT_uKT*uKT_P) + (YT_uKN*uKN_P) + (YT_uZT*uZT_P) + (YT_uZN*uZN_P);
YT_2lambda = YT_1lambda + (YT_uKT*uKT_1lambda) + (YT_uKN*uKN_1lambda) + (YT_uZT*uZT_1lambda) + (YT_uZN*uZN_1lambda);

YN_2K = YN_1K + (YN_uKT*uKT_1K) + (YN_uKN*uKN_1K) + (YN_uZT*uZT_1K) + (YN_uZN*uZN_1K);
YN_P = YN_1P + (YN_uKT*uKT_P) + (YN_uKN*uKN_P) + (YN_uZT*uZT_P) + (YN_uZN*uZN_P);
YN_2lambda = YN_1lambda + (YN_uKT*uKT_1lambda) + (YN_uKN*uKN_1lambda) + (YN_uZT*uZT_1lambda) + (YN_uZN*uZN_1lambda);

CT_1K = (CT_uKT*uKT_1K) + (CT_uKN*uKN_1K) + (CT_uZT*uZT_1K) + (CT_uZN*uZN_1K);
CT_P  = CT_2P + (CT_uKT*uKT_P) + (CT_uKN*uKN_P) + (CT_uZT*uZT_P) + (CT_uZN*uZN_P);
CT_2lambda = CT_1lambda + (CT_uKT*uKT_1lambda) + (CT_uKN*uKN_1lambda) + (CT_uZT*uZT_1lambda) + (CT_uZN*uZN_1lambda);

CN_1K = (CN_uKT*uKT_1K) + (CN_uKN*uKN_1K) + (CN_uZT*uZT_1K) + (CN_uZN*uZN_1K);
CN_P  = CN_2P + (CN_uKT*uKT_P) + (CN_uKN*uKN_P) + (CN_uZT*uZT_P) + (CN_uZN*uZN_P);
CN_2lambda = CN_1lambda + (CN_uKT*uKT_1lambda) + (CN_uKN*uKN_1lambda) + (CN_uZT*uZT_1lambda) + (CN_uZN*uZN_1lambda);

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI);
v_P  = - (1-alphaI)/(kappa*P);

% Solution for J = J(K,Q,PN,PH)
J_1K = deltaK;
J_1Q = K*v_1Q;
J_P = K*v_P;

% Solution for JN, JT - Jj=Jj(P,K,Q)
I     = deltaK*K;
JN_P  = -(IN/P)*(phiI*alphaI) + (IN/I)*J_P;
JN_1K = (IN/I)*J_1K;
JN_1Q = (IN/I)*J_1Q;

JT_P  =  (IT/P)*phiI*(1-alphaI) + (IT/I)*J_P;
JT_1K = (IT/I)*J_1K;
JT_1Q = (IT/I)*J_1Q;

% R=R(lambda,K,P)                                          
R_1K  = -RK*thetaT*(uKT_1K + (kT_1K/kT));                  
R_P   = -RK*thetaT*(uKT_P + (kT_P/kT));                    
R_1lambda  = -RK*thetaT*(uKT_1lambda + (kT_1lambda/kT));   

% Labor L(lambda,K,P)
L_1K = (L_uKT*uKT_1K) + (L_uKN*uKN_1K) + (L_uZT*uZT_1K) + (L_uZN*uZN_1K);
L_P  = L_2P + (L_uKT*uKT_P) + (L_uKN*uKN_P) + (L_uZT*uZT_P) + (L_uZN*uZN_P);
L_2lambda = L_1lambda + (L_uKT*uKT_1lambda) + (L_uKN*uKN_1lambda) + (L_uZT*uZT_1lambda) + (L_uZN*uZN_1lambda);

% Sectoral Capital stock Kj(lambda,K,P)
KT_1K = (LT_2K*kT) + (LT*kT_1K);
KT_P  = (LT_P*kT) + (LT*kT_P);
KT_1lambda = (LT_2lambda*kT) + (LT*kT_1lambda);

KN_1K = (LN_2K*kN) + (LN*kN_1K);
KN_P  = (LN_P*kN) + (LN*kN_P);
KN_1lambda =(LN_2lambda*kN) + (LN*kN_1lambda);

C_1K = (C_uKT*uKT_1K) + (C_uKN*uKN_1K) + (C_uZT*uZT_1K) + (C_uZN*uZN_1K);
C_P  = C_2P + (C_uKT*uKT_P) + (C_uKN*uKN_P) + (C_uZT*uZT_P) + (C_uZN*uZN_P);
C_2lambda = C_1lambda + (C_uKT*uKT_1lambda) + (C_uKN*uKN_1lambda) + (C_uZT*uZT_1lambda) + (C_uZN*uZN_1lambda);

% W(lambda,K,P)
W_1K = (W_uKT*uKT_1K) + (W_uKN*uKN_1K);
W_P  = W_1P + (W_uKT*uKT_P) + (W_uKN*uKN_P);
W_1lambda = (W_uKT*uKT_1lambda) + (W_uKN*uKN_1lambda);

% Partial Derivatives Gj=Gj(G)
GN_G   = omegaGN/P;
GT_G   = (1-omegaGN);

% Solving for the relative price P=P(lambda,K,Q,G)
DeltaP   = (YN_P - CN_P - JN_P) - (KN*xi1N*uKN_P);
P_K      = -(1/DeltaP)*(YN_2K - CN_1K - JN_1K - (KN*xi1N*uKN_1K));
P_Q      = (JN_1Q/DeltaP);
P_G      = GN_G/DeltaP;
P_lambda = -(1/DeltaP)*(YN_2lambda - CN_2lambda - (KN*xi1N*uKN_1lambda));

% Solving for capital-labor ratios kj=kj(K,Q,G,Aj,Bj) -
% sectoral labor Lj=Lj(K,Q,G,Aj,Bj) - sectoral output
% Yj=Yj(K,Q,G,Aj,Bj) - Final Solutions
kT_K = kT_1K + (kT_P*P_K);
kT_Q = (kT_P*P_Q);
kT_G = (kT_P*P_G);
kT_lambda = kT_1lambda + (kT_P*P_lambda);

kN_K = kN_1K + (kN_P*P_K);
kN_Q = (kN_P*P_Q) ;
kN_G = (kN_P*P_G);
kN_lambda = kN_1lambda + (kN_P*P_lambda);

LT_K  = LT_2K + (LT_P*P_K);
LT_Q  = (LT_P*P_Q);
LT_G  = (LT_P*P_G);
LT_lambda = LT_2lambda + (LT_P*P_lambda);

LN_K = LN_2K + (LN_P*P_K);
LN_Q = (LN_P*P_Q);
LN_G = (LN_P*P_G);
LN_lambda = LN_2lambda + (LN_P*P_lambda);

YT_K = YT_2K + (YT_P*P_K);
YT_Q = (YT_P*P_Q);
YT_G = (YT_P*P_G);
YT_lambda = YT_2lambda + (YT_P*P_lambda);

YN_K = YN_2K + (YN_P*P_K);
YN_Q = (YN_P*P_Q) ;
YN_G = (YN_P*P_G) ;
YN_lambda = YN_2lambda + (YN_P*P_lambda);

uKT_K  = uKT_1K + (uKT_P*P_K);
uKT_Q  = (uKT_P*P_Q);
uKT_G  = (uKT_P*P_G);
uKT_lambda = uKT_1lambda + (uKT_P*P_lambda);

uKN_K = uKN_1K + (uKN_P*P_K);
uKN_Q = (uKN_P*P_Q);
uKN_G = (uKN_P*P_G);
uKN_lambda = uKN_1lambda + (uKN_P*P_lambda);

uZT_K  = uZT_1K + (uZT_P*P_K);
uZT_Q  = (uZT_P*P_Q);
uZT_G  = (uZT_P*P_G);
uZT_lambda = uZT_1lambda + (uZT_P*P_lambda);

uZN_K = uZN_1K + (uZN_P*P_K);
uZN_Q = (uZN_P*P_Q);
uZN_G = (uZN_P*P_G);
uZN_lambda = uZN_1lambda + (uZN_P*P_lambda);

% Solving for consumption Cj=Cj(lambda,K,Q,G), investment inputs
% Jj=Jj(K,Q,G)
CT_K      = CT_1K + (CT_P*P_K);
CT_Q      = (CT_P*P_Q);
CT_G      = (CT_P*P_G);
CT_lambda = CT_2lambda + (CT_P*P_lambda);

CN_K      = CN_1K + (CN_P*P_K);
CN_Q      = (CN_P*P_Q);
CN_G      = (CN_P*P_G);
CN_lambda = CN_2lambda + (CN_P*P_lambda);

JT_K       = JT_1K + (JT_P*P_K);
JT_Q       = JT_1Q + (JT_P*P_Q);
JT_G       = (JT_P*P_G);
JT_lambda  = (JT_P*P_lambda);

JN_K       = JN_1K + (JN_P*P_K);
JN_Q       = JN_1Q + (JN_P*P_Q);
JN_G       = (JN_P*P_G);
JN_lambda  = (JN_P*P_lambda);

v_K        = (v_P*P_K);
v_Q        = v_1Q + (v_P*P_Q);
v_G        = (v_P*P_G);
v_lambda   = (v_P*P_lambda);

R_K = R_1K + (R_P*P_K);                 
R_Q = (R_P*P_Q);                       
R_G = (R_P*P_G);                       
R_lambda = R_1lambda + (R_P*P_lambda);  

KT_K = KT_1K + (KT_P*P_K);
KT_Q = (KT_P*P_Q);
KT_G = (KT_P*P_G);
KT_lambda = KT_1lambda + (KT_P*P_lambda);

KN_K = KN_1K + (KN_P*P_K);
KN_Q = (KN_P*P_Q) ;
KN_G = (KN_P*P_G) ;
KN_lambda = KN_1lambda + (KN_P*P_lambda);

% Elements of the Jacobian Matrix
Upsilon_K = (I/IN)*(YN_K-CN_K-(KN*xi1N*uKN_K)) - deltaK + alphaI*phiI*I*(P_K/P);
Upsilon_Q = (I/IN)*(YN_Q-CN_Q-(KN*xi1N*uKN_Q)) + alphaI*phiI*I*(P_Q/P);
Sigma_K   = -(R_K-(RK/K)+(RK/K)*((KT*uKT_K)+(KN*uKN_K)+(KT*uZT_K)+(KN*uZN_K)+(KT_K+KN_K))-(KT/K)*xi1T*uKT_K-(P*KN/K)*xi1N*uKN_K + (PI*kappa*v_K*deltaK) );
Sigma_Q   = (r+deltaK)-( R_Q+(RK/K)*((KT*uKT_Q)+(KN*uKN_Q))+(RK/K)*((KT*uZT_Q)+(KN*uZN_Q))+(RK/K)*(KT_Q+KN_Q)-(KT/K)*xi1T*uKT_Q-(P*KN/K)*xi1N*uKN_Q + (PI*kappa*v_Q*deltaK) );

x11 = Upsilon_K;
x12 = Upsilon_Q;
x21 = Sigma_K;
x22 = Sigma_Q;

J = [x11 x12; x21 x22];
[V,nu]=eig(J);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu1 = nu_sorted(1,1);
nu2 = nu_sorted(2,2);
omega11 = V_sorted(1,1)/V_sorted(1,1);
omega21 = V_sorted(2,1)/V_sorted(1,1);
omega12 = V_sorted(1,2)/V_sorted(1,2);
omega22 = V_sorted(2,2)/V_sorted(1,2);

TrJ  = trace(J);
DetJ = det(J);

% Intertemporal solvency condition - lambda
B_K   = (YT_K - CT_K - JT_K) - (KT*xi1T*uKT_K);
B_Q   = (YT_Q - CT_Q - JT_Q) - (KT*xi1T*uKT_Q);
N1    = (B_K + (B_Q*omega21));
H1    = N1/(nu1-r);

% Solutions for L,C,KT,KN,W,R(K,Q,G,lambda)
L_K = L_1K + (L_P*P_K);
L_Q = (L_P*P_Q) ;
L_G = (L_P*P_G) ;
L_lambda = L_2lambda + (L_P*P_lambda);

C_K = C_1K + (C_P*P_K);
C_Q = (C_P*P_Q) ;
C_G = (C_P*P_G) ;
C_lambda = C_2lambda + (C_P*P_lambda);

W_K = W_1K + (W_P*P_K);
W_Q = (W_P*P_Q) ;
W_G = (W_P*P_G) ;
W_lambda = W_1lambda + (W_P*P_lambda);

% Government spending 
G  = GT+ (P*GN);   

% Investment 
I_check = ( (varphiI^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-varphiI)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1)); 
I = deltaK*K; 
EI = PI*I; 
omegaI = PI*I/Y; 

% Net exports, current account and saving
NX  = YT-CT-GT-IT; 
CA  = (r*B) + YT - CT - GT - IT; 
A   = B + (PI*K); 
Tax = GT + (P*GN); 
Sav = (r*A) + (W*L) - (PC*C) - Tax; 

% Real Aggregate Wage 
WPC  = W/PC;
WTPC = WT/PC;
WNPC = WN/PC;
RKPC = RK/PC;

% Labor income and Capital income shares
EL      = W*L; 
omegaL  = EL/Y; 
EK      = RK*K; 
omegaK  = EK/Y;
alphaK  = (RKT*KT)/(RK*K); 

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WT); 
YTYN  = (YT/YN); 
LTLN  = (LT/LN);

% Consumption 
C_check = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1)); 

% Unit Cost or Producing   
UCT = ((W/thetaT)^thetaT)*((RK/(1-thetaT))^(1-thetaT));   
UCN = ((W/thetaN)^thetaN)*((RK/(1-thetaN))^(1-thetaN));    

% Sectoral ratios
omegaINYN = IN/YN; 
omegaITYT = IT/YT; 
omegaGTYT =  GT / YT;
omegaGNYN =  GN / (YN);
omegaGN   =  (P*GN) / G;
omegaYN   =  (P*YN)/Y; 
omegaLT   =  LT / L;
omegaLN   =  LN / L; 

% Targeted ratios
omegaC    =  (PC*C) / Y;
omegaNX   =  NX / Y; 
omegaG    =  (GT+P*GN)/Y;
omegaB    = (r*B)/Y; 
omegaKY   = K/Y; 

% Check the closure of the model
cond1  = (1-thetaT)*(YT/KT)-RK;                               
cond2  = P*(1-thetaN)*(YN/KN)-RK;                             
cond3  = thetaT*(YT/LT)-WT;                                   
cond4  = P*thetaN*(YN/LN)-WN;                                 
cond5  = (LT*kT)+(LN*kN)-K;                                   
cond6  = RK-(deltaK+r)*PI;                                    
cond7  = YN-CN-GN-IN;                                         
cond8  = YT-CT-GT-IT+(r*B);                                   
cond9  = (B-B0) - H1*(K-K0);                                  
cond10 = DetJ - (nu1*nu2);                                   
cond11 = TrJ - (nu1+nu2);                                     
cond12 = (LT+LN) - L;  
cond13 = (CT/CN) - (varphi/(1-varphi))*P^(phi);               
cond14 = (PC*C) - (CT+(P*CN));                                
cond15 = (W*L) - ((WT*LT)+(WN*LN));                                        
cond16 = Y - (PC*C) - G - (PI*I) + (r*B);                     
cond17 = Sav;                                                 
cond18 = (PC*C) - (CT+(P*CN));                                
cond19 = (IT/IN) - (varphiI/(1-varphiI))*P^(phiI);            
cond20 = (PI*I) - (IT+(P*IN));                                
cond21 = (RK*K) - ((RKT*KT)+(RKN*KN));                        
cond22 = 1 - (omegaK + omegaL);  
cond23 = -U_L - (lambda*WT);                                              
cond24 = -U_L - (lambda*WN); 
cond25 = alphaC - alphaC_check;        
cond26 = alphaI - alphaI_check;        
cond27 = UCT - PT;                     
cond28 = UCN - P;                      
 
disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                     Initial Steady State with kT > kN');
disp('                           The Benchmark: ');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (benchmark)');
disp(sprintf('thetaT  : %5.2f   thetaN   : %5.2f',thetaT,thetaN));
disp(sprintf('phi     : %5.2f   varphi   : %5.2f',phi,varphi));  
disp(sprintf('phiI    : %5.2f   iota     : %5.2f',phiI,varphiI)); 
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f sigma   : %5.2f',sigmaL,gammaL,sigma));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('ZT      : %5.2f   ZN       : %5.2f',ZT,ZN));
disp(sprintf('GT      : %5.2f   GN       : %5.2f  G      : %5.2f',GT,GN,G));
disp(' ');

disp(' ');
disp('The production side (benchmark)');
disp(sprintf('kT       : %9.3f    kN   : %9.3f',kT,kN));
disp(sprintf('LT       : %9.3f    LN   : %9.3f',LT,LN));
disp(sprintf('KT       : %9.3f    KN   : %9.3f',KT,KN));
disp(sprintf('YT       : %9.3f    YN   : %9.3f',YT,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('alphaL   : %9.3f   ',alphaL));

disp(' ');
disp('The demand side (benchmark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('CT       :   %7.3f    CN     : %9.3f',CT,CN));

disp('The demand side (benchmark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('IT       :   %7.3f    IN     : %9.3f',IT,IN));
disp(sprintf('EI       :   %7.3f',EI));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector T');
disp(sprintf('Gross output (YT)  : %9.3f',YT));
disp(sprintf('WT                 : %9.3f',WT));
disp(sprintf('Profit             : %9.10f',PiT));

disp(' ');
disp('Partial derivatives CT and CN');
disp(sprintf('CN_P  :   %7.3f    CT_P    : %9.3f',CN_P,CT_P));

disp('Partial derivatives LT and LN');                                                                                             
disp(sprintf('LN_K        :   %7.3f  LT_K       : %9.3f',LN_K,LT_K));                                                              
disp(sprintf('LN_P        :   %7.3f  LT_P       : %9.3f',LN_P,LT_P));                                                              
disp(sprintf('LN_lamb     :   %7.3f  LT_lamb    : %9.3f',LN_lambda,LT_lambda));                                                    
disp(sprintf('LN_G         :   %7.3f  LT_G      : %9.3f',LN_G,LT_G));                                                              
                                                                                                                                   
disp('Partial derivatives kT and kN');                                                                                             
disp(sprintf('kN_P       :   %7.6f  kT_P       : %9.6f',kN_P,kT_P));                                                               
disp(sprintf('kN_G       :   %7.6f  kT_G      : %9.6f',kN_G,kT_G));                                                                
                                                                                                                                   
disp('Partial derivatives C');                                                                                                     
disp(sprintf('YN_P       :   %7.6f  YT_P       : %9.6f',YN_P,YT_P));                                                               
disp(sprintf('YN_K       :   %7.6f  YT_K       : %9.6f',YN_K,YT_K));                                                               
disp(sprintf('YN_lambda  :   %7.3f  YT_lambda  : %9.3f',YN_lambda,YT_lambda));                                                     
disp(sprintf('YN_G      :   %7.6f  YT_G      : %9.6f',YN_G,YT_G));                                                                 
                                                                                                                                   
disp('Partial derivatives of L');                                                                                                  
disp(sprintf('L_K        :   %7.3f  L_Q        : %9.3f',L_K,L_Q));                                                                 
disp(sprintf('L_G        :   %7.3f',L_G));                                                                                         
disp(sprintf('L_lambda   :   %7.3f  L_W        : %9.3f',L_lambda,L_W));                                                            
disp(sprintf('W_K        :   %7.3f  W_Q        : %9.3f',W_K,W_Q));                                                                 
disp(sprintf('W_G        :   %7.3f',W_G));                                                                                         
                                                                                                                                                                                                                                                                     
disp(' ');                                                                                                                         
disp('Wealth');                                                                                                                    
disp(sprintf('K      :   %5.3f    B  :   %5.6f',K,B));                                                                             
disp(sprintf('lambda :   %5.15f   A  :   %5.3f',lambda,A));                                                                        
disp(sprintf('Sav    :   %5.10f   CA :   %5.10f',Sav,CA));                                                                         
                                                                                                                                   
disp(' ');                                                                                                                         
disp('Linearization');                                                                                                             
disp(sprintf('R_Q       :  %5.4f  R_Q       : %5.4f',R_K,R_Q));                                                                    
disp(sprintf('R_G       :  %5.4f',R_G));                                                                                           
disp(sprintf('DeltaP    :  %5.4f  P_K       : %5.4f   P_Q     : %5.4f',DeltaP,P_K,P_Q));                                           
disp(sprintf('P_G       :  %5.4f',P_G));                                                                                           
disp(sprintf('v_K       :  %5.4f  v_Q       : %5.4f',v_K,v_Q));                                                                    
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_Q : %5.4f',Upsilon_K,Upsilon_Q));                                                        
disp(sprintf('Sigma_K   :  %5.4f  Sigma_Q : %5.4f',Sigma_K,Sigma_Q));                                                              
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));                                                                    
                                                                                                                                   
disp(' ');                                                                                                                         
disp('Eigenvalues and Eigenvectors');                                                                                              
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));                                                                 
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));                                                                 
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu1,nu2));                                                                 
disp(sprintf('omega11    :   %5.6f  omega12    : %5.6f',omega11,omega12));                                                         
disp(sprintf('omega21    :   %5.6f  omega22    : %5.6f',omega21,omega22));                                                         
disp(sprintf('N1         :   %5.6f    H1       : %5.6f',N1,H1));                                                                   
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));                                                                

disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('YT / Y    :  %5.3f      P*YN / Y  : %5.3f',omegaYT,omegaYN));
disp(sprintf('LT / L    :  %5.3f      LN / L    : %5.3f',omegaLT,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('P*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GT / YT   :  %5.3f  GN / YN  : %5.3f  (P*GN)/G  : %5.3f',omegaGTYT,omegaGNYN,omegaGN));
disp(sprintf('IN / YN   :  %5.3f  IT / YT  :  %5.3f  (r*B)/Y  : %5.3f',omegaINYN,omegaITYT,omegaB));
disp(sprintf('WT*LT/W*L :  %5.3f RT*KT/R*K :  %5.3f',alphaL,alphaK));
disp(sprintf('IT/PI*I :  %5.3f CT/PC*C :  %5.3f',alphaI,alphaC));
disp(sprintf('W*L/P*Y   :  %5.3f R*K/P*Y   :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y       :  %5.3f',omegaKY));

disp(' ');
disp(sprintf('Marginal product of KT = RT       : %9.16f   ',cond1));
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));
disp(sprintf('Marginal product of LT = WT       : %9.16f   ',cond3));
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));
disp(sprintf('Resource contraint for capital    : %9.16f   ',cond5));
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));
disp(sprintf('Market clearing condition good T  : %9.16f   ',cond8));
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));
disp(sprintf('Resource constraint for labor     : %9.16f   ',cond12));
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));
disp(sprintf('Global market clearing condition  : %9.16f   ',cond16));
disp(sprintf('Private Savings                   : %9.16f   ',cond17));
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond18));
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond19));
disp(sprintf('Investment expenditure check      : %9.16f   ',cond20));
disp(sprintf('Capital income R*K                : %9.16f   ',cond21));
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond22));
disp(sprintf('-U_L = lambda*WT                  : %9.16f   ',cond23));
disp(sprintf('-U_L = lambda*WN                  : %9.16f   ',cond24));
disp(sprintf('alphaC - alphaC_check             : %9.16f   ',cond25));       
disp(sprintf('alphaI - alphaI_check             : %9.16f   ',cond26));       
disp(sprintf('UCT - PT;                         : %9.16f   ',cond27));       
disp(sprintf('UCN - P;                          : %9.16f   ',cond28));       

kT_0 = kT;  kN_0 = kN; P_0 = P; K_0 = K; C_0 = C;  
L_0 = L; W_0 = W; YT_0  = YT; YN_0  = YN; Y_0  = Y; G_0 = G;     
PC_0 = PC; CN_0 = CN; CT_0 = CT;  
ZT_0 = ZT; ZN_0 = ZN; ZA_0 = ZA; GT_0 = GT; GN_0 = GN; 
LT_0 = LT; LN_0 = LN; KT_0 = KT; KN_0 = KN; WT_0 = WT; WN_0 = WN; 
Omega_0 = Omega; YTYN_0 = YTYN; LTLN_0 = LTLN; k_0 = k; 

CA_0 = CA; Sav_0 = Sav; NX_0 = NX; I_0 = I; lambda_0  = lambda; A_0 = A; 
B_0 = B; IN_0 = IN; IT_0 = IT; PI_0 = PI; EI_0 = EI; 
WPC_0 = WPC; WTPC_0 = WTPC; WNPC_0 = WNPC; RK_0 = RK; PT_0 = 1; PN_0 = P; 

omegaL_0 = omegaL; omegaK_0 = omegaK; omegaI_0 = omegaI; omegaINYN_0 = omegaINYN;
omegaITYT_0 = omegaITYT; omegaGTYT_0 = omegaGTYT; omegaGNYN_0 = omegaGNYN; omegaGN_0 = omegaGN;
omegaYT_0 = omegaYT; omegaYN_0 = omegaYN; omegaLT_0 = omegaLT; omegaLN_0 = omegaLN; 
omegaC_0 =omegaC; omegaNX_0 =omegaNX; omegaG_0 =omegaG; omegaB_0 =omegaB; omegaKY_0 = omegaKY; 
alphaL_0 = alphaL; alphaK_0 = alphaK; alphaC_0 = alphaC; alphaI_0 = alphaI; 
sLT_0 = sLT; sLN_0 = sLN; sL_0 = sL; VL_0 = VL; PT_0 = PT; YR_0 = Y; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  Temporary Government Spending shock             %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
B0       = B_0;
K0       = K_0; 
GT       = GT_0; 
GN       = GN_0;                                               
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                  
%%%%%%%  Temporary increase in G  %%%  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                    
filename = 'Calibration_Shock_2021_recons';                                        
sheet    = 8;                                                                    
xlRange  = 'C3:K5';                                                              
datac = xlsread(filename,sheet,xlRange);                                         
parameters = xlsread(filename,sheet,xlRange);       

barg     = parameters(1,1); 
xi       = parameters(2,1);                                                                                                                               
chi      = parameters(3,1);                                                                                                                                  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                                                                     
x0 =[C_0 L_0 kT_0 kN_0 W_0 LT_0 LN_0 P_0 K_0 B_0 CN_0 CT_0 PC_0 IN_0 IT_0 PI_0 YT_0 YN_0 VL_0 lambda_0];
[x,fval,exitflag]=fsolve('TECH_PML_CAC_perm',x0,optimset('display','off','TolFun',1e-011));
C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kT      = x(3)  ; % Capital-labor ratio in sector T
kN      = x(4)  ; % Capital-labor ratio in sector N
W       = x(5)  ; % Aggregate wage index
LT      = x(6) ; % Labor in sector T
LN      = x(7) ; % Labor in sector N 
P       = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
B       = x(10) ; % Stock of Traded Bonds
CN      = x(11) ; % Consumption in non tradables 
CT      = x(12) ; % Consumption in tradables 
PC      = x(13) ; % Consumption price index
IN      = x(14) ; % Non tradable investment
IT      = x(15) ; % Tradable investment 
PI      = x(16) ; % Investment price index
YT      = x(17) ; % Labor in sector T
YN      = x(18) ; % Labor in sector N  
VL      = x(19) ; % Labor disutility
lambda  = x(20) ; % Marginal utility of wealth lambda

% Shares
I = deltaK*K; 
alphaC = CT/(PC*C); 
alphaI = IT/(PI*I); 
alphaL = (W*LT)/(W*L); 
alphaC_check = (varphi*(1/PC)^(1-phi));
alphaI_check = (varphiI*(1/PI)^(1-phiI));

xi1T = RK;     
xi1N = (RK/P); 
chi1T = YT;    
chi1N = YN;    

% Sectoral outputs and sectoral profits   
PT = 1; 
KT  = LT*kT;  
RK  = (1-thetaT)*(YT/KT);
WT  = thetaT*(YT/LT); 
PiT = YT - (RK*KT) - (WT*LT);
  
KN  = LN*kN;  
WN  = P*thetaN*(YN/LN);
PiN = (P*YN) - (RK*KN) - (WN*LN);

% Labor income share in the traded good and non traded good sector
sLT = WT*LT/(YT);
sLN = WN*LN/(P*YN); 

% Capital Rental Rates
RKT = (1-thetaT)*(YT/KT);
RKN = P*(1-thetaN)*(YN/KN); 

% GDP and shares in real terms
Y  = YT + (P*YN); 
YR = YT + (P_0*YN);
omegaYTR = YT/YR; 
omegaYNR = (P_0*YN)/YR; 
sL  = W*L/Y; 

% Technology
ZA  = (ZT^omegaYT_0)*(ZN^(1-omegaYT_0));

% Sep preferences
C_1P     = -(1-alphaC)*(C/P);  
C_W      = 0; 
C_1uZT   = 0; 
C_1uZN   = 0; 
L_W      = sigmaL*(L/W); 
L_1P     = 0; 
L_1uZT   = sigmaL*L*alphaL; 
L_1uZN   = sigmaL*L*(1-alphaL);
U_C      = C^(-1); 
U_L      = -gammaL*(L^(1/sigmaL)); 

% Intermediate solution for CN, CT - Cj=Cj(lambda,P,W)
CN_1P = -(CN/P)*(alphaC*phi) + (CN/C)*C_1P;
CN_W  = (CN/C)*C_W;
CN_1uZT  = (CN/C)*C_1uZT;
CN_1uZN  = (CN/C)*C_1uZN;

CT_1P = (CT/P)*phi*(1-alphaC) + (CT/C)*C_1P;
CT_W  = (CT/C)*C_W;
CT_1uZT  = (CT/C)*C_1uZT;
CT_1uZN  = (CT/C)*C_1uZN;

% Solutions for kj=kj(P,Zj)
d11 = -(thetaT/kT);
d12 = (thetaN/kN);
d21 = (1-thetaT)/kT;
d22 = -(1-thetaN)/kN;

% P, uKT, uKN
e11 = (1/P);
e12 = thetaT;
e13 = -thetaN;

e21 = (1/P);
e22 = -(1-thetaT);
e23 = (1-thetaN);

M2 = [d11 d12; d21 d22];
X2 = [e11 e12 e13; e21 e22 e23];
JST2 = inv(M2);
MST2 = JST2*X2;
kT_1P = MST2(1,1); kT_uKT = MST2(1,2); kT_uKN = MST2(1,3);
kN_1P = MST2(2,1); kN_uKT = MST2(2,2); kN_uKN = MST2(2,3);

% Solution for W=W(P,uKT,uKN),
W_1P  = (1-thetaT)*(W/kT)*kT_1P;
W_uKT = (1-thetaT)*(W/kT)*kT_uKT + (1-thetaT)*W;
W_uKN = (1-thetaT)*(W/kT)*kT_uKN;

% Solution for ,C(lambda,P,uKT,uKN,uZT,uZN)
L_2P  = L_1P + (L_W*W_1P);
L_uKT = (L_W*W_uKT);
L_uKN = (L_W*W_uKN);
L_uZT = L_1uZT;
L_uZN = L_1uZN;

% Consumption C(lambda,K,P)
C_2P  = C_1P + (C_W*W_1P);
C_uKT = (C_W*W_uKT);
C_uKN = (C_W*W_uKN);
C_uZT = C_1uZT;
C_uZN = C_1uZN;

% Solution for Cj(lambda,P,uKT,uKN,uZT,uZN)
CN_2P  = CN_1P + (CN_W*W_1P);
CN_uKT = (CN_W*W_uKT);
CN_uKN = (CN_W*W_uKN);
CN_uZT = CN_1uZT;
CN_uZN = CN_1uZN;

CT_2P  = CT_1P + (CT_W*W_1P);
CT_uKT = (CT_W*W_uKT);
CT_uKN = (CT_W*W_uKN);
CT_uZT = CT_1uZT;
CT_uZN = CT_1uZN;

% Solutions for Lj=Lj(K,P,uKT,uKN,uZT,uZN,lambda)
Psi_P   = ( (LT*kT_1P) + (LN*kN_1P) );
Psi_uKT = ( (LT*kT_uKT) + (LN*kN_uKT) );
Psi_uKN = ( (LT*kT_uKN) + (LN*kN_uKN) );

f11 = 1;             % LT
f12 = 1;             % LN
f21 = kT;            % LT
f22 = kN;            % LN

% K, P, uKT, uKN, uZT, uZN, lambda
g11 = 0;             % K
g12 = L_2P;          % P
g13 = L_uKT;         % uKT
g14 = L_uKN;         % uKN
g15 = L_uZT;         % uZT
g16 = L_uZN;         % uZN

g21 = 1;             % K
g22 = -Psi_P;        % P
g23 = -Psi_uKT;      % uKT
g24 = -Psi_uKN;      % uKN
g25 = 0;             % uZT
g26 = 0;             % uZN

M3 = [f11 f12; f21 f22];
X3 = [g11 g12 g13 g14 g15 g16; g21 g22 g23 g24 g25 g26];
JST3 = inv(M3);
MST3 = JST3*X3;
LT_1K = MST3(1,1); LT_1P = MST3(1,2); LT_uKT = MST3(1,3); LT_uKN = MST3(1,4); LT_uZT = MST3(1,5); LT_uZN = MST3(1,6);
LN_1K = MST3(2,1); LN_1P = MST3(2,2); LN_uKT = MST3(2,3); LN_uKN = MST3(2,4); LN_uZT = MST3(2,5); LN_uZN = MST3(2,6);

% Solutions for sectoral sectoral output Yj=Yj(K,P,uKT,uKN,uZT,uZN,lambda)
YT_1P  = YT*( (LT_1P/LT) + (1-thetaT)*(kT_1P/kT) );
YT_1K  = YT*(LT_1K/LT);
YT_uKT = YT*( (LT_uKT/LT) + (1-thetaT)*(kT_uKT/kT) + (1-thetaT) );
YT_uKN = YT*( (LT_uKN/LT) + (1-thetaT)*(kT_uKN/kT) );
YT_uZT = YT*(LT_uZT/LT);
YT_uZN = YT*(LT_uZN/LT);

YN_1P  = YN*( (LN_1P/LN) + (1-thetaN)*(kN_1P/kN) );
YN_1K  = YN*(LN_1K/LN);
YN_uKT = YN*( (LN_uKT/LN) + (1-thetaN)*(kN_uKT/kN) );
YN_uKN = YN*( (LN_uKN/LN) + (1-thetaN)*(kN_uKN/kN) + (1-thetaN) );
YN_uZT = YN*(LN_uZT/LN);
YN_uZN = YN*(LN_uZN/LN);

% Solving for capital and technology utilization rates: uKT, uKN, uZT, uZN; uKj,uZj(P,K,lambda)
f11 = ((xi2T/xi1T) + thetaT) + thetaT*(kT_uKT/kT);
f12 = thetaT*(kT_uKN/kT);
f13 = -1;
f14 = 0;
f21 = thetaN*(kN_uKT/kN);
f22 = ((xi2N/xi1N) + thetaN) + thetaN*(kN_uKN/kN);
f23 = 0;
f24 = -1;
f31 = -YT_uKT/YT;
f32 = -YT_uKN/YT;
f33 = (chi2T/chi1T)-(YT_uZT/YT);
f34 = -YT_uZN/YT;
f41 = -YN_uKT/YN;
f42 = -YN_uKN/YN;
f43 = -YN_uZT/YN;
f44 = (chi2N/chi1N)-(YN_uZN/YN);

% P, K, lambda
g11 = -thetaT*(kT_1P/kT);
g12 = 0;

g21 = -thetaN*(kN_1P/kN);
g22 = 0;

g31 = YT_1P/YT;
g32 = YT_1K/YT;

g41 = YN_1P/YN;
g42 = YN_1K/YN;

M4 = [f11 f12 f13 f14; f21 f22 f23 f24; f31 f32 f33 f34; f41 f42 f43 f44];
X4 = [g11 g12; g21 g22; g31 g32; g41 g42];
JST4 = inv(M4);
MST4 = JST4*X4;

uKT_P = MST4(1,1); uKT_1K = MST4(1,2);
uKN_P = MST4(2,1); uKN_1K = MST4(2,2);
uZT_P = MST4(3,1); uZT_1K = MST4(3,2);
uZN_P = MST4(4,1); uZN_1K = MST4(4,2);

% Solving for sectoral labor and sectoral output - kj,Lj,yj,Yj,Kj(lambda,K,P)
kT_1K = (kT_uKT*uKT_1K) + (kT_uKN*uKN_1K);
kT_P  = kT_1P + (kT_uKT*uKT_P) + (kT_uKN*uKN_P);

kN_1K = (kN_uKT*uKT_1K) + (kN_uKN*uKN_1K);
kN_P  = kN_1P + (kN_uKT*uKT_P) + (kN_uKN*uKN_P);

LT_2K = LT_1K + (LT_uKT*uKT_1K) + (LT_uKN*uKN_1K) + (LT_uZT*uZT_1K) + (LT_uZN*uZN_1K);
LT_P  = LT_1P + (LT_uKT*uKT_P) + (LT_uKN*uKN_P) + (LT_uZT*uZT_P) + (LT_uZN*uZN_P);

LN_2K = LN_1K + (LN_uKT*uKT_1K) + (LN_uKN*uKN_1K) + (LN_uZT*uZT_1K) + (LN_uZN*uZN_1K);
LN_P  = LN_1P + (LN_uKT*uKT_P) + (LN_uKN*uKN_P) + (LN_uZT*uZT_P) + (LN_uZN*uZN_P);

YT_2K = YT_1K + (YT_uKT*uKT_1K) + (YT_uKN*uKN_1K) + (YT_uZT*uZT_1K) + (YT_uZN*uZN_1K);
YT_P  = YT_1P + (YT_uKT*uKT_P) + (YT_uKN*uKN_P) + (YT_uZT*uZT_P) + (YT_uZN*uZN_P);

YN_2K = YN_1K + (YN_uKT*uKT_1K) + (YN_uKN*uKN_1K) + (YN_uZT*uZT_1K) + (YN_uZN*uZN_1K);
YN_P  = YN_1P + (YN_uKT*uKT_P) + (YN_uKN*uKN_P) + (YN_uZT*uZT_P) + (YN_uZN*uZN_P);

CT_1K = (CT_uKT*uKT_1K) + (CT_uKN*uKN_1K) + (CT_uZT*uZT_1K) + (CT_uZN*uZN_1K);
CT_P  = CT_2P + (CT_uKT*uKT_P) + (CT_uKN*uKN_P) + (CT_uZT*uZT_P) + (CT_uZN*uZN_P);

CN_1K = (CN_uKT*uKT_1K) + (CN_uKN*uKN_1K) + (CN_uZT*uZT_1K) + (CN_uZN*uZN_1K);
CN_P  = CN_2P + (CN_uKT*uKT_P) + (CN_uKN*uKN_P) + (CN_uZT*uZT_P) + (CN_uZN*uZN_P);

% Sectoral Capital stock Kj(lambda,K,P)
KT_1K = (LT_2K*kT) + (LT*kT_1K);
KT_P  = (LT_P*kT) + (LT*kT_P);

KN_1K = (LN_2K*kN) + (LN*kN_1K);
KN_P  = (LN_P*kN) + (LN*kN_P);

% Labor L(lambda,K,P)
L_1K = (L_uKT*uKT_1K) + (L_uKN*uKN_1K) + (L_uZT*uZT_1K) + (L_uZN*uZN_1K);
L_P  = L_2P + (L_uKT*uKT_P) + (L_uKN*uKN_P) + (L_uZT*uZT_P) + (L_uZN*uZN_P);

% Consumption C(lambda,K,P)
C_1K = (C_uKT*uKT_1K) + (C_uKN*uKN_1K) + (C_uZT*uZT_1K) + (C_uZN*uZN_1K);
C_P  = C_2P + (C_uKT*uKT_P) + (C_uKN*uKN_P) + (C_uZT*uZT_P) + (C_uZN*uZN_P);

% W(lambda,K,P)
W_1K = (W_uKT*uKT_1K) + (W_uKN*uKN_1K);
W_P  = W_1P + (W_uKT*uKT_P) + (W_uKN*uKN_P);

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI);
v_P  = - (1-alphaI)/(kappa*P);

% Solution for J = J(K,Q,PN,PH)
J_1K = deltaK;
J_1Q = K*v_1Q;
J_P = K*v_P;

% Solution for JN, JT - Jj=Jj(P,K,Q)
I     = deltaK*K;
JN_P  = -(IN/P)*(phiI*alphaI) + (IN/I)*J_P;
JN_1K = (IN/I)*J_1K;
JN_1Q = (IN/I)*J_1Q;

JT_P  =  (IT/P)*phiI*(1-alphaI) + (IT/I)*J_P;
JT_1K = (IT/I)*J_1K;
JT_1Q = (IT/I)*J_1Q;

% R=R(lambda,K,P)
R_1K  = -RK*thetaT*(uKT_1K + (kT_1K/kT));
R_P   = -RK*thetaT*(uKT_P + (kT_P/kT));

% Partial Derivatives Gj=Gj(G)
GN_G   = omegaGN/P;
GT_G   = (1-omegaGN);

% Solving for the relative price P=P(lambda,K,Q,G)
DeltaP   = (YN_P - CN_P - JN_P) - (KN*xi1N*uKN_P);
P_K      = -(1/DeltaP)*(YN_2K - CN_1K - JN_1K - (KN*xi1N*uKN_1K));
P_Q      = (JN_1Q/DeltaP);
P_G      = (GN_G/DeltaP);

% Solving for capital-labor ratios kj=kj(K,Q,G,Aj,Bj) -
% sectoral labor Lj=Lj(K,Q,G,Aj,Bj) - sectoral output
% Yj=Yj(K,Q,G,Aj,Bj) - Final Solutions
kT_K = kT_1K + (kT_P*P_K);
kT_Q = (kT_P*P_Q);
kT_G = (kT_P*P_G);

kN_K = kN_1K + (kN_P*P_K);
kN_Q = (kN_P*P_Q) ;
kN_G = (kN_P*P_G);

LT_K  = LT_2K + (LT_P*P_K);
LT_Q  = (LT_P*P_Q);
LT_G  = (LT_P*P_G);

LN_K = LN_2K + (LN_P*P_K);
LN_Q = (LN_P*P_Q);
LN_G = (LN_P*P_G);

YT_K = YT_2K + (YT_P*P_K);
YT_Q = (YT_P*P_Q);
YT_G = (YT_P*P_G);

YN_K = YN_2K + (YN_P*P_K);
YN_Q = (YN_P*P_Q) ;
YN_G = (YN_P*P_G) ;

uKT_K  = uKT_1K + (uKT_P*P_K);
uKT_Q  = (uKT_P*P_Q);
uKT_G  = (uKT_P*P_G);

uKN_K = uKN_1K + (uKN_P*P_K);
uKN_Q = (uKN_P*P_Q);
uKN_G = (uKN_P*P_G);

uZT_K  = uZT_1K + (uZT_P*P_K);
uZT_Q  = (uZT_P*P_Q);
uZT_G  = (uZT_P*P_G);

uZN_K = uZN_1K + (uZN_P*P_K);
uZN_Q = (uZN_P*P_Q);
uZN_G = (uZN_P*P_G);

% Solving for consumption Cj=Cj(lambda,K,Q,G), investment inputs
% Jj=Jj(K,Q,G)
% Solving for consumption Cj=Cj(lambda,K,Q,G), investment inputs
% Jj=Jj(K,Q,G)
CT_K = CT_1K + (CT_P*P_K);
CT_Q = (CT_P*P_Q);
CT_G = (CT_P*P_G);

CN_K = CN_1K + (CN_P*P_K);
CN_Q = (CN_P*P_Q);
CN_G = (CN_P*P_G);

JT_K = JT_1K + (JT_P*P_K);
JT_Q = JT_1Q + (JT_P*P_Q);
JT_G = (JT_P*P_G);

JN_K = JN_1K + (JN_P*P_K);
JN_Q = JN_1Q + (JN_P*P_Q);
JN_G = (JN_P*P_G);

v_K  = (v_P*P_K);
v_Q  = v_1Q + (v_P*P_Q);
v_G  = (v_P*P_G);

R_K  = R_1K + (R_P*P_K);
R_Q  = (R_P*P_Q);
R_G  = (R_P*P_G);

KT_K = KT_1K + (KT_P*P_K);     
KT_Q = (KT_P*P_Q);            
KT_G = (KT_P*P_G);            
                               
KN_K = KN_1K + (KN_P*P_K);     
KN_Q = (KN_P*P_Q);            
KN_G = (KN_P*P_G);  

% Elements of the Jacobian Matrix
Upsilon_K = (I/IN)*(YN_K-CN_K-(KN*xi1N*uKN_K)) - deltaK + alphaI*phiI*I*(P_K/P);
Upsilon_Q = (I/IN)*(YN_Q-CN_Q-(KN*xi1N*uKN_Q)) + alphaI*phiI*I*(P_Q/P);
Sigma_K   = -(R_K-(RK/K)+(RK/K)*((KT*uKT_K)+(KN*uKN_K)+(KT*uZT_K)+(KN*uZN_K)+(KT_K+KN_K))-(KT/K)*xi1T*uKT_K-(P*KN/K)*xi1N*uKN_K + (PI*kappa*v_K*deltaK) );
Sigma_Q   = (r+deltaK)-( R_Q+(RK/K)*((KT*uKT_Q)+(KN*uKN_Q)+((KT*uZT_Q)+(KN*uZN_Q))+(KT_Q+KN_Q))-(KT/K)*xi1T*uKT_Q-(P*KN/K)*xi1N*uKN_Q + (PI*kappa*v_Q*deltaK) );

x11 = Upsilon_K;
x12 = Upsilon_Q;
x21 = Sigma_K;
x22 = Sigma_Q;

J = [x11 x12; x21 x22];
[V,nu]=eig(J);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1);
nu_2 = nu_sorted(2,2);
omega_11 = V_sorted(1,1)/V_sorted(1,1);
omega_21 = V_sorted(2,1)/V_sorted(1,1);
omega_12 = V_sorted(1,2)/V_sorted(1,2);
omega_22 = V_sorted(2,2)/V_sorted(1,2);

TrJ  = trace(J);
DetJ = det(J);

% Elements of general solutions for capital K(t) and the relative price P(t)
% K(t) -K = X1(t)+X2(t); P(t)-P = omega21*X1(t)+omega22*X2(t)
% X1(t) = (K0-K)*exp(nu1*t)+Gamma2*exp(nu1*t) - Gamma1*(exp(nu1*t)-exp(-xi*t));
% X2(t) = -Gamma2*exp(-xi*t);
Upsilon_G  = (I/IN)*(YN_G-CN_G-GN_G-(KN*xi1N*uKN_G)) + (alphaI*phiI*I)*(P_G/P);
Sigma_G    = -( R_G+(RK/K)*((KT*uKT_G)+(KN*uKN_G)+(KT*uZT_G)+(KN*uZN_G)+(KT_G+KN_G))-(KT/K)*xi1T*uKT_G-(P*KN/K)*xi1N*uKN_G + (PI*kappa*v_G*deltaK) );

%%%%%%%%%%%%%%%%%% Solutions for Permanent Shocks %%%%%%%%%%%%%%%%%%%%
Vnorm = [omega_11 omega_12; omega_21 omega_22];
Vinv   = inv(Vnorm);
u11    = Vinv(1,1);
u12    = Vinv(1,2);
u21    = Vinv(2,1);
u22    = Vinv(2,2);

s11   = (u11*Upsilon_G) + (u12*Sigma_G);
s21   = (u21*Upsilon_G) + (u22*Sigma_G);

DeltaG_1   = - s11*Y_0*(1/(nu_1+xi));
DeltaG_2   = s21*Y_0*(1/(nu_2+xi));

ThetaG_1    = (1-barg)*((nu_1+xi)/(nu_1+chi));
ThetaG_2    = (1-barg)*((nu_2+xi)/(nu_2+chi));

X20 = - DeltaG_2*(1-ThetaG_2);
X10 = (K0-K) - X20;
X11 = X10 - DeltaG_1*(1-ThetaG_1);

% Intertemporal solvency condition - lambda
B_K   = (YT_K - CT_K - JT_K) - (KT*xi1T*uKT_K);
B_Q   = (YT_Q - CT_Q - JT_Q) - (KT*xi1T*uKT_Q);
B_G   = (YT_G - CT_G - GT_G - JT_G) - (KT*xi1T*uKT_G);

N1    = (B_K + (B_Q*omega_21));
N2    = (B_K + (B_Q*omega_22));

ThetaG_prime   = (1-barg)*((xi+r)/(chi+r));
ThetaG_1prime  = ThetaG_1*((xi+r)/(chi+r));
ThetaG_2prime  = ThetaG_2*((xi+r)/(chi+r));

wB1   = N1*X11;
wBG2  = B_G*Y_0*(1-ThetaG_prime) + N1*DeltaG_1*(1-ThetaG_1prime) - N2*DeltaG_2*(1-ThetaG_2prime);

% Solutions for L,C,KT,KN,W,R(K,Q,G,lambda)
%L_K = L_1K + (L_P*P_K);
%L_Q = (L_P*P_Q) ;
%L_G = (L_P*P_G) ;

%C_K = C_1K + (C_P*P_K);
%C_Q = (C_P*P_Q);
%C_G = (C_P*P_G);   

% Solving for sectoral wages - Wj=Wj(lambda,K,Q,ZH,ZN)
W_K = W_1K + (W_P*P_K);
W_Q = (W_P*P_Q) ;
W_G = (W_P*P_G) ;      

WT_K  = W_K;
WT_Q  = W_Q;
WT_G  = W_G;

WN_K  = W_K;
WN_Q  = W_Q;
WN_G  = W_G;

L_K = (L_1P*P_K) + (L_W*W_K) + (L_1uZT*uZT_K) + (L_1uZN*uZN_K);                       
L_Q = (L_1P*P_Q) + (L_W*W_Q) + (L_1uZT*uZT_Q) + (L_1uZN*uZN_Q);                       
L_G = (L_1P*P_G) + (L_W*W_G) + (L_1uZT*uZT_G) + (L_1uZN*uZN_G);                       
                                                                                      
C_K = (C_1P*P_K) + (C_uKT*uKT_K) + (C_uKN*uKN_K) + (C_1uZT*uZT_K) + (C_1uZN*uZN_K);   
C_Q = (C_1P*P_Q) + (C_uKT*uKT_Q) + (C_uKN*uKN_Q) + (C_1uZT*uZT_Q) + (C_1uZN*uZN_Q);   
C_G = (C_1P*P_G) + (C_uKT*uKT_G) + (C_uKN*uKN_G) + (C_1uZT*uZT_G) + (C_1uZN*uZN_G);   
                                                                                                                                                                        
% Solution for J = J(K,Q,ZT,ZN)                                         
J_K   = J_1K + (J_P*P_K);                                               
J_Q   = J_1Q + (J_P*P_Q);                                               
J_G   = (J_P*P_G);                                                      
                                                                        
% Solution for PC,PI(K,Q,ZT,ZN)                                         
PC_K   = (PC/P)*(1-alphaC)*P_K;                                         
PC_Q   = (PC/P)*(1-alphaC)*P_Q;                                         
PC_G   = (PC/P)*(1-alphaC)*P_G;                                         
                                                                        
PI_K   = (PI/P)*(1-alphaI)*P_K;                                         
PI_Q   = (PI/P)*(1-alphaI)*P_Q;                                         
PI_G   = (PI/P)*(1-alphaI)*P_G;                                         
                                                                        
% Solution for GE=GT + P*GN = G(K,Q,ZT,ZN,G)                            
G_K   = (P_K*GN);                                                       
G_Q   = (P_Q*GN);                                                       
G_G   = (P_G*GN) + (P*GN_G) + GT_G;                                            
G_lambda  = (P_lambda*GN);                                              
                                                                      
% Solution for the stock of financial wealth                                                                                                    
A_K  = ((WT_K*LT)+(WN_K*LN))+((WT*LT_K)+(WN*LN_K))+((WT*LT*uZT_K)+(WN*LN*uZN_K))-G_K-((PC_K*C)+(PC*C_K))-((chi1T*uZT_K)+(P*chi1N*uZN_K));  
A_Q  = ((WT_Q*LT)+(WN_Q*LN))+((WT*LT_Q)+(WN*LN_Q))+((WT*LT*uZT_Q)+(WN*LN*uZN_Q))-G_Q-((PC_Q*C)+(PC*C_Q))-((chi1T*uZT_Q)+(P*chi1N*uZN_Q));  
A_G  = ((WT_G*LT)+(WN_G*LN))+((WT*LT_G)+(WN*LN_G))+((WT*LT*uZT_G)+(WN*LN*uZN_G))-G_G-((PC_G*C)+(PC*C_G))-((chi1T*uZT_G)+(P*chi1N*uZN_G));  

M1   = A_K + (A_Q*omega_21);
M2   = A_K + (A_Q*omega_22);

wA1  = M1*X11;
wAG2 = A_G*Y_0*(1-ThetaG_prime) + M1*DeltaG_1*(1-ThetaG_1prime) - M2*DeltaG_2*(1-ThetaG_2prime);

dA_bias = (wA1/(r-nu_1)) + (wAG2/(xi+r));

% Solution for Real GDP as function Y,YR(K,Q,lambda,G) 
Y_K   = (YT_K) + (P_0*YN_K) + (P_K*YN_0);   
Y_Q   = (YT_Q) + (P_0*YN_Q) + (P_Q*YN_0);   
Y_G   = (YT_G) + (P_0*YN_G) + (P_G*YN_0);   

YR_K  = (YT_K) + (P_0*YN_K);                                
YR_Q  = (YT_Q) + (P_0*YN_Q);                                
YR_G  = (YT_G) + (P_0*YN_G);                                

% Relative Sectoral Wages WjW-K,Q,G)
WTW_K = (WT/W)*( (WT_K/WT) - (W_K/W) );
WTW_Q = (WT/W)*( (WT_Q/WT) - (W_Q/W) );
WTW_G = (WT/W)*( (WT_G/WT) - (W_G/W) );

WNW_K = (WN/W)*( (WN_K/WN) - (W_K/W) );
WNW_Q = (WN/W)*( (WN_Q/WN) - (W_Q/W) );
WNW_G = (WN/W)*( (WN_G/WN) - (W_G/W) );

Omega_K  = Omega*( (WN_K/WN) - (WT_K/WT) );
Omega_Q  = Omega*( (WN_Q/WN) - (WT_Q/WT) );
Omega_G  = Omega*( (WN_G/WN) - (WT_G/WT) );

% Solution for Wj/PC,W/PC(K,Q,G,Aj,Bj)
WTPC_K  = WTPC*( (WT_K/WT) - (PC_K/PC) );
WTPC_Q  = WTPC*( (WT_Q/WT) - (PC_Q/PC) );
WTPC_G  = WTPC*( (WT_G/WT) - (PC_G/PC) );

WNPC_K  = WNPC*( (WN_K/WN) - (PC_K/PC) );
WNPC_Q  = WNPC*( (WN_Q/WN) - (PC_Q/PC) );
WNPC_G  = WNPC*( (WN_G/WN) - (PC_G/PC) );

WPC_K  = WPC*( (W_K/W) - (PC_K/PC) );
WPC_Q  = WPC*( (W_Q/W) - (PC_Q/PC) );
WPC_G  = WPC*( (W_G/W) - (PC_G/PC) );

% RPj=Rj/Pj=Rj(K,Q,G,Aj,Bj);
RPT_K  = (RK_0/PT_0)*(R_K/RK_0);
RPT_Q  = (RK_0/PT_0)*(R_Q/RK_0);
RPT_G  = (RK_0/PT_0)*(R_G/RK_0);

RPN_K  = (RK_0/P_0)*((R_K/RK_0) - (P_K/P_0));
RPN_Q  = (RK_0/P_0)*((R_Q/RK_0) - (P_Q/P_0));
RPN_G  = (RK_0/P_0)*((R_G/RK_0) - (P_G/P_0));

tildeRPT_K  = RPT_K + (RK_0/PT_0)*uZT_K;
tildeRPT_Q  = RPT_Q + (RK_0/PT_0)*uZT_Q;
tildeRPT_G  = RPT_G + (RK_0/PT_0)*uZT_G;

tildeRPN_K  = RPN_K + (RK_0/P_0)*uZN_K;
tildeRPN_Q  = RPN_Q + (RK_0/P_0)*uZN_Q;
tildeRPN_G  = RPN_G + (RK_0/P_0)*uZN_G;

% Solution for tildeW(K,Q,G,Aj,Bj) - tildeW(tildeWT,tildeWN)
W_uZT    = W*alphaL;
W_uZN    = W*(1-alphaL);
tildeW_K = W_K + (W_uZT*uZT_K) + (W_uZN*uZN_K);
tildeW_Q = W_Q + (W_uZT*uZT_Q) + (W_uZN*uZN_Q);
tildeW_G = W_G + (W_uZT*uZT_G) + (W_uZN*uZN_G);

% Solution for the labor income share sLj=LISj(K,Q,G,Aj,Bj)=Wj*Lj/Pj*Yj
LIST_K  = sLT_0*( (WT_K/WT_0) + (LT_K/LT_0) - (YT_K/YT_0) );
LIST_Q  = sLT_0*( (WT_Q/WT_0) + (LT_Q/LT_0) - (YT_Q/YT_0) );
LIST_G  = sLT_0*( (WT_G/WT_0) + (LT_G/LT_0) - (YT_G/YT_0) );

LISN_K  = sLN_0*( (WN_K/WN_0) + (LN_K/LN_0) - (P_K/P_0) - (YN_K/YN_0) );
LISN_Q  = sLN_0*( (WN_Q/WN_0) + (LN_Q/LN_0) - (P_Q/P_0) - (YN_Q/YN_0) );
LISN_G  = sLN_0*( (WN_G/WN_0) + (LN_G/LN_0) - (P_G/P_0) - (YN_G/YN_0) );

% Solution for LT(K,Q,G,Aj,Bj)/LN(K,Q,G,Aj,Bj)
LTLN_K = (LT_0/LN_0)*( (LT_K/LT_0) - (LN_K/LN_0) );
LTLN_Q = (LT_0/LN_0)*( (LT_Q/LT_0) - (LN_Q/LN_0) );
LTLN_G = (LT_0/LN_0)*( (LT_G/LT_0) - (LN_G/LN_0) );

% Solution for YT(K,Q,G,Aj,Bj)/YN(K,Q,G,Aj,Bj)
YTYN_K = (YT_0/YN_0)*( (YT_K/YT_0) - (YN_K/YN_0) );
YTYN_Q = (YT_0/YN_0)*( (YT_Q/YT_0) - (YN_Q/YN_0) );
YTYN_G = (YT_0/YN_0)*( (YT_G/YT_0) - (YN_G/YN_0) );

% Solutions for the employment shares Lj/L=(Lj/L)(K,Q,G,Aj,Bj)
LTS_K  = (LT_0/L_0)*((LT_K/LT_0)-(L_K/L_0));
LTS_Q  = (LT_0/L_0)*((LT_Q/LT_0)-(L_Q/L_0));
LTS_G  = (LT_0/L_0)*((LT_G/LT_0)-(L_G/L_0));

LNS_K  = (LN_0/L_0)*((LN_K/LN_0)-(L_K/L_0));
LNS_Q  = (LN_0/L_0)*((LN_Q/LN_0)-(L_Q/L_0));
LNS_G  = (LN_0/L_0)*((LN_G/LN_0)-(L_G/L_0));

% Solutions for the Real Sectoral Output Yj/YR=(Yj/YR)(K,Q,G,Aj,Bj)
YTS_K  = (YT_0/Y_0)*( (YT_K/YT_0) - (YR_K/Y_0) );           
YTS_Q  = (YT_0/Y_0)*( (YT_Q/YT_0) - (YR_Q/Y_0) );           
YTS_G  = (YT_0/Y_0)*( (YT_G/YT_0) - (YR_G/Y_0) );           
                                                            
YNS_K  = (YN_0/Y_0)*( (YN_K/YN_0) - (YR_K/Y_0) );           
YNS_Q  = (YN_0/Y_0)*( (YN_Q/YN_0) - (YR_Q/Y_0) );           
YNS_G  = (YN_0/Y_0)*( (YN_G/YN_0) - (YR_G/Y_0) );           

% Solutions for the Kj/K: Kj/K=Kj/K(lambda,K,Q,AH,BH,AN,BN) -
% aggregate capital utilization rate uK =(KT/K)*uKT + (KN/K)*uKN
KTK_K  = (KT_0/K_0)*( (KT_K/KT_0) - (1/K_0) );
KTK_Q  = (KT_0/K_0)*(KT_Q/KT_0);
KTK_G  = (KT_0/K_0)*(KT_G/KT_0);

KNK_K  = (KN_0/K_0)*( (KN_K/KN_0) - (1/K_0) );
KNK_Q  = (KN_0/K_0)*(KN_Q/KN_0);
KNK_G  = (KN_0/K_0)*(KN_G/KN_0);

uK_K   = KTK_K + KNK_K + (KT_0/K_0)*uKT_K + (KN_0/K_0)*uKN_K;
uK_Q   = KTK_Q + KNK_Q + (KT_0/K_0)*uKT_Q + (KN_0/K_0)*uKN_Q;
uK_G   = KTK_G + KNK_G + (KT_0/K_0)*uKT_G + (KN_0/K_0)*uKN_G;

% Solutions tildeZj,tildeZ(K,Q,G,Aj,Bj);
tildeZT_K   = ZT_0*uZT_K;
tildeZT_Q   = ZT_0*uZT_Q;
tildeZT_G   = ZT_0*uZT_G;

tildeZN_K   = ZN_0*uZN_K;
tildeZN_Q   = ZN_0*uZN_Q;
tildeZN_G   = ZN_0*uZN_G;

tildeZ_K    = omegaYT_0*(ZA_0/ZT_0)*tildeZT_K  + (1-omegaYT_0)*(ZA_0/ZN_0)*tildeZN_K;
tildeZ_Q    = omegaYT_0*(ZA_0/ZT_0)*tildeZT_Q  + (1-omegaYT_0)*(ZA_0/ZN_0)*tildeZN_Q;
tildeZ_G    = omegaYT_0*(ZA_0/ZT_0)*tildeZT_G  + (1-omegaYT_0)*(ZA_0/ZN_0)*tildeZN_G;

% Solutions tildeWj,tildeRj,tildeKj,tildeYj(K,Q,G,Aj,Bj); tildeWj=uZj*Wj;
% tildeRj=RK*uZj; tildeKj=uKj*Kj; tildeYj=uZj*Yj;
tildeWT_K  = WT_K + (WT*uZT_K);
tildeWT_Q  = WT_Q + (WT*uZT_Q);
tildeWT_G  = WT_G + (WT*uZT_G);

tildeWN_K  = WN_K + (WN*uZN_K);
tildeWN_Q  = WN_Q + (WN*uZN_Q);
tildeWN_G  = WN_G + (WN*uZN_G);

tildeWTPC_K  = WTPC_0*( (tildeWT_K/WT_0) - (PC_K/PC_0) );
tildeWTPC_Q  = WTPC_0*( (tildeWT_Q/WT_0) - (PC_Q/PC_0) );
tildeWTPC_G  = WTPC_0*( (tildeWT_G/WT_0) - (PC_G/PC_0) );

tildeWNPC_K  = WNPC_0*( (tildeWN_K/WN_0) - (PC_K/PC_0) );
tildeWNPC_Q  = WNPC_0*( (tildeWN_Q/WN_0) - (PC_Q/PC_0) );
tildeWNPC_G  = WNPC_0*( (tildeWN_G/WN_0) - (PC_G/PC_0) );

tildeRT_K  = R_K + (RK*uZT_K);
tildeRT_Q  = R_Q + (RK*uZT_Q);
tildeRT_G  = R_G + (RK*uZT_G);

tildeRN_K  = R_K + (RK*uZN_K);
tildeRN_Q  = R_Q + (RK*uZN_Q);
tildeRN_G  = R_G + (RK*uZN_G);

tildeKT_K  = KT_K + (KT*uKT_K);
tildeKT_Q  = KT_Q + (KT*uKT_Q);
tildeKT_G  = KT_G + (KT*uKT_G);

tildeKN_K  = KN_K + (KN*uKN_K);
tildeKN_Q  = KN_Q + (KN*uKN_Q);
tildeKN_G  = KN_G + (KN*uKN_G);

tildekT_K  = kT*( (tildeKT_K/KT) - (LT_K/LT) );
tildekT_Q  = kT*( (tildeKT_Q/KT) - (LT_Q/LT) );
tildekT_G  = kT*( (tildeKT_G/KT) - (LT_G/LT) );

tildekN_K  = kN*( (tildeKN_K/KN) - (LN_K/LN) );
tildekN_Q  = kN*( (tildeKN_Q/KN) - (LN_Q/LN) );
tildekN_G  = kN*( (tildeKN_G/KN) - (LN_G/LN) );

tildeYT_K  = YT_K + (YT*uZT_K);
tildeYT_Q  = YT_Q + (YT*uZT_Q);
tildeYT_G  = YT_G + (YT*uZT_G);

tildeYN_K  = YN_K + (YN*uZN_K);
tildeYN_Q  = YN_Q + (YN*uZN_Q);
tildeYN_G  = YN_G + (YN*uZN_G);

tildeYR_K   = YR_K + (YT*uZT_K) + (P_0*YN*uZN_K);  
tildeYR_Q   = YR_Q + (YT*uZT_Q) + (P_0*YN*uZN_Q);  
tildeYR_G   = YR_G + (YT*uZT_G) + (P_0*YN*uZN_G);  

tildeK_K  = 1 + (K*uK_K);
tildeK_Q  = (K*uK_Q);
tildeK_G  = (K*uK_G);

tildeWPC_K  = WPC_0*( (tildeW_K/W_0) - (PC_K/PC_0) );
tildeWPC_Q  = WPC_0*( (tildeW_Q/W_0) - (PC_Q/PC_0) );
tildeWPC_G  = WPC_0*( (tildeW_G/W_0) - (PC_G/PC_0) );

tildeOmega_K  = Omega_0*( (tildeWN_K/WN_0) - (tildeWT_K/WT_0) );
tildeOmega_Q  = Omega_0*( (tildeWN_Q/WN_0) - (tildeWT_Q/WT_0) );
tildeOmega_G  = Omega_0*( (tildeWN_G/WN_0) - (tildeWT_G/WT_0) );

% Solution for tildeWT/wtildeW = tildeWj(K,Q,G,Aj,Bj)/tildeW(K,Q,G,Aj,Bj)
tildeWTW_K = (WT_0/W_0)*( (tildeWT_K/WT_0) - (tildeW_K/W_0) );
tildeWTW_Q = (WT_0/W_0)*( (tildeWT_Q/WT_0) - (tildeW_Q/W_0) );
tildeWTW_G = (WT_0/W_0)*( (tildeWT_G/WT_0) - (tildeW_G/W_0) );

tildeWNW_K = (WN_0/W_0)*( (tildeWN_K/WN_0) - (tildeW_K/W_0) );
tildeWNW_Q = (WN_0/W_0)*( (tildeWN_Q/WN_0) - (tildeW_Q/W_0) );
tildeWNW_G = (WN_0/W_0)*( (tildeWN_G/WN_0) - (tildeW_G/W_0) );

% Solutions for the tildeKj/tildeK,tildeR(lambda,K,Q,AH,BH,AN,BN) - tildeK = uK*K; tildeKj = uKj*Kj
tildeKTK_K  = (KT_0/K_0)*( (tildeKT_K/KT_0) - (tildeK_K/K_0) );
tildeKTK_Q  = (KT_0/K_0)*( (tildeKT_Q/KT_0) - (tildeK_Q/K_0) );
tildeKTK_G  = (KT_0/K_0)*( (tildeKT_G/KT_0) - (tildeK_G/K_0) );

tildeKNK_K  = (KN_0/K_0)*( (tildeKN_K/KN_0) - (tildeK_K/K_0) );
tildeKNK_Q  = (KN_0/K_0)*( (tildeKN_Q/KN_0) - (tildeK_Q/K_0) );
tildeKNK_G  = (KN_0/K_0)*( (tildeKN_G/KN_0) - (tildeK_G/K_0) );

tildeR_K     = (RK*tildeKTK_K) + (KT_0/K_0)*tildeRT_K + (RK*tildeKNK_K) + (KN_0/K_0)*tildeRN_K;
tildeR_Q     = (RK*tildeKTK_Q) + (KT_0/K_0)*tildeRT_Q + (RK*tildeKNK_Q) + (KN_0/K_0)*tildeRN_Q;
tildeR_G     = (RK*tildeKTK_G) + (KT_0/K_0)*tildeRT_G + (RK*tildeKNK_G) + (KN_0/K_0)*tildeRN_G;

% Solution for tildeYT(K,Q,G,Aj,Bj)/tildeYN(K,Q,G,Aj,Bj);
% Solutions for the Real Sectoral Output tildeYj/tildeYR=(tildeYj/tildeYR)(K,Q,G,Aj,Bj)
tildeYTYN_K = (YT_0/YN_0)*( (tildeYT_K/YT_0) - (tildeYN_K/YN_0) );       
tildeYTYN_Q = (YT_0/YN_0)*( (tildeYT_Q/YT_0) - (tildeYN_Q/YN_0) );       
tildeYTYN_G = (YT_0/YN_0)*( (tildeYT_G/YT_0) - (tildeYN_G/YN_0) );       
                                                                         
tildeYTS_K  = (YT_0/Y_0)*( (tildeYT_K/YT_0) - (tildeYR_K/Y_0) );         
tildeYTS_Q  = (YT_0/Y_0)*( (tildeYT_Q/YT_0) - (tildeYR_Q/Y_0) );         
tildeYTS_G  = (YT_0/Y_0)*( (tildeYT_G/YT_0) - (tildeYR_G/Y_0) );         
                                                                         
tildeYNS_K  = (YN_0/Y_0)*( (tildeYN_K/YN_0) - (tildeYR_K/Y_0) );         
tildeYNS_Q  = (YN_0/Y_0)*( (tildeYN_Q/YN_0) - (tildeYR_Q/Y_0) );         
tildeYNS_G  = (YN_0/Y_0)*( (tildeYN_G/YN_0) - (tildeYR_G/Y_0) );         
                                                                         
% Solutions TFPj(K,Q,G,Aj,Bj);
TFPT_K      = (ZT_0/YT_0)*tildeYT_K - thetaT*(ZT_0/LT_0)*LT_K - (1-thetaT)*(ZT_0/KT_0)*KT_K;
TFPT_Q      = (ZT_0/YT_0)*tildeYT_Q - thetaT*(ZT_0/LT_0)*LT_Q - (1-thetaT)*(ZT_0/KT_0)*KT_Q;
TFPT_G      = (ZT_0/YT_0)*tildeYT_G - thetaT*(ZT_0/LT_0)*LT_G - (1-thetaT)*(ZT_0/KT_0)*KT_G;

TFPN_K      = (ZN_0/YN_0)*tildeYN_K - thetaN*(ZN_0/LN_0)*LN_K - (1-thetaN)*(ZN_0/KN_0)*KN_K;
TFPN_Q      = (ZN_0/YN_0)*tildeYN_Q - thetaN*(ZN_0/LN_0)*LN_Q - (1-thetaN)*(ZN_0/KN_0)*KN_Q;
TFPN_G      = (ZN_0/YN_0)*tildeYN_G - thetaN*(ZN_0/LN_0)*LN_G - (1-thetaN)*(ZN_0/KN_0)*KN_G;

TFP_K      =  omegaYT_0*(ZA_0/ZT_0)*TFPT_K + (1-omegaYT_0)*(ZA_0/ZN_0)*TFPN_K;
TFP_Q      =  omegaYT_0*(ZA_0/ZT_0)*TFPT_Q + (1-omegaYT_0)*(ZA_0/ZN_0)*TFPN_Q;
TFP_G      =  omegaYT_0*(ZA_0/ZT_0)*TFPT_G + (1-omegaYT_0)*(ZA_0/ZN_0)*TFPN_G;

TFPT_K_check      = ZT_0*uZT_K + (1-sLT_0)*ZT_0*uKT_K;
TFPT_Q_check      = ZT_0*uZT_Q + (1-sLT_0)*ZT_0*uKT_Q;
TFPT_G_check      = ZT_0*uZT_G + (1-sLT_0)*ZT_0*uKT_G;

TFPN_K_check      =  ZN_0*uZN_K + (1-sLN_0)*ZN_0*uKN_K;
TFPN_Q_check      =  ZN_0*uZN_Q + (1-sLN_0)*ZN_0*uKN_Q;
TFPN_G_check      =  ZN_0*uZN_G + (1-sLN_0)*ZN_0*uKN_G;

% Relative TFP
TFPR_K  = (ZT_0/ZN_0)*( (TFPT_K/ZT_0) - (TFPN_K/ZN_0) );  
TFPR_Q  = (ZT_0/ZN_0)*( (TFPT_Q/ZT_0) - (TFPN_Q/ZN_0) );  
TFPR_G  = (ZT_0/ZN_0)*( (TFPT_G/ZT_0) - (TFPN_G/ZN_0) );  

uZR_K  = uZT_K - uZN_K;
uZR_Q  = uZT_Q - uZN_Q;
uZR_G  = uZT_G - uZN_G;

% Aggregate capital labor ratio k = K/L
k_K  = k_0*( (1/K_0) - (L_K/L_0) );
k_Q  = -k_0*(L_Q/L_0);
k_G  = -k_0*(L_G/L_0);

% Aggregate LIS                                                                       
LIS_K  = sL_0*( (W_K/W_0) + (L_K/L_0)  - (Y_K/Y_0) );                                 
LIS_Q  = sL_0*( (W_Q/W_0) + (L_Q/L_0)  - (Y_Q/Y_0) );                                 
LIS_G  = sL_0*( (W_G/W_0) + (L_G/L_0)  - (Y_G/Y_0) );                                 
                                                                                      
% Output share of non-tradables at current prices                                     
tildeY_K   = Y_K + (YT_0*uZT_K) + (P_0*YN_0*uZN_K);                                   
tildeY_Q   = Y_Q + (YT_0*uZT_Q) + (P_0*YN_0*uZN_Q);                                   
tildeY_G   = Y_G + (YT_0*uZT_G) + (P_0*YN_0*uZN_G);                                   
                                                                                      
omegaYN_K  = omegaYN_0*( (P_K/PN_0) + (tildeYN_K/YN_0) - (tildeY_K/Y_0) );            
omegaYN_Q  = omegaYN_0*( (P_Q/PN_0) + (tildeYN_Q/YN_0) - (tildeY_Q/Y_0) );            
omegaYN_G  = omegaYN_0*( (P_G/PN_0) + (tildeYN_G/YN_0) - (tildeY_G/Y_0) );            
                                                                                      
% Aggregate LIS                                                                       
LIS_K  = sL_0*( (tildeW_K/W_0) + (L_K/L_0)  - (tildeY_K/Y_0) );                       
LIS_Q  = sL_0*( (tildeW_Q/W_0) + (L_Q/L_0)  - (tildeY_Q/Y_0) );                       
LIS_G  = sL_0*( (tildeW_G/W_0) + (L_G/L_0)  - (tildeY_G/Y_0) );                       
                                                                                                                                                      
% Solution for NX = NX(K,Q,ZT,ZN)                                                                 
NX_K   = (YT_K - CT_K - JT_K) - (KT*xi1T*uKT_K);
NX_Q   = (YT_Q - CT_Q - JT_Q) - (KT*xi1T*uKT_Q);
NX_G   = (YT_G - CT_G - GT_G - JT_G) - (KT*xi1T*uKT_G);                                                                                                                                
                                                                                                  
% Solution for Q/PI(K,Q,ZT,ZN)                                                                    
QPI_K  = - (PI_K/PI);                                                                             
QPI_Q  = (1/PI) - (PI_Q/PI);                                                                      
QPI_G = - (PI_G/PI);              
                                   
% Check uZT and uZN                                                
uZT_check_K = (thetaT/W)*tildeWT_K + ((1-thetaT)/RK)*tildeRT_K;    
uZT_check_Q = (thetaT/W)*tildeWT_Q + ((1-thetaT)/RK)*tildeRT_Q;    
uZT_check_G = (thetaT/W)*tildeWT_G + ((1-thetaT)/RK)*tildeRT_G;    
                                                                   
uZN_check_K = (thetaN/W)*tildeWN_K + ((1-thetaN)/RK)*tildeRN_K;    
uZN_check_Q = (thetaN/W)*tildeWN_Q + ((1-thetaN)/RK)*tildeRN_Q;    
uZN_check_G = (thetaN/W)*tildeWN_G + ((1-thetaN)/RK)*tildeRN_G;                 
                                                                                                                                    
% Government spending 
G = GT + (P*GN);   

% Investment 
I_check = ( (varphiI^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-varphiI)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1)); 
EI      = PI*I; 
omegaI  = PI*I/Y; 

% Net exports, current account and saving
NX   = YT-CT-GT-IT; 
CA   = (r*B) + YT - CT - GT - IT; 
A    = B + (PI*K); 
Tax  = GT + (P*GN); 
Sav  = (r*A) + (W*L) - (PC*C) - Tax; 

% Real Aggregate Wage 
WPC = W/PC;
WTPC = WT/PC;
WNPC = WN/PC;

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WT); 
YTYN  = (YT/YN); 
LTLN  = (LT/LN);

% Consumption 
C_check = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1));

% Unit Cost or Producing                                
UCT = ((W/thetaT)^thetaT)*((RK/(1-thetaT))^(1-thetaT)); 
UCN = ((W/thetaN)^thetaN)*((RK/(1-thetaN))^(1-thetaN)); 

% Sectoral ratios
omegaINYN = IN/YN; 
omegaITYT = IT/YT; 
omegaGTYT =  GT / YT;
omegaGNYN =  GN / (YN);
omegaGN   =  (P*GN) / G;
omegaYT   =  YT / Y;
omegaYN   =  (P*YN)/Y; 
omegaLT   =  LT / L;
omegaLN   =  LN / L; 

% Targeted ratios
omegaC    =  (PC*C) / Y;
omegaNX   =  NX / Y; 
omegaG    =  (GT+P*GN)/Y;
omegaB    = (r*B)/Y; 
omegaKY   = K/Y; 

% Confirmation
cond1  = (1-thetaT)*(YT/KT)-RK;                               
cond2  = P*(1-thetaN)*(YN/KN)-RK;                             
cond3  = thetaT*(YT/LT)-WT;                                   
cond4  = P*thetaN*(YN/LN)-WN;                                 
cond5  = (LT*kT)+(LN*kN)-K;                                   
cond6  = RK-(deltaK+r)*PI; 
cond7  = YN-CN-GN-IN;
cond8  = YT-CT-GT-IT+(r*B);
cond9  = (B-B0)-( (wB1/(r-nu_1)) + (wBG2/(xi+r)) );    
cond10 = DetJ - (nu_1*nu_2);
cond11 = TrJ - (nu_1+nu_2); 
cond12 = (LT+LN) - L;
cond13 = (CT/CN) - (varphi/(1-varphi))*P^(phi);
cond14 = (PC*C) - (CT+(P*CN)); 
cond15 = (W*L) - ((WT*LT)+(WN*LN)); 
cond16 = Y - (PC*C) - G - (PI*I) + (r*B); 
cond17 = Sav; 
cond18 = (PC*C) - (CT+(P*CN)); 
cond19 = (IT/IN) - (varphiI/(1-varphiI))*P^(phiI);
cond20 = (PI*I) - (IT+(P*IN)); 
cond21 = (RK*K) - ((RKT*KT)+(RKN*KN));
cond22 = 1 - (omegaK + omegaL); 
cond23 = alphaC - alphaC_check; 
cond24 = alphaI - alphaI_check; 
cond25 = UCT - PT; 
cond26 = UCN - P;  

% Define New steady-state values
kT_pmltech = kT; kN_pmltech = kN; P_pmltech = P;K_pmltech = K; C_pmltech = C;  
L_pmltech  = L; W_pmltech = W;
YT_pmltech = YT; YN_pmltech = YN; Y_pmltech = Y; G_pmltech = G;     
PC_pmltech = PC; CN_pmltech = CN; CT_pmltech = CT;  
GT_pmltech = GT; GN_pmltech = GN; ZT_pmltech = ZT; ZN_pmltech = ZN; ZA_pmltech = ZA; 
LT_pmltech = LT; LN_pmltech = LN; KT_pmltech = KT; KN_pmltech = KN; WT_pmltech = WT; WN_pmltech = WN; 
Omega_pmltech = Omega; WPC_pmltech = WPC; WTPC_pmltech = WTPC; WNPC_pmltech = WNPC;

YTYN_pmltech = YTYN; LTLN_pmltech = LTLN; IT_pmltech = IT; IN_pmltech = IN; 
PI_pmltech = PI; EI_pmltech = EI; I_pmltech = I;
CA_pmltech = CA; Sav_pmltech = Sav; NX_pmltech = NX; A_pmltech = A; 
B_pmltech = B; lambda_pmltech  = lambda; RK_pmltech = RK; YR_pmltech = YR; 

omegaL_pmltech = omegaL; omegaK_pmltech = omegaK; omegaI_pmltech = omegaI; omegaINYN_pmltech = omegaINYN;
omegaITYT_pmltech = omegaITYT; omegaGTYT_pmltech = omegaGTYT; omegaGNYN_pmltech = omegaGNYN; omegaGN_pmltech = omegaGN;
omegaYT_pmltech = omegaYT; omegaYN_pmltech = omegaYN; omegaLT_pmltech = omegaLT; omegaLN_pmltech = omegaLN; 
omegaC_pmltech =omegaC; omegaNX_pmltech =omegaNX; omegaG_pmltech =omegaG; omegaB_pmltech =omegaB; omegaKY_pmltech = omegaKY; 
alphaL_pmltech = alphaL; alphaK_pmltech = alphaK; alphaC_pmltech = alphaC; alphaI_pmltech = alphaI; 
omegaYTR_pmltech = omegaYTR; omegaYNR_pmltech = omegaYNR; sLT_pmltech = sLT; sLN_pmltech = sLN; PT_pmltech = PT; 
% Steady-State Changes
dC       = C_pmltech - C_0; % Steady-state change of real consumption 
dK       = K_pmltech - K_0; % Steady-state change of real capital 
dL       = L_pmltech - L_0; % Steady-state change of employment 
dP       = P_pmltech - P_0; % Steady-state change of real exchange rate 
dPT      = PT_pmltech - PT_0; % Steady-state change of terms of trade 
dB       = B_pmltech - B_0; % Steady-state change of traded bonds holding 
dlambda  = lambda_pmltech - lambda_0; % Steady-state change of marginal utility of wealth 
dY       = (YT_pmltech+(P_pmltech*YN_pmltech)) - (YT_0+(P_0*YN_0)); % Steady-state change of real GDP 
dY_check = Y_pmltech - Y_0; % Steady-state change of real GDP - Check
dA       = A_pmltech - A_0; % Steady-state change of financial wealth 
dW       = W_pmltech - W_0; % Steady-state change of the wage rate 
dWPC     = WPC_pmltech - WPC_0; % Steady-state change of the real aggregate wage W/PC 
dOmega   = Omega_pmltech - Omega_0; % Steady-state change of the sector wage ratio
dRK      = RK_pmltech - RK_0; % Steady-state change of the capital rental rate 

dG     = G_pmltech - G_0; % Steady-state change of CT
dCT   = CT_pmltech - CT_0; % Steady-state change of CT
dCN   = CN_pmltech - CN_0; % Steady-state change of CN
dLT   = LT_pmltech - LT_0; % Steady-state change of real capital 
dLN   = LN_pmltech - LN_0; % Steady-state change of employment 
dKT   = KT_pmltech - KT_0; % Steady-state change of real capital 
dKN   = KN_pmltech - KN_0; % Steady-state change of employment 
dYT   = YT_pmltech - YT_0; % Steady-state change of YT
dYN   = YN_pmltech - YN_0; % Steady-state change of YN
dWT   = WT_pmltech - WT_0; % Steady-state change of WT
dWN   = WN_pmltech - WN_0; % Steady-state change of WN
dWTPC = WTPC_pmltech - WTPC_0; % Steady-state change of WT/PC
dWNPC = WNPC_pmltech - WNPC_0; % Steady-state change of WN/PC
dkT   = kT_pmltech - kT_0; % Steady-state change of kT 
dkN   = kN_pmltech - kN_0; % Steady-state change of kN
dLTLN = LTLN_pmltech - LTLN_0; % Steady-state change of LT/LN
dYTYN = YTYN_pmltech - YTYN_0; % Steady-state change of LT/LN

dZT   = ZT_pmltech - ZT_0; 
dZN   = ZN_pmltech - ZN_0; 
dZA   = ZA_pmltech - ZA_0; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Solution for investment PI*K,
EK1   = PI + (K*omega_21); % Q(t)*K(t) - Q*K = EK1*X1(t) + EK2*X2(t)
EK2   = PI + (K*omega_22);

% Solution for the Relative Price of Non tradables P=P(K,Q,G)
wP_1   = P_K + (P_Q*omega_21);
wP_2   = P_K + (P_Q*omega_22);

% Solution for the Consumption Price index PC=PC(K,Q,G)
wPC_1  =  PC_K + (PC_Q*omega_21);
wPC_2  =  PC_K + (PC_Q*omega_22);

% Solution for the Investment Price index PI=PI(K,Q,G)
wPI_1  =  PI_K + (PI_Q*omega_21);
wPI_2  =  PI_K + (PI_Q*omega_22);

% Solution for Q(t)/PI(P(t))
wQPI_1  = QPI_K + (QPI_Q*omega_21);
wQPI_2  = QPI_K + (QPI_Q*omega_22);

% Solution for Consumption C=C(K,Q,G)
wC_1   = C_K + (C_Q*omega_21);
wC_2   = C_K + (C_Q*omega_22);

% Solution for Consumption J=J(K,Q,G)
wJ_1   = J_K + (J_Q*omega_21);
wJ_2   = J_K + (J_Q*omega_22);

% Solution for Consumption J=J(K,Q,G)
wNX_1   = NX_K + (NX_Q*omega_21);
wNX_2   = NX_K + (NX_Q*omega_22);

% Solution for the Capital Rental Rate R=R(K,Q,G)
wR_1  =  R_K + (R_Q*omega_21);
wR_2  =  R_K + (R_Q*omega_22);

wtildeRT_1  =  tildeRT_K + (tildeRT_Q*omega_21);           
wtildeRT_2  =  tildeRT_K + (tildeRT_Q*omega_22);           
wtildeRN_1  =  tildeRN_K + (tildeRN_Q*omega_21);           
wtildeRN_2  =  tildeRN_K + (tildeRN_Q*omega_22);           
                                                           
wtildeR_1  =  tildeR_K + (tildeR_Q*omega_21);              
wtildeR_2  =  tildeR_K + (tildeR_Q*omega_22);              

% Solution for the Aggregate Wage Index W=W(K,Q,G)
wW_1  =  W_K + (W_Q*omega_21);
wW_2  =  W_K + (W_Q*omega_22);

wtildeW_1  =  tildeW_K + (tildeW_Q*omega_21);   
wtildeW_2  =  tildeW_K + (tildeW_Q*omega_22);   

% Solution for the Real Consumption Wage W(K,Q,G,Aj,Bj)/PC(P)                  
wWPC_1  = WPC_K + (WPC_Q*omega_21);                                            
wWPC_2  = WPC_K + (WPC_Q*omega_22);

wtildeWPC_1  = tildeWPC_K + (tildeWPC_Q*omega_21);
wtildeWPC_2  = tildeWPC_K + (tildeWPC_Q*omega_22);

% Solution for Labor L=L(lambda,W)=L(K,Q,G)
wL_1  =  L_K + (L_Q*omega_21);
wL_2  =  L_K + (L_Q*omega_22);

% Solutions for the Sectoral Labor kj,K(K,Q,G)               
wkT_1  =  kT_K + (kT_Q*omega_21);                            
wkT_2  =  kT_K + (kT_Q*omega_22);                            
wkN_1  =  kN_K + (kN_Q*omega_21);                            
wkN_2  =  kN_K + (kN_Q*omega_22);                            
                                                             
wtildekT_1  =  tildekT_K + (tildekT_Q*omega_21);             
wtildekT_2  =  tildekT_K + (tildekT_Q*omega_22);             
wtildekN_1  =  tildekN_K + (tildekN_Q*omega_21);             
wtildekN_2  =  tildekN_K + (tildekN_Q*omega_22);             
                                                             
wtildeK_1  =  tildeK_K + (tildeK_Q*omega_21);                
wtildeK_2  =  tildeK_K + (tildeK_Q*omega_22);                
                                                             
% Solutions for the Sectoral Labor Lj=Lj(K,Q,G)
wLT_1  =  LT_K + (LT_Q*omega_21);
wLT_2  =  LT_K + (LT_Q*omega_22);

wLN_1  =  LN_K + (LN_Q*omega_21);
wLN_2  =  LN_K + (LN_Q*omega_22);

% Solution for Real GDP Y=Y(K,Q,G)
wY_1  = Y_K + (Y_Q*omega_21);
wY_2  = Y_K + (Y_Q*omega_22);

% Solutions for the Sectoral Output Yj=Yj(K,Q,G)
wYT_1  = YT_K + (YT_Q*omega_21);
wYT_2  = YT_K + (YT_Q*omega_22);
wYN_1  = YN_K + (YN_Q*omega_21);
wYN_2  = YN_K + (YN_Q*omega_22);

wtildeYT_1  = tildeYT_K + (tildeYT_Q*omega_21);    
wtildeYT_2  = tildeYT_K + (tildeYT_Q*omega_22);    
                                                   
wtildeYN_1  = tildeYN_K + (tildeYN_Q*omega_21);    
wtildeYN_2  = tildeYN_K + (tildeYN_Q*omega_22);    

wtildeYTYN_1  = tildeYTYN_K + (tildeYTYN_Q*omega_21);  
wtildeYTYN_2  = tildeYTYN_K + (tildeYTYN_Q*omega_22);  

% Solutions for Sectoral Capital Utilization Rate uKj(K,Q,G)                   
wuKT_1  = uKT_K + (uKT_Q*omega_21);                                            
wuKT_2  = uKT_K + (uKT_Q*omega_22);                                            
wuKN_1  = uKN_K + (uKN_Q*omega_21);                                            
wuKN_2  = uKN_K + (uKN_Q*omega_22);                                            
                                                                               
wuK_1   =  uK_K + (uK_Q*omega_21);                                             
wuK_2   =  uK_K + (uK_Q*omega_22);                                             
                                                                               
wuZT_1  =  uZT_K + (uZT_Q*omega_21);                                           
wuZT_2  =  uZT_K + (uZT_Q*omega_22);                                           
wuZN_1  =  uZN_K + (uZN_Q*omega_21);                                           
wuZN_2  =  uZN_K + (uZN_Q*omega_22);    

% Solutions for tildeZj,tildeZ(lambda,K,Q,G)                   
wtildeZT_1  = tildeZT_K + (tildeZT_Q*omega_21);                
wtildeZT_2  = tildeZT_K + (tildeZT_Q*omega_22);                
wtildeZN_1  = tildeZN_K + (tildeZN_Q*omega_21);                
wtildeZN_2  = tildeZN_K + (tildeZN_Q*omega_22);                
                                                               
wtildeZ_1   = tildeZ_K + (tildeZ_Q*omega_21);                  
wtildeZ_2   = tildeZ_K + (tildeZ_Q*omega_22);   

% Solutions for TFPj,TFP(lambda,K,Q,G)                              
wTFPT_1  = TFPT_K + (TFPT_Q*omega_21);                              
wTFPT_2  = TFPT_K + (TFPT_Q*omega_22);                              
wTFPN_1  = TFPN_K + (TFPN_Q*omega_21);                              
wTFPN_2  = TFPN_K + (TFPN_Q*omega_22);                              
                                                                    
wTFPT_1_check  = TFPT_K_check + (TFPT_Q_check*omega_21);            
wTFPT_2_check  = TFPT_K_check + (TFPT_Q_check*omega_22);            
wTFPN_1_check  = TFPN_K_check + (TFPN_Q_check*omega_21);            
wTFPN_2_check  = TFPN_K_check + (TFPN_Q_check*omega_22);            
                                                                    
wTFP_1   = TFP_K + (TFP_Q*omega_21);                                
wTFP_2   = TFP_K + (TFP_Q*omega_22);                                
                                                                    
wTFPR_1  = TFPR_K + (TFPR_Q*omega_21);                              
wTFPR_2  = TFPR_K + (TFPR_Q*omega_22);                              
wuZR_1   = uZR_K + (uZR_Q*omega_21);                                
wuZR_2   = uZR_K + (uZR_Q*omega_22);                                
                                                                                                                                             
% Solutions for the Sectoral Wages Wj=Wj(K,Q,G)
wWT_1  = WT_K + (WT_Q*omega_21);
wWT_2  = WT_K + (WT_Q*omega_22);
wWN_1  = WN_K + (WN_Q*omega_21);
wWN_2  = WN_K + (WN_Q*omega_22);

wtildeWT_1  = tildeWT_K + (tildeWT_Q*omega_21);     
wtildeWT_2  = tildeWT_K + (tildeWT_Q*omega_22);     
wtildeWN_1  = tildeWN_K + (tildeWN_Q*omega_21);     
wtildeWN_2  = tildeWN_K + (tildeWN_Q*omega_22);     

% Solutions for the Real Sectoral Wages Wj(K,Q,G,Aj,Bj)/PC(K,Q,G,Aj,Bj)        
wWTPC_1  = WTPC_K + (WTPC_Q*omega_21);                                         
wWTPC_2  = WTPC_K + (WTPC_Q*omega_22);                                         
wWNPC_1  = WNPC_K + (WNPC_Q*omega_21);                                         
wWNPC_2  = WNPC_K + (WNPC_Q*omega_22);    

wtildeWTPC_1  = tildeWTPC_K + (tildeWTPC_Q*omega_21);   
wtildeWTPC_2  = tildeWTPC_K + (tildeWTPC_Q*omega_22);   
wtildeWNPC_1  = tildeWNPC_K + (tildeWNPC_Q*omega_21);   
wtildeWNPC_2  = tildeWNPC_K + (tildeWNPC_Q*omega_22);   

% Solutions for the relative wages Wj/W: WjW=WjW(K,Q,G)        
% Solution for Omega = WN(K,Q,G)/WT(K,Q,G)                     
wWTW_1  = WTW_K + (WTW_Q*omega_21);                            
wWTW_2  = WTW_K + (WTW_Q*omega_22);                            
wWNW_1  = WNW_K + (WNW_Q*omega_21);                            
wWNW_2  = WNW_K + (WNW_Q*omega_22);                            
                                                               
wtildeWTW_1  = tildeWTW_K + (tildeWTW_Q*omega_21);             
wtildeWTW_2  = tildeWTW_K + (tildeWTW_Q*omega_22);             
wtildeWNW_1  = tildeWNW_K + (tildeWNW_Q*omega_21);             
wtildeWNW_2  = tildeWNW_K + (tildeWNW_Q*omega_22);             
                                                               
wOmega_1  =  Omega_K + (Omega_Q*omega_21);                     
wOmega_2  =  Omega_K + (Omega_Q*omega_22);                     
                                                               
wtildeOmega_1  =  tildeOmega_K + (tildeOmega_Q*omega_21);      
wtildeOmega_2  =  tildeOmega_K + (tildeOmega_Q*omega_22);  

% Solutions for YT/YN,LT/LN,tildeYT/tildeYN(K,Q,G)       
wYTYN_1  = YTYN_K + (YTYN_Q*omega_21);                   
wYTYN_2  = YTYN_K + (YTYN_Q*omega_22);                   
wLTLN_1  = LTLN_K + (LTLN_Q*omega_21);                   
wLTLN_2  = LTLN_K + (LTLN_Q*omega_22);                   
                                                         
wtildeYTYN_1  = tildeYTYN_K + (tildeYTYN_Q*omega_21);    
wtildeYTYN_2  = tildeYTYN_K + (tildeYTYN_Q*omega_22);    

% Solution for YH(K,Q,G)/YN(K,Q,G), Solution for LH(K,Q,G)/LN(K,Q,G)
% Solutions for the Real Sectoral Output Yj/YR=(Yj/YR)(K,Q,G)
% Solutions for the employment shares Lj/L=(Lj/L)(K,Q,G)
% Solutions for the employment shares sLj=LISj(K,Q,G) -

wLTS_1  = LTS_K + (LTS_Q*omega_21);
wLTS_2  = LTS_K + (LTS_Q*omega_22);
wLNS_1  = LNS_K + (LNS_Q*omega_21);
wLNS_2  = LNS_K + (LNS_Q*omega_22);

wYTS_1  = YTS_K + (YTS_Q*omega_21);
wYTS_2  = YTS_K + (YTS_Q*omega_22);
wYNS_1  = YNS_K + (YNS_Q*omega_21);
wYNS_2  = YNS_K + (YNS_Q*omega_22);

wtildeYTS_1  = tildeYTS_K + (tildeYTS_Q*omega_21);   
wtildeYTS_2  = tildeYTS_K + (tildeYTS_Q*omega_22);   
wtildeYNS_1  = tildeYNS_K + (tildeYNS_Q*omega_21);   
wtildeYNS_2  = tildeYNS_K + (tildeYNS_Q*omega_22);   

% sLj = Wj*Lj/(Pj*Yj) -
wLIST_1  = LIST_K + (LIST_Q*omega_21);
wLIST_2  = LIST_K + (LIST_Q*omega_22);
wLISN_1  = LISN_K + (LISN_Q*omega_21);
wLISN_2  = LISN_K + (LISN_Q*omega_22);

% Solutions for the Kj/K: Kj/K=Kj/K(lambda,K,Q,AH,BH,AN,BN) -
wKTK_1  = KTK_K + (KTK_Q*omega_21);
wKTK_2  = KTK_K + (KTK_Q*omega_22);
wKNK_1  = KNK_K + (KNK_Q*omega_21);
wKNK_2  = KNK_K + (KNK_Q*omega_22);

wtildeKTK_1  = tildeKTK_K + (tildeKTK_Q*omega_21);   
wtildeKTK_2  = tildeKTK_K + (tildeKTK_Q*omega_22);   
wtildeKNK_1  = tildeKNK_K + (tildeKNK_Q*omega_21);   
wtildeKNK_2  = tildeKNK_K + (tildeKNK_Q*omega_22);   

% Solutions for aggregate capital-labor ratio k, aggregate LIS sL, output
% share of non-tradables at current prices omegaYN
wLIS_1   =  LIS_K + (LIS_Q*omega_21);
wLIS_2   =  LIS_K + (LIS_Q*omega_22);

womegaYN_1   =  omegaYN_K + (omegaYN_Q*omega_21);
womegaYN_2   =  omegaYN_K + (omegaYN_Q*omega_22);

% Solutions for the relative return on capital uZj*R/Pj(K,Q,G)                       
wRPT_1  = RPT_K + (RPT_Q*omega_21);                                          
wRPT_2  = RPT_K + (RPT_Q*omega_22);                                          
wRPN_1  = RPN_K + (RPN_Q*omega_21);                                          
wRPN_2  = RPN_K + (RPN_Q*omega_22);                                          
                                                                             
wtildeRPT_1  = tildeRPT_K + (tildeRPT_Q*omega_21);                           
wtildeRPT_2  = tildeRPT_K + (tildeRPT_Q*omega_22);                           
wtildeRPN_1  = tildeRPN_K + (tildeRPN_Q*omega_21);                           
wtildeRPN_2  = tildeRPN_K + (tildeRPN_Q*omega_22);     

% Solution for Real GDP YR=YR(K,Q,G,Aj,Bj)                                                                                                                                                                                                                              
wYR_1  = YR_K + (YR_Q*omega_21);                            
wYR_2  = YR_K + (YR_Q*omega_22);

wtildeYR_1  = tildeYR_K + (tildeYR_Q*omega_21);                            
wtildeYR_2  = tildeYR_K + (tildeYR_Q*omega_22);

% Check uZT and uZN  
wuZT_check_1  =  uZT_check_K + (uZT_check_Q*omega_21);  
wuZT_check_2  =  uZT_check_K + (uZT_check_Q*omega_22);  
wuZN_check_1  =  uZN_check_K + (uZN_check_Q*omega_21);  
wuZN_check_2  =  uZN_check_K + (uZN_check_Q*omega_22);       

% Transitional Paths 
Tm = 0; Tu = 1; Tg = 10;
time0 = [Tm:Tu:0]; % Span of time t= [-20..0[ 
pathdGY0    = (omegaG_0 - omegaG_0) + 0*time0;
pathdZT0    = (ZT_0 - ZT_0) + 0*time0;
pathdZN0    = (ZN_0 - ZN_0) + 0*time0;
pathdZ0     = (ZA_0 - ZA_0) + 0*time0;
pathCY0     = (C_0 - C_0) + 0*time0;
pathdP0     = (P_0 - P_0) + 0*time0;
pathCAY0    = CA_0 + 0*time0;
pathdL0     = (L_0 - L_0) + 0*time0;
pathdLTL0   = (LN_0 - LN_0) + 0*time0;
pathdLNL0   = (LT_0 - LT_0) + 0*time0;
pathIY0     = (I_0 - I_0) + 0*time0;
pathSY0     = CA_0 + 0*time0;
pathdW0     = (W_0 - W_0) + 0*time0;
pathdK0     = (K_0 - K_0) + 0*time0;
pathdY0     = (Y_0 - Y_0) + 0*time0;
pathdWT0    = (WT_0 - WT_0) + 0*time0;
pathdWN0    = (WN_0 - WN_0) + 0*time0;
pathdOmega0 = (Omega_0 - Omega_0) + 0*time0;
pathdYTYN0  = (YTYN_0 - YTYN_0) + 0*time0;
pathdLTLN0  = (LTLN_0 - LTLN_0) + 0*time0;
pathdITY0   = (IN_0 - IN_0) + 0*time0;
pathdINY0   = (IT_0 - IT_0) + 0*time0;
pathdWPC0   = (WPC_0 - WPC_0) + 0*time0;
pathdQ0     = (PI_0 - PI_0) + 0*time0; 
pathdR0     = (RK_0 - RK_0) + 0*time0; 
pathdLIST0  = (sLT_0 - sLT_0) + 0*time0;
pathduKT0   = (PT_0 - PT_0) + 0*time0;
pathduZT0   = (PT_0 - PT_0) + 0*time0;
pathdLISN0  = (sLN_0 - sLN_0) + 0*time0;

time1        = [0:Tu:Tg]; % span of time t = [0..100]
VG           = exp(-xi*time1) - (1-barg)*exp(-chi*time1);
VG1          = exp(-xi*time1) - ThetaG_1*exp(-chi*time1);
VG2          = exp(-xi*time1) - ThetaG_2*exp(-chi*time1);

VG1prime      = xi*exp(-xi*time1) - chi*ThetaG_1*exp(-chi*time1);
VG2prime      = xi*exp(-xi*time1) - chi*ThetaG_2*exp(-chi*time1);
VGprime       = xi*exp(-xi*time1) - chi*(1-barg)*exp(-chi*time1);

VBG1prime     = xi*exp(-xi*time1) - chi*ThetaG_1prime*exp(-chi*time1);
VBG2prime     = xi*exp(-xi*time1) - chi*ThetaG_2prime*exp(-chi*time1);
VBGprime      = xi*exp(-xi*time1) - chi*ThetaG_prime*exp(-chi*time1);

X1 = X11*exp(nu_1*time1) + (DeltaG_1*VG1);
X2 = - (DeltaG_2*VG2);
%%%%%%%%%% Transitional paths %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% Transitional paths %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pathdGTY1    = (1-omegaGN)*VG*100;
pathdGNY1    = omegaGN*VG*100;
pathdGY1     = VG*100;

pathdK1      = (((K_pmltech-K_0) + (X1 + X2) )/K_0)*100;
pathdQ1      = (((PI_pmltech-PI_0) + (omega_21*X1) + (omega_22*X2) )/PI_0)*100;
pathdP1      = (((P_pmltech-P_0) + (wP_1*X1) + (wP_2*X2)  + (P_G*Y_0*VG) )/P_0)*100;
pathdCY1     = ( PC_0*((C_pmltech-C_0) + (wC_1*X1) + (wC_2*X2) + (C_G*Y_0*VG) )/Y_0 )*100;
pathdJY1     = ( PI_0*((I_pmltech-I_0) + (wJ_1*X1) + (wJ_2*X2) + (J_G*Y_0*VG) )/Y_0 )*100;
pathdNXY1    = ( ((NX_pmltech-NX_0) + (wNX_1*X1) + (wNX_2*X2)  + (NX_G*Y_0*VG) )/Y_0 )*100;

pathdQPI1    = ( (wQPI_1*X1) + (wQPI_2*X2) + (QPI_G*Y_0*VG) )*100;
pathdL1      = (((L_pmltech-L_0)  + (wL_1*X1) + (wL_2*X2) + (L_G*Y_0*VG) )/L_0)*100;
pathdLT1     = ( (W_0/W_0)*( (LT_pmltech-LT_0) + (wLT_1*X1) + (wLT_2*X2) + (LT_G*Y_0*VG) )/L_0)*100;
pathdLN1     = ( (W_0/W_0)*( (LN_pmltech-LN_0) + (wLN_1*X1) + (wLN_2*X2) + (LN_G*Y_0*VG) )/L_0)*100;
pathdW1      = (((W_pmltech-W_0) + (wW_1*X1) + (wW_2*X2)  + (W_G*Y_0*VG) )/W_0)*100;
pathdWT1     = (((WT_pmltech-WT_0) + (wWT_1*X1) + (wWT_2*X2)  + (WT_G*Y_0*VG) )/WT_0)*100;
pathdWN1     = (((WN_pmltech-WN_0) + (wWN_1*X1) + (wWN_2*X2)  + (WN_G*Y_0*VG) )/WN_0)*100;
pathdRPT1    = ((((RK_pmltech/PT_pmltech)-(RK_0/PT_0)) + (wRPT_1*X1) + (wRPT_2*X2) + (RPT_G*Y_0*VG) )/(RK_0/PT_0))*100;   
pathdRPN1    = ((((RK_pmltech/P_pmltech)-(RK_0/P_0)) + (wRPN_1*X1) + (wRPN_2*X2) + (RPN_G*Y_0*VG) )/(RK_0/P_0))*100;    

pathdWPC1    = (((WPC_pmltech-WPC_0) + (wWPC_1*X1) + (wWPC_2*X2) + (WPC_G*Y_0*VG) )/WPC_0)*100;
pathdWTPC1   = (((WTPC_pmltech-WTPC_0) + (wWTPC_1*X1) + (wWTPC_2*X2) + (WTPC_G*Y_0*VG) )/WTPC_0)*100;
pathdWNPC1   = (((WNPC_pmltech-WNPC_0) + (wWNPC_1*X1) + (wWNPC_2*X2) + (WNPC_G*Y_0*VG) )/WNPC_0)*100;

pathdY1      = (((Y_pmltech-Y_0) + (wY_1*X1) + (wY_2*X2) + (Y_G*Y_0*VG) )/Y_0)*100;
pathdYR1     = (((YR_pmltech-Y_0) + (wYR_1*X1) + (wYR_2*X2) + (YR_G*Y_0*VG) )/Y_0)*100;
pathdYT1     = (((YT_pmltech-YT_0) + (wYT_1*X1) + (wYT_2*X2) + (YT_G*Y_0*VG) )/Y_0)*100;
pathdYN1     = ( P_0*((YN_pmltech-YN_0) + (wYN_1*X1) + (wYN_2*X2) + (YN_G*Y_0*VG) )/Y_0)*100;

pathdOmega1  = (((Omega_pmltech-Omega_0) + (wOmega_1*X1) + (wOmega_2*X2) + (Omega_G*Y_0*VG) )/Omega_0)*100;              
pathdYTYN1   = (PT_0/P_0)*( ((YT_pmltech/YN_pmltech)-(YT_0/YN_0)) + (wYTYN_1*X1) + (wYTYN_2*X2) + (YTYN_G*Y_0*VG) )*100;  
pathdLTLN1   = (WT_0/WN_0)*( ((LT_pmltech/LN_pmltech)-(LT_0/LN_0)) + (wLTLN_1*X1) + (wLTLN_2*X2) + (LTLN_G*Y_0*VG) )*100; 

pathdWTW1   = (( ((WT_pmltech/W_pmltech)-(WT_0/W_0)) + (wWTW_1*X1) + (wWTW_2*X2) + (WTW_G*Y_0*VG) )/(WT_0/W_0) )*100; 
pathdWNW1   = (( ((WN_pmltech/W_pmltech)-(WN_0/W_0)) + (wWNW_1*X1) + (wWNW_2*X2) + (WNW_G*Y_0*VG) )/(WN_0/W_0) )*100; 
pathdLTS1    = (WT_0/W_0)*( ((LT_pmltech/L_pmltech)- (LT_0/L_0)) + (wLTS_1*X1) + (wLTS_2*X2)  + (LTS_G*Y_0*VG) )*100;
pathdLNS1    = (WN_0/W_0)*( ((LN_pmltech/L_pmltech)- (LN_0/L_0)) + (wLNS_1*X1) + (wLNS_2*X2)  + (LNS_G*Y_0*VG) )*100;
pathdYTS1    = ( ((YT_pmltech/YR_pmltech)- (YT_0/Y_0)) + (wYTS_1*X1) + (wYTS_2*X2) + (YTS_G*Y_0*VG) )*100;
pathdYNS1    = P_0*( ((YN_pmltech/YR_pmltech)- (YN_0/Y_0)) + (wYNS_1*X1) + (wYNS_2*X2) + (YNS_G*Y_0*VG) )*100;
pathdKTK1    =  ( ((KT_pmltech/K_pmltech)-(KT_0/K_0)) + (wKTK_1*X1) + (wKTK_2*X2)  + (KTK_G*Y_0*VG) )*100;
pathdKNK1    =  ( ((KN_pmltech/K_pmltech)-(KN_0/K_0)) + (wKNK_1*X1) + (wKNK_2*X2)  + (KNK_G*Y_0*VG) )*100;
pathdkT1     = ( LT_0*((kT_pmltech-kT_0) + (wkT_1*X1) + (wkT_2*X2)  + (kT_G*Y_0*VG) )/K_0)*100;
pathdkN1     = ( LN_0*((kN_pmltech-kN_0) + (wkN_1*X1) + (wkN_2*X2)  + (kN_G*Y_0*VG) )/K_0)*100;
pathdLIST1   = ( (sLT_pmltech-sLT_0) + (wLIST_1*X1) + (wLIST_2*X2)  + (LIST_G*Y_0*VG) )*100;
pathdLISN1   = ( (sLN_pmltech-sLN_0) + (wLISN_1*X1) + (wLISN_2*X2)  + (LISN_G*Y_0*VG) )*100;

pathdomegaYN1 = ( (omegaYN_pmltech-omegaYN_0) + (womegaYN_1*X1) + (womegaYN_2*X2) + (omegaYN_G*Y_0*VG) )*100;

CA_G  = (B_G*Y_0/(xi+r))*VBGprime + (N1*DeltaG_1/(xi+r))*VBG1prime - (N2*DeltaG_2/(xi+r))*VBG2prime;
SAV_G = (A_G*Y_0/(xi+r))*VBGprime + (M1*DeltaG_1/(xi+r))*VBG1prime - (M2*DeltaG_2/(xi+r))*VBG2prime;

dotX1 = nu_1*X11*exp(nu_1*time1) - (DeltaG_1*VG1prime);
dotX2 = (DeltaG_2*VG2prime);

pathCAY1 = (( -nu_1*(wB1/(r-nu_1))*exp(nu_1*time1) + CA_G )/Y_0 )*100;
pathSY1  = (( -nu_1*(wA1/(r-nu_1))*exp(nu_1*time1) + SAV_G )/Y_0 )*100;
pathIY1  = (( (EK1*dotX1) + (EK2*dotX2) )/Y_0)*100;

% Technology                                                                                                                                           
%%%%%%%%% Transitional paths - including technology and capital utilization rates %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                           
pathduKT1    = ( (wuKT_1*X1) + (wuKT_2*X2) + (uKT_G*Y_0*VG) )*100;                                                                                     
pathduKN1    = ( (wuKN_1*X1) + (wuKN_2*X2) + (uKN_G*Y_0*VG) )*100;                                                                                     
pathduK1     = ( (wuK_1*X1) + (wuK_2*X2) + (uK_G*Y_0*VG) )*100;                                                                                        
pathduZT1    = ( (wuZT_1*X1) + (wuZT_2*X2) + (uZT_G*Y_0*VG) )*100;                                                                                     
pathduZN1    = ( (wuZN_1*X1) + (wuZN_2*X2) + (uZN_G*Y_0*VG) )*100;    
pathduZT_check1 = ( (wuZT_check_1*X1) + (wuZT_check_2*X2) + (uZT_check_G*Y_0*VG) )*100;
pathduZN_check1 = ( (wuZN_check_1*X1) + (wuZN_check_2*X2) + (uZN_check_G*Y_0*VG) )*100;
pathdtildeZT1 = (( (ZT_pmltech-ZT_0) + (wtildeZT_1*X1) + (wtildeZT_2*X2) + (tildeZT_G*Y_0*VG) )/ZT_0)*100;                                              
pathdtildeZN1 = (( (ZN_pmltech-ZN_0) + (wtildeZN_1*X1) + (wtildeZN_2*X2) + (tildeZN_G*Y_0*VG) )/ZN_0)*100;                                              
pathdtildeZ1  = (( (ZA_pmltech-ZA_0) + (wtildeZ_1*X1) + (wtildeZ_2*X2) + (tildeZ_G*Y_0*VG) )/ZA_0)*100;     
pathdFBTCT1  = ((1-sigmaT)/sigmaT)*( pathduZT1 - pathduZT1 )*100; 
pathdFBTCN1  = ((1-sigmaN)/sigmaN)*( pathduZN1 - pathduZN1 )*100; 
                                                                                                                                                      
pathdTFPT1   = (( (ZT_pmltech-ZT_0) + (wTFPT_1*X1) + (wTFPT_2*X2) + (TFPT_G*Y_0*VG) )/ZT_0)*100;                                                        
pathdTFPN1   = (( (ZN_pmltech-ZN_0) + (wTFPN_1*X1) + (wTFPN_2*X2) + (TFPN_G*Y_0*VG) )/ZN_0)*100;                                                        
pathdTFP1    = (( (ZA_pmltech-ZA_0) + (wTFP_1*X1) + (wTFP_2*X2) + (TFP_G*Y_0*VG) )/ZA_0)*100;                                                              
pathdTFPT1_check   = (( (ZT_pmltech-ZT_0) + (wTFPT_1_check*X1) + (wTFPT_2_check*X2) + (TFPT_G_check*Y_0*VG) )/ZT_0)*100;                                
pathdTFPN1_check   = (( (ZN_pmltech-ZN_0) + (wTFPN_1_check*X1) + (wTFPN_2_check*X2) + (TFPN_G_check*Y_0*VG) )/ZN_0)*100;                                
pathdTFPR1   = (( ((ZT_pmltech/ZN_pmltech)-(ZT_0/ZN_0)) + (wTFPR_1*X1) + (wTFPR_2*X2) + (TFPR_G*Y_0*VG) )/(ZT_0/ZN_0))*100;                              
pathduZR1    = ( (wuZR_1*X1) + (wuZR_2*X2) + (uZR_G*Y_0*VG) )*100;                                                                                     
                                                                                                                                                       
pathdtildeK1    = (( (K_pmltech-K_0) + (wtildeK_1*X1) + (wtildeK_2*X2) + (tildeK_G*Y_0*VG) )/K_0)*100;                                                  
pathdtildeW1    = (((W_pmltech-W_0) + (wtildeW_1*X1) + (wtildeW_2*X2) + (tildeW_G*Y_0*VG) )/W_0)*100;                                                   
pathdtildeR1    = (((RK_pmltech-RK_0) + (wtildeR_1*X1) + (wtildeR_2*X2) + (tildeR_G*Y_0*VG) )/RK_0)*100;                                                
pathdtildeWPC1  = (((WPC_pmltech-WPC_0) + (wtildeWPC_1*X1) + (wtildeWPC_2*X2) + (tildeWPC_G*Y_0*VG) )/WPC_0)*100;                                       
pathdtildeYR1   = (((YR_pmltech-Y_0) + (wtildeYR_1*X1) + (wtildeYR_2*X2) + (tildeYR_G*Y_0*VG) )/Y_0)*100;                                               
pathdtildeYT1   = ( PT_0*((YT_pmltech-YT_0) + (wtildeYT_1*X1) + (wtildeYT_2*X2) + (tildeYT_G*Y_0*VG) )/Y_0)*100;                                        
pathdtildeYN1   = ( P_0*((YN_pmltech-YN_0) + (wtildeYN_1*X1) + (wtildeYN_2*X2) + (tildeYN_G*Y_0*VG) )/Y_0)*100;                                         
pathdtildeWT1   = (((WT_pmltech-WT_0) + (wtildeWT_1*X1) + (wtildeWT_2*X2) + (tildeWT_G*Y_0*VG) )/WT_0)*100;                                             
pathdtildeWN1   = (((WN_pmltech-WN_0) + (wtildeWN_1*X1) + (wtildeWN_2*X2) + (tildeWN_G*Y_0*VG) )/WN_0)*100;                                             
pathdtildeWTPC1 = (((WTPC_pmltech-WTPC_0) + (wtildeWTPC_1*X1) + (wtildeWTPC_2*X2) + (tildeWTPC_G*Y_0*VG) )/WTPC_0)*100;                                 
pathdtildeWNPC1 = (((WNPC_pmltech-WNPC_0) + (wtildeWNPC_1*X1) + (wtildeWNPC_2*X2) + (tildeWNPC_G*Y_0*VG) )/WNPC_0)*100;                                 
pathdtildekT1   = ( LT_0*((kT_pmltech-kT_0) + (wtildekT_1*X1) + (wtildekT_2*X2) + (tildekT_G*Y_0*VG) )/K_0)*100; 
pathdtildekN1   = ( LN_0*((kN_pmltech-kN_0) + (wtildekN_1*X1) + (wtildekN_2*X2) + (tildekN_G*Y_0*VG) )/K_0)*100;                                      
pathdtildeRPT1  = ((((RK_pmltech/PT_pmltech)-(RK_0/PT_0)) + (wtildeRPT_1*X1) + (wtildeRPT_2*X2) + (tildeRPT_G*Y_0*VG) )/(RK_0/PT_0))*100;                
pathdtildeRPN1  = ((((RK_pmltech/P_pmltech)-(RK_0/P_0)) + (wtildeRPN_1*X1) + (wtildeRPN_2*X2) + (tildeRPN_G*Y_0*VG) )/(RK_0/P_0))*100;                  
                                                                                                                                                       
pathdtildeOmega1 = (((Omega_pmltech-Omega_0) + (wtildeOmega_1*X1) + (wtildeOmega_2*X2) + (tildeOmega_G*Y_0*VG) )/Omega_0)*100;                          
pathdtildeYTYN1  = (1/P_0)*( ((YT_pmltech/YN_pmltech)-(YT_0/YN_0)) + (wtildeYTYN_1*X1) + (wtildeYTYN_2*X2) + (tildeYTYN_G*Y_0*VG) )*100;                 
pathdtildeYTS1   = PT_0*( ((YT_pmltech/YR_pmltech)- (YT_0/YR_0)) + (wtildeYTS_1*X1) + (wtildeYTS_2*X2) + (tildeYTS_G*Y_0*VG) )*100;                      
pathdtildeYNS1   = P_0*( ((YN_pmltech/YR_pmltech)- (YN_0/YR_0)) + (wtildeYNS_1*X1) + (wtildeYNS_2*X2) + (tildeYNS_G*Y_0*VG) )*100;                       
pathdtildeWTW1   = (( ((WT_pmltech/W_pmltech)-(WT_0/W_0)) + (wtildeWTW_1*X1) + (wtildeWTW_2*X2) + (tildeWTW_G*Y_0*VG) )/(WT_0/W_0) )*100;                
pathdtildeWNW1   = (( ((WN_pmltech/W_pmltech)-(WN_0/W_0)) + (wtildeWNW_1*X1) + (wtildeWNW_2*X2) + (tildeWNW_G*Y_0*VG) )/(WN_0/W_0) )*100;                
pathdtildeKTK1   =  ( ((KT_pmltech/K_pmltech)-(KT_0/K_0)) + (wtildeKTK_1*X1) + (wtildeKTK_2*X2) + (tildeKTK_G*Y_0*VG) )*100;                             
pathdtildeKNK1   =  ( ((KN_pmltech/K_pmltech)-(KN_0/K_0)) + (wtildeKNK_1*X1) + (wtildeKNK_2*X2) + (tildeKNK_G*Y_0*VG) )*100;                             

% Temporal paths over entire period
timetemp = [time0 time1];
pathdGY_pmltech    = [pathdGY0  pathdGY1];
pathdQ_pmltech     = [pathdQ0  pathdQ1];
pathdQPI_pmltech   = [pathdQ0  pathdQPI1];
pathdP_pmltech     = [pathdP0  pathdP1];
pathCY_pmltech     = [pathCY0  pathdCY1];
pathdL_pmltech     = [pathdL0  pathdL1];
pathdLT_pmltech   = [pathdLTL0 pathdLT1];
pathdLN_pmltech   = [pathdLNL0 pathdLN1];
pathdkT_pmltech   = [pathdLTL0 pathdkT1];
pathdkN_pmltech   = [pathdLNL0 pathdkN1];
pathdW_pmltech     = [pathdW0 pathdW1];
pathdYR_pmltech    = [pathdY0 pathdYR1];
pathdYT_pmltech   = [pathdY0 pathdYT1];
pathdYN_pmltech   = [pathdY0 pathdYN1];
pathdWT_pmltech    = [pathdWT0  pathdWT1];
pathdWN_pmltech    = [pathdWN0  pathdWN1];

pathdWPC_pmltech     = [pathdW0 pathdWPC1];
pathdWTPC_pmltech    = [pathdWT0  pathdWTPC1];
pathdWNPC_pmltech    = [pathdWN0  pathdWNPC1];

pathIY_pmltech     = [pathIY0  pathIY1];
pathCAY_pmltech    = [pathCAY0 pathCAY1];
pathSY_pmltech     = [pathSY0  pathSY1];

pathdLTS_pmltech   = [pathdLTL0 pathdLTS1];
pathdLNS_pmltech   = [pathdLNL0 pathdLNS1];
pathdYTS_pmltech   = [pathdY0 pathdYTS1];
pathdYNS_pmltech   = [pathdY0 pathdYNS1];

pathdLIST_pmltech  = [pathdLIST0 pathdLIST1];
pathdLISN_pmltech  = [pathdLISN0 pathdLISN1];

pathdomegaYN_pmltech  = [pathdLISN0 pathdomegaYN1];

% IRF including technology and capital utilization rates                                   
pathduKT_pmltech   = [pathduKT0 pathduKT1];                                
pathduKN_pmltech   = [pathduKT0 pathduKN1];                                
pathduK_pmltech    = [pathduKT0 pathduK1];                                 
pathduZT_pmltech   = [pathduZT0 pathduZT1];                                
pathduZN_pmltech   = [pathduZT0 pathduZN1];                                
pathdtildeZT_pmltech  = [pathduKT0 pathdtildeZT1];                         
pathdtildeZN_pmltech  = [pathduKT0 pathdtildeZN1];                         
pathdtildeZ_pmltech   = [pathduKT0 pathdtildeZ1];                          
pathdTFPT_pmltech  = [pathduKT0 pathdTFPT1];                               
pathdTFPN_pmltech  = [pathduKT0 pathdTFPN1];                               
pathdTFP_pmltech   = [pathduKT0 pathdTFP1];                                
pathdTFPT_check_pmltech  = [pathduKT0 pathdTFPT1_check];                   
pathdTFPN_check_pmltech  = [pathduKT0 pathdTFPN1_check];                   
pathdTFPR_pmltech  = [pathduKT0 pathdTFPR1];                               
pathduZR_pmltech   = [pathduKT0 pathduZR1];  
pathduZT_check_pmltech   = [pathduZT0 pathduZT_check1];   
pathduZN_check_pmltech   = [pathduZT0 pathduZN_check1];   
                                                                                           
pathdtildeK_pmltech     = [pathdK0  pathdtildeK1];                                          
pathdtildeW_pmltech     = [pathdW0 pathdtildeW1];                                           
pathdtildeR_pmltech     = [pathdR0 pathdtildeR1];                                           
pathdtildeWPC_pmltech   = [pathdWPC0 pathdtildeWPC1];                                       
pathdtildeYR_pmltech    = [pathdY0 pathdtildeYR1];                                          
pathdtildeYT_pmltech    = [pathdY0 pathdtildeYT1];                                          
pathdtildeYN_pmltech    = [pathdY0 pathdtildeYN1];                                          
pathdtildeWT_pmltech    = [pathdWT0  pathdtildeWT1];                                        
pathdtildeWN_pmltech    = [pathdWN0  pathdtildeWN1];                                        
pathdtildeWTPC_pmltech  = [pathdWT0 pathdtildeWTPC1];                                       
pathdtildeWNPC_pmltech  = [pathdWN0 pathdtildeWNPC1];                                       
pathdtildeRPH_pmltech    = [pathdR0  pathdtildeRPT1];                                       
pathdtildeRPN_pmltech    = [pathdR0  pathdtildeRPN1];                                       
                                                                                           
pathdtildeYTS_pmltech   = [pathdY0 pathdtildeYTS1];                                         
pathdtildeYNS_pmltech   = [pathdY0 pathdtildeYNS1];                                         
pathdtildeWTW_pmltech   = [pathdWT0 pathdtildeWTW1];                                        
pathdtildeWNW_pmltech   = [pathdWN0 pathdtildeWNW1];                                        
pathdtildeKTK_pmltech   = [pathdK0 pathdtildeKTK1];                                        
pathdtildeKNK_pmltech   = [pathdK0 pathdtildeKNK1];                                        
                                                                                           
pathdtildekT_pmltech    = [pathdK0 pathdtildekT1];                                         
pathdtildekN_pmltech    = [pathdK0 pathdtildekN1];                                         
pathdtildeOmega_pmltech = [pathdOmega0 pathdtildeOmega1];                                   
pathdtildeYTYN_pmltech  = [pathdYTYN0 pathdtildeYTYN1];                                     
                                                                                           
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% Dynamic and steadty-state effects of a Permanent increase in ZH/ZN %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Impact effects of fiscal shock: dynamic processes
VG0          = 1 - (1-barg);
VG10         = 1 - ThetaG_1;
VG20         = 1 - ThetaG_2;

VG1prime0    = xi - chi*ThetaG_1;
VG2prime0    = xi - chi*ThetaG_2;
VGprime0     = xi - chi*(1-barg);

VBG1prime0   = xi - (chi*ThetaG_1prime);
VBG2prime0   = xi - (chi*ThetaG_2prime);
VBGprime0    = xi - (chi*ThetaG_prime);

X10 = X11 + (DeltaG_1*VG10);
X20 = - (DeltaG_2*VG20);
%%%%%%%%%% Transitional paths %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% Transitional paths %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dGTYtime0_pmltech    = (1-omegaGN)*VG0*100;
dGNYtime0_pmltech    = omegaGN*VG0*100;
dGYtime0_pmltech     = VG0*100;

dKtime0_pmltech      = (((K_pmltech-K_0) + (X10 + X20) )/K_0)*100;
dQtime0_pmltech      = (((PI_pmltech-PI_0) + (omega_21*X10) + (omega_22*X20) )/PI_0)*100;
dPtime0_pmltech      = (((P_pmltech-P_0) + (wP_1*X10) + (wP_2*X20)  + (P_G*Y_0*VG0) )/P_0)*100;
dPTtime0_pmltech     = ((PT_pmltech-PT_0)/PT_0)*100;

dCYtime0_pmltech     = ( PC_0*((C_pmltech-C_0) + (wC_1*X10) + (wC_2*X20)  + (C_G*Y_0*VG0) )/Y_0 )*100;
dJYtime0_pmltech     = ( PI_0*((I_pmltech-I_0) + (wJ_1*X10) + (wJ_2*X20)  + (J_G*Y_0*VG0) )/Y_0 )*100;
dNXYtime0_pmltech    = ( ((NX_pmltech-NX_0) + (wNX_1*X10) + (wNX_2*X20)   + (NX_G*Y_0*VG0) )/Y_0 )*100;

dQPItime0_pmltech    = ( (wQPI_1*X10) + (wQPI_2*X20) + (QPI_G*Y_0*VG0) )*100;
dLtime0_pmltech      = (((L_pmltech-L_0)  + (wL_1*X10) + (wL_2*X20) + (L_G*Y_0*VG0) )/L_0)*100;
dLTtime0_pmltech     = ( (W_0/W_0)*( (LT_pmltech-LT_0) + (wLT_1*X10) + (wLT_2*X20) + (LT_G*Y_0*VG0) )/L_0)*100;
dLNtime0_pmltech     = ( (W_0/W_0)*( (LN_pmltech-LN_0) + (wLN_1*X10) + (wLN_2*X20) + (LN_G*Y_0*VG0) )/L_0)*100;
dWtime0_pmltech      = (((W_pmltech-W_0) + (wW_1*X10) + (wW_2*X20)  + (W_G*Y_0*VG0) )/W_0)*100;
dWTtime0_pmltech     = (((WT_pmltech-WT_0) + (wWT_1*X10) + (wWT_2*X20)  + (WT_G*Y_0*VG0) )/WT_0)*100;
dWNtime0_pmltech     = (((WN_pmltech-WN_0) + (wWN_1*X10) + (wWN_2*X20)  + (WN_G*Y_0*VG0) )/WN_0)*100;
dRtime0_pmltech      = (((RK_pmltech-RK_0) + (wR_1*X10) + (wR_2*X20)  + (R_G*Y_0*VG0) )/RK_0)*100;

dWPCtime0_pmltech    = (((WPC_pmltech-WPC_0) + (wWPC_1*X10) + (wWPC_2*X20) + (WPC_G*Y_0*VG0) )/WPC_0)*100;
dWTPCtime0_pmltech   = (((WTPC_pmltech-WTPC_0) + (wWTPC_1*X10) + (wWTPC_2*X20) + (WTPC_G*Y_0*VG0) )/WTPC_0)*100;
dWNPCtime0_pmltech   = (((WNPC_pmltech-WNPC_0) + (wWNPC_1*X10) + (wWNPC_2*X20) + (WNPC_G*Y_0*VG0) )/WNPC_0)*100;
dRPTtime0_pmltech    = ((((RK_pmltech/PT_pmltech)-(RK_0/PT_0)) + (wRPT_1*X10) + (wRPT_2*X20) + (RPT_G*Y_0*VG0) )/(RK_0/PT_0))*100; 
dRPNtime0_pmltech    = ((((RK_pmltech/P_pmltech)-(RK_0/P_0)) + (wRPN_1*X10) + (wRPN_2*X20) + (RPN_G*Y_0*VG0) )/(RK_0/P_0))*100;  

dYtime0_pmltech      = (((Y_pmltech-Y_0) + (wY_1*X10) + (wY_2*X20) + (Y_G*Y_0*VG0) )/Y_0)*100;
dYRtime0_pmltech     = (((YR_pmltech-Y_0) + (wYR_1*X10) + (wYR_2*X20) + (YR_G*Y_0*VG0) )/Y_0)*100;
dYTtime0_pmltech     = (((YT_pmltech-YT_0) + (wYT_1*X10) + (wYT_2*X20) + (YT_G*Y_0*VG0) )/Y_0)*100;
dYNtime0_pmltech     = ( P_0*((YN_pmltech-YN_0) + (wYN_1*X10) + (wYN_2*X20) + (YN_G*Y_0*VG0) )/Y_0)*100;

dOmegatime0_pmltech  = (((Omega_pmltech-Omega_0) + (wOmega_1*X10) + (wOmega_2*X20) + (Omega_G*Y_0*VG0) )/Omega_0)*100;              
dYTYNtime0_pmltech   = (PT_0/P_0)*(  ((YT_pmltech/YN_pmltech)-(YT_0/YN_0)) + (wYTYN_1*X10) + (wYTYN_2*X20) + (YTYN_G*Y_0*VG0) )*100; 
dLTLNtime0_pmltech   = (WT_0/WN_0)*( ((LT_pmltech/LN_pmltech)-(LT_0/LN_0)) + (wLTLN_1*X10) + (wLTLN_2*X20) + (LTLN_G*Y_0*VG0) )*100; 
dWTWtime0_pmltech   = (( ((WT_pmltech/W_pmltech)-(WT_0/W_0)) + (wWTW_1*X10) + (wWTW_2*X20) + (WTW_G*Y_0*VG0) )/(WT_0/W_0) )*100; 
dWNWtime0_pmltech   = (( ((WN_pmltech/W_pmltech)-(WN_0/W_0)) + (wWNW_1*X10) + (wWNW_2*X20) + (WNW_G*Y_0*VG0) )/(WN_0/W_0) )*100; 

dLTStime0_pmltech    = (WT_0/W_0)*( ((LT_pmltech/L_pmltech)- (LT_0/L_0)) + (wLTS_1*X10) + (wLTS_2*X20)  + (LTS_G*Y_0*VG0) )*100;
dLNStime0_pmltech    = (WN_0/W_0)*( ((LN_pmltech/L_pmltech)- (LN_0/L_0)) + (wLNS_1*X10) + (wLNS_2*X20)  + (LNS_G*Y_0*VG0) )*100;
dYTStime0_pmltech    = ( ((YT_pmltech/YR_pmltech)- (YT_0/Y_0)) + (wYTS_1*X10) + (wYTS_2*X20) + (YTS_G*Y_0*VG0) )*100;
dYNStime0_pmltech    = P_0*( ((YN_pmltech/YR_pmltech)- (YN_0/Y_0)) + (wYNS_1*X10) + (wYNS_2*X20) + (YNS_G*Y_0*VG0) )*100;
dKTKtime0_pmltech    =  ( ((KT_pmltech/K_pmltech)-(KT_0/K_0)) + (wKTK_1*X10) + (wKTK_2*X20)  + (KTK_G*Y_0*VG0) )*100;
dKNKtime0_pmltech    =  ( ((KN_pmltech/K_pmltech)-(KN_0/K_0)) + (wKNK_1*X10) + (wKNK_2*X20)  + (KNK_G*Y_0*VG0) )*100;
dkTtime0_pmltech     = ( LT_0*((kT_pmltech-kT_0) + (wkT_1*X10) + (wkT_2*X20)  + (kT_G*Y_0*VG0) )/K_0)*100;
dkNtime0_pmltech     = ( LN_0*((kN_pmltech-kN_0) + (wkN_1*X10) + (wkN_2*X20)  + (kN_G*Y_0*VG0) )/K_0)*100;
dLISTtime0_pmltech   = ( (sLT_pmltech-sLT_0) + (wLIST_1*X10) + (wLIST_2*X20)  + (LIST_G*Y_0*VG0) )*100;
dLISNtime0_pmltech   = ( (sLN_pmltech-sLN_0) + (wLISN_1*X10) + (wLISN_2*X20)  + (LISN_G*Y_0*VG0) )*100;

domegaYNtime0_pmltech = ( (omegaYN_pmltech-omegaYN_0) + (womegaYN_1*X10) + (womegaYN_2*X20) + (omegaYN_G*Y_0*VG0) )*100;

CA_G0  = (B_G*Y_0/(xi+r))*VBGprime0 + (N1*DeltaG_1/(xi+r))*VBG1prime0 - (N2*DeltaG_2/(xi+r))*VBG2prime0;
SAV_G0 = (A_G*Y_0/(xi+r))*VBGprime0 + (M1*DeltaG_1/(xi+r))*VBG1prime0 - (M2*DeltaG_2/(xi+r))*VBG2prime0;

dotX10 = (nu_1*X11) - (DeltaG_1*VG1prime0);
dotX20 = (DeltaG_2*VG2prime0);

CAYtime0_pmltech = (( -nu_1*(wB1/(r-nu_1)) + CA_G0 )/Y_0 )*100;
SYtime0_pmltech  = (( -nu_1*(wA1/(r-nu_1)) + SAV_G0 )/Y_0 )*100;
IYtime0_pmltech  = (( (EK1*dotX10) + (EK2*dotX20) )/Y_0)*100;

CAYtime0_pmltech_check = SYtime0_pmltech - IYtime0_pmltech;

% Technology
%%%%%%%%% Transitional paths - including technology and capital utilization rates %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
duKTtime0_pmltech    = ( (wuKT_1*X10) + (wuKT_2*X20) + (uKT_G*Y_0*VG0) )*100;
duKNtime0_pmltech    = ( (wuKN_1*X10) + (wuKN_2*X20) + (uKN_G*Y_0*VG0) )*100;
duKtime0_pmltech     = ( (wuK_1*X10) + (wuK_2*X20) + (uK_G*Y_0*VG0) )*100;
duZTtime0_pmltech    = ( (wuZT_1*X10) + (wuZT_2*X20) + (uZT_G*Y_0*VG0) )*100;
duZNtime0_pmltech    = ( (wuZN_1*X10) + (wuZN_2*X20) + (uZN_G*Y_0*VG0) )*100;
dtildeZTtime0_pmltech = (( (ZT_pmltech-ZT_0) + (wtildeZT_1*X10) + (wtildeZT_2*X20) + (tildeZT_G*Y_0*VG0) )/ZT_0)*100;
dtildeZNtime0_pmltech = (( (ZN_pmltech-ZN_0) + (wtildeZN_1*X10) + (wtildeZN_2*X20) + (tildeZN_G*Y_0*VG0) )/ZN_0)*100;
dtildeZtime0_pmltech  = (( (ZA_pmltech-ZA_0) + (wtildeZ_1*X10) + (wtildeZ_2*X20) + (tildeZ_G*Y_0*VG0) )/ZA_0)*100;
dFBTCTtime0_pmltech = ((1-sigmaT)/sigmaT)*( duZTtime0_pmltech - duZTtime0_pmltech  )*100; 
dFBTCNtime0_pmltech = ((1-sigmaN)/sigmaN)*( duZNtime0_pmltech - duZNtime0_pmltech  )*100; 
duZTtime0_check_pmltech    = ( (wuZT_check_1*X10) + (wuZT_check_2*X20) + (uZT_check_G*Y_0*VG0) )*100; 
duZNtime0_check_pmltech    = ( (wuZN_check_1*X10) + (wuZN_check_2*X20) + (uZN_check_G*Y_0*VG0) )*100; 

dTFPTtime0_pmltech   = (( (ZT_pmltech-ZT_0) + (wTFPT_1*X10) + (wTFPT_2*X20) + (TFPT_G*Y_0*VG0) )/ZT_0)*100;
dTFPNtime0_pmltech   = (( (ZN_pmltech-ZN_0) + (wTFPN_1*X10) + (wTFPN_2*X20) + (TFPN_G*Y_0*VG0) )/ZN_0)*100;
dTFPtime0_pmltech    = (( (ZA_pmltech-ZA_0) + (wTFP_1*X10) + (wTFP_2*X20) + (TFP_G*Y_0*VG0) )/ZA_0)*100;
dTFPTtime0_check_pmltech = (( (ZT_pmltech-ZT_0) + (wTFPT_1_check*X10) + (wTFPT_2_check*X20) + (TFPT_G_check*Y_0*VG0) )/ZT_0)*100;
dTFPNtime0_check_pmltech = (( (ZN_pmltech-ZN_0) + (wTFPN_1_check*X10) + (wTFPN_2_check*X20) + (TFPN_G_check*Y_0*VG0) )/ZN_0)*100;
dTFPRtime0_pmltech   = (( ((ZT_pmltech/ZN_pmltech)-(ZT_0/ZN_0)) + (wTFPR_1*X10) + (wTFPR_2*X20) + (TFPR_G*Y_0*VG0) )/(ZT_0/ZN_0))*100;
duZRtime0_pmltech    = ( (wuZR_1*X10) + (wuZR_2*X20) + (uZR_G*Y_0*VG0) )*100;

dtildeKtime0_pmltech    = (( (K_pmltech-K_0) + (wtildeK_1*X10) + (wtildeK_2*X20) + (tildeK_G*Y_0*VG0) )/K_0)*100;
dtildeWtime0_pmltech    = (((W_pmltech-W_0) + (wtildeW_1*X10) + (wtildeW_2*X20) + (tildeW_G*Y_0*VG0) )/W_0)*100;
dtildeRtime0_pmltech    = (((RK_pmltech-RK_0) + (wtildeR_1*X10) + (wtildeR_2*X20) + (tildeR_G*Y_0*VG0) )/RK_0)*100;
dtildeWPCtime0_pmltech  = (((WPC_pmltech-WPC_0) + (wtildeWPC_1*X10) + (wtildeWPC_2*X20) + (tildeWPC_G*Y_0*VG0) )/WPC_0)*100;
dtildeYRtime0_pmltech   = (((YR_pmltech-Y_0) + (wtildeYR_1*X10) + (wtildeYR_2*X20) + (tildeYR_G*Y_0*VG0) )/Y_0)*100;
dtildeYTtime0_pmltech   = ( PT_0*((YT_pmltech-YT_0) + (wtildeYT_1*X10) + (wtildeYT_2*X20) + (tildeYT_G*Y_0*VG0) )/Y_0)*100;
dtildeYNtime0_pmltech   = ( P_0*((YN_pmltech-YN_0) + (wtildeYN_1*X10) + (wtildeYN_2*X20) + (tildeYN_G*Y_0*VG0) )/Y_0)*100;
dtildeWTtime0_pmltech   = (((WT_pmltech-WT_0) + (wtildeWT_1*X10) + (wtildeWT_2*X20) + (tildeWT_G*Y_0*VG0) )/WT_0)*100;
dtildeWNtime0_pmltech   = (((WN_pmltech-WN_0) + (wtildeWN_1*X10) + (wtildeWN_2*X20) + (tildeWN_G*Y_0*VG0) )/WN_0)*100;
dtildeWTPCtime0_pmltech = (((WTPC_pmltech-WTPC_0) + (wtildeWTPC_1*X10) + (wtildeWTPC_2*X20) + (tildeWTPC_G*Y_0*VG0) )/WTPC_0)*100;
dtildeWNPCtime0_pmltech = (((WNPC_pmltech-WNPC_0) + (wtildeWNPC_1*X10) + (wtildeWNPC_2*X20) + (tildeWNPC_G*Y_0*VG0) )/WNPC_0)*100;
dtildekTtime0_pmltech   = ( LT_0*((kT_pmltech-kT_0) + (wtildekT_1*X10) + (wtildekT_2*X20) + (tildekT_G*Y_0*VG0) )/K_0)*100;
dtildekNtime0_pmltech   = ( LN_0*((kN_pmltech-kN_0) + (wtildekN_1*X10) + (wtildekN_2*X20) + (tildekN_G*Y_0*VG0) )/K_0)*100;
dtildeRPTtime0_pmltech  = ((((RK_pmltech/PT_pmltech)-(RK_0/PT_0)) + (wtildeRPT_1*X10) + (wtildeRPT_2*X20) + (tildeRPT_G*Y_0*VG0) )/(RK_0/PT_0))*100;
dtildeRPNtime0_pmltech  = ((((RK_pmltech/P_pmltech)-(RK_0/P_0)) + (wtildeRPN_1*X10) + (wtildeRPN_2*X20) + (tildeRPN_G*Y_0*VG0) )/(RK_0/P_0))*100;

dtildeOmegatime0_pmltech = (((Omega_pmltech-Omega_0) + (wtildeOmega_1*X10) + (wtildeOmega_2*X20) + (tildeOmega_G*Y_0*VG0) )/Omega_0)*100;
dtildeYTYNtime0_pmltech  = (1/P_0)*( ((YT_pmltech/YN_pmltech)-(YT_0/YN_0)) + (wtildeYTYN_1*X10) + (wtildeYTYN_2*X20) + (tildeYTYN_G*Y_0*VG0) )*100;
dtildeYTStime0_pmltech   = PT_0*( ((YT_pmltech/YR_pmltech)- (YT_0/YR_0)) + (wtildeYTS_1*X10) + (wtildeYTS_2*X20) + (tildeYTS_G*Y_0*VG0) )*100;
dtildeYNStime0_pmltech   = P_0*( ((YN_pmltech/YR_pmltech)- (YN_0/YR_0)) + (wtildeYNS_1*X10) + (wtildeYNS_2*X20) + (tildeYNS_G*Y_0*VG0) )*100;
dtildeWTWtime0_pmltech   = (( ((WT_pmltech/W_pmltech)-(WT_0/W_0)) + (wtildeWTW_1*X10) + (wtildeWTW_2*X20) + (tildeWTW_G*Y_0*VG0) )/(WT_0/W_0) )*100;
dtildeWNWtime0_pmltech   = (( ((WN_pmltech/W_pmltech)-(WN_0/W_0)) + (wtildeWNW_1*X10) + (wtildeWNW_2*X20) + (tildeWNW_G*Y_0*VG0) )/(WN_0/W_0) )*100;
dtildeKTKtime0_pmltech   =  ( ((KT_pmltech/K_pmltech)-(KT_0/K_0)) + (wtildeKTK_1*X10) + (wtildeKTK_2*X20) + (tildeKTK_G*Y_0*VG0) )*100;
dtildeKNKtime0_pmltech   =  ( ((KN_pmltech/K_pmltech)-(KN_0/K_0)) + (wtildeKNK_1*X10) + (wtildeKNK_2*X20) + (tildeKNK_G*Y_0*VG0) )*100;

% DECOMPOSITION t=5
% Cumulative responses t=5: 6 periods
tcumul       = 5;
t6           = [0:Tu:tcumul]; % span of time t = [0..5]
VGt6         = exp(-(xi+r)*t6) - (1-barg)*exp(-(chi+r)*t6);
VG1t6        = exp(-(xi+r)*t6) - ThetaG_1*exp(-(chi+r)*t6);
VG2t6        = exp(-(xi+r)*t6) - ThetaG_2*exp(-(chi+r)*t6);

X1t6 = X11*exp((nu_1-r)*t6) + (DeltaG_1*VG1t6);
X2t6 = - (DeltaG_2*VG2t6);

dGYcum       = VGt6*100;
dtildeYRcum  = (((YR_pmltech-Y_0)*exp(-r*t6) + (wtildeYR_1*X1t6) + (wtildeYR_2*X2t6) + (tildeYR_G*Y_0*VGt6) )/Y_0)*100;
dLcum        = (((L_pmltech-L_0)*exp(-r*t6)  + (wL_1*X1t6) + (wL_2*X2t6) + (L_G*Y_0*VGt6) )/L_0)*100;
dLNScum      = (WN_0/W_0)*( ((LN_pmltech/L_pmltech)- (LN_0/L_0))*exp(-r*t6) + (wLNS_1*X1t6) + (wLNS_2*X2t6)  + (LNS_G*Y_0*VGt6) )*100;
dtildeYNScum = P_0*( ((YN_pmltech/YR_pmltech)- (YN_0/YR_0))*exp(-r*t6) + (wtildeYNS_1*X1t6) + (wtildeYNS_2*X2t6) + (tildeYNS_G*Y_0*VGt6) )*100;
dtildeZTcum = (( (ZT_pmltech-ZT_0)*exp(-r*t6) + (wtildeZT_1*X1t6) + (wtildeZT_2*X2t6) + (tildeZT_G*Y_0*VGt6) )/ZT_0)*100;
dtildeZNcum = (( (ZN_pmltech-ZN_0)*exp(-r*t6) + (wtildeZN_1*X1t6) + (wtildeZN_2*X2t6) + (tildeZN_G*Y_0*VGt6) )/ZN_0)*100;

dGYcum_t          = cumsum(dGYcum);
dGYcum_pmltech       = dGYcum_t(6);
dLcum_t           = cumsum(dLcum);
dLcum_pmltech        = dLcum_t(6);
dtildeYRcum_t     = cumsum(dtildeYRcum);
dtildeYRcum_pmltech  = dtildeYRcum_t(6);
dLNScum_t         = cumsum(dLNScum);
dLNScum_pmltech      = dLNScum_t(6);
dtildeYNScum_t    = cumsum(dtildeYNScum);
dtildeYNScum_pmltech = dtildeYNScum_t(6);
dtildeZTcum_t     = cumsum(dtildeZTcum);
dtildeZTcum_pmltech  = dtildeZTcum_t(6);
dtildeZNcum_t     = cumsum(dtildeZNcum);
dtildeZNcum_pmltech  = dtildeZNcum_t(6);      

dLTcum        = ( (W_0/W_0)*( (LT_pmltech-LT_0) + (wLT_1*X1t6) + (wLT_2*X2t6) + (LT_G*Y_0*VGt6) )/L_0)*100;                     
dLNcum        = ( (W_0/W_0)*( (LN_pmltech-LN_0) + (wLN_1*X1t6) + (wLN_2*X2t6) + (LN_G*Y_0*VGt6) )/L_0)*100;                     
dtildeYTcum   = ( PT_0*((YT_pmltech-YT_0) + (wtildeYT_1*X1t6) + (wtildeYT_2*X2t6) + (tildeYT_G*Y_0*VGt6) )/Y_0)*100;            
dtildeYNcum   = ( P_0*((YN_pmltech-YN_0) + (wtildeYN_1*X1t6) + (wtildeYN_2*X2t6) + (tildeYN_G*Y_0*VGt6) )/Y_0)*100;             
dLISTcum      = ( (sLT_pmltech-sLT_0) + (wLIST_1*X1t6) + (wLIST_2*X2t6)  + (LIST_G*Y_0*VGt6) )*100;                             
dLISNcum      = ( (sLN_pmltech-sLN_0) + (wLISN_1*X1t6) + (wLISN_2*X2t6)  + (LISN_G*Y_0*VGt6) )*100;                             
                                                                                                                                
dLTcum_t              = cumsum(dLTcum);                                                                                         
dLTcum_pmltech       = dLTcum_t(6);                                                                                             
dLNcum_t              = cumsum(dLNcum);                                                                                         
dLNcum_pmltech       = dLNcum_t(6);                                                                                             
dtildeYTcum_t         = cumsum(dtildeYTcum);                                                                                    
dtildeYTcum_pmltech  = dtildeYTcum_t(6);                                                                                        
dtildeYNcum_t         = cumsum(dtildeYNcum);                                                                                    
dtildeYNcum_pmltech  = dtildeYNcum_t(6);                                                                                        
dLISTcum_t            = cumsum(dLISTcum);                                                                                       
dLISTcum_pmltech     = dLISTcum_t(6);                                                                                           
dLISNcum_t            = cumsum(dLISNcum);                                                                                       
dLISNcum_pmltech     = dLISNcum_t(6);  

%%%%%%%%%%%%%%%%%%%%%% CA,SAV,INV %%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                          
                                                                                                                                        
VG1primet6   = xi*exp(-(xi+r)*t6) - chi*ThetaG_1*exp(-(chi+r)*t6);                                                                      
VG2primet6   = xi*exp(-(xi+r)*t6) - chi*ThetaG_2*exp(-(chi+r)*t6);                                                                      
VGprimet6    = xi*exp(-(xi+r)*t6) - chi*(1-barg)*exp(-(chi+r)*t6);                                                                      
                                                                                                                                        
VBG1primet6  = xi*exp(-(xi+r)*t6) - chi*ThetaG_1prime*exp(-(chi+r)*t6);                                                                 
VBG2primet6  = xi*exp(-(xi+r)*t6) - chi*ThetaG_2prime*exp(-(chi+r)*t6);                                                                 
VBGprimet6   = xi*exp(-(xi+r)*t6) - chi*ThetaG_prime*exp(-(chi+r)*t6);                                                                  
                                                                                                                                        
CA_Gt6  = (B_G*Y_0/(xi+r))*VBGprimet6 + (N1*DeltaG_1/(xi+r))*VBG1primet6 - (N2*DeltaG_2/(xi+r))*VBG2primet6;                            
SAV_Gt6 = (A_G*Y_0/(xi+r))*VBGprimet6 + (M1*DeltaG_1/(xi+r))*VBG1primet6 - (M2*DeltaG_2/(xi+r))*VBG2primet6;                            
                                                                                                                                        
dotX1t6 = nu_1*X11*exp((nu_1-r)*t6) - (DeltaG_1*VG1primet6);                                                                            
dotX2t6 = (DeltaG_2*VG2primet6);                                                                                                        
                                                                                                                                        
dCAYcum = (( -nu_1*(wB1/(r-nu_1))*exp((nu_1-r)*t6) + CA_Gt6 )/Y_0 )*100;                                                                
dSYcum  = (( -nu_1*(wA1/(r-nu_1))*exp((nu_1-r)*t6) + SAV_Gt6 )/Y_0 )*100;                                                               
dIYcum  = (( (EK1*dotX1t6) + (EK2*dotX2t6) )/Y_0)*100;                                                                                  
                                                                                                                                        
dCAYcheckcum =  dSYcum - dIYcum;                                                                                                        
                                                                                                                                        
dCAYcum_t             = cumsum(dCAYcum);                                                                                                
dCAYcum_pmltech      = dCAYcum_t(6);                                                                                                    
dSYcum_t              = cumsum(dSYcum);                                                                                                 
dSYcum_pmltech       = dSYcum_t(6);                                                                                                     
dIYcum_t              = cumsum(dIYcum);                                                                                                 
dIYcum_pmltech       = dIYcum_t(6);                                                                                                     
dCAYcheckcum_t        = cumsum(dCAYcheckcum);                                                                                           
dCAYcheckcum_pmltech = dCAYcheckcum_t(6);                                                                                               
                                                                                                                                                                                                                                                                                 
% Steady-state changes and impact effects - scaled to their initial values
hatlambda_pmltech   = (dlambda/lambda_0)*100;
dCoverY_pmltech     = ((PC_0*dC)/Y_0)*100; % Rate of change of the real consumption
dGY_pmltech         = (dG/Y_0)*100; % Chane in G
hatL_pmltech        = (dL/L_0)*100; % Rate of change of employment
hatK_pmltech        = (dK/K_0)*100; % Rate of change of the stock of foreign assets
dLToverL_pmltech    = (W_0/W_0)*(dLT/L_0)*100; % Rate of change of LH
dLNoverL_pmltech    = (W_0/W_0)*(dLN/L_0)*100; % Rate of change of LN
hatPT_pmltech       = (dPT/PT_0)*100; % Rate of change of PH
hatP_pmltech        = (dP/P_0)*100; % Rate of change of PN/PH
dBoverY_pmltech     = (dB/Y_0)*100; % Rate of change of the stock of foreign assets
dAoverY_pmltech     = (dA/Y_0)*100; % Rate of change of the stock of financial assets
hatW_pmltech        = (dW/W_0)*100; % Rate of change of wage
hatWPC_pmltech      = (dWPC/WPC_0)*100; % Rate of change of Real Aggregate Wage W/pc
hatY_pmltech        = (dY/Y_0)*100; % Rate of change of GDP
hatYR_pmltech       = ((YR-Y_0)/Y_0)*100; % Rate of change of Real GDP
dYToverY_pmltech    = (PT_0*dYT/Y_0)*100; % Rate of change of YH
dYNoverY_pmltech    = (P_0*dYN/Y_0)*100; % Rate of change of YN
hatWT_pmltech       = (dWT/WT_0)*100; % Rate of change of WT
hatWN_pmltech       = (dWN/WN_0)*100; % Rate of change of WN
dkT_pmltech         = LT_0*(dkT/K_0)*100; % Rate of change of kH
dkN_pmltech         = LN_0*(dkN/K_0)*100; % Rate of change of kN
dLTS_pmltech        = (W_0/W_0)*((LT/L)-(LT_0/L_0))*100; % change in  the labor share of T
dLNS_pmltech        = (W_0/W_0)*((LN/L)-(LN_0/L_0))*100; % change in the labor share of NT
dYTS_pmltech        = PT_0*((YT/YR)-(YT_0/Y_0))*100; % change in the output share of T
dYNS_pmltech        = P_0*((YN/YR)-(YN_0/Y_0))*100; % change in the output share of NT
dLIST_pmltech       = (sLT_pmltech-sLT_0)*100; % Change in the labor income share H
dLISN_pmltech       = (sLN_pmltech-sLN_0)*100; % Change in the labor income share N
dWTW_pmltech        = (((WT/W)-(WT_0/W_0))/((WT_0/W_0)))*100; % Change in the relative wage H
dWNW_pmltech        = (((WN/W)-(WN_0/W_0))/((WT_0/W_0)))*100; % Change in the relative wage N
dKTK_pmltech        = ((KT/K)-(KT_0/K_0))*100; % Change in the capital share of H
dKNK_pmltech        = ((KN/K)-(KN_0/K_0))*100; % Change in the capital share of N

% Technology
hatZT_pmltech   = (dZT/ZT_0)*100;
hatZN_pmltech   = (dZN/ZN_0)*100;
hatZA_pmltech   = (dZA/ZA_0)*100;                                                                                             
                                                                                                         
disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                    Final Steady State with kT > kN');
disp('                           The Benchmark: ');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (benchmark)');
disp('The structural parameters (benchmark)');
disp(sprintf('thetaT  : %5.2f   thetaN   : %5.2f',thetaT,thetaN));
disp(sprintf('phi     : %5.2f   varphi   : %5.2f',phi,varphi));  
disp(sprintf('phiI    : %5.2f   iota     : %5.2f',phiI,varphiI)); 
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f sigma   : %5.2f',sigmaL,gammaL,sigma));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('ZT      : %5.2f   ZN       : %5.2f',ZT,ZN));
disp(sprintf('GT      : %5.2f   GN       : %5.2f  G      : %5.2f',GT,GN,G));
disp(' ');

disp(' ');
disp('The production side (benchmark)');
disp(sprintf('kT       : %9.3f    kN   : %9.3f',kT,kN));
disp(sprintf('LT       : %9.3f    LN   : %9.3f',LT,LN));
disp(sprintf('KT       : %9.3f    KN   : %9.3f',KT,KN));
disp(sprintf('YT       : %9.3f    YN   : %9.3f',YT,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('alphaL   : %9.3f   ',alphaL));

disp(' ');
disp('The demand side (benchmark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('CT       :   %7.3f    CN     : %9.3f',CT,CN));

disp('The demand side (benchmark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('IT       :   %7.3f    IN     : %9.3f',IT,IN));
disp(sprintf('EI       :   %7.3f',EI));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector T');
disp(sprintf('Gross output (YT)  : %9.3f',YT));
disp(sprintf('WT                 : %9.3f',WT));
disp(sprintf('Profit             : %9.10f',PiT));


disp('Relative Price P=P(lambda,K,Q,ZT,ZN)');
disp(sprintf('DeltaP   :   %7.3f ',DeltaP));
disp(sprintf('P_K      :   %7.3f    P_Q    : %9.3f',P_K,P_Q));
disp(sprintf('P_G      :   %7.3f ',P_G));

disp('Linearization');
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_Q : %5.4f',Upsilon_K,Upsilon_Q));
disp(sprintf('Sigma_K   :  %5.4f  Sigma_Q   : %5.4f',Sigma_K,Sigma_Q));
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));

disp(' ');
disp('Eigenvalues and Eigenvectors');
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu_1,nu_2));
disp(sprintf('N1         :   %5.6f    H1       : %5.6f',N1,H1));
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));

disp('Eigenvectors');
disp(sprintf('omega11   :   %5.6f  omega12 : %5.6f',omega_11,omega_12));
disp(sprintf('omega21   :   %5.6f  omega22 : %5.6f',omega_21,omega_22));
disp(sprintf('X10       :   %5.3f  X20     : %5.3f ',X10,X20));

disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('YT / Y    :  %5.3f      P*YN / Y  : %5.3f',omegaYT,omegaYN));
disp(sprintf('LT / L    :  %5.3f      LN / L    : %5.3f',omegaLT,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('P*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GT / YT   :  %5.3f  GN / YN  : %5.3f  (P*GN)/G  : %5.3f',omegaGTYT,omegaGNYN,omegaGN));
disp(sprintf('IN / YN   :  %5.3f  IT / YT  :  %5.3f  (r*B)/Y  : %5.3f',omegaINYN,omegaITYT,omegaB));
disp(sprintf('WN*LN/W*L :  %5.3f RN*KN/R*K :  %5.3f',alphaL,alphaK));
disp(sprintf('P*IN/PI*I :  %5.3f P*CN/PC*C :  %5.3f',alphaI,alphaC));
disp(sprintf('W*L/P*Y   :  %5.3f R*K/P*Y   :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y       :  %5.3f',omegaKY));
disp(' ');
disp(sprintf('Marginal product of KT = RT       : %9.16f   ',cond1));
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));
disp(sprintf('Marginal product of LT = WT       : %9.16f   ',cond3));
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));
disp(sprintf('Resource contraint for capital    : %9.16f   ',cond5));
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));
disp(sprintf('Market clearing condition good T  : %9.16f   ',cond8));
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));
disp(sprintf('Resource constraint for labor     : %9.16f   ',cond12));
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));
disp(sprintf('Global market clearing condition  : %9.16f   ',cond16));
disp(sprintf('Private Savings                   : %9.16f   ',cond17));
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond18));
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond19));
disp(sprintf('Investment expenditure check      : %9.16f   ',cond20));
disp(sprintf('Capital income R*K                : %9.16f   ',cond21));
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond22));
disp(sprintf('alphaC check                      : %9.16f   ',cond23));
disp(sprintf('alphaI check                      : %9.16f   ',cond24));
disp(sprintf('UCT - PT;                         : %9.16f   ',cond25));   
disp(sprintf('UCN - P;                          : %9.16f   ',cond26));   

disp('-------------------------------------------------------------------------------------------------------- ');
disp('                       Increase in gN : Impact and Steady State Changes (after a rise in gN)     ');
disp('-------------------------------------------------------------------------------------------------------- ');
disp('-------------------------------------------------------------------------------------------------------- ');
disp('                               |     Temporary   |');
disp('-------------------------------------------------------------------------------------------------------- ');
disp(' ');

disp(' ');
disp(' Steady State Deviations ( = (x-x0)/x0 where x0 is the value of x at the initial steady state)  ');
disp(sprintf('hatlambda_pmltech        :         |           |%10.3f',hatlambda_pmltech));
disp(sprintf('dZAoverZA_pmltech        :         |           |%10.3f',hatZA_pmltech));
disp(sprintf('dZToverZT_pmltech        :         |           |%10.3f',hatZT_pmltech));
disp(sprintf('dZNoverZN_pmltech        :         |           |%10.3f',hatZN_pmltech));
disp(sprintf('dCoverY_pmltech          :         |           |%10.3f',dCoverY_pmltech));
disp(sprintf('dLoverL_pmltech          :         |           |%10.3f',hatL_pmltech));
disp(sprintf('dYoverY_pmltech          :         |           |%10.3f',hatY_pmltech));
disp(sprintf('dYRoverY_pmltech         :         |           |%10.3f',hatYR_pmltech));
disp(sprintf('dKoverK_pmltech          :         |           |%10.3f',hatK_pmltech));
disp(sprintf('dLToverL_pmltech         :         |           |%10.3f',dLToverL_pmltech));
disp(sprintf('dLNover_pmltech          :         |           |%10.3f',dLNoverL_pmltech));
disp(sprintf('dYToverY_pmltech         :         |           |%10.3f',dYToverY_pmltech));
disp(sprintf('dYNoverY_pmltech         :         |           |%10.3f',dYNoverY_pmltech));
disp(sprintf('hatP_pmltech             :         |           |%10.3f',hatP_pmltech));
disp(sprintf('hatPT_pmltech            :         |           |%10.3f',hatPT_pmltech));
disp(sprintf('dBoverY_pmltech          :         |           |%10.3f',dBoverY_pmltech));
disp(sprintf('dAoverY_pmltech          :         |           |%10.3f',dAoverY_pmltech));
disp(sprintf('dWoverW_pmltech          :         |           |%10.3f',hatW_pmltech));
disp(sprintf('dWToverWT_pmltech        :         |           |%10.3f',hatWT_pmltech));
disp(sprintf('dWNoverWN_pmltech        :         |           |%10.3f',hatWN_pmltech));
disp(sprintf('dkToverK_pmltech         :         |           |%10.3f',dkT_pmltech));
disp(sprintf('dkNoverK_pmltech         :         |           |%10.3f',dkN_pmltech));
disp(sprintf('domegaLT_pmltech         :         |           |%10.3f',dLTS_pmltech));
disp(sprintf('domegaLN_pmltech         :         |           |%10.3f',dLNS_pmltech));
disp(sprintf('domegaYTS_pmltech        :         |           |%10.3f',dYTS_pmltech));
disp(sprintf('domegaYNS_pmltech        :         |           |%10.3f',dYNS_pmltech));
disp(sprintf('dLIST_pmltech            :         |           |%10.3f',dLIST_pmltech));   
disp(sprintf('dLISN_pmltech            :         |           |%10.3f',dLISN_pmltech));   
disp(sprintf('dWTW_pmltech             :         |           |%10.3f',dWTW_pmltech));    
disp(sprintf('dWNW_pmltech             :         |           |%10.3f',dWNW_pmltech)); 

%disp(' ');                                                                                                             
disp('                                           Initial responses ');                                                  
disp(sprintf('dGYtime0_pmltech        :                |                 |%10.3f',dGYtime0_pmltech));                     
disp(sprintf('dGTYtime0_pmltech       :                |                 |%10.3f',dGTYtime0_pmltech));                    
disp(sprintf('dGNYtime0_pmltech       :                |                 |%10.3f',dGNYtime0_pmltech));                                        
                 
                                                                                                                        
disp('                                           Initial responses ');                                                  
disp(sprintf('dCYtime0_pmltech        :                |                 |%10.3f',dCYtime0_pmltech));                     
disp(sprintf('dJYtime0_pmltech        :                |                 |%10.3f',dJYtime0_pmltech));                     
disp(sprintf('dLtime0_pmltech         :                |                 |%10.3f',dLtime0_pmltech));                      
disp(sprintf('dLTtime0_pmltech        :                |                 |%10.3f',dLTtime0_pmltech));                     
disp(sprintf('dLNtime0_pmltech        :                |                 |%10.3f',dLNtime0_pmltech));                     
%disp(sprintf('dLTLNtime0_pmltech      :                |                 |%10.3f',dLTLNtime0_pmltech));                   
disp(sprintf('dYRtime0_pmltech        :                |                 |%10.3f',dYRtime0_pmltech));                     
disp(sprintf('dYTtime0_pmltech        :                |                 |%10.3f',dYTtime0_pmltech));                     
disp(sprintf('dYNtime0_pmltech        :                |                 |%10.3f',dYNtime0_pmltech));                     
%disp(sprintf('dYTYNtime0_pmltech      :                |                 |%10.3f',dYTYNtime0_pmltech));                   
disp(sprintf('dPTtime0_pmltech        :                |                 |%10.3f',dPTtime0_pmltech));                     
disp(sprintf('dPtime0_pmltech         :                |                 |%10.3f',dPtime0_pmltech));                      
disp(sprintf('dSYtime0_pmltech        :                |                 |%10.3f',SYtime0_pmltech));                      
disp(sprintf('dIYtime0_pmltech        :                |                 |%10.3f',IYtime0_pmltech));                      
disp(sprintf('dCAYtime0_pmltech       :                |                 |%10.5f',CAYtime0_pmltech));                     
disp(sprintf('dCAYtime0_pmltech_check :                |                 |%10.5f',CAYtime0_pmltech_check));               
disp(sprintf('dWtime0_pmltech         :                |                 |%10.3f',dWtime0_pmltech));                      
disp(sprintf('dWPCtime0_pmltech       :                |                 |%10.3f',dWPCtime0_pmltech));                    
disp(sprintf('dWTtime0_pmltech        :                |                 |%10.3f',dWTtime0_pmltech));                     
disp(sprintf('dWNtime0_pmltech        :                |                 |%10.3f',dWNtime0_pmltech));                     
disp(sprintf('dOmegatime0_pmltech     :                |                 |%10.3f',dOmegatime0_pmltech));                  
disp(sprintf('dWTPCtime0_pmltech      :                |                 |%10.3f',dWTPCtime0_pmltech));                   
disp(sprintf('dWNPCtime0_pmltech      :                |                 |%10.3f',dWNPCtime0_pmltech));                   
disp(sprintf('dkTKtime0_pmltech       :                |                 |%10.3f',dkTtime0_pmltech));                     
disp(sprintf('dkNKtime0_pmltech       :                |                 |%10.3f',dkNtime0_pmltech));                     
disp(sprintf('dLTStime0_pmltech       :                |                 |%10.3f',dLTStime0_pmltech));                    
disp(sprintf('dLNStime0_pmltech       :                |                 |%10.3f',dLNStime0_pmltech));                    
disp(sprintf('dYTStime0_pmltech       :                |                 |%10.3f',dYTStime0_pmltech));                    
disp(sprintf('dYNStime0_pmltech       :                |                 |%10.3f',dYNStime0_pmltech));                    
disp(sprintf('dWTWtime0_pmltech       :                |                 |%10.3f',dWTWtime0_pmltech));                    
disp(sprintf('dWNWtime0_pmltech       :                |                 |%10.3f',dWNWtime0_pmltech));                    
disp(sprintf('dLISTtime0_pmltech      :                |                 |%10.3f',dLISTtime0_pmltech));                   
disp(sprintf('dLISNtime0_pmltech      :                |                 |%10.3f',dLISNtime0_pmltech));
disp(sprintf('dFBTCTtime0_pmltech     :                |                 |%10.3f',dFBTCTtime0_pmltech));                  
disp(sprintf('dFBTCNtime0_pmltech     :                |                 |%10.3f',dFBTCNtime0_pmltech));
disp(sprintf('dKTKtime0_pmltech       :                |                 |%10.3f',dKTKtime0_pmltech));                    
disp(sprintf('dKNKtime0_pmltech       :                |                 |%10.3f',dKNKtime0_pmltech));                    
disp(sprintf('dRtime0_pmltech         :                |                 |%10.3f',dRtime0_pmltech));                      
disp(sprintf('dRPTtime0_pmltech       :                |                 |%10.3f',dRPTtime0_pmltech));                    
disp(sprintf('dRPNtime0_pmltech       :                |                 |%10.3f',dRPNtime0_pmltech));                    
                                                                                                                        
disp('                Initial responses including capital and technology utilization rates');                           
disp(sprintf('duKTtime0_pmltech            :                |                 |%10.3f',duKTtime0_pmltech));               
disp(sprintf('duKNtime0_pmltech            :                |                 |%10.3f',duKNtime0_pmltech));               
disp(sprintf('duKtime0_pmltech             :                |                 |%10.3f',duKtime0_pmltech));                
disp(sprintf('duZTtime0_pmltech            :                |                 |%10.3f',duZTtime0_pmltech));               
disp(sprintf('duZNtime0_pmltech            :                |                 |%10.3f',duZNtime0_pmltech));  
disp(sprintf('duZTtime0_check_pmltech      :                |                 |%10.3f',duZTtime0_check_pmltech));   
disp(sprintf('duZNtime0_check_pmltech      :                |                 |%10.3f',duZNtime0_check_pmltech));   
disp(sprintf('dtildeZTtime0_pmltech        :                |                 |%10.3f',dtildeZTtime0_pmltech));           
disp(sprintf('dtildeZNtime0_pmltech        :                |                 |%10.3f',dtildeZNtime0_pmltech));           
disp(sprintf('dtildeZtime0_pmltech         :                |                 |%10.3f',dtildeZtime0_pmltech));            
disp(sprintf('dTFPTtime0_pmltech           :                |                 |%10.3f',dTFPTtime0_pmltech));              
disp(sprintf('dTFPNtime0_pmltech           :                |                 |%10.3f',dTFPNtime0_pmltech));              
disp(sprintf('dTFPTtime0_check_pmltech     :                |                 |%10.3f',dTFPTtime0_check_pmltech));        
disp(sprintf('dTFPNtime0_check_pmltech     :                |                 |%10.3f',dTFPNtime0_check_pmltech));        
disp(sprintf('dTFPtime0_pmltech            :                |                 |%10.3f',dTFPtime0_pmltech));               
disp(sprintf('dTFPRtime0_pmltech           :                |                 |%10.3f',dTFPRtime0_pmltech));              
disp(sprintf('duZRtime0_pmltech            :                |                 |%10.3f',duZRtime0_pmltech));               
disp(sprintf('dtildeYRtime0_pmltech        :                |                 |%10.3f',dtildeYRtime0_pmltech));           
disp(sprintf('dtildeYTtime0_pmltech        :                |                 |%10.3f',dtildeYTtime0_pmltech));           
disp(sprintf('dtildeYNtime0_pmltech        :                |                 |%10.3f',dtildeYNtime0_pmltech));           
disp(sprintf('dtildeYTYNtime0_pmltech      :                |                 |%10.3f',dtildeYTYNtime0_pmltech));         
disp(sprintf('dtildeWtime0_pmltech         :                |                 |%10.3f',dtildeWtime0_pmltech));            
disp(sprintf('dtildeWPCtime0_pmltech       :                |                 |%10.3f',dtildeWPCtime0_pmltech));          
disp(sprintf('dtildeWTtime0_pmltech        :                |                 |%10.3f',dtildeWTtime0_pmltech));           
disp(sprintf('dtildeWNtime0_pmltech        :                |                 |%10.3f',dtildeWNtime0_pmltech));           
disp(sprintf('dtildeOmegatime0_pmltech     :                |                 |%10.3f',dtildeOmegatime0_pmltech));        
disp(sprintf('dtildeWTPCtime0_pmltech      :                |                 |%10.3f',dtildeWTPCtime0_pmltech));         
disp(sprintf('dtildeWNPCtime0_pmltech      :                |                 |%10.3f',dtildeWNPCtime0_pmltech));         
disp(sprintf('dtildekTKtime0_pmltech       :                |                 |%10.3f',dtildekTtime0_pmltech));           
disp(sprintf('dtildekNKtime0_pmltech       :                |                 |%10.3f',dtildekNtime0_pmltech));           
disp(sprintf('dtildeYTStime0_pmltech       :                |                 |%10.3f',dtildeYTStime0_pmltech));          
disp(sprintf('dtildeYNStime0_pmltech       :                |                 |%10.3f',dtildeYNStime0_pmltech));          
disp(sprintf('dtildeWTWtime0_pmltech       :                |                 |%10.3f',dtildeWTWtime0_pmltech));          
disp(sprintf('dtildeWNWtime0_pmltech       :                |                 |%10.3f',dtildeWNWtime0_pmltech));          
disp(sprintf('dtildeRPTtime0_pmltech       :                |                 |%10.3f',dtildeRPTtime0_pmltech));          
disp(sprintf('dtildeRPNtime0_pmltech       :                |                 |%10.3f',dtildeRPNtime0_pmltech));    

disp('Cumulative responses: cumul t=0..5');                                                                          
disp(sprintf('dGYcum_pmltech            :                |                 |%10.3f',dGYcum_pmltech));                  
disp(sprintf('dLcum_pmltech             :                |                 |%10.3f',dLcum_pmltech));                   
disp(sprintf('dtildeYRcum_pmltech       :                |                 |%10.3f',dtildeYRcum_pmltech));             
disp(sprintf('dtildeYNScum_pmltech      :                |                 |%10.3f',dtildeYNScum_pmltech));            
disp(sprintf('dLNScum_pmltech           :                |                 |%10.3f',dLNScum_pmltech));                 
disp(sprintf('dtildeZHcum_pmltech       :                |                 |%10.3f',dtildeZTcum_pmltech));             
disp(sprintf('dtildeZNcum_pmltech       :                |                 |%10.3f',dtildeZNcum_pmltech));     
disp(' ');                                                                                                    
disp(sprintf('dLTcum_pmltech           :                |                 |%10.3f',dLTcum_pmltech));          
disp(sprintf('dLNcum_pmltech           :                |                 |%10.3f',dLNcum_pmltech));          
disp(sprintf('dtildeYTcum_pmltech      :                |                 |%10.3f',dtildeYTcum_pmltech));     
disp(sprintf('dtildeYNcum_pmltech      :                |                 |%10.3f',dtildeYNcum_pmltech));     
disp(sprintf('dLISTcum_pmltech         :                |                 |%10.3f',dLISTcum_pmltech));        
disp(sprintf('dLISNcum_pmltech         :                |                 |%10.3f',dLISNcum_pmltech));        
                                                                                                                                                                                                                                                                                                                                                                                                               
disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('YT / Y    :  %5.3f      P*YN / Y  : %5.3f',omegaYT_0,omegaYN_0));
disp(sprintf('LT / L    :  %5.3f      LN / L    : %5.3f',omegaLT_0,omegaLN_0));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC_0,omegaNX_0));
disp(sprintf('P*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI_0,omegaG_0));
disp(sprintf('xi   :  %5.3f   chi   : %5.3f barg   : %5.3f',xi,chi,barg));
disp(sprintf('chi1T     :  %5.3f      chi1N     : %5.3f',chi1T,chi1N));
disp(' ');
disp(sprintf('GT / YT   :  %5.3f  GN / YN  : %5.3f  (P*GN)/G  : %5.3f',omegaGTYT_0,omegaGNYN_0,omegaGN_0));
disp(sprintf('IN / YN   :  %5.3f  IT / YT  :  %5.3f  (r*B)/Y  : %5.3f',omegaINYN_0,omegaITYT_0,omegaB_0));
disp(sprintf('WT*LT/W*L :  %5.3f RT*KT/R*K :  %5.3f',alphaL_0,alphaK_0));
disp(sprintf('IT/PI*I   :  %5.3f CT/PC*C :  %5.3f',alphaI_0,alphaC_0));
disp(sprintf('W*L/P*Y   :  %5.3f R*K/P*Y   :  %5.3f',omegaL_0,omegaK_0));
disp(sprintf('K/Y       :  %5.3f',omegaKY_0));

