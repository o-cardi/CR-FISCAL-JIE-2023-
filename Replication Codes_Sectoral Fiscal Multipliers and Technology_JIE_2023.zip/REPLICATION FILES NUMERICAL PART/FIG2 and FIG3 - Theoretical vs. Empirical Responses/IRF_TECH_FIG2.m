clc
clear

% Maximum duration for graphics
Tg = 8;
       
% Minimum duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;

FISC_IML_CAC_TOT_CD_NOTECH;
FISC_IML_CAC_TOT_CES_TECH;  

%%%%% LISj and kj %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% LP_LISN
[xdata23]=xlsread('LP_LLSN0.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LLSN0');  nbPVAR  = 1;

[obs nbvar23]=size(xdata23);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=9)
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar23     = nbvar23/3;                       % number of variables included in VAR
irf23      = xdata23(1:obs,nvar23+1:2*nvar23);    % IRF of variables
lowerb23   = xdata23(1:obs,1:nvar23);           % lower bound of IRF
upperb23   = xdata23(1:obs,2*nvar23+1:3*nvar23);  % upper bound of IRF


%%%%% LP_LISH
[xdata25]=xlsread('LP_LLST0.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LLST0');  nbPVAR  = 1;

[obs nbvar25]=size(xdata25);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=9)
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar25     = nbvar25/3;                       % number of variables included in VAR
irf25      = xdata25(1:obs,nvar25+1:2*nvar25);    % IRF of variables
lowerb25   = xdata25(1:obs,1:nvar25);           % lower bound of IRF
upperb25   = xdata25(1:obs,2*nvar25+1:3*nvar25);  % upper bound of IRF

%%%%% LP_ZH
[xdata29]=xlsread('LP_LZT.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LZT');  

[obs nbvar29]=size(xdata29);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if n
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to npts
nvar29     = nbvar29/3;                       % number of variables included in VAR
irf29      = xdata29(1:obs,nvar29+1:2*nvar29);    % IRF of variables
lowerb29   = xdata29(1:obs,1:nvar29);           % lower bound of IRF
upperb29   = xdata29(1:obs,2*nvar29+1:3*nvar29);  % upper bound of IRF

%%%%% LP_ZN reconstructed - hatZN = (hatZA - nuY,Y*hatZH)/(1-nuY,H)
[xdata30]=xlsread('LP_LZN_recons.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LZN');  

[obs nbvar30]=size(xdata30);                                                                                  
nptless  = 0;                             % number of points that we want to delete (obs = 11, if n           
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to npts           
nvar30     = nbvar30/3;                       % number of variables included in VAR                           
irf30      = xdata30(1:obs,nvar30+1:2*nvar30);    % IRF of variables                                          
lowerb30   = xdata30(1:obs,1:nvar30);           % lower bound of IRF                                          
upperb30   = xdata30(1:obs,2*nvar30+1:3*nvar30);  % upper bound of IRF                                        
                                                                                                        
%%%%% LP_ZN
[xdata31]=xlsread('LP_LZN.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LZN');  

[obs nbvar31]=size(xdata31);                                                                          
nptless  = 0;                             % number of points that we want to delete (obs = 11, if n   
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to npts   
nvar31     = nbvar31/3;                       % number of variables included in VAR                   
irf31      = xdata31(1:obs,nvar31+1:2*nvar31);    % IRF of variables                                  
lowerb31   = xdata31(1:obs,1:nvar31);           % lower bound of IRF                                  
upperb31   = xdata31(1:obs,2*nvar31+1:3*nvar31);  % upper bound of IRF                                
    
%%%%% LP_ZadjKH
[xdata32]=xlsread('LP_LZADJKT.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LZADJKT');  

[obs nbvar32]=size(xdata32);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if n
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to npts
nvar32     = nbvar32/3;                       % number of variables included in VAR
irf32      = xdata32(1:obs,nvar32+1:2*nvar32);    % IRF of variables
lowerb32   = xdata32(1:obs,1:nvar32);           % lower bound of IRF
upperb32   = xdata32(1:obs,2*nvar32+1:3*nvar32);  % upper bound of IRF

%%%%% LP_ZadjKN                                                                                        
[xdata33]=xlsread('LP_LZADJKN_recons.xlsx');   %scaling=[1 1 1];                                              
namvar= char('IRF_LZADJKN');                                                                           
                                                                                                       
[obs nbvar33]=size(xdata33);                                                                           
nptless  = 0;                             % number of points that we want to delete (obs = 11, if n    
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to npts    
nvar33     = nbvar33/3;                       % number of variables included in VAR                    
irf33      = xdata33(1:obs,nvar33+1:2*nvar33);    % IRF of variables                                   
lowerb33   = xdata33(1:obs,1:nvar33);           % lower bound of IRF                                   
upperb33   = xdata33(1:obs,2*nvar33+1:3*nvar33);  % upper bound of IRF     

%%%%% LP_ZadjKN                                                                                          
[xdata34]=xlsread('LP_LZADJKN.xlsx');   %scaling=[1 1 1];                                                
namvar= char('IRF_LZADJKN');                                                                             
                                                                                                         
[obs nbvar34]=size(xdata34);                                                                             
nptless  = 0;                             % number of points that we want to delete (obs = 11, if n      
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to npts      
nvar34     = nbvar34/3;                       % number of variables included in VAR                      
irf34      = xdata34(1:obs,nvar34+1:2*nvar34);    % IRF of variables                                     
lowerb34   = xdata34(1:obs,1:nvar34);           % lower bound of IRF                                     
upperb34   = xdata34(1:obs,2*nvar34+1:3*nvar34);  % upper bound of IRF                                   

%%%%%%%%%%% Impulse functions %%%%%%%%%% 

figure(1)
%subplot(2,2,1)
hold on
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb32(1:11,1)',fliplr(lowerb32(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdtildeZH_endo(2:12),'-ks','LineWidth',5);
plot(timetemp(2:12),pathdtildeZH_notech(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf32(1:11,1)','blue','LineWidth',3);
%plot(timetemp(2:12),lowerb32(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb32(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation from initial steady-state');  %title('Utilization-adjusted TFP of tradables, ZH');
legend('Technology channel','No technology channel','LP (data)'); 

figure(2)
%subplot(2,2,1)
hold on
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb29(1:11,1)',fliplr(lowerb29(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdTFPH_check_endo(2:12),'-ks','LineWidth',5);
plot(timetemp(2:12),pathdTFPH_check_notech(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf29(1:11,1)','blue','LineWidth',3);
%plot(timetemp(2:12),lowerb29(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb29(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation from initial steady-state');  %title('Traded TFP, TFPH');
legend('Technology channel','No technology channel','LP (data)'); 

figure(3)
%subplot(2,2,1)
hold on
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb25(1:11,1)',fliplr(lowerb25(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdLISH_endo(2:12),'-ks','LineWidth',5);
plot(timetemp(2:12),pathdLISH_notech(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf25(1:11,1)','blue','LineWidth',3);
%plot(timetemp(2:12),lowerb25(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb25(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation from initial steady-state');  %title('Labor income share, LISH');
legend('Technology channel','No technology channel','LP (data)'); 


figure(4)
%subplot(2,2,1)
hold on
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb33(1:11,1)',fliplr(lowerb33(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdtildeZN_endo(2:12),'-ks','LineWidth',5);
plot(timetemp(2:12),pathdtildeZN_notech(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf33(1:11,1)','blue','LineWidth',3);
plot(timetemp(2:12),irf34(1:11,1)','blue','LineWidth',3,'LineStyle',':');
%plot(timetemp(2:12),lowerb33(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb33(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation from initial steady-state');  %title('Utilization-adjusted TFP of Non-tradables, ZN');
legend('Technology channel','No technology channel','Reconstructed IRF','LP (data)'); 

figure(5)
%subplot(2,2,1)
hold on
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb30(1:11,1)',fliplr(lowerb30(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdTFPN_check_endo(2:12),'-ks','LineWidth',5);
plot(timetemp(2:12),pathdTFPN_check_notech(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf30(1:11,1)','blue','LineWidth',3);
plot(timetemp(2:12),irf31(1:11,1)','blue','LineWidth',3,'LineStyle',':');
%plot(timetemp(2:12),lowerb30(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb30(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation from initial steady-state');  %title('Non-traded TFP, TFPN');
legend('Technology channel','No technology channel','Reconstructed IRF','LP (data)'); 



figure(6)
%subplot(2,2,1)
hold on
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb23(1:11,1)',fliplr(lowerb23(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdLISN_endo(2:12),'-ks','LineWidth',5);
plot(timetemp(2:12),pathdLISN_notech(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf23(1:11,1)','blue','LineWidth',3);
%plot(timetemp(2:12),lowerb23(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb23(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation from initial steady-state');  %title('Labor income share, LISN');
legend('Technology channel','No technology channel','LP (data)'); 

clear

