%clc
%clear

global sigmaC phi varphi rho varphiH
global phiI iota rhoI iotaH 
global ex nuX
global epsilon vartheta 
global gammaL sigmaL
global r deltaK kappa
global thetaH thetaN
global omegaG omegaGN omegaGH GH GN GF
global xi1H xi1N chi1H chi1N
global xi2H xi2N chi2H chi2N
global B0 K0 Y_0 ZH ZN  
global barg xi chi 

% Maxim duration for graphics
Tg = 10;
       
% Minim duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% BENCH IML CAC TOT - epsilon =0.98, sigmaL=0.5, kH>kN    %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
AH_0         = 1.00;  
AN_0         = 1.00;
BH_0         = 1.00;  
BN_0         = 1.00;
omegaG       = 0.191; 
omegaGN      = 0.8; 
omegaGH      = 0.9;
thetaH_0     = 0.631; 
thetaN_0     = 0.687; 
sigmaL_0     = 1; 
gammaL       = 1; 
sigmaC_0     = 1;  
phi_0        = 0.77;
varphi_0     = 0.463; 
rho_0        = 1.5;  
varphiH_0    = 0.734; 
epsilon_0    = 0.83; 
vartheta_0   = 0.405;
phiI_0       = 1.000001;                    
iota_0       = 0.31;  
rhoI_0       = 1.5;  
iotaH_0      = 0.517; 
kappa        = 17; 
ex           = 1; 
nuX          = 1.7;

r            = 0.03; 
beta         = r; 
deltaK       = 0.078;

B0           = 0;
K0           = 0;

AH           = AH_0;       
AN           = AN_0;  
BH           = BH_0;       
BN           = BN_0;
thetaH       = thetaH_0;   
thetaN       = thetaN_0;   
sigmaC       = sigmaC_0;  
sigmaL       = sigmaL_0;   
phi          = phi_0;     
varphi       = varphi_0;  
rho          = rho_0;     
varphiH      = varphiH_0;
phiI         = phiI_0;    
iota         = iota_0; 
rhoI         = rhoI_0;    
iotaH        = iotaH_0;
epsilon      = epsilon_0;  
vartheta     = vartheta_0;   


ZH           = ((AH)^thetaH)*(BH^(1-thetaH)); 
ZN           = ((AN)^thetaN)*(BN^(1-thetaN));  
sigmaH       = 1; 
sigmaN       = 1;

filename = 'Calibration_Shock_2021_IRF';                                                                                            
sheet    = 8;                                                                                                                                          
xlRange  = 'C3:K5';                                                                                                                                 
parameters = xlsread(filename,sheet,xlRange)                                                                                                                                                                                                                                               
chi2H    = 0.7;  %1 technology utilization adjustment cost in the traded sector                                                                                                                          
chi2N    = 4; %6; % technology utilization adjustment cost in the non-traded sector                                                                                                                         
xi2H     = 0.27; %0.12; % capital utilization adustment costs in the traded sector                                                                                                                              
xi2N     = 0.02; %0.03 % capital utilization adustment costs in the non-traded sector
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C_ini        = 1.367  ; % Consumption 
L_ini        = 1.054  ; % Labor supply 
kH_ini       = 6.137  ; % Capital-labor ratio in sector H
WH_ini       = 3.382  ; % Wage rate in sector H
WN_ini       = 3.809  ; % Wage rate in sector N
W_ini        = 3.644  ; % Aggregate wage index
kN_ini       = 5.411  ; % Capital-labor ratio in sector N
PN_ini       = 2.881  ; % Relative price of non tradables
K_ini        = 5.978  ; % Stock of capital
PH_ini       = 2.295  ; % Terms of trade
B_ini        = 0.028  ; % Stock of traded Bonds
alphaL_ini   = 0.345  ; % Non tradable share of compensation of employees
PC_ini       = 2.400  ; % Aggregate consumption price index
PT_ini       = 1.959  ; % Consumption price index for tradables
CN_ini       = 0.631  ; % Consumption in non tradables 
CH_ini       = 0.495  ; % Consumption in tradables 
CF_ini       = 0.328  ; % Consumption in foreign goods 
alphaC_ini   = 0.446  ; % Tradable content of consumption expenditure
alphaH_ini   = 0.776  ; % Home goods content of consumption expenditure on traded goods
PI_ini       = 2.307  ; % Aggregate investment price index
PIT_ini      = 1.604  ; % Investment price index for traded goods
IN_ini       = 0.277  ; % Non traded investment
IH_ini       = 0.110  ; % Home goods investment
IF_ini       = 0.235  ; % Foreign goods investment
alphaI_ini   = 0.379  ; % Tradable content of investment expenditure
alphaIH_ini  = 0.517  ; % Home goods content of investment expenditure on traded goods
LH_ini       = 0.391  ; % Labor in sector H
LN_ini       = 0.661  ; % Labor in sector N 
GF_ini       = 0.03   ; % Government spending in foreign goods
GH_ini       = 0.05   ; % Government spending in home goods
GN_ini       = 0.35   ; % Government spending in non tradables 
YH_ini       = 0.898  ; % Output of home traded goods
YN_ini       = 1.255  ; % Output of non traded goods
XH_ini       = 0.245  ; % Exports of home traded goods
MF_ini       = 0.562  ; % Imports of foreign goods
RK_ini       = 0.307  ; % Return on capital
xi1H_ini     = 0.1337 ; % Parameter of traded capital utilization cost function: xi1H*(uKH-1)+(xi2H/2)*(uKH-1)^2
xi1N_ini     = 0.1065 ; % Parameter of non-traded capital utilization cost function
chi1H_ini    = 0.898  ; % Parameter of traded technology utilization cost function: chi1H*(uZH-1)+(chi2H/2)*(uZH-1)^2
chi1N_ini    = 1.255  ; % Parameter of non-traded technology utilization cost function
lambda_ini   = 0.967  ; % Intertemporal Solvency Condition         
                                                          
x0 =[C_ini L_ini kH_ini WH_ini WN_ini W_ini kN_ini PN_ini K_ini PH_ini B_ini alphaL_ini PC_ini PT_ini CN_ini CH_ini CF_ini alphaC_ini alphaH_ini PI_ini PIT_ini IN_ini IH_ini IF_ini alphaI_ini alphaIH_ini LH_ini LN_ini GF_ini GN_ini GH_ini YH_ini YN_ini XH_ini MF_ini RK_ini xi1H_ini xi1N_ini chi1H_ini chi1N_ini lambda_ini];
[x,fval,exitflag]=fsolve('IML_CAC_TOT_SS0',x0,optimset('display','off','TolFun',1e-011));

C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kH      = x(3)  ; % Capital-labor ratio in sector H
WH      = x(4)  ; % Wage rate in sector H
WN      = x(5)  ; % Wage rate in sector N
W       = x(6)  ; % Aggregate wage index
kN      = x(7)  ; % Capital-labor ratio in sector N
PN      = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
PH      = x(10) ; % Terms of trade : PH/PF with PF = numeraire
B       = x(11) ; % Stock of Traded Bonds
alphaL  = x(12) ; % Output per worker in sector N 
PC      = x(13) ; % Aggregate consumption price index
PT      = x(14) ; % Consumption price index for tradables
CN      = x(15) ; % Consumption in non tradables 
CH      = x(16) ; % Consumption in tradables 
CF      = x(17) ; % Consumption goods imports
alphaC  = x(18) ; % Tradable content of consumption expenditure 
alphaH  = x(19) ; % Home goods content of consumption expenditure on traded goods
PI      = x(20) ; % Aggregate investment price index
PIT     = x(21) ; % Investment price index for tradables
IN      = x(22) ; % Non tradable investment
IH      = x(23) ; % Investment in home goods
IF      = x(24) ; % Investment in foreign goods
alphaI  = x(25) ; % Tradable content of investment expenditure
alphaIH = x(26) ; % Home goods content of investment expenditure
LH      = x(27) ; % Labor in sector H
LN      = x(28) ; % Labor in sector N 
GF      = x(29) ; % Government spending in foreign goods
GN      = x(30) ; % Government spending in non tradables 
GH      = x(31) ; % Government spending in home traded goods
YH      = x(32) ; % Output of home traded goods
YN      = x(33) ; % Output of non traded goods
XH      = x(34) ; % Exports of home traded goods
MF      = x(35) ; % Imports of foreign goods
RK      = x(36) ; % Return on capital
xi1H    = x(37) ; % Parameter of traded capital utilization cost function: xi1H*(uKH-1)+(xi2H/2)*(uKH-1)^2
xi1N    = x(38) ; % Parameter of non-traded capital utilization cost function
chi1H   = x(39) ; % Parameter of traded technology utilization cost function: chi1H*(uZH-1)+(chi2H/2)*(uZH-1)^2
chi1N   = x(40) ; % Parameter of non-traded technology utilization cost function
lambda  = x(41) ; % Intertemporal Solvency Condition  

% VA per hours worked
yH     = YH/LH; 
yN     = YN/LN; 

% Sectoral outputs and sectoral profits   
KH  = LH*kH;  
RK  = PH*(1-thetaH)*(YH/KH); 
PiH = (PH*YH) - (RK*KH) - (WH*LH);
  
KN  = LN*kN;   
PiN = (PN*YN) - (RK*KN) - (WN*LN);

% Labor income share in the home traded good and non traded good sector
sLH = WH*LH/(PH*YH);
sLN = WN*LN/(PN*YN);
Y   = (PH*YH) +(PN*YN);
sL  = W*L/Y; 
k   = K/L; 

% Partial derivatives of LH and LN
LH_1lamb   = sigmaL*LH/lambda; 
LN_1lamb   = sigmaL*LN/lambda;

% LHj = partial Lj/partial Wj: Lj=Lj(WH,WN,uZH,uZN)
LH_WH   = (LH/WH)*( epsilon*(1-alphaL) + (sigmaL*alphaL) );
LH_1uZH = LH*( epsilon*(1-alphaL) + (sigmaL*alphaL) );
LH_WN   = (LH/WN)*(1-alphaL)*(sigmaL-epsilon); 
LH_1uZN = LH*(1-alphaL)*(sigmaL-epsilon); 
LN_WH   = (LN/WH)*alphaL*(sigmaL-epsilon); 
LN_1uZH = LN*alphaL*(sigmaL-epsilon);
LN_WN   = (LN/WN)*( (epsilon*alphaL) + sigmaL*(1-alphaL) );  
LN_1uZN = LN*( (epsilon*alphaL) + sigmaL*(1-alphaL) ); 
LH_1lamb = sigmaL*LH/lambda; 
LN_1lamb = sigmaL*LN/lambda;

% Solving for kH, kN, WH, WN as functions of (PH, PN, K, uKH, uKN, uZH, uZN)
Psi_WH   = ( (kH*LH_WH) + (kN*LN_WH) );
Psi_WN   = ( (kH*LH_WN) + (kN*LN_WN) );
Psi_uZH  = ((kH*LH_1uZH) + (kN*LN_1uZH)); 
Psi_uZN  = ((kH*LH_1uZN) + (kN*LN_1uZN)); 
Psi_lamb = ( (kH*LH_1lamb) + (kN*LN_1lamb) );

d11 = -(thetaH/kH); 
d12 = (thetaN/kN);
d13 = 0;
d14 = 0;
d21 = ((1-thetaH)/kH); 
d22 = 0;  
d23 = -(1/WH); 
d24 = 0; 
d31 = 0; 
d32 = ((1-thetaN)/kN);
d33 = 0; 
d34 = -(1/WN);
d41 = LH; 
d42 = LN; 
d43 = Psi_WH; 
d44 = Psi_WN; 

% PN, PH, K, uKH, uKN, uZH, uZN, lambda
e11  = (1/PN);
e12  = -(1/PH);
e13  = 0;
e14  = thetaH;
e15  = -thetaN;
e16  = 0;
e17  = 0;
e18  = 0;

e21  = 0;
e22  = -(1/PH);
e23  = 0;
e24  = -(1-thetaH);
e25  = 0;
e26  = 0;
e27  = 0;
e28  = 0;

e31  = -(1/PN);
e32  = 0;
e33  = 0;
e34  = 0;
e35  = -(1-thetaN);
e36  = 0;
e37  = 0;
e38  = 0;

e41  = 0;
e42  = 0;
e43  = 1;
e44  = 0;
e45  = 0;
e46  = -Psi_uZH;
e47  = -Psi_uZN;
e48  = -Psi_lamb;

M1 = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X1 = [e11 e12 e13 e14 e15 e16 e17 e18; e21 e22 e23 e24 e25 e26 e27 e28; e31 e32 e33 e34 e35 e36 e37 e38; e41 e42 e43 e44 e45 e46 e47 e48];
JST1 = inv(M1);
MST1 = JST1*X1;
kH_1PN = MST1(1,1); kH_1PH = MST1(1,2); kH_1K = MST1(1,3); kH_uKH = MST1(1,4); kH_uKN = MST1(1,5); kH_uZH = MST1(1,6); kH_uZN = MST1(1,7); kH_1lambda = MST1(1,8);
kN_1PN = MST1(2,1); kN_1PH = MST1(2,2); kN_1K = MST1(2,3); kN_uKH = MST1(2,4); kN_uKN = MST1(2,5); kN_uZH = MST1(2,6); kN_uZN = MST1(2,7); kN_1lambda = MST1(2,8);
WH_1PN = MST1(3,1); WH_1PH = MST1(3,2); WH_1K = MST1(3,3); WH_uKH = MST1(3,4); WH_uKN = MST1(3,5); WH_uZH = MST1(3,6); WH_uZN = MST1(3,7); WH_1lambda = MST1(3,8);
WN_1PN = MST1(4,1); WN_1PH = MST1(4,2); WN_1K = MST1(4,3); WN_uKH = MST1(4,4); WN_uKN = MST1(4,5); WN_uZH = MST1(4,6); WN_uZN = MST1(4,7); WN_1lambda = MST1(4,8);

% Solving for sectoral labor and sectoral output - Lj,yj,Yj,Kj(PN,PH,K,uKj,uZj)
LH_1PN = (LH_WH*WH_1PN) + (LH_WN*WN_1PN);
LH_1PH = (LH_WH*WH_1PH) + (LH_WN*WN_1PH);
LH_1K  = (LH_WH*WH_1K)  + (LH_WN*WN_1K);
LH_uKH = (LH_WH*WH_uKH) + (LH_WN*WN_uKH);
LH_uKN = (LH_WH*WH_uKN) + (LH_WN*WN_uKN);
LH_uZH = LH_1uZH + (LH_WH*WH_uZH) + (LH_WN*WN_uZH);
LH_uZN = LH_1uZN + (LH_WH*WH_uZN) + (LH_WN*WN_uZN);
LH_1lambda = LH_1lamb + (LH_WH*WH_1lambda) + (LH_WN*WN_1lambda);

LN_1PN = (LN_WH*WH_1PN) + (LN_WN*WN_1PN);
LN_1PH = (LN_WH*WH_1PH) + (LN_WN*WN_1PH);
LN_1K  = (LN_WH*WH_1K)  + (LN_WN*WN_1K);
LN_uKH = (LN_WH*WH_uKH) + (LN_WN*WN_uKH);
LN_uKN = (LN_WH*WH_uKN) + (LN_WN*WN_uKN);
LN_uZH = LN_1uZH + (LN_WH*WH_uZH) + (LN_WN*WN_uZH);
LN_uZN = LN_1uZN + (LN_WH*WH_uZN) + (LN_WN*WN_uZN);
LN_1lambda = LN_1lamb + (LN_WH*WH_1lambda) + (LN_WN*WN_1lambda);

yH_1PN = (yH/kH)*(1-thetaH)*kH_1PN;
yH_1PH = (yH/kH)*(1-thetaH)*kH_1PH;
yH_1K  = (yH/kH)*(1-thetaH)*kH_1K;
yH_uKH = yH*(1-thetaH) + (yH/kH)*(1-thetaH)*kH_uKH;
yH_uKN = (yH/kH)*(1-thetaH)*kH_uKN;
yH_uZH = (yH/kH)*(1-thetaH)*kH_uZH;
yH_uZN = (yH/kH)*(1-thetaH)*kH_uZN;
yH_1lambda  = (yH/kH)*(1-thetaH)*kH_1lambda;

yN_1PN = (yN/kN)*(1-thetaN)*kN_1PN;
yN_1PH = (yN/kN)*(1-thetaN)*kN_1PH;
yN_1K  = (yN/kN)*(1-thetaN)*kN_1K;
yN_uKH = (yN/kN)*(1-thetaN)*kN_uKH;
yN_uKN = yN*(1-thetaN) + (yN/kN)*(1-thetaN)*kN_uKN;
yN_uZH = (yN/kN)*(1-thetaN)*kN_uZH;
yN_uZN = (yN/kN)*(1-thetaN)*kN_uZN;
yN_1lambda  = (yN/kN)*(1-thetaN)*kN_1lambda;

YH_1PN = (LH*yH_1PN) + (yH*LH_1PN);
YH_1PH = (LH*yH_1PH) + (yH*LH_1PH);
YH_1K  = (LH*yH_1K) + (yH*LH_1K);
YH_uKH = (LH*yH_uKH) + (yH*LH_uKH);
YH_uKN = (LH*yH_uKN) + (yH*LH_uKN);
YH_uZH = (LH*yH_uZH) + (yH*LH_uZH);
YH_uZN = (LH*yH_uZN) + (yH*LH_uZN);
YH_1lambda = (LH*yH_1lambda) + (yH*LH_1lambda);

YN_1PN = (LN*yN_1PN) + (yN*LN_1PN);
YN_1PH = (LN*yN_1PH) + (yN*LN_1PH);
YN_1K  = (LN*yN_1K) + (yN*LN_1K);
YN_uKH = (LN*yN_uKH) + (yN*LN_uKH);
YN_uKN = (LN*yN_uKN) + (yN*LN_uKN);
YN_uZH = (LN*yN_uZH) + (yN*LN_uZH);
YN_uZN = (LN*yN_uZN) + (yN*LN_uZN);
YN_1lambda = (LN*yN_1lambda) + (yN*LN_1lambda);

KH_1PN = (LH*kH_1PN) + (kH*LH_1PN);
KH_1PH = (LH*kH_1PH) + (kH*LH_1PH);
KH_1K  = (LH*kH_1K) + (kH*LH_1K);
KH_uKH = (LH*kH_uKH) + (kH*LH_uKH);
KH_uKN = (LH*kH_uKN) + (kH*LH_uKN);
KH_uZH = (LH*kH_uZH) + (kH*LH_uZH);
KH_uZN = (LH*kH_uZN) + (kH*LH_uZN);
KH_1lambda = (LH*kH_1lambda) + (kH*LH_1lambda);

KN_1PN = (LN*kN_1PN) + (kN*LN_1PN);
KN_1PH = (LN*kN_1PH) + (kN*LN_1PH);
KN_1K  = (LN*kN_1K) + (kN*LN_1K);
KN_uKH = (LN*kN_uKH) + (kN*LN_uKH);
KN_uKN = (LN*kN_uKN) + (kN*LN_uKN);
KN_uZH = (LN*kN_uZH) + (kN*LN_uZH);
KN_uZN = (LN*kN_uZN) + (kN*LN_uZN);
KN_1lambda = (LN*kN_1lambda) + (kN*LN_1lambda);

% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH)
CN_PN = - (CN/PN)*( (alphaC*phi) + sigmaC*(1-alphaC) ); 
CN_PH = (CN/PH)*alphaC*alphaH*(phi-sigmaC); 
CH_PN = (CH/PN)*(phi-sigmaC)*(1-alphaC); 
CH_PH = -(CH/PH)*( rho*(1-alphaH) + alphaH*( phi*(1-alphaC) + (sigmaC*alphaC) ) ); 
CF_PN = (CF/PN)*(1-alphaC)*(phi-sigmaC); 
CF_PH = (CF/PH)*alphaH*(rho - (phi*(1-alphaC)+(sigmaC*alphaC))); 

CH_1lambda = -(CH/lambda)*sigmaC; 
CN_1lambda = -(CN/lambda)*sigmaC;
CF_1lambda = -(CF/lambda)*sigmaC;

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_K  = deltaK; 
J_Q  = K*v_1Q; 
J_PN = K*v_PN; 
J_PH = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q)
I     = deltaK*K; 
JN_PN = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K = (IN/I)*J_K; 
JN_1Q = (IN/I)*J_Q; 

JH_PN =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_K; 
JH_1Q  = (IH/I)*J_Q; 

JF_PN = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_K; 
JF_1Q  = (IF/I)*J_Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH  = -(XH/PH)*nuX; 

% Solving for capital and technology utilization rates: uKH, uKN, uZH, uZN; uKj,uZj(PN,PH,K)
f11 = ((xi2H/xi1H) + thetaH) + thetaH*(kH_uKH/kH);
f12 = thetaH*(kH_uKN/kH);
f13 = (thetaH*(kH_uZH/kH)-1);
f14 = thetaH*(kH_uZN/kH);
f21 = thetaN*(kN_uKH/kN);
f22 = ((xi2N/xi1N) + thetaN) + thetaN*(kN_uKN/kN);
f23 = thetaN*(kN_uZH/kN);
f24 = (thetaN*(kN_uZN/kN)-1);
f31 = -YH_uKH;
f32 = -YH_uKN;
f33 = (chi2H-YH_uZH);
f34 = -YH_uZN;
f41 = -YN_uKH;
f42 = -YN_uKN;
f43 = -YN_uZH;
f44 = (chi2N-YN_uZN);

% PN, PH, K,
g11 = -thetaH*(kH_1PN/kH);       
g12 = -thetaH*(kH_1PH/kH);       
g13 = -thetaH*(kH_1K/kH);        
g14 = -thetaH*(kH_1lambda/kH);   
                                 
g21 = -thetaN*(kN_1PN/kN);       
g22 = -thetaN*(kN_1PH/kN);       
g23 = -thetaN*(kN_1K/kN);        
g24 = -thetaN*(kN_1lambda/kN);   

g31 = YH_1PN;
g32 = YH_1PH;
g33 = YH_1K;
g34 = YH_1lambda;

g41 = YN_1PN;
g42 = YN_1PH;
g43 = YN_1K;
g44 = YN_1lambda;

M2 = [f11 f12 f13 f14; f21 f22 f23 f24; f31 f32 f33 f34; f41 f42 f43 f44];
X2 = [g11 g12 g13 g14; g21 g22 g23 g24; g31 g32 g33 g34; g41 g42 g43 g44];
JST2 = inv(M2);
MST2 = JST2*X2;

uKH_PN = MST2(1,1); uKH_PH = MST2(1,2); uKH_1K = MST2(1,3); uKH_1lambda = MST2(1,4);
uKN_PN = MST2(2,1); uKN_PH = MST2(2,2); uKN_1K = MST2(2,3); uKN_1lambda = MST2(2,4);
uZH_PN = MST2(3,1); uZH_PH = MST2(3,2); uZH_1K = MST2(3,3); uZH_1lambda = MST2(3,4);
uZN_PN = MST2(4,1); uZN_PH = MST2(4,2); uZN_1K = MST2(4,3); uZN_1lambda = MST2(4,4);

% Solving for sectoral labor and sectoral output - kj,Wj,Lj,yj,Yj,Kj(lambda,K,PH,PN,AH,BH,AN,BN)
kH_2K  = kH_1K + (kH_uKH*uKH_1K) + (kH_uKN*uKN_1K) + (kH_uZH*uZH_1K) + (kH_uZN*uZN_1K);
kH_PH  = kH_1PH + (kH_uKH*uKH_PH) + (kH_uKN*uKN_PH) + (kH_uZH*uZH_PH) + (kH_uZN*uZN_PH);
kH_PN  = kH_1PN + (kH_uKH*uKH_PN) + (kH_uKN*uKN_PN) + (kH_uZH*uZH_PN) + (kH_uZN*uZN_PN);
kH_2lambda = kH_1lambda + (kH_uKH*uKH_1lambda) + (kH_uKN*uKN_1lambda) + (kH_uZH*uZH_1lambda) + (kH_uZN*uZN_1lambda);

kN_2K  = kN_1K + (kN_uKH*uKH_1K) + (kN_uKN*uKN_1K) + (kN_uZH*uZH_1K) + (kN_uZN*uZN_1K);
kN_PH  = kN_1PH + (kN_uKH*uKH_PH) + (kN_uKN*uKN_PH) + (kN_uZH*uZH_PH) + (kN_uZN*uZN_PH);
kN_PN  = kN_1PN + (kN_uKH*uKH_PN) + (kN_uKN*uKN_PN) + (kN_uZH*uZH_PN) + (kN_uZN*uZN_PN);
kN_2lambda = kN_1lambda + (kN_uKH*uKH_1lambda) + (kN_uKN*uKN_1lambda) + (kN_uZH*uZH_1lambda) + (kN_uZN*uZN_1lambda);

WH_2K  = WH_1K + (WH_uKH*uKH_1K) + (WH_uKN*uKN_1K) + (WH_uZH*uZH_1K) + (WH_uZN*uZN_1K);
WH_PH  = WH_1PH + (WH_uKH*uKH_PH) + (WH_uKN*uKN_PH) + (WH_uZH*uZH_PH) + (WH_uZN*uZN_PH);
WH_PN  = WH_1PN + (WH_uKH*uKH_PN) + (WH_uKN*uKN_PN) + (WH_uZH*uZH_PN) + (WH_uZN*uZN_PN);
WH_2lambda = WH_1lambda + (WH_uKH*uKH_1lambda) + (WH_uKN*uKN_1lambda) + (WH_uZH*uZH_1lambda) + (WH_uZN*uZN_1lambda);

WN_2K = WN_1K + (WN_uKH*uKH_1K) + (WN_uKN*uKN_1K) + (WN_uZH*uZH_1K) + (WN_uZN*uZN_1K);
WN_PH = WN_1PH + (WN_uKH*uKH_PH) + (WN_uKN*uKN_PH) + (WN_uZH*uZH_PH) + (WN_uZN*uZN_PH);
WN_PN = WN_1PN + (WN_uKH*uKH_PN) + (WN_uKN*uKN_PN) + (WN_uZH*uZH_PN) + (WN_uZN*uZN_PN);
WN_2lambda = WN_1lambda + (WN_uKH*uKH_1lambda) + (WN_uKN*uKN_1lambda) + (WN_uZH*uZH_1lambda) + (WN_uZN*uZN_1lambda);

LH_2K = LH_1K + (LH_uKH*uKH_1K) + (LH_uKN*uKN_1K) + (LH_uZH*uZH_1K) + (LH_uZN*uZN_1K);
LH_PH = LH_1PH + (LH_uKH*uKH_PH) + (LH_uKN*uKN_PH) + (LH_uZH*uZH_PH) + (LH_uZN*uZN_PH);
LH_PN = LH_1PN + (LH_uKH*uKH_PN) + (LH_uKN*uKN_PN) + (LH_uZH*uZH_PN) + (LH_uZN*uZN_PN);
LH_2lambda = LH_1lambda + (LH_uKH*uKH_1lambda) + (LH_uKN*uKN_1lambda) + (LH_uZH*uZH_1lambda) + (LH_uZN*uZN_1lambda);

LN_2K = LN_1K + (LN_uKH*uKH_1K) + (LN_uKN*uKN_1K) + (LN_uZH*uZH_1K) + (LN_uZN*uZN_1K);
LN_PH = LN_1PH + (LN_uKH*uKH_PH) + (LN_uKN*uKN_PH) + (LN_uZH*uZH_PH) + (LN_uZN*uZN_PH);
LN_PN = LN_1PN + (LN_uKH*uKH_PN) + (LN_uKN*uKN_PN) + (LN_uZH*uZH_PN) + (LN_uZN*uZN_PN);
LN_2lambda = LN_1lambda + (LN_uKH*uKH_1lambda) + (LN_uKN*uKN_1lambda) + (LN_uZH*uZH_1lambda) + (LN_uZN*uZN_1lambda);

YH_2K = YH_1K + (YH_uKH*uKH_1K) + (YH_uKN*uKN_1K) + (YH_uZH*uZH_1K) + (YH_uZN*uZN_1K);
YH_PH = YH_1PH + (YH_uKH*uKH_PH) + (YH_uKN*uKN_PH) + (YH_uZH*uZH_PH) + (YH_uZN*uZN_PH);
YH_PN = YH_1PN + (YH_uKH*uKH_PN) + (YH_uKN*uKN_PN) + (YH_uZH*uZH_PN) + (YH_uZN*uZN_PN);
YH_2lambda = YH_1lambda + (YH_uKH*uKH_1lambda) + (YH_uKN*uKN_1lambda) + (YH_uZH*uZH_1lambda) + (YH_uZN*uZN_1lambda);

YN_2K = YN_1K + (YN_uKH*uKH_1K) + (YN_uKN*uKN_1K) + (YN_uZH*uZH_1K) + (YN_uZN*uZN_1K);
YN_PH = YN_1PH + (YN_uKH*uKH_PH) + (YN_uKN*uKN_PH) + (YN_uZH*uZH_PH) + (YN_uZN*uZN_PH);
YN_PN = YN_1PN + (YN_uKH*uKH_PN) + (YN_uKN*uKN_PN) + (YN_uZH*uZH_PN) + (YN_uZN*uZN_PN);
YN_2lambda = YN_1lambda + (YN_uKH*uKH_1lambda) + (YN_uKN*uKN_1lambda) + (YN_uZH*uZH_1lambda) + (YN_uZN*uZN_1lambda);

KH_2K = KH_1K + (KH_uKH*uKH_1K) + (KH_uKN*uKN_1K) + (KH_uZH*uZH_1K) + (KH_uZN*uZN_1K);
KH_PH = KH_1PH + (KH_uKH*uKH_PH) + (KH_uKN*uKN_PH) + (KH_uZH*uZH_PH) + (KH_uZN*uZN_PH);
KH_PN = KH_1PN + (KH_uKH*uKH_PN) + (KH_uKN*uKN_PN) + (KH_uZH*uZH_PN) + (KH_uZN*uZN_PN);
KH_2lambda = KH_1lambda + (KH_uKH*uKH_1lambda) + (KH_uKN*uKN_1lambda) + (KH_uZH*uZH_1lambda) + (KH_uZN*uZN_1lambda);

KN_2K = KN_1K + (KN_uKH*uKH_1K) + (KN_uKN*uKN_1K) + (KN_uZH*uZH_1K) + (KN_uZN*uZN_1K);
KN_PH = KN_1PH + (KN_uKH*uKH_PH) + (KN_uKN*uKN_PH) + (KN_uZH*uZH_PH) + (KN_uZN*uZN_PH);
KN_PN = KN_1PN + (KN_uKH*uKH_PN) + (KN_uKN*uKN_PN) + (KN_uZH*uZH_PN) + (KN_uZN*uZN_PN);
KN_2lambda = KN_1lambda + (KN_uKH*uKH_1lambda) + (KN_uKN*uKN_1lambda) + (KN_uZH*uZH_1lambda) + (KN_uZN*uZN_1lambda);

% Partial Derivatives Gj=Gj(G)
GN_G   = omegaGN/PN;
GH_G   = (1-omegaGN)*(omegaGH/PH);
GF_G   = (1-omegaGN)*(1-omegaGH);

% Solving for traded and non-traded prices: PH,PN(K,Q,G,AH,BH,AN,BN,lambda)
h11 = (YN_PH - CN_PH - JN_PH) - (KN*xi1N*uKN_PH);
h12 = (YN_PN - CN_PN - JN_PN) - (KN*xi1N*uKN_PN);
h21 = (YH_PH - CH_PH - JH_PH - XH_PH) - (KH*xi1H*uKH_PH);
h22 = (YH_PN - CH_PN - JH_PN) - (KH*xi1H*uKH_PN);

% K,Q,G,AH,BH,AN,BN,lambda
k11 = -(YN_2K - JN_1K - (KN*xi1N*uKN_1K));
k12 = JN_1Q;
k13 = GN_G;
k14 = -((YN_2lambda - CN_1lambda) - (KN*xi1N*uKN_1lambda));

k21 = -(YH_2K - JH_1K - (KH*xi1H*uKH_1K));
k22 = JH_1Q;
k23 = GH_G;
k24 = -((YH_2lambda - CH_1lambda) - (KH*xi1H*uKH_1lambda));

M3 = [h11 h12; h21 h22];
X3 = [k11 k12 k13 k14; k21 k22 k23 k24];
JST3 = inv(M3);
MST3 = JST3*X3;

PH_K = MST3(1,1); PH_Q = MST3(1,2); PH_G = MST3(1,3); PH_lambda = MST3(1,4);
PN_K = MST3(2,1); PN_Q = MST3(2,2); PN_G = MST3(2,3); PN_lambda = MST3(2,4);

% Solving for capital-labor ratios kj=kj(K,Q,G,Aj,Bj) -                                 
% sectoral labor Lj=Lj(K,Q,G,Aj,Bj) - sectoral output                                   
% Yj=Yj(K,Q,G,Aj,Bj) - Final Solutions                                                  
kH_K = kH_2K + (kH_PH*PH_K) + (kH_PN*PN_K);                                             
kH_Q = (kH_PH*PH_Q) + (kH_PN*PN_Q);                                                     
kH_G = (kH_PH*PH_G) + (kH_PN*PN_G);                                                     
kH_lambda = kH_2lambda + (kH_PH*PH_lambda) + (kH_PN*PN_lambda);                         
                                                                                        
kN_K = kN_2K + (kN_PH*PH_K) + (kN_PN*PN_K);                                             
kN_Q = (kN_PH*PH_Q) + (kN_PN*PN_Q);                                                     
kN_G = (kN_PH*PH_G) + (kN_PN*PN_G);                                                     
kN_lambda = kN_2lambda + (kN_PH*PH_lambda) + (kN_PN*PN_lambda);                         
                                                                                        
LH_K  = LH_2K + (LH_PH*PH_K) + (LH_PN*PN_K);                                            
LH_Q  = (LH_PH*PH_Q) + (LH_PN*PN_Q);                                                    
LH_G  = (LH_PH*PH_G) + (LH_PN*PN_G);                                                    
LH_lambda = LH_2lambda + (LH_PH*PH_lambda) + (LH_PN*PN_lambda);                         
                                                                                        
LN_K = LN_2K + (LN_PH*PH_K) + (LN_PN*PN_K);                                             
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);                                                     
LN_G = (LN_PH*PH_G) + (LN_PN*PN_G);                                                     
LN_lambda = LN_2lambda + (LN_PH*PH_lambda) + (LN_PN*PN_lambda);                         
                                                                                        
YH_K = YH_2K + (YH_PH*PH_K) + (YH_PN*PN_K);                                             
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q);                                                     
YH_G = (YH_PH*PH_G) + (YH_PN*PN_G);                                                     
YH_lambda = YH_2lambda + (YH_PH*PH_lambda) + (YH_PN*PN_lambda);                         
                                                                                        
YN_K = YN_2K + (YN_PH*PH_K) + (YN_PN*PN_K);                                             
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);                                                     
YN_G = (YN_PH*PH_G) + (YN_PN*PN_G);                                                     
YN_lambda = YN_2lambda + (YN_PH*PH_lambda) + (YN_PN*PN_lambda);                         
                                                                                        
KH_K  = KH_2K + (KH_PH*PH_K) + (KH_PN*PN_K);                                            
KH_Q  = (KH_PH*PH_Q) + (KH_PN*PN_Q);                                                    
KH_G  = (KH_PH*PH_G) + (KH_PN*PN_G);                                                    
KH_lambda = KH_2lambda + (KH_PH*PH_lambda) + (KH_PN*PN_lambda);                         
                                                                                        
KN_K = KN_2K + (KN_PH*PH_K) + (KN_PN*PN_K);                                             
KN_Q = (KN_PH*PH_Q) + (KN_PN*PN_Q);                                                     
KN_G = (KN_PH*PH_G) + (KN_PN*PN_G);                                                     
KN_lambda = KN_2lambda + (KN_PH*PH_lambda) + (KN_PN*PN_lambda);                         
                                                                                        
uKH_K  = uKH_1K + (uKH_PH*PH_K) + (uKH_PN*PN_K);                                        
uKH_Q  = (uKH_PH*PH_Q) + (uKH_PN*PN_Q);                                                 
uKH_G  = (uKH_PH*PH_G) + (uKH_PN*PN_G);                                                 
uKH_lambda = uKH_1lambda + (uKH_PH*PH_lambda) + (uKH_PN*PN_lambda);                     
                                                                                        
uKN_K = uKN_1K + (uKN_PH*PH_K) + (uKN_PN*PN_K);                                         
uKN_Q = (uKN_PH*PH_Q) + (uKN_PN*PN_Q);                                                  
uKN_G = (uKN_PH*PH_G) + (uKN_PN*PN_G);                                                  
uKN_lambda = uKN_1lambda + (uKN_PH*PH_lambda) + (uKN_PN*PN_lambda);                     
                                                                                        
uZH_K  = uZH_1K + (uZH_PH*PH_K) + (uZH_PN*PN_K);                                        
uZH_Q  = (uZH_PH*PH_Q) + (uZH_PN*PN_Q);                                                 
uZH_G  = (uZH_PH*PH_G) + (uZH_PN*PN_G);                                                 
uZH_lambda = uZH_1lambda + (uZH_PH*PH_lambda) + (uZH_PN*PN_lambda);                     
                                                                                        
uZN_K = uZN_1K + (uZN_PH*PH_K) + (uZN_PN*PN_K);                                         
uZN_Q = (uZN_PH*PH_Q) + (uZN_PN*PN_Q);                                                  
uZN_G = (uZN_PH*PH_G) + (uZN_PN*PN_G);                                                  
uZN_lambda = uZN_1lambda + (uZN_PH*PH_lambda) + (uZN_PN*PN_lambda);                     
                                                                                        
% Solving for consumption Cj=Cj(lambda,K,Q,G), investment inputs
% Jj=Jj(K,Q,G), imports MF=MF(lambda,K,Q,G), exports
%XH=XH(K,Q,G)- Final Solutions
CH_K      = (CH_PH*PH_K) + (CH_PN*PN_K);
CH_Q      = (CH_PH*PH_Q) + (CH_PN*PN_Q);
CH_G      = (CH_PH*PH_G) + (CH_PN*PN_G);
CH_lambda = CH_1lambda + (CH_PH*PH_lambda) + (CH_PN*PN_lambda);

CN_K      = (CN_PH*PH_K) + (CN_PN*PN_K);
CN_Q      = (CN_PH*PH_Q) + (CN_PN*PN_Q);
CN_G      = (CN_PH*PH_G) + (CN_PN*PN_G);
CN_lambda = CN_1lambda + (CN_PH*PH_lambda) + (CN_PN*PN_lambda);

CF_K      = (CF_PH*PH_K) + (CF_PN*PN_K);
CF_Q      = (CF_PH*PH_Q) + (CF_PN*PN_Q);
CF_G      = (CF_PH*PH_G) + (CF_PN*PN_G);
CF_lambda = CF_1lambda + (CF_PH*PH_lambda) + (CF_PN*PN_lambda);

JH_K       = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K);
JH_Q       = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q);
JH_G       = (JH_PH*PH_G) + (JH_PN*PN_G);
JH_lambda  = (JH_PH*PH_lambda) + (JH_PN*PN_lambda);

JN_K       = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K);
JN_Q       = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q);
JN_G       = (JN_PH*PH_G) + (JN_PN*PN_G);
JN_lambda  = (JN_PH*PH_lambda) + (JN_PN*PN_lambda);

JF_K       = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K);
JF_Q       = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q);
JF_G       = (JF_PH*PH_G) + (JF_PN*PN_G);
JF_lambda  = (JF_PH*PH_lambda) + (JF_PN*PN_lambda);

XH_K      = XH_PH*PH_K;
XH_Q      = XH_PH*PH_Q;
XH_G      = XH_PH*PH_G;
XH_lambda = XH_PH*PH_lambda;

MF_K      = (CF_K + JF_K);
MF_Q      = (CF_Q + JF_Q);
MF_G      = (CF_G + JF_G);
MF_lambda = (CF_lambda + JF_lambda);

% Solving for sectoral wages - Wj=Wj(K,Q,G)
WH_K = WH_2K + (WH_PH*PH_K) + (WH_PN*PN_K);
WH_Q = (WH_PH*PH_Q) + (WH_PN*PN_Q);
WH_G = (WH_PH*PH_G) + (WH_PN*PN_G);
WH_lambda = WH_2lambda + (WH_PH*PH_lambda) + (WH_PN*PN_lambda);

WN_K = WN_2K + (WN_PH*PH_K) + (WN_PN*PN_K);
WN_Q = (WN_PH*PH_Q) + (WN_PN*PN_Q);
WN_G = (WN_PH*PH_G) + (WN_PN*PN_G);
WN_lambda = WN_2lambda + (WN_PH*PH_lambda) + (WN_PN*PN_lambda);

% Solutions tildeWj,tildeRj,tildeKj,tildeYj(K,Q,G); tildeWj=uZj*Wj;
% tildeRj=RK*uZj; tildeKj=uKj*Kj; tildeYj=uZj*Yj;
tildeWH_K  = WH_K + (WH*uZH_K);
tildeWH_Q  = WH_Q + (WH*uZH_Q);
tildeWH_G  = WH_G + (WH*uZH_G);
tildeWH_lambda = WH_lambda + (WH*uZH_lambda);

tildeWN_K  = WN_K + (WN*uZN_K);
tildeWN_Q  = WN_Q + (WN*uZN_Q);
tildeWN_G  = WN_G + (WN*uZN_G);
tildeWN_lambda = WN_lambda + (WN*uZN_lambda);

% Solution for tildeW(K,Q,G) - tildeW(tildeWH,tildeWN)
tildeW_WH      = (W/WH)*alphaL;
tildeW_WN      = (W/WN)*(1-alphaL);
tildeW_K       = (tildeW_WH*tildeWH_K)  + (tildeW_WN*tildeWN_K);
tildeW_Q       = (tildeW_WH*tildeWH_Q)  + (tildeW_WN*tildeWN_Q);
tildeW_G       = (tildeW_WH*tildeWH_G)  + (tildeW_WN*tildeWN_G);
tildeW_lambda  = (tildeW_WH*tildeWH_lambda) + (tildeW_WN*tildeWN_lambda);

% Solution for L as function L=L(K,Q,G)
L_1lambda = sigmaL*(L/lambda);
L_W  = sigmaL*(L/W);
L_WH = sigmaL*L*alphaL/WH;
L_WN = sigmaL*L*(1-alphaL)/WN;
L_K  = (L_WH*tildeWH_K)  + (L_WN*tildeWN_K);
L_Q  = (L_WH*tildeWH_Q)  + (L_WN*tildeWN_Q);
L_G  = (L_WH*tildeWH_G)  + (L_WN*tildeWN_G);
L_lambda  = L_1lambda + (L_WH*tildeWH_lambda) + (L_WN*tildeWN_lambda);

% Solution for C as function C=C(K,Q,G)
C_1lambda  = -sigmaC*(C/lambda);
C_PH       = -sigmaC*alphaC*alphaH*(C/PH);
C_PN       = -sigmaC*(1-alphaC)*(C/PN);
C_K        = (C_PH*PH_K) + (C_PN*PN_K);
C_Q        = (C_PH*PH_Q) + (C_PN*PN_Q);
C_G        = (C_PH*PH_G) + (C_PN*PN_G);
C_lambda   = C_1lambda + (C_PH*PH_lambda) + (C_PN*PN_lambda);

% Solution for PC=PC(PH,PN) - PC = PC(K,Q,G)
PC_K       = (PC/PH)*alphaC*alphaH*PH_K + (PC/PN)*(1-alphaC)*PN_K;
PC_Q       = (PC/PH)*alphaC*alphaH*PH_Q + (PC/PN)*(1-alphaC)*PN_Q;
PC_G       = (PC/PH)*alphaC*alphaH*PH_G + (PC/PN)*(1-alphaC)*PN_G;
PC_lambda  = (PC/PH)*alphaC*alphaH*PH_lambda + (PC/PN)*(1-alphaC)*PN_lambda;

% Solution for PI=PI(PH,PN) - PI = PI(K,Q,G)
PI_K       = (PI/PH)*alphaI*alphaIH*PH_K + (PI/PN)*(1-alphaI)*PN_K;
PI_Q       = (PI/PH)*alphaI*alphaIH*PH_Q + (PI/PN)*(1-alphaI)*PN_Q;
PI_G       = (PI/PH)*alphaI*alphaIH*PH_G + (PI/PN)*(1-alphaI)*PN_G;
PI_lambda  = (PI/PH)*alphaI*alphaIH*PH_lambda + (PI/PN)*(1-alphaI)*PN_lambda;

% Solution for GE=PH*GH + PN*GN + GF - G = G(K,Q,G)
G_K        = (PH_K*GH) + (PN_K*GN);
G_Q        = (PH_Q*GH) + (PN_Q*GN);
G_G        = (PH_G*GH) + (PN_G*GN) + (PH*GH_G) + (PN*GN_G) + GF_G;
G_lambda   = (PH_lambda*GH) + (PN_lambda*GN);

% Capital rental rates
RKH = PH*(1-thetaH)*(YH/KH); 
RKN = PN*(1-thetaN)*(YN/KN);

% Solution for the price of non traded goods in terms of home traded goods
% - P = P(K,Q,G,Aj,Bj);
P    = PN/PH;
P_K  = (P/PN)*PN_K - (P/PH)*PH_K;
P_Q  = (P/PN)*PN_Q - (P/PH)*PH_Q;
P_G  = (P/PN)*PN_G - (P/PH)*PH_G;
P_lambda = (P/PN)*PN_lambda - (P/PH)*PH_lambda;

% GDP and output shares in real terms
Y   = (PH*YH) +(PN*YN);

% Solution for Y as function Y=Y(K,Q,lambda,GH,GN)
Y_K       = (PH_K*YH) + (PH*YH_K) + (PN_K*YN) + (PN*YN_K);
Y_Q       = (PH_Q*YH) + (PH*YH_Q) + (PN_Q*YN) + (PN*YN_Q);
Y_G       = (PH_G*YH) + (PH*YH_G) + (PN_G*YN) + (PN*YN_G);
Y_lambda  = (PH_lambda*YH) + (PH*YH_lambda) + (PN_lambda*YN) + (PN*YN_lambda);

% Marginal revenue of capital R = PH*partial YH/partial KH.
% R=R(K,Q,G,Aj,Bj,lambda)
R_K = (RK/PH)*PH_K - (RK/kH)*thetaH*kH_K - RK*thetaH*uKH_K; 
R_Q = (RK/PH)*PH_Q - (RK/kH)*thetaH*kH_Q - RK*thetaH*uKH_Q; 
R_G = (RK/PH)*PH_G - (RK/kH)*thetaH*kH_G - RK*thetaH*uKH_G;
R_lambda = (RK/PH)*PH_lambda - (RK/kH)*thetaH*kH_lambda - RK*thetaH*uKH_lambda;

% Solving for investment function I/K = v(Q/PI)+delta_K -
% v=v(K,Q,G,Aj,Bj,lambda) final solution
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q);
v_K  = (v_PN*PN_K) + (v_PH*PH_K);
v_G  = (v_PN*PN_G) + (v_PH*PH_G);
v_lambda = (v_PN*PN_lambda) + (v_PH*PH_lambda);

% Elements of the Jacobian Matrix 
Upsilon_K = (I/IN)*(YN_K-CN_K-(KN*xi1N*uKN_K)) - deltaK + alphaI*phiI*I*( (PN_K/PN) - (alphaIH/PH)*PH_K );                                                                        
Upsilon_Q = (I/IN)*(YN_Q-CN_Q-(KN*xi1N*uKN_Q)) + alphaI*phiI*I*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );
Sigma_K   = -(R_K-(RK/K)+(RK/K)*((KH*uKH_K)+(KN*uKN_K)+(KH*uZH_K)+(KN*uZN_K)+(KH_K+KN_K))-(PH*KH/K)*xi1H*uKH_K-(PN*KN/K)*xi1N*uKN_K + (PI*kappa*v_K*deltaK) ); 
Sigma_Q   = (r+deltaK)-( R_Q+(RK/K)*((KH*uKH_Q)+(KN*uKN_Q))+(RK/K)*((KH*uZH_Q)+(KN*uZN_Q))+(RK/K)*(KH_Q+KN_Q)-(PH*KH/K)*xi1H*uKH_Q-(PN*KN/K)*xi1N*uKN_Q + (PI*kappa*v_Q*deltaK) ); 

x11 = Upsilon_K;                                                                         
x12 = Upsilon_Q;                                                                                                                                                                                                                     
x21 = Sigma_K;                        
x22 = Sigma_Q;    

J = [x11 x12; x21 x22];
[V,nu]=eig(J)
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu1 = nu_sorted(1,1); 
nu2 = nu_sorted(2,2); 
omega11 = V_sorted(1,1)/V_sorted(1,1); 
omega21 = V_sorted(2,1)/V_sorted(1,1); 
omega12 = V_sorted(1,2)/V_sorted(1,2); 
omega22 = V_sorted(2,2)/V_sorted(1,2); 
TrJ = trace(J); 
DetJ = det(J); 

% Intertemporal solvency condition - lambda - dotB = Xi(lambda,K,P,Q);
% Xi_Q=0
B_K   = (PH_K*XH) + (PH*XH_K) - MF_K; 
B_Q   = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
N1    = (B_K + (B_Q*omega21));
H1    = N1/(nu1-r); 

% Government spending 
G       = (PH*GH) + (PN*GN) + GF;   
GT      = GF + (PH*GH); 
omegaGT = GT/G; 
%omegaGH = (PH*GH)/G; 
omegaGF = GF/G; 

% Investment 
IT       = deltaK*K*iota*((PIT/PI)^(-phiI));
I_check  = ( (iota^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-iota)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1)); 
IT_check = ( (iotaH^(1/rhoI))*(IH^((rhoI-1)/rhoI)) + ((1-iotaH)^(1/rhoI))*(IF^((rhoI-1)/rhoI)) )^(rhoI/(rhoI-1));  
I        = deltaK*K; 
EI       = PI*I; 
EIT      = (PH*IH) + IF; 
omegaI   = PI*I/Y;
omegaIH  = (PH*IH)/(PI*I);
omegaIF  = (IF)/(PI*I);

% Net exports, current account and saving
NX  = (PH*XH) - MF;  
CA  = (r*B) + (PH*XH) - MF; 
A   = B + (PI*K); 
Tax = G; 
Sav = (r*A) + (W*L) - (PC*C) - Tax; 

% Real Aggregate Wage 
WPC  = W/PC;
WHPC = WH/PC;
WNPC = WN/PC;
RKPC = RK/PC;

% Labor income and Capital income shares
EL      = W*L; 
omegaL  = EL/Y; 
EK      = RK*K; 
omegaK  = EK/Y;
alphaK  = (RKN*KN)/(RK*K); 

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WH); 
YHYN  = (YH/YN); 
LHLN  = (LH/LN);

% Consumption 
CT       = C*varphi*((PT/PC)^(-phi));
C_check  = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1)); 
CT_check = ( (varphiH^(1/rho))*(CH^((rho-1)/rho)) + ((1-varphiH)^(1/rho))*(CF^((rho-1)/rho)) )^(rho/(rho-1));
omegaCH  = (PH*CH)/(PC*C); 
omegaCF  = (CF)/(PC*C);

% L_H, L_N and FOC for LH and LN 
Vut     = ( (vartheta^(-1/epsilon))*(LH^((epsilon+1)/epsilon)) + ((1-vartheta)^(-1/epsilon))*(LN^((epsilon+1)/epsilon)) ); 
L_check = Vut^(epsilon/(epsilon+1)); 
L_H     = ((vartheta)^(-1/epsilon))*(LH/L)^(1/epsilon); 
L_N     = ((1-vartheta)^(-1/epsilon))*(LN/L)^(1/epsilon);

% Sectoral ratios
omegaINYN = IN/YN; 
omegaIHYH = IH /YH; 
omegaIFYH =  IF/YH;
omegaGHYH = GH / YH;
omegaGFYH = GF / (PH*YH);
omegaGNYN = GN / YN;
%omegaGN   = (PN*GN) / G;
omegaYH   = (PH*YH) / Y;
omegaYN   = (PN*YN) /Y; 
omegaLH   = LH / L;
omegaLN   = LN / L; 
omegaXHY  = (PH*XH) / Y; 
omegaXHYH = XH / YH;

% Targeted ratios
omegaC    = (PC*C) / Y;
omegaNX   =  NX / Y; 
omegaG    = G/Y;
omegaB    = (r*B)/Y; 
omegaKY   = K/Y; 

% Technology
Z  = (ZH^omegaYH)*(ZN^(1-omegaYH));

% TFP
TFPH = YH/((LH^thetaH)*(KH^(1-thetaH))); 
TFPN = YN/((LN^thetaN)*(KN^(1-thetaN))); 
TFP  = (TFPH^omegaYH)*(TFPN^(1-omegaYH));

% Check the closure of the model
cond1  = PH*(1-thetaH)*(YH/KH)-RK;                               
cond2  = PN*(1-thetaN)*(YN/KN)-RK;                             
cond3  = PH*thetaH*(YH/LH)-WH;                                   
cond4  = PN*thetaN*(YN/LN)-WN;                                 
cond5  = (LH*kH)+(LN*kN)-K;                                   
cond6  = RK-(deltaK+r)*PI;                                    
cond7  = YN-CN-GN-IN;                                         
cond8  = YH-CH-GH-IH-XH;                                   
cond9  = (B-B0) - H1*(K-K0);                                  
cond10  = DetJ - (nu1*nu2);                                   
cond11 = TrJ - (nu1+nu2);                                     
cond12 = (LH/LN) - (vartheta/(1-vartheta))*Omega^(-epsilon);  
cond13 = (CT/CN) - (varphi/(1-varphi))*(PN/PT)^(phi);               
cond14 = (PC*C) - ((PT*CT)+(PN*CN));                                
cond15 = (W*L) - ((WH*LH)+(WN*LN));                           
cond16 = gammaL*(L^(1/sigmaL))*L_H - (lambda*WH);               
cond17 = gammaL*(L^(1/sigmaL))*L_N - (lambda*WN);               
cond18 = Y - (PC*C) - G - (PI*I) + (r*B);                     
cond19 = Sav;                                                 
cond20 = (PC*C) - (CF+(PH*CH)+(PN*CN));                                
cond21 = (IT/IN) - (iota/(1-iota))*(PN/PIT)^(phiI);            
cond22 = (PI*I) - ((PIT*IT)+(PN*IN));                                
cond23 = (RK*K) - ((RKH*KH)+(RKN*KN));                        
cond24 = 1 - (omegaK + omegaL);    
cond25 = (CH/CF) - (varphiH/(1-varphiH))*(PH)^(-rho);    
cond26 = (PT*CT) - ((PH*CH)+CF); 
cond27 = (IH/IF) - (iotaH/(1-iotaH))*(PH)^(-rhoI);    
cond28 = (PIT*IT) - ((PH*IH)+IF); 
cond29 = r*B + (PH*XH) - MF; 
cond30 = r*B + (RK*K) + (W*L) - G - (PC*C) - (PI*I); 
cond31 = RK - PI*(r+deltaK);
 
disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                     Initial Steady State with kH > kN');
disp('                           The Benchmark: ');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (benchmark)');
disp(sprintf('thetaH  : %5.2f   thetaN   : %5.2f',thetaH,thetaN));
disp(sprintf('sLH     : %5.2f   sLN      : %5.2f',sLH,sLN));
disp(sprintf('sigmaC  : %5.2f   phi      : %5.2f  varphi : %5.2f',sigmaC,phi,varphi));
disp(sprintf('rho     : %5.2f   varphiH  : %5.2f ',rho,varphiH));
disp(sprintf('phiI    : %5.2f   iota     : %5.2f ',phiI,iota)); 
disp(sprintf('rhoI    : %5.2f   iotaH    : %5.2f ',rhoI,iotaH))
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f ',sigmaL,gammaL));
disp(sprintf('epsilon : %5.2f   vartheta : %5.2f',epsilon,vartheta));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('ZH      : %5.2f   ZN       : %5.2f',ZH,ZN));
disp(sprintf('TFPH    : %5.2f   TFPN     : %5.2f',TFPH,TFPN));
disp(sprintf('omegaYH : %5.2f   Z        : %5.2f TFP        : %5.2f',omegaYH,Z,TFP));
disp(sprintf('GH      : %5.2f   GN       : %5.2f',GH,GN));
disp(sprintf('GF      : %5.2f   G        : %5.2f',GF,G));
disp(' ');

disp(' ');
disp('The production side (benchmark)');
disp(sprintf('kH       : %9.3f    kN   : %9.3f',kH,kN));
disp(sprintf('LH       : %9.3f    LN   : %9.3f',LH,LN));
disp(sprintf('KH       : %9.3f    KN   : %9.3f',KH,KN));
disp(sprintf('YH       : %9.3f    YN   : %9.3f',YH,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('L_check  : %9.3f   ',L_check));
disp(sprintf('alphaL   : %9.3f   ',alphaL));

disp(' ');
disp('The demand side (benchmark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('CT       :   %7.3f  CT_check : %9.3f',CT,CT_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('PT       :   %7.3f    alphaH : %9.3f',PT,alphaH));
disp(sprintf('CH       :   %7.3f    CN     : %9.3f',CH,CN));
disp(sprintf('CF       :   %7.3f',CF));

disp('The demand side (benchmark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('PIT      :   %7.3f   alphaIH : %9.3f',PIT,alphaIH));
disp(sprintf('IH       :   %7.3f    IN     : %9.3f',IH,IN));
disp(sprintf('EI       :   %7.3f    EIT    : %9.3f',EI,EIT));

disp('Export and import (benchmark)');
disp(sprintf('XH        :   %7.3f   MF : %9.3f',XH,MF));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector H');
disp(sprintf('Gross output (YH)  : %9.3f',YH));
disp(sprintf('WH                 : %9.3f',WH));
disp(sprintf('Profit             : %9.10f',PiH));

disp('Price of Non Tradables in terms of Imports');                                                                
disp(' ');                                                                                      
disp('Relative Prices');  
disp(sprintf('PN_K       : %5.4f   PN_Q       : %5.4f',PN_K,PN_Q));                                 
disp(sprintf('PN_G       :  %5.4f  PN_lambda  : %5.4f',PN_G,PN_lambda));  
disp(sprintf('PH_K       : %5.4f   PH_Q       : %5.4f',PH_K,PH_Q));                                 
disp(sprintf('PH_G       :  %5.4f  PH_lambda  : %5.4f',PH_G,PH_lambda));                                                                                                                       
                                                                                               
disp(' ');                                                                                      
disp('Partial derivatives CH and CN');                                                          
disp(sprintf('CN_K        :   %7.3f  CH_K      : %9.3f',CN_K,CH_K));                            
disp(sprintf('CN_Q        :   %7.3f  CH_Q      : %9.3f',CN_Q,CH_Q));                            
disp(sprintf('CN_lamb     :   %7.3f  CH_lamb   : %9.3f',CN_lambda,CH_lambda));                  
disp(sprintf('CN_G        :   %7.3f  CH_G      : %9.3f',CN_G,CH_G)); 
disp(sprintf('CN_lamb     :   %7.3f  CH_lamb   : %9.3f',CN_lambda,CH_lambda));                                                                                                                                                                                                                  
disp('Partial derivatives LH and LN');                                                          
disp(sprintf('LN_WH       :   %7.3f  LH_WH      : %9.3f',LN_WH,LH_WH));                         
disp(sprintf('LN_WN       :   %7.3f  LH_WN      : %9.3f',LN_WN,LH_WN));                         
disp(sprintf('LN_lamb     :   %7.3f  LH_lamb    : %9.3f',LN_lambda,LH_lambda));                 
disp(sprintf('LN_G        :   %7.3f  LH_G       : %9.3f',LN_G,LH_G));  
                                                                                                
disp('Partial derivatives kH and kN');                                                          
disp(sprintf('kN_Q       :   %7.6f  kH_Q       : %9.6f',kN_Q,kH_Q));                            
disp(sprintf('kN_K       :   %7.6f  kH_K       : %9.6f',kN_K,kH_K));                            
disp(sprintf('kN_lambda  :   %7.3f  kH_lambda  : %9.3f',kN_lambda,kH_lambda));                  
disp(sprintf('kN_G       :   %7.6f  kH_G       : %9.6f',kN_G,kH_G));   
                                                                                              
disp('Partial derivatives WH and WN');                                                          
disp(sprintf('WN_Q       :   %7.6f  WH_Q       : %9.6f',WN_Q,WH_Q));                            
disp(sprintf('WN_K       :   %7.6f  WH_K       : %9.6f',WN_K,WH_K));                            
disp(sprintf('WN_lambda  :   %7.3f  WH_lambda  : %9.3f',WN_lambda,WH_lambda));                  
disp(sprintf('WN_G       :   %7.6f  WH_G       : %9.6f',WN_G,WH_G)); 
                                                                                               
disp('Partial derivatives LH and LN');                                                          
disp(sprintf('LN_Q       :   %7.6f  LH_Q       : %9.6f',LN_Q,LH_Q));                            
disp(sprintf('LN_K       :   %7.6f  LH_K       : %9.6f',LN_K,LH_K));                            
disp(sprintf('LN_lambda  :   %7.3f  LH_lambda  : %9.3f',LN_lambda,LH_lambda));                  
disp(sprintf('LN_G       :   %7.6f  LH_G       : %9.6f',LN_G,LH_G)); 

disp('Partial derivatives Yj');  
disp(sprintf('YN_1PN     :   %7.6f  YN_1PH     : %9.6f',YN_1PN,YN_1PH));
disp(sprintf('YN_1K      :   %7.6f  YN_1lambda : %9.6f',YN_1K,YN_1lambda));
disp(sprintf('YN_uKH     :   %7.6f  YN_uKN     : %9.6f',YN_uKH,YN_uKN));
disp(sprintf('YN_uZH     :   %7.6f  YH_uZN     : %9.6f',YN_uZH,YN_uZN));
disp(' ');
disp(sprintf('YH_1PN     :   %7.6f  YH_1PH     : %9.6f',YH_1PN,YH_1PH));
disp(sprintf('YH_1K      :   %7.6f  YH_1lambda : %9.6f',YH_1K,YH_1lambda));
disp(sprintf('YH_uKH     :   %7.6f  YH_uKN     : %9.6f',YH_uKH,YH_uKN));
disp(sprintf('YH_uZH     :   %7.6f  YH_uZN     : %9.6f',YH_uZH,YH_uZN));
disp(' ');

disp(sprintf('YN_Q       :   %7.6f  YH_Q       : %9.6f',YN_Q,YH_Q));                            
disp(sprintf('YN_K       :   %7.6f  YH_K       : %9.6f',YN_K,YH_K));                            
disp(sprintf('YN_lambda  :   %7.3f  YH_lambda  : %9.3f',YN_lambda,YH_lambda));                  
disp(sprintf('YN_G       :   %7.6f  YH_G       : %9.6f',YN_G,YH_G));
                                                                                                
disp('Partial derivatives of Y');                                                               
disp(sprintf('Y_Q        :   %7.3f  Y_K        : %9.3f',Y_Q,Y_K));  
disp(sprintf('Y_G        :   %7.3f  Y_lambda   : %9.3f',Y_G,Y_lambda));                                                                          
                                                                         
disp('Partial derivatives of L');
disp(sprintf('L_H        :   %7.3f  L_N        : %9.3f',L_H,L_N));

disp('Partial derivatives of L');                                                               
disp(sprintf('L_Q        :   %7.3f  L_K        : %9.3f',L_Q,L_K));                              
disp(sprintf('L_G        :   %7.3f ',L_G));      
disp(sprintf('L_lambda   :   %7.3f  tildeW_lambda   : %9.3f',L_lambda,tildeW_lambda));  

disp('Partial derivatives of uKj');  
disp(sprintf('uKN_Q       :   %7.6f  uKH_Q       : %9.6f',uKN_Q,uKH_Q));             
disp(sprintf('uKN_K       :   %7.6f  uKH_K       : %9.6f',uKN_K,uKH_K));             
disp(sprintf('uKN_lambda  :   %7.3f  uKH_lambda  : %9.3f',uKN_lambda,uKH_lambda));   
disp(sprintf('uKN_G       :   %7.6f  uKH_G       : %9.6f',uKN_G,uKH_G));             
  
disp('Partial derivatives of uZj');  
disp(sprintf('uZN_Q       :   %7.6f  uZH_Q       : %9.6f',uZN_Q,uZH_Q));            
disp(sprintf('uZN_K       :   %7.6f  uZH_K       : %9.6f',uZN_K,uZH_K));            
disp(sprintf('uZN_lambda  :   %7.3f  uZH_lambda  : %9.3f',uZN_lambda,uZH_lambda));  
disp(sprintf('uZN_G       :   %7.6f  uZH_G       : %9.6f',uZN_G,uZH_G));            
                                                                                                       
disp('Partial derivatives of W');                                                               
disp(sprintf('tildeW_WH       :   %7.3f  tildeW_WN       : %9.3f',tildeW_WH,tildeW_WN));   
disp(sprintf('tildeW_Q        :   %7.3f  tildeW_K        : %9.3f',tildeW_Q,tildeW_K));          
disp(sprintf('tildeW_G        :   %7.3f',tildeW_G));                                          
disp(' ');
disp('Wealth');
disp(sprintf('K      :   %5.3f    B  :   %5.6f',K,B));
disp(sprintf('lambda :   %5.15f   A  :   %5.3f',lambda,A));
disp(sprintf('Sav    :   %5.10f   CA :   %5.10f',Sav,CA));

disp(' ');                                                                                      
disp('Linearization');                                                                          
disp(sprintf('R_lambda  :  %5.4f  R_K       : %5.4f   R_Q     : %5.4f',R_lambda,R_K,R_Q));      
disp(sprintf('R_G       :  %5.4f',R_G));
disp(sprintf('P_K       : %5.4f   P_Q       : %5.4f',P_K,P_Q));                                 
disp(sprintf('P_G       :  %5.4f',P_G));     
disp(sprintf('v_K       :  %5.4f  v_Q       : %5.4f',v_K,v_Q));                                 
disp(sprintf('v_G       :  %5.4f',v_G));          
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_Q : %5.4f',Upsilon_K,Upsilon_Q));                     
disp(sprintf('Sigma_K   :  %5.4f  Sigma_Q   : %5.4f',Sigma_K,Sigma_Q));                         
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));  
                                                                                                
disp(' ');
disp('Eigenvalues and Eigenvectors');
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu1,nu2));
disp(sprintf('omega11    :   %5.6f  omega12    : %5.6f',omega11,omega12));
disp(sprintf('omega21    :   %5.6f  omega22    : %5.6f',omega21,omega22));
disp(sprintf('N1         :   %5.6f    H1       : %5.6f',N1,H1));
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));

disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('YH / Y    :  %5.3f      PN*YN / Y  : %5.3f',omegaYH,omegaYN));
disp(sprintf('LH / L    :  %5.3f      LN / L    : %5.3f',omegaLH,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('PN*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GH / YH     :  %5.3f  GN / YN    :  %5.3f  (PN*GN)/G  : %5.3f',omegaGHYH,omegaGNYN,omegaGN));
disp(sprintf('(PH*GH)/G   :  %5.3f  GF / G     :  %5.3f  GT/G       : %5.3f',omegaGH,omegaGF,omegaGT));
disp(sprintf('IN / YN     :  %5.3f  IH / YH    :  %5.3f  (r*B)/Y    : %5.3f',omegaINYN,omegaIHYH,omegaB));
disp(sprintf('IF / YH     :  %5.3f  GF / YH    :  %5.3f',omegaIFYH,omegaGFYH));
disp(sprintf('WN*LN/W*L   :  %5.3f RN*KN/R*K   :  %5.3f',alphaL,alphaK));
disp(sprintf('PIT*IT/PI*I :  %5.3f PT*CT/PC*C  :  %5.3f',alphaI,alphaC));
disp(sprintf('PH*IH/PT*IT :  %5.3f PH*CH/PT*CT :  %5.3f',alphaIH,alphaH));
disp(sprintf('PH*IH/PI*I  :  %5.3f PH*CH/PC*C  :  %5.3f',omegaIH,omegaCH));
disp(sprintf('IF/PI*I     :  %5.3f    CF/PC*C  :  %5.3f',omegaIF,omegaCF));
disp(sprintf('PH*XH/Y  :  %5.3f       XH / YH  :  %5.3f',omegaXHY,omegaXHYH));
disp(sprintf('W*L/Y       :  %5.3f R*K/Y       :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y         :  %5.3f',omegaKY));

disp(' ');
disp(sprintf('Marginal product of KH = RT       : %9.16f   ',cond1));
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));
disp(sprintf('Marginal product of LH = WH       : %9.16f   ',cond3));
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));
disp(sprintf('Resource contraint for capital    : %9.16f   ',cond5));
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));
disp(sprintf('Market clearing condition good H  : %9.16f   ',cond8));
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));
disp(sprintf('Relative labor  LH/LN             : %9.16f   ',cond12));
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));
disp(sprintf('FOC -V_L*(dL/dLH) = lambda*WH     : %9.16f   ',cond16));
disp(sprintf('FOC -V_L*(dL/dLN) = lambda*WN     : %9.16f   ',cond17));
disp(sprintf('Global market clearing condition  : %9.16f   ',cond18));
disp(sprintf('Private Savings                   : %9.16f   ',cond19));
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond20));
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond21));
disp(sprintf('Investment expenditure check      : %9.16f   ',cond22));
disp(sprintf('Capital income R*K                : %9.16f   ',cond23));
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond24));
disp(sprintf('relative consumption  CH/CF       : %9.16f   ',cond25));
disp(sprintf('Consumption expenditure in T PT*CT: %9.16f   ',cond26));
disp(sprintf('relative investment   IH/IF       : %9.16f   ',cond27));
disp(sprintf('Investment expenditure in T PIT*JT: %9.16f   ',cond28));
disp(sprintf('Current account                   : %9.16f   ',cond29));
disp(sprintf('Current account                   : %9.16f   ',cond30));

kH_0 = kH;  kN_0 = kN; PN_0 = PN; LH_0 = LH; K_0 = K; C_0 = C;  
LN_0  = LN; L_0 = L; W_0 = W; P_0 = P; 
YH_0  = YH; YN_0  = YN; Y_0  = Y; YR_0 = Y_0; KH_0  = KH; KN_0  = KN; G_0 = G;     
PC_0 = PC; alphaC_0 = alphaC; CN_0 = CN; CH_0 = CH;  
ZH_0 = ZH; ZN_0 = ZN; Z_0 = Z; AH_0 = AH; BH_0 = BH; AN_0 = AN; 
BN_0 = BN; GH_0 = GH; GN_0 = GN;  GF_0 = GF;
LH_0 = LH; LN_0 = LN; KH_0 = KH; KN_0 = KN; WH_0 = WH; WN_0 = WN; 
Omega_0 = Omega; YHYN_0 = YHYN; LHLN_0 = LHLN;
IF_0 = IF; CF_0 = CF; XH_0 = XH; MF_0 = MF; PH_0 = PH; 
PT_0 = PT; PIT_0 = PIT; CT_0 = CT; IT_0 = IT; GT_0 = GT; 

CA_0 = CA; Sav_0 = Sav; NX_0 = NX; I_0 = I; lambda_0  = lambda; A_0 = A; 
B_0 = B; IN_0 = IN; IH_0 = IH; PI_0 = PI; alphaI_0 = alphaI; EI_0 = EI; 
WPC_0 = WPC; WHPC_0 = WHPC; WNPC_0 = WNPC; alphaL_0 = alphaL; RK_0 = RK; 
yH_0 = yH; yN_0 = yN; 

omegaL_0 = omegaL; omegaK_0 = omegaK; omegaI_0 = omegaI; omegaINYN_0 = omegaINYN;
omegaIHYH_0 = omegaIHYH; omega_IFYH_0 = omegaIFYH; omegaGHYH_0 = omegaGHYH; 
omegaGFYH_0 = omegaGFYH; omegaGNYN_0 = omegaGNYN; omegaGN_0 = omegaGN;
omegaYH_0 = omegaYH; omegaYN_0 = omegaYN; omegaLH_0 = omegaLH; omegaLN_0 = omegaLN; 
omegaC_0 =omegaC; omegaNX_0 =omegaNX; omegaG_0 =omegaG; omegaB_0 =omegaB; 
omegaIFYH_0 = omegaIFYH; omegaGFYH_0 = omegaGFYH; omegaIH_0 = omegaIH; 
omegaCH_0 = omegaCH; omegaIF_0 = omegaIF; omegaCF_0 = omegaCF; 
omegaGT_0 = omegaGT; omegaGH_0 = omegaGH; omegaGF_0 = omegaGF; 
omegaKY_0 = omegaKY; omegaIH_0 = omegaIH; omegaIF_0 = omegaIF;
omegaXHY_0 = omegaXHY; omegaXHYH_0 = omegaXHYH; 
alphaL_0 = alphaL; alphaK_0 = alphaK; alphaC_0 = alphaC; 
alphaI_0 = alphaI; alphaH_0 = alphaH; alphaIH_0 = alphaIH; 
sLH_0 = sLH; sLN_0 = sLN; 
TFPH_0 = TFPH; TFPN_0 = TFPN; TFP_0 = TFP; sL_0 = sL; k_0 = k;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  Temporary Fiscal Shock                          %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
B0       = B_0;
K0       = K_0; 
GH       = GH_0; 
GN       = GN_0; 
GF       = GF_0; 
AH       = AH_0; 
BH       = BH_0; 
AN       = AN_0;
BN       = BN_0;   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Endogenous response of G, Aj, Bj to an exogenous government spending shock 
barg     = parameters(1,1); 
xi       = parameters(2,1);                                                                                                                               
chi      = parameters(3,1); 

baraH    = 0.0000000000001;  
barbH    = 0.0000000000001;  
baraN    = 0.0000000000001;  
barbN    = 0.0000000000001;  
xiAH     = 0.0000000000001;  
chiAH    = 0.0000000000001;  
xiBH     = 0.0000000000001;  
chiBH    = 0.0000000000001;  
xiAN     = 0.0000000000001;  
chiAN    = 0.0000000000001;  
xiBN     = 0.0000000000001;  
chiBN    = 0.0000000000001;  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                                                                                                                                                                                                     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x0 =[C_0 L_0 kH_0 WH_0 WN_0 W_0 kN_0 PN_0 K_0 PH_0 B_0 alphaL_0 PC_0 PT_0 CN_0 CH_0 CF_0 PI_0 PIT_0 IN_0 IH_0 IF_0 LH_0 LN_0 yH_0 YH_0 yN_0 YN_0 XH_0 MF_0 lambda_0];
[x,fval,exitflag]=fsolve('IML_CAC_TOT_CD_temp',x0,optimset('display','off','TolFun',1e-011));
C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kH      = x(3)  ; % Capital-labor ratio in sector H
WH      = x(4)  ; % Wage rate in sector H
WN      = x(5)  ; % Wage rate in sector N
W       = x(6)  ; % Aggregate wage index
kN      = x(7)  ; % Capital-labor ratio in sector N
PN      = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
PH      = x(10) ; % Terms of trade : PH/PF with PF = numeraire
B       = x(11) ; % Stock of Traded Bonds
alphaL  = x(12) ; % Output per worker in sector H
PC      = x(13) ; % Aggregate consumption price index
PT      = x(14) ; % Consumption price index for tradables
CN      = x(15) ; % Consumption in non tradables 
CH      = x(16) ; % Consumption in tradables 
CF      = x(17) ; % Consumption goods imports
PI      = x(18) ; % Aggregate investment price index
PIT     = x(19) ; % Investment price index for tradables
IN      = x(20) ; % Non tradable investment
IH      = x(21) ; % Investment in home goods
IF      = x(22) ; % Investment in foreign goods
LH      = x(23) ; % Labor in sector H
LN      = x(24) ; % Labor in sector N 
yH      = x(25) ; % Output of home traded goods per worker
YH      = x(26) ; % Output of home traded goods
yN      = x(27) ; % Output of non traded goods per worker
YN      = x(28) ; % Output of non traded goods
XH      = x(29) ; % Exports of home traded goods
MF      = x(30) ; % Imports of foreign goods
lambda  = x(31) ; % Marginal utility of wealth lambda

% Shares
I       = deltaK*K;
alphaC  = varphi*(PT/PC)^(1-phi);
alphaH  = varphiH*(PH/PT)^(1-rho);
alphaI  = iota*(PIT/PI)^(1-phiI);
alphaIH = iotaH*(PH/PIT)^(1-rhoI);

% Technology
Z  = (ZH^omegaYH_0)*(ZN^(1-omegaYH_0));

% Nominal and Real GDP
Y  = (PH*YH) +(PN*YN);
YR = (PH_0*YH) + (PN_0*YN); 

% VA shares in real terms
omegaYHR = (PH_0*YH)/YR; 
omegaYNR = (PN_0*YN)/YR; 

% Technology
Z  = (ZH^omegaYH)*(ZN^(1-omegaYH));

% Sectoral outputs and sectoral profits   
RK  = PI*(r+deltaK);
KH  = LH*kH;   
PiH = (PH*YH) - (RK*KH) - (WH*LH);
  
KN  = LN*kN;  
PiN = (PN*YN) - (RK*KN) - (WN*LN);

% TFP
TFPH = YH/((LH^thetaH)*(KH^(1-thetaH))); 
TFPN = YN/((LN^thetaN)*(KN^(1-thetaN))); 
TFP  = (TFPH^omegaYH)*(TFPN^(1-omegaYH));

% Capital rental rates
RKH = PH*(1-thetaH)*(YH/KH); 
RKN = PN*(1-thetaN)*(YN/KN);

% Labor income share in the home traded good and non traded good sector
sLH = WH*LH/(PH*YH);
sLN = WN*LN/(PN*YN);
sL  = W*L/Y; 
k   = K/L;

% Labor income and Capital income shares
EL      = W*L; 
omegaL  = EL/Y; 
EK      = RK*K; 
omegaK  = EK/Y;
alphaK  = (RKH*KH)/(RK*K); 

% Government spending 
G       = (PH*GH) + (PN*GN) + GF;   
GT      = GF + (PH*GH); 

% LHj = partial Lj/partial Wj: Lj=Lj(WH,WN,uZH,uZN)
LH_WH   = (LH/WH)*( epsilon*(1-alphaL) + (sigmaL*alphaL) );
LH_1uZH = LH*( epsilon*(1-alphaL) + (sigmaL*alphaL) );
LH_WN   = (LH/WN)*(1-alphaL)*(sigmaL-epsilon); 
LH_1uZN = LH*(1-alphaL)*(sigmaL-epsilon); 
LN_WH   = (LN/WH)*alphaL*(sigmaL-epsilon); 
LN_1uZH = LN*alphaL*(sigmaL-epsilon);
LN_WN   = (LN/WN)*( (epsilon*alphaL) + sigmaL*(1-alphaL) );  
LN_1uZN = LN*( (epsilon*alphaL) + sigmaL*(1-alphaL) ); 
LH_1lamb = sigmaL*LH/lambda; 
LN_1lamb = sigmaL*LN/lambda;

% Solving for kH, kN, WH, WN as functions of (PH, PN, K, uKH, uKN, uZH,
% uZN)
Psi_WH   = ( (kH*LH_WH) + (kN*LN_WH) );
Psi_WN   = ( (kH*LH_WN) + (kN*LN_WN) );
Psi_uZH  = ((kH*LH_1uZH) + (kN*LN_1uZH)); 
Psi_uZN  = ((kH*LH_1uZN) + (kN*LN_1uZN)); 

d11 = -(thetaH/kH); 
d12 = (thetaN/kN);
d13 = 0;
d14 = 0;
d21 = ((1-thetaH)/kH); 
d22 = 0;  
d23 = -(1/WH); 
d24 = 0; 
d31 = 0; 
d32 = ((1-thetaN)/kN);
d33 = 0; 
d34 = -(1/WN);
d41 = LH; 
d42 = LN; 
d43 = Psi_WH; 
d44 = Psi_WN; 

% PN, PH, K, uKH, uKN, uZH, uZN 
e11 = (1/PN);                   
e12 = -(1/PH);                  
e13 = 0;                        
e14 = thetaH;                   
e15 = -thetaN;                  
e16 = 0;                        
e17 = 0; 

e21 = 0;                        
e22 = -(1/PH);                  
e23 = 0;                        
e24 = -(1-thetaH);              
e25 = 0;                        
e26 = 0; 
e27 = 0;  

e31 = -(1/PN);                  
e32 = 0;                        
e33 = 0;                        
e34 = 0;                        
e35 = -(1-thetaN);              
e36 = 0;                        
e37 = 0; 

e41 = 0;                        
e42 = 0;                        
e43 = 1;                        
e44 = 0;                        
e45 = 0;                        
e46  = -Psi_uZH; 
e47  = -Psi_uZN;
    
M1 = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X1 = [e11 e12 e13 e14 e15 e16 e17; e21 e22 e23 e24 e25 e26 e27; e31 e32 e33 e34 e35 e36 e37; e41 e42 e43 e44 e45 e46 e47];
JST1 = inv(M1);
MST1 = JST1*X1;
kH_1PN = MST1(1,1); kH_1PH = MST1(1,2); kH_1K = MST1(1,3); kH_uKH = MST1(1,4); kH_uKN = MST1(1,5); kH_uZH = MST1(1,6); kH_uZN = MST1(1,7); 
kN_1PN = MST1(2,1); kN_1PH = MST1(2,2); kN_1K = MST1(2,3); kN_uKH = MST1(2,4); kN_uKN = MST1(2,5); kN_uZH = MST1(2,6); kN_uZN = MST1(2,7); 
WH_1PN = MST1(3,1); WH_1PH = MST1(3,2); WH_1K = MST1(3,3); WH_uKH = MST1(3,4); WH_uKN = MST1(3,5); WH_uZH = MST1(3,6); WH_uZN = MST1(3,7); 
WN_1PN = MST1(4,1); WN_1PH = MST1(4,2); WN_1K = MST1(4,3); WN_uKH = MST1(4,4); WN_uKN = MST1(4,5); WN_uZH = MST1(4,6); WN_uZN = MST1(4,7); 
    
% Solving for sectoral labor and sectoral output - Lj,yj,Yj,Kj(PN,PH,K,uKj,uZj)
LH_1PN = (LH_WH*WH_1PN) + (LH_WN*WN_1PN);
LH_1PH = (LH_WH*WH_1PH) + (LH_WN*WN_1PH);
LH_1K  = (LH_WH*WH_1K)  + (LH_WN*WN_1K);
LH_uKH = (LH_WH*WH_uKH) + (LH_WN*WN_uKH);
LH_uKN = (LH_WH*WH_uKN) + (LH_WN*WN_uKN);
LH_uZH = LH_1uZH + (LH_WH*WH_uZH) + (LH_WN*WN_uZH);
LH_uZN = LH_1uZN + (LH_WH*WH_uZN) + (LH_WN*WN_uZN);

LN_1PN = (LN_WH*WH_1PN) + (LN_WN*WN_1PN);
LN_1PH = (LN_WH*WH_1PH) + (LN_WN*WN_1PH);
LN_1K  = (LN_WH*WH_1K)  + (LN_WN*WN_1K);
LN_uKH = (LN_WH*WH_uKH) + (LN_WN*WN_uKH);
LN_uKN = (LN_WH*WH_uKN) + (LN_WN*WN_uKN);
LN_uZH = LN_1uZH + (LN_WH*WH_uZH) + (LN_WN*WN_uZH);
LN_uZN = LN_1uZN + (LN_WH*WH_uZN) + (LN_WN*WN_uZN);

yH_1PN = (yH/kH)*(1-thetaH)*kH_1PN;                                              
yH_1PH = (yH/kH)*(1-thetaH)*kH_1PH;                                              
yH_1K  = (yH/kH)*(1-thetaH)*kH_1K;                                               
yH_uKH = yH*(1-thetaH) + (yH/kH)*(1-thetaH)*kH_uKH;                              
yH_uKN = (yH/kH)*(1-thetaH)*kH_uKN;                                              
yH_uZH = (yH/kH)*(1-thetaH)*kH_uZH;                                              
yH_uZN = (yH/kH)*(1-thetaH)*kH_uZN;                                              
                                                                                 
yN_1PN = (yN/kN)*(1-thetaN)*kN_1PN;                                              
yN_1PH = (yN/kN)*(1-thetaN)*kN_1PH;                                              
yN_1K  = (yN/kN)*(1-thetaN)*kN_1K;                                               
yN_uKH = (yN/kN)*(1-thetaN)*kN_uKH;                                              
yN_uKN = yN*(1-thetaN) + (yN/kN)*(1-thetaN)*kN_uKN;                              
yN_uZH = (yN/kN)*(1-thetaN)*kN_uZH;                                              
yN_uZN = (yN/kN)*(1-thetaN)*kN_uZN;    

YH_1PN = (LH*yH_1PN) + (yH*LH_1PN);
YH_1PH = (LH*yH_1PH) + (yH*LH_1PH);
YH_1K  = (LH*yH_1K) + (yH*LH_1K);
YH_uKH = (LH*yH_uKH) + (yH*LH_uKH);
YH_uKN = (LH*yH_uKN) + (yH*LH_uKN);
YH_uZH = (LH*yH_uZH) + (yH*LH_uZH);
YH_uZN = (LH*yH_uZN) + (yH*LH_uZN);

YN_1PN = (LN*yN_1PN) + (yN*LN_1PN);
YN_1PH = (LN*yN_1PH) + (yN*LN_1PH);
YN_1K  = (LN*yN_1K) + (yN*LN_1K);
YN_uKH = (LN*yN_uKH) + (yN*LN_uKH);
YN_uKN = (LN*yN_uKN) + (yN*LN_uKN);
YN_uZH = (LN*yN_uZH) + (yN*LN_uZH);
YN_uZN = (LN*yN_uZN) + (yN*LN_uZN);

KH_1PN = (LH*kH_1PN) + (kH*LH_1PN);
KH_1PH = (LH*kH_1PH) + (kH*LH_1PH);
KH_1K  = (LH*kH_1K) + (kH*LH_1K);
KH_uKH = (LH*kH_uKH) + (kH*LH_uKH);
KH_uKN = (LH*kH_uKN) + (kH*LH_uKN);
KH_uZH = (LH*kH_uZH) + (kH*LH_uZH);
KH_uZN = (LH*kH_uZN) + (kH*LH_uZN);             

KN_1PN = (LN*kN_1PN) + (kN*LN_1PN);
KN_1PH = (LN*kN_1PH) + (kN*LN_1PH);
KN_1K  = (LN*kN_1K) + (kN*LN_1K);
KN_uKH = (LN*kN_uKH) + (kN*LN_uKH);
KN_uKN = (LN*kN_uKN) + (kN*LN_uKN);
KN_uZH = (LN*kN_uZH) + (kN*LN_uZH);
KN_uZN = (LN*kN_uZN) + (kN*LN_uZN);        

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_K  = deltaK; 
J_Q  = K*v_1Q; 
J_PN = K*v_PN; 
J_PH = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q) 
JN_PN  = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH  = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K  = (IN/I)*J_K; 
JN_1Q  = (IN/I)*J_Q; 

JH_PN  =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH  = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_K; 
JH_1Q  = (IH/I)*J_Q; 

JF_PN  = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH  = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_K; 
JF_1Q  = (IF/I)*J_Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH  = -(XH/PH)*nuX; 

% Solving for capital and technology utilization rates: uKH, uKN, uZH, uZN; uKj,uZj(PN,PH,K)
f11 = ((xi2H/xi1H) + thetaH) + thetaH*(kH_uKH/kH);
f12 = thetaH*(kH_uKN/kH);
f13 = (thetaH*(kH_uZH/kH)-1);
f14 = thetaH*(kH_uZN/kH);
f21 = thetaN*(kN_uKH/kN);
f22 = ((xi2N/xi1N) + thetaN) + thetaN*(kN_uKN/kN);
f23 = thetaN*(kN_uZH/kN);
f24 = (thetaN*(kN_uZN/kN)-1);
f31 = -(YH_uKH/YH);
f32 = -(YH_uKN/YH);
f33 = ((chi2H/chi1H)-(YH_uZH/YH));
f34 = -(YH_uZN/YH);
f41 = -(YN_uKH/YN);
f42 = -(YN_uKN/YN);
f43 = -(YN_uZH/YN);
f44 = ((chi2N/chi1N)-(YN_uZN/YN));

% PN, PH, K
g11 = -thetaH*(kH_1PN/kH);
g12 = -thetaH*(kH_1PH/kH);
g13 = -thetaH*(kH_1K/kH);

g21 = -thetaN*(kN_1PN/kN);
g22 = -thetaN*(kN_1PH/kN);
g23 = -thetaN*(kN_1K/kN);

g31 = (YH_1PN/YH);
g32 = (YH_1PH/YH);
g33 = (YH_1K/YH);

g41 = (YN_1PN/YN);
g42 = (YN_1PH/YN);
g43 = (YN_1K/YN);

M2 = [f11 f12 f13 f14; f21 f22 f23 f24; f31 f32 f33 f34; f41 f42 f43 f44];
X2 = [g11 g12 g13; g21 g22 g23; g31 g32 g33; g41 g42 g43];
JST2 = inv(M2);
MST2 = JST2*X2;

uKH_PN = MST2(1,1); uKH_PH = MST2(1,2); uKH_1K = MST2(1,3);  
uKN_PN = MST2(2,1); uKN_PH = MST2(2,2); uKN_1K = MST2(2,3);  
uZH_PN = MST2(3,1); uZH_PH = MST2(3,2); uZH_1K = MST2(3,3);  
uZN_PN = MST2(4,1); uZN_PH = MST2(4,2); uZN_1K = MST2(4,3);   

% Solving for sectoral labor and sectoral output - kj,Wj,Lj,yj,Yj,Kj(lambda,K,PH,PN,AH,BH,AN,BN) 
kH_2K  = kH_1K + (kH_uKH*uKH_1K) + (kH_uKN*uKN_1K) + (kH_uZH*uZH_1K) + (kH_uZN*uZN_1K); 
kH_PH  = kH_1PH + (kH_uKH*uKH_PH) + (kH_uKN*uKN_PH) + (kH_uZH*uZH_PH) + (kH_uZN*uZN_PH);
kH_PN  = kH_1PN + (kH_uKH*uKH_PN) + (kH_uKN*uKN_PN) + (kH_uZH*uZH_PN) + (kH_uZN*uZN_PN);

kN_2K  = kN_1K + (kN_uKH*uKH_1K) + (kN_uKN*uKN_1K) + (kN_uZH*uZH_1K) + (kN_uZN*uZN_1K);     
kN_PH  = kN_1PH + (kN_uKH*uKH_PH) + (kN_uKN*uKN_PH) + (kN_uZH*uZH_PH) + (kN_uZN*uZN_PH);
kN_PN  = kN_1PN + (kN_uKH*uKH_PN) + (kN_uKN*uKN_PN) + (kN_uZH*uZH_PN) + (kN_uZN*uZN_PN);
 
WH_2K  = WH_1K + (WH_uKH*uKH_1K) + (WH_uKN*uKN_1K) + (WH_uZH*uZH_1K) + (WH_uZN*uZN_1K);  
WH_PH  = WH_1PH + (WH_uKH*uKH_PH) + (WH_uKN*uKN_PH) + (WH_uZH*uZH_PH) + (WH_uZN*uZN_PH); 
WH_PN  = WH_1PN + (WH_uKH*uKH_PN) + (WH_uKN*uKN_PN) + (WH_uZH*uZH_PN) + (WH_uZN*uZN_PN);

WN_2K = WN_1K + (WN_uKH*uKH_1K) + (WN_uKN*uKN_1K) + (WN_uZH*uZH_1K) + (WN_uZN*uZN_1K);  
WN_PH = WN_1PH + (WN_uKH*uKH_PH) + (WN_uKN*uKN_PH) + (WN_uZH*uZH_PH) + (WN_uZN*uZN_PH); 
WN_PN = WN_1PN + (WN_uKH*uKH_PN) + (WN_uKN*uKN_PN) + (WN_uZH*uZH_PN) + (WN_uZN*uZN_PN);                       

LH_2K = LH_1K + (LH_uKH*uKH_1K) + (LH_uKN*uKN_1K) + (LH_uZH*uZH_1K) + (LH_uZN*uZN_1K);  
LH_PH = LH_1PH + (LH_uKH*uKH_PH) + (LH_uKN*uKN_PH) + (LH_uZH*uZH_PH) + (LH_uZN*uZN_PH); 
LH_PN = LH_1PN + (LH_uKH*uKH_PN) + (LH_uKN*uKN_PN) + (LH_uZH*uZH_PN) + (LH_uZN*uZN_PN);                            

LN_2K = LN_1K + (LN_uKH*uKH_1K) + (LN_uKN*uKN_1K) + (LN_uZH*uZH_1K) + (LN_uZN*uZN_1K);  
LN_PH = LN_1PH + (LN_uKH*uKH_PH) + (LN_uKN*uKN_PH) + (LN_uZH*uZH_PH) + (LN_uZN*uZN_PH); 
LN_PN = LN_1PN + (LN_uKH*uKH_PN) + (LN_uKN*uKN_PN) + (LN_uZH*uZH_PN) + (LN_uZN*uZN_PN);                         

YH_2K = YH_1K + (YH_uKH*uKH_1K) + (YH_uKN*uKN_1K) + (YH_uZH*uZH_1K) + (YH_uZN*uZN_1K);   
YH_PH = YH_1PH + (YH_uKH*uKH_PH) + (YH_uKN*uKN_PH) + (YH_uZH*uZH_PH) + (YH_uZN*uZN_PH);  
YH_PN = YH_1PN + (YH_uKH*uKH_PN) + (YH_uKN*uKN_PN) + (YH_uZH*uZH_PN) + (YH_uZN*uZN_PN);                           

YN_2K = YN_1K + (YN_uKH*uKH_1K) + (YN_uKN*uKN_1K) + (YN_uZH*uZH_1K) + (YN_uZN*uZN_1K);   
YN_PH = YN_1PH + (YN_uKH*uKH_PH) + (YN_uKN*uKN_PH) + (YN_uZH*uZH_PH) + (YN_uZN*uZN_PH);  
YN_PN = YN_1PN + (YN_uKH*uKH_PN) + (YN_uKN*uKN_PN) + (YN_uZH*uZH_PN) + (YN_uZN*uZN_PN);                        

KH_2K = KH_1K + (KH_uKH*uKH_1K) + (KH_uKN*uKN_1K) + (KH_uZH*uZH_1K) + (KH_uZN*uZN_1K);  
KH_PH = KH_1PH + (KH_uKH*uKH_PH) + (KH_uKN*uKN_PH) + (KH_uZH*uZH_PH) + (KH_uZN*uZN_PH); 
KH_PN = KH_1PN + (KH_uKH*uKH_PN) + (KH_uKN*uKN_PN) + (KH_uZH*uZH_PN) + (KH_uZN*uZN_PN);                          

KN_2K = KN_1K + (KN_uKH*uKH_1K) + (KN_uKN*uKN_1K) + (KN_uZH*uZH_1K) + (KN_uZN*uZN_1K);  
KN_PH = KN_1PH + (KN_uKH*uKH_PH) + (KN_uKN*uKN_PH) + (KN_uZH*uZH_PH) + (KN_uZN*uZN_PH); 
KN_PN = KN_1PN + (KN_uKH*uKH_PN) + (KN_uKN*uKN_PN) + (KN_uZH*uZH_PN) + (KN_uZN*uZN_PN);                         

% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH)
CN_PN = - (CN/PN)*( (alphaC*phi) + sigmaC*(1-alphaC) ); 
CN_PH = (CN/PH)*alphaC*alphaH*(phi-sigmaC); 
CH_PN = (CH/PN)*(phi-sigmaC)*(1-alphaC); 
CH_PH = -(CH/PH)*( rho*(1-alphaH) + alphaH*( phi*(1-alphaC) + (sigmaC*alphaC) ) ); 
CF_PN = (CF/PN)*(1-alphaC)*(phi-sigmaC); 
CF_PH = (CF/PH)*alphaH*(rho - (phi*(1-alphaC)+(sigmaC*alphaC))); 

% Partial Derivatives Gj=Gj(G) 
GN_G   = omegaGN/PN; 
GH_G   = (1-omegaGN)*(omegaGH/PH);
GF_G   = (1-omegaGN)*(1-omegaGH);

% Solving for traded and non-traded prices: PH,PN(K,Q,G,AH,BH,AN,BN,lambda)     
h11 = (YN_PH - CN_PH - JN_PH) - (KN*xi1N*uKN_PH);           
h12 = (YN_PN - CN_PN - JN_PN) - (KN*xi1N*uKN_PN);           
h21 = (YH_PH - CH_PH - JH_PH - XH_PH) - (KH*xi1H*uKH_PH);   
h22 = (YH_PN - CH_PN - JH_PN) - (KH*xi1H*uKH_PN);           
                                                            
% K,Q,G,AH,BH,AN,BN,lambda                                                       
k11 = -(YN_2K - JN_1K - (KN*xi1N*uKN_1K));                  
k12 = JN_1Q;    
k13 = GN_G;                       

k21 = -(YH_2K - JH_1K - (KH*xi1H*uKH_1K));                  
k22 = JH_1Q;  
k23 = GH_G;                        
                                                            
M3 = [h11 h12; h21 h22];                                    
X3 = [k11 k12 k13; k21 k22 k23];                                    
JST3 = inv(M3);                                             
MST3 = JST3*X3;                                             
                                                            
PH_K = MST3(1,1); PH_Q = MST3(1,2); PH_G = MST3(1,3); 
PN_K = MST3(2,1); PN_Q = MST3(2,2); PN_G = MST3(2,3);                          

% Solving for capital-labor ratios kj=kj(K,Q,G,Aj,Bj) - 
% sectoral labor Lj=Lj(K,Q,G,Aj,Bj) - sectoral output 
% Yj=Yj(K,Q,G,Aj,Bj) - Final Solutions
kH_K = kH_2K + (kH_PH*PH_K) + (kH_PN*PN_K); 
kH_Q = (kH_PH*PH_Q) + (kH_PN*PN_Q);
kH_G = (kH_PH*PH_G) + (kH_PN*PN_G);

kN_K = kN_2K + (kN_PH*PH_K) + (kN_PN*PN_K);
kN_Q = (kN_PH*PH_Q) + (kN_PN*PN_Q); 
kN_G = (kN_PH*PH_G) + (kN_PN*PN_G);
 
LH_K  = LH_2K + (LH_PH*PH_K) + (LH_PN*PN_K); 
LH_Q  = (LH_PH*PH_Q) + (LH_PN*PN_Q); 
LH_G  = (LH_PH*PH_G) + (LH_PN*PN_G);

LN_K = LN_2K + (LN_PH*PH_K) + (LN_PN*PN_K);
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);
LN_G = (LN_PH*PH_G) + (LN_PN*PN_G); 

YH_K = YH_2K + (YH_PH*PH_K) + (YH_PN*PN_K); 
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q); 
YH_G = (YH_PH*PH_G) + (YH_PN*PN_G);

YN_K = YN_2K + (YN_PH*PH_K) + (YN_PN*PN_K);
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);
YN_G = (YN_PH*PH_G) + (YN_PN*PN_G);

KH_K  = KH_2K + (KH_PH*PH_K) + (KH_PN*PN_K);                     
KH_Q  = (KH_PH*PH_Q) + (KH_PN*PN_Q);                             
KH_G  = (KH_PH*PH_G) + (KH_PN*PN_G);                                             
                                                                 
KN_K = KN_2K + (KN_PH*PH_K) + (KN_PN*PN_K);                      
KN_Q = (KN_PH*PH_Q) + (KN_PN*PN_Q);                              
KN_G = (KN_PH*PH_G) + (KN_PN*PN_G);                                                

uKH_K  = uKH_1K + (uKH_PH*PH_K) + (uKH_PN*PN_K);                     
uKH_Q  = (uKH_PH*PH_Q) + (uKH_PN*PN_Q);                              
uKH_G  = (uKH_PH*PH_G) + (uKH_PN*PN_G);                                                
                                                                     
uKN_K = uKN_1K + (uKN_PH*PH_K) + (uKN_PN*PN_K);                      
uKN_Q = (uKN_PH*PH_Q) + (uKN_PN*PN_Q);                               
uKN_G = (uKN_PH*PH_G) + (uKN_PN*PN_G);                                                   

uZH_K  = uZH_1K + (uZH_PH*PH_K) + (uZH_PN*PN_K);                         
uZH_Q  = (uZH_PH*PH_Q) + (uZH_PN*PN_Q);                                  
uZH_G  = (uZH_PH*PH_G) + (uZH_PN*PN_G);                                                             
                                                                         
uZN_K = uZN_1K + (uZN_PH*PH_K) + (uZN_PN*PN_K);                          
uZN_Q = (uZN_PH*PH_Q) + (uZN_PN*PN_Q);                                   
uZN_G = (uZN_PH*PH_G) + (uZN_PN*PN_G);                                                              

% Solving for consumption Cj=Cj(lambda,K,Q,G,Aj,Bj), investment inputs 
% Jj=Jj(K,Q,GH,GN), imports MF=MF(lambda,K,Q,G,Aj,Bj), exports 
%XH=XH(K,Q,G,Aj,Bj)- Final Solutions
CH_K      = (CH_PH*PH_K) + (CH_PN*PN_K);
CH_Q      = (CH_PH*PH_Q) + (CH_PN*PN_Q);
CH_G      = (CH_PH*PH_G) + (CH_PN*PN_G);

CN_K      = (CN_PH*PH_K) + (CN_PN*PN_K);
CN_Q      = (CN_PH*PH_Q) + (CN_PN*PN_Q);
CN_G      = (CN_PH*PH_G) + (CN_PN*PN_G);

CF_K      = (CF_PH*PH_K) + (CF_PN*PN_K);
CF_Q      = (CF_PH*PH_Q) + (CF_PN*PN_Q);
CF_G      = (CF_PH*PH_G) + (CF_PN*PN_G);

JH_K       = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K);
JH_Q       = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q);
JH_G       = (JH_PH*PH_G) + (JH_PN*PN_G);

JN_K       = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K);
JN_Q       = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q);
JN_G       = (JN_PH*PH_G) + (JN_PN*PN_G);

JF_K       = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K);
JF_Q       = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q);
JF_G       = (JF_PH*PH_G) + (JF_PN*PN_G);

XH_K      = XH_PH*PH_K;
XH_Q      = XH_PH*PH_Q;
XH_G      = XH_PH*PH_G;

MF_K      = (CF_K + JF_K);
MF_Q      = (CF_Q + JF_Q);
MF_G      = (CF_G + JF_G);

% Solving for sectoral wages - Wj=Wj(K,Q,G,Aj,Bj)
WH_K = WH_2K + (WH_PH*PH_K) + (WH_PN*PN_K);                       
WH_Q = (WH_PH*PH_Q) + (WH_PN*PN_Q);                               
WH_G = (WH_PH*PH_G) + (WH_PN*PN_G);                                                  
                                                                  
WN_K = WN_2K + (WN_PH*PH_K) + (WN_PN*PN_K);                       
WN_Q = (WN_PH*PH_Q) + (WN_PN*PN_Q);                               
WN_G = (WN_PH*PH_G) + (WN_PN*PN_G);                                                    

% Solution for W as function W=W(K,Q,G,Aj,Bj) 
W_WH      = (W/WH)*alphaL; 
W_WN      = (W/WN)*(1-alphaL); 
W_K       = (W_WH*WH_K) + (W_WN*WN_K); 
W_Q       = (W_WH*WH_Q) + (W_WN*WN_Q);
W_G       = (W_WH*WH_G) + (W_WN*WN_G); 

% Solutions for the relative wages Wj/W: WjW=WjW(K,Q,G,Aj,Bj); 
% Solution for Omega = WN(K,Q,G,Aj,Bj)/WH(K,Q,G,Aj,Bj) 
WHW_K = (WH_0/W_0)*( (WH_K/WH_0) - (W_K/W_0) );                      
WHW_Q = (WH_0/W_0)*( (WH_Q/WH_0) - (W_Q/W_0) );                      
WHW_G = (WH_0/W_0)*( (WH_G/WH_0) - (W_G/W_0) );                                      
                                                                     
WNW_K = (WN_0/W_0)*( (WN_K/WN_0) - (W_K/W_0) );                      
WNW_Q = (WN_0/W_0)*( (WN_Q/WN_0) - (W_Q/W_0) );                      
WNW_G = (WN_0/W_0)*( (WN_G/WN_0) - (W_G/W_0) );                                     
                                                                     
Omega_K  = Omega_0*( (WN_K/WN_0) - (WH_K/WH_0) );       
Omega_Q  = Omega_0*( (WN_Q/WN_0) - (WH_Q/WH_0) );       
Omega_G  = Omega_0*( (WN_G/WN_0) - (WH_G/WH_0) );                        
 
% Solution for C as function C=C(K,Q,G,Aj,Bj) 
% Solution for C as function C=C(lambda,K,Q,AH,BH,AN,BN) 
C_1lambda  = -sigmaC*(C/lambda); 
C_PH       = -sigmaC*alphaC*alphaH*(C/PH); 
C_PN       = -sigmaC*(1-alphaC)*(C/PN); 
C_K        = (C_PH*PH_K) + (C_PN*PN_K); 
C_Q        = (C_PH*PH_Q) + (C_PN*PN_Q);
C_G        = (C_PH*PH_G) + (C_PN*PN_G); 

% Solution for PC=PC(PH,PN) - PC = PC(K,Q,G,Aj,Bj)
PC_K       = (PC/PH)*alphaC*alphaH*PH_K + (PC/PN)*(1-alphaC)*PN_K; 
PC_Q       = (PC/PH)*alphaC*alphaH*PH_Q + (PC/PN)*(1-alphaC)*PN_Q;
PC_G       = (PC/PH)*alphaC*alphaH*PH_G + (PC/PN)*(1-alphaC)*PN_G;

% Solution for Wj/PC,W/PC(K,Q,G,Aj,Bj)
WHPC_K  = WHPC_0*( (WH_K/WH_0) - (PC_K/PC_0) );   
WHPC_Q  = WHPC_0*( (WH_Q/WH_0) - (PC_Q/PC_0) );   
WHPC_G  = WHPC_0*( (WH_G/WH_0) - (PC_G/PC_0) );   
                                                  
WNPC_K  = WNPC_0*( (WN_K/WN_0) - (PC_K/PC_0) );   
WNPC_Q  = WNPC_0*( (WN_Q/WN_0) - (PC_Q/PC_0) );   
WNPC_G  = WNPC_0*( (WN_G/WN_0) - (PC_G/PC_0) );   

WPC_K  = WPC_0*( (W_K/W_0) - (PC_K/PC_0) );    
WPC_Q  = WPC_0*( (W_Q/W_0) - (PC_Q/PC_0) );    
WPC_G  = WPC_0*( (W_G/W_0) - (PC_G/PC_0) );    

% Solution for PI=PI(PH,PN) - PI = PI(K,Q,G,Aj,Bj)
PI_K       = (PI/PH)*alphaI*alphaIH*PH_K + (PI/PN)*(1-alphaI)*PN_K; 
PI_Q       = (PI/PH)*alphaI*alphaIH*PH_Q + (PI/PN)*(1-alphaI)*PN_Q;
PI_G       = (PI/PH)*alphaI*alphaIH*PH_G + (PI/PN)*(1-alphaI)*PN_G;  

% Solution for GE=PH*GH + PN*GN + GF - G = G(K,Q,G,Aj,Bj)
G_K        = (PH_K*GH) + (PN_K*GN); 
G_Q        = (PH_Q*GH) + (PN_Q*GN);
G_G        = (PH_G*GH) + (PN_G*GN) + (PH*GH_G) + (PN*GN_G); %+ GF_G;   

% Solution for the price of non traded goods in terms of home traded goods
% - P = P(K,Q,G,Aj,Bj); 
P    = PN/PH; 
P_K  = (P/PN)*PN_K - (P/PH)*PH_K; 
P_Q  = (P/PN)*PN_Q - (P/PH)*PH_Q;
P_G  = (P/PN)*PN_G - (P/PH)*PH_G; 

% Solution for Y as function Y=Y(K,Q,lambda,GH,GN) 
Y_K       = (PH_K*YH) + (PH*YH_K) + (PN_K*YN) + (PN*YN_K); 
Y_Q       = (PH_Q*YH) + (PH*YH_Q) + (PN_Q*YN) + (PN*YN_Q);
Y_G       = (PH_G*YH) + (PH*YH_G) + (PN_G*YN) + (PN*YN_G);

% Solution for Real GDP as function YR=YR(K,Q,lambda,GH,GN)
YR_K   = (PH_0*YH_K) + (PN_0*YN_K);                            
YR_Q   = (PH_0*YH_Q) + (PN_0*YN_Q);
YR_G   = (PH_0*YH_G) + (PN_0*YN_G); 

% Marginal revenue of capital R = PH*partial YH/partial KH.
% R=R(K,Q,G,Aj,Bj,lambda)
RK   = PI*(r+deltaK); 
R_K  = (RK/PH)*PH_K - (RK/kH)*thetaH*kH_K - RK*thetaH*uKH_K; 
R_Q  = (RK/PH)*PH_Q - (RK/kH)*thetaH*kH_Q - RK*thetaH*uKH_Q;
R_G  = (RK/PH)*PH_G - (RK/kH)*thetaH*kH_G - RK*thetaH*uKH_G;

% Solving for investment function I/K = v(Q/PI)+delta_K - 
% v=v(K,Q,G,Aj,Bj,lambda) final solution
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q); 
v_K  = (v_PN*PN_K) + (v_PH*PH_K); 
v_G  = (v_PN*PN_G) + (v_PH*PH_G); 

% Elements of the Jacobian Matrix 
Upsilon_K = (I/IN)*(YN_K-CN_K-(KN*xi1N*uKN_K)) - deltaK + alphaI*phiI*I*( (PN_K/PN) - (alphaIH/PH)*PH_K );                                                                        
Upsilon_Q = (I/IN)*(YN_Q-CN_Q-(KN*xi1N*uKN_Q)) + alphaI*phiI*I*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );
Sigma_K   = -(R_K-(RK/K)+(RK/K)*((KH*uKH_K)+(KN*uKN_K)+(KH*uZH_K)+(KN*uZN_K)+(KH_K+KN_K))-(PH*KH/K)*xi1H*uKH_K-(PN*KN/K)*xi1N*uKN_K + (PI*kappa*v_K*deltaK) ); 
Sigma_Q   = (r+deltaK)-( R_Q+(RK/K)*((KH*uKH_Q)+(KN*uKN_Q)+(KH*uZH_Q)+(KN*uZN_Q)+(KH_Q+KN_Q))-(PH*KH/K)*xi1H*uKH_Q-(PN*KN/K)*xi1N*uKN_Q + (PI*kappa*v_Q*deltaK) ); 

x11   = Upsilon_K;                                                                         
x12   = Upsilon_Q;     
x21   = Sigma_K;                        
x22   = Sigma_Q;
J = [x11 x12; x21 x22];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[mu order] = sort(diag(mu),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1); 
nu_2 = nu_sorted(2,2); 
omega_11 = V_sorted(1,1)/V_sorted(1,1); 
omega_21 = V_sorted(2,1)/V_sorted(1,1); 
omega_12 = V_sorted(1,2)/V_sorted(1,2); 
omega_22 = V_sorted(2,2)/V_sorted(1,2); 

TrJ = trace(J); 
DetJ = det(J); 

% Elements of general solutions for capital K(t) and the relative price P(t)
% K(t) -K = X1(t)+X2(t); P(t)-P = omega21*X1(t)+omega22*X2(t)
% X1(t) = (K0-K)*exp(nu1*t)+Gamma2*exp(nu1*t) - Gamma1*(exp(nu1*t)-exp(-xi*t)); 
% X2(t) = -Gamma2*exp(-xi*t); 
Upsilon_G  = (I/IN)*(YN_G-CN_G-GN_G-(KN*xi1N*uKN_G)) + (alphaI*phiI*I)*( (PN_G/PN) - (alphaIH/PH)*PH_G );
Sigma_G    = -( R_G+(RK/K)*((KH*uKH_G)+(KN*uKN_G)+(KH*uZH_G)+(KN*uZN_G)+(KH_G+KN_G))-(PH*KH/K)*xi1H*uKH_G-(PN*KN/K)*xi1N*uKN_G + (PI*kappa*v_G*deltaK) ); 

PhiG_1     = (x11-nu_2)*Upsilon_G + (x12*Sigma_G); 
PhiG_2     = (x11-nu_1)*Upsilon_G + (x12*Sigma_G);
ThetaG_1   = (1-barg)*((nu_1+xi)/(nu_1+chi)); 
ThetaG_2   = (1-barg)*((nu_2+xi)/(nu_2+chi));
GammaG_1   = -((PhiG_1*Y_0)/(nu_1-nu_2))*(1/(nu_1+xi)) ;
GammaG_2   = -((PhiG_2*Y_0)/(nu_1-nu_2))*(1/(nu_2+xi));  

X20       = -GammaG_2*(1-ThetaG_2); 
X10       = (K0-K) - X20; 

% Intertemporal solvency condition - lambda 
B_K          = (PH_K*XH) + (PH*XH_K) - MF_K; 
B_Q          = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
B_G          = (PH_G*XH) + (PH*XH_G) - MF_G; 
N1           = (B_K + (B_Q*omega_21));
N2           = (B_K + (B_Q*omega_22)); 
ThetaG_prime  = (1-barg)*((xi+r)/(chi+r)); 
ThetaG_1prime = ThetaG_1*((xi+r)/(chi+r));
ThetaG_2prime = ThetaG_2*((xi+r)/(chi+r));
wB1           = N1*((K0-K) + GammaG_2*(1-ThetaG_2)- GammaG_1*(1-ThetaG_1)); 
wBG2          = B_G*Y_0*(1-ThetaG_prime) + N1*GammaG_1*(1-ThetaG_1prime) - N2*GammaG_2*(1-ThetaG_2prime);  

% Solution for the stock of financial wealth
A0        = B0 + (PI*K0); 
A_K       = ((WH_K*LH)+(WN_K*LN))+((WH*LH_K)+(WN*LN_K))+((WH*LH*uZH_K)+(WN*LN*uZN_K))-G_K-((PC_K*C)+(PC*C_K))-((PH*chi1H*uZH_K)+(PN*chi1N*uZN_K)); 
A_Q       = ((WH_Q*LH)+(WN_Q*LN))+((WH*LH_Q)+(WN*LN_Q))+((WH*LH*uZH_Q)+(WN*LN*uZN_Q))-G_Q-((PC_Q*C)+(PC*C_Q))-((PH*chi1H*uZH_Q)+(PN*chi1N*uZN_Q));  
A_G       = ((WH_G*LH)+(WN_G*LN))+((WH*LH_G)+(WN*LN_G))+((WH*LH*uZH_G)+(WN*LN*uZN_G))-G_G-((PC_G*C)+(PC*C_G))-((PH*chi1H*uZH_G)+(PN*chi1N*uZN_G));           
L1        = A_K + (A_Q*omega_21); 
L2        = A_K + (A_Q*omega_22);
wA1       = L1*((K0-K) + GammaG_2*(1-ThetaG_2)- GammaG_1*(1-ThetaG_1)); 
wAG2      = A_G*Y_0*(1-ThetaG_prime) + L1*GammaG_1*(1-ThetaG_1prime) - L2*GammaG_2*(1-ThetaG_2prime);  
dA_CD   = (wA1/(r-nu_1)) + (wAG2/(xi+r)); 

% RPj=Rj/Pj=Rj(K,Q,G,Aj,Bj);
RPH_K  = (RK_0/PH_0)*((R_K/RK_0) - (PH_K/PH_0));   
RPH_Q  = (RK_0/PH_0)*((R_Q/RK_0) - (PH_Q/PH_0));   
RPH_G  = (RK_0/PH_0)*((R_G/RK_0) - (PH_G/PH_0));   
                                                   
RPN_K  = (RK_0/PN_0)*((R_K/RK_0) - (PN_K/PN_0));   
RPN_Q  = (RK_0/PN_0)*((R_Q/RK_0) - (PN_Q/PN_0));   
RPN_G  = (RK_0/PN_0)*((R_G/RK_0) - (PN_G/PN_0));      

tildeRPH_K  = RPH_K + (RK_0/PH_0)*uZH_K;   
tildeRPH_Q  = RPH_Q + (RK_0/PH_0)*uZH_Q;   
tildeRPH_G  = RPH_G + (RK_0/PH_0)*uZH_G;   
                                           
tildeRPN_K  = RPN_K + (RK_0/PN_0)*uZN_K;   
tildeRPN_Q  = RPN_Q + (RK_0/PN_0)*uZN_Q;   
tildeRPN_G  = RPN_G + (RK_0/PN_0)*uZN_G;   

% Solutions tildeWj(K,Q,G,Aj,Bj); tildeWj=uZj*Wj; 
tildeWH_K  = WH_K + (WH*uZH_K); 
tildeWH_Q  = WH_Q + (WH*uZH_Q);
tildeWH_G  = WH_G + (WH*uZH_G);

tildeWN_K  = WN_K + (WN*uZN_K);    
tildeWN_Q  = WN_Q + (WN*uZN_Q);    
tildeWN_G  = WN_G + (WN*uZN_G);    

% Solution for tildeW(K,Q,G,Aj,Bj) - tildeW(tildeWH,tildeWN)
tildeW_WH      = (W/WH)*alphaL;                                            
tildeW_WN      = (W/WN)*(1-alphaL);                                        
tildeW_K       = (tildeW_WH*tildeWH_K)  + (tildeW_WN*tildeWN_K);           
tildeW_Q       = (tildeW_WH*tildeWH_Q)  + (tildeW_WN*tildeWN_Q);           
tildeW_G       = (tildeW_WH*tildeWH_G)  + (tildeW_WN*tildeWN_G);            

W_uZH          = W*alphaL;                                   
W_uZN          = W*(1-alphaL);                               
tildeW_K_check = W_K + (W_uZH*uZH_K) + (W_uZN*uZN_K);   
tildeW_Q_check = W_Q + (W_uZH*uZH_Q) + (W_uZN*uZN_Q);   
tildeW_G_check = W_G + (W_uZH*uZH_G) + (W_uZN*uZN_G);   
 
% Solution for L as function L=L(K,Q,G,Aj,Bj) - L=L(tildeWH,tildeWN)
L_W  = sigmaL*(L/W); 
L_WH = sigmaL*L*alphaL/WH; 
L_WN = sigmaL*L*(1-alphaL)/WN; 
L_K  = (L_WH*tildeWH_K)  + (L_WN*tildeWN_K);                            
L_Q  = (L_WH*tildeWH_Q)  + (L_WN*tildeWN_Q);                            
L_G  = (L_WH*tildeWH_G)  + (L_WN*tildeWN_G);                                                      

% Solution for the labor income share sLj=LISj(K,Q,G,Aj,Bj)=Wj*Lj/Pj*Yj       
LISH_K  = sLH_0*( (WH_K/WH_0) + (LH_K/LH_0) - (PH_K/PH_0) - (YH_K/YH_0) );    
LISH_Q  = sLH_0*( (WH_Q/WH_0) + (LH_Q/LH_0) - (PH_Q/PH_0) - (YH_Q/YH_0) );    
LISH_G  = sLH_0*( (WH_G/WH_0) + (LH_G/LH_0) - (PH_G/PH_0) - (YH_G/YH_0) );    
                                                                              
LISN_K  = sLN_0*( (WN_K/WN_0) + (LN_K/LN_0) - (PN_K/PN_0) - (YN_K/YN_0) );    
LISN_Q  = sLN_0*( (WN_Q/WN_0) + (LN_Q/LN_0) - (PN_Q/PN_0) - (YN_Q/YN_0) );    
LISN_G  = sLN_0*( (WN_G/WN_0) + (LN_G/LN_0) - (PN_G/PN_0) - (YN_G/YN_0) );             

% Solution for LH(K,Q,G,Aj,Bj)/LN(K,Q,G,Aj,Bj)                                
LHLN_K = (LH_0/LN_0)*( (LH_K/LH_0) - (LN_K/LN_0) );                           
LHLN_Q = (LH_0/LN_0)*( (LH_Q/LH_0) - (LN_Q/LN_0) );                           
LHLN_G = (LH_0/LN_0)*( (LH_G/LH_0) - (LN_G/LN_0) );                                                 
                                                                              
% Solution for YH(K,Q,G,Aj,Bj)/YN(K,Q,G,Aj,Bj)                                
YHYN_K = (YH_0/YN_0)*( (YH_K/YH_0) - (YN_K/YN_0) );                           
YHYN_Q = (YH_0/YN_0)*( (YH_Q/YH_0) - (YN_Q/YN_0) );                           
YHYN_G = (YH_0/YN_0)*( (YH_G/YH_0) - (YN_G/YN_0) );                                                   
                                                                              
% Solutions for the employment shares Lj/L=(Lj/L)(K,Q,G,Aj,Bj)                
LHS_K  = (LH_0/L_0)*((LH_K/LH_0)-(L_K/L_0));                                  
LHS_Q  = (LH_0/L_0)*((LH_Q/LH_0)-(L_Q/L_0));                                  
LHS_G  = (LH_0/L_0)*((LH_G/LH_0)-(L_G/L_0));                                                               
                                                                              
LNS_K  = (LN_0/L_0)*((LN_K/LN_0)-(L_K/L_0));                                  
LNS_Q  = (LN_0/L_0)*((LN_Q/LN_0)-(L_Q/L_0));                                  
LNS_G  = (LN_0/L_0)*((LN_G/LN_0)-(L_G/L_0));                                                                
                                                                              
% Solutions for the Real Sectoral Output Yj/YR=(Yj/YR)(K,Q,G,Aj,Bj)           
YHS_K  = (YH_0/YR_0)*( (YH_K/YH_0) - (YR_K/YR_0) );                           
YHS_Q  = (YH_0/YR_0)*( (YH_Q/YH_0) - (YR_Q/YR_0) );                           
YHS_G  = (YH_0/YR_0)*( (YH_G/YH_0) - (YR_G/YR_0) );                                                 
                                                                              
YNS_K  = (YN_0/YR_0)*( (YN_K/YN_0) - (YR_K/YR_0) );                           
YNS_Q  = (YN_0/YR_0)*( (YN_Q/YN_0) - (YR_Q/YR_0) );                           
YNS_G  = (YN_0/YR_0)*( (YN_G/YN_0) - (YR_G/YR_0) );                           

% Solutions for the Kj/K: Kj/K=Kj/K(lambda,K,Q,AH,BH,AN,BN) -
% aggregate capital utilization rate uK =(KH/K)*uKH + (KN/K)*uKN
KHK_K  = (KH_0/K_0)*( (KH_K/KH_0) - (1/K_0) );    
KHK_Q  = (KH_0/K_0)*(KH_Q/KH_0)                   
KHK_G  = (KH_0/K_0)*(KH_G/KH_0);                                  
                                                  
KNK_K  = (KN_0/K_0)*( (KN_K/KN_0) - (1/K_0) );    
KNK_Q  = (KN_0/K_0)*(KN_Q/KN_0);                   
KNK_G  = (KN_0/K_0)*(KN_G/KN_0);                     

uK_K   = KHK_K + KNK_K + (KH_0/K_0)*uKH_K + (KN_0/K_0)*uKN_K;      
uK_Q   = KHK_Q + KNK_Q + (KH_0/K_0)*uKH_Q + (KN_0/K_0)*uKN_Q;      
uK_G   = KHK_G + KNK_G + (KH_0/K_0)*uKH_G + (KN_0/K_0)*uKN_G;      

% Solutions tildeZj,tildeZ(K,Q,G,Aj,Bj);
tildeZH_K   = ZH_0*uZH_K;   
tildeZH_Q   = ZH_0*uZH_Q;   
tildeZH_G   = ZH_0*uZH_G;     
                            
tildeZN_K   = ZN_0*uZN_K;   
tildeZN_Q   = ZN_0*uZN_Q;   
tildeZN_G   = ZN_0*uZN_G;   

tildeZ_K    = omegaYH_0*(Z_0/ZH_0)*tildeZH_K  + (1-omegaYH_0)*(Z_0/ZN_0)*tildeZN_K;     
tildeZ_Q    = omegaYH_0*(Z_0/ZH_0)*tildeZH_Q  + (1-omegaYH_0)*(Z_0/ZN_0)*tildeZN_Q;     
tildeZ_G    = omegaYH_0*(Z_0/ZH_0)*tildeZH_G  + (1-omegaYH_0)*(Z_0/ZN_0)*tildeZN_G;       
                                                                              
% Solutions tildeWj,tildeRj,tildeKj,tildeYj(K,Q,G,Aj,Bj); tildeWj=uZj*Wj;
% tildeRj=RK*uZj; tildeKj=uKj*Kj; tildeYj=uZj*Yj; 
tildeWH_K  = WH_K + (WH*uZH_K); 
tildeWH_Q  = WH_Q + (WH*uZH_Q);
tildeWH_G  = WH_G + (WH*uZH_G);

tildeWN_K  = WN_K + (WN*uZN_K);    
tildeWN_Q  = WN_Q + (WN*uZN_Q);    
tildeWN_G  = WN_G + (WN*uZN_G);    
 
tildeWHPC_K  = WHPC_0*( (tildeWH_K/WH_0) - (PC_K/PC_0) );   
tildeWHPC_Q  = WHPC_0*( (tildeWH_Q/WH_0) - (PC_Q/PC_0) );   
tildeWHPC_G  = WHPC_0*( (tildeWH_G/WH_0) - (PC_G/PC_0) );   
                                                            
tildeWNPC_K  = WNPC_0*( (tildeWN_K/WN_0) - (PC_K/PC_0) );   
tildeWNPC_Q  = WNPC_0*( (tildeWN_Q/WN_0) - (PC_Q/PC_0) );   
tildeWNPC_G  = WNPC_0*( (tildeWN_G/WN_0) - (PC_G/PC_0) );         
                                                                           
tildeRH_K  = R_K + (RK*uZH_K);    
tildeRH_Q  = R_Q + (RK*uZH_Q);    
tildeRH_G  = R_G + (RK*uZH_G);     
                                  
tildeRN_K  = R_K + (RK*uZN_K);    
tildeRN_Q  = R_Q + (RK*uZN_Q);    
tildeRN_G  = R_G + (RK*uZN_G);     

tildeKH_K  = KH_K + (KH*uKH_K);   
tildeKH_Q  = KH_Q + (KH*uKH_Q);   
tildeKH_G  = KH_G + (KH*uKH_G);   
                                  
tildeKN_K  = KN_K + (KN*uKN_K);   
tildeKN_Q  = KN_Q + (KN*uKN_Q);   
tildeKN_G  = KN_G + (KN*uKN_G);     

tildekH_K  = kH*( (tildeKH_K/KH) - (LH_K/LH) );   
tildekH_Q  = kH*( (tildeKH_Q/KH) - (LH_Q/LH) );   
tildekH_G  = kH*( (tildeKH_G/KH) - (LH_G/LH) );   
                                                  
tildekN_K  = kN*( (tildeKN_K/KN) - (LN_K/LN) );   
tildekN_Q  = kN*( (tildeKN_Q/KN) - (LN_Q/LN) );   
tildekN_G  = kN*( (tildeKN_G/KN) - (LN_G/LN) );   

tildeYH_K  = YH_K + (YH*uZH_K);    
tildeYH_Q  = YH_Q + (YH*uZH_Q);    
tildeYH_G  = YH_G + (YH*uZH_G);     
                                   
tildeYN_K  = YN_K + (YN*uZN_K);     
tildeYN_Q  = YN_Q + (YN*uZN_Q);     
tildeYN_G  = YN_G + (YN*uZN_G);       

tildeYR_K   = YR_K + (PH_0*YH*uZH_K) + (PN_0*YN*uZN_K);       
tildeYR_Q   = YR_Q + (PH_0*YH*uZH_Q) + (PN_0*YN*uZN_Q);       
tildeYR_G   = YR_G + (PH_0*YH*uZH_G) + (PN_0*YN*uZN_G);       

tildeK_K  = 1 + (K*uK_K);   
tildeK_Q  = (K*uK_Q);       
tildeK_G  = (K*uK_G);           

tildeWPC_K  = WPC_0*( (tildeW_K/W_0) - (PC_K/PC_0) );
tildeWPC_Q  = WPC_0*( (tildeW_Q/W_0) - (PC_Q/PC_0) );
tildeWPC_G  = WPC_0*( (tildeW_G/W_0) - (PC_G/PC_0) );  

tildeOmega_K  = Omega_0*( (tildeWN_K/WN_0) - (tildeWH_K/WH_0) );     
tildeOmega_Q  = Omega_0*( (tildeWN_Q/WN_0) - (tildeWH_Q/WH_0) );     
tildeOmega_G  = Omega_0*( (tildeWN_G/WN_0) - (tildeWH_G/WH_0) );     

% Solution for tildeWH/wtildeW = tildeWj(K,Q,G,Aj,Bj)/tildeW(K,Q,G,Aj,Bj)  
tildeWHW_K = (WH_0/W_0)*( (tildeWH_K/WH_0) - (tildeW_K/W_0) );             
tildeWHW_Q = (WH_0/W_0)*( (tildeWH_Q/WH_0) - (tildeW_Q/W_0) );             
tildeWHW_G = (WH_0/W_0)*( (tildeWH_G/WH_0) - (tildeW_G/W_0) );                      
                                                                           
tildeWNW_K = (WN_0/W_0)*( (tildeWN_K/WN_0) - (tildeW_K/W_0) );             
tildeWNW_Q = (WN_0/W_0)*( (tildeWN_Q/WN_0) - (tildeW_Q/W_0) );             
tildeWNW_G = (WN_0/W_0)*( (tildeWN_G/WN_0) - (tildeW_G/W_0) );             

% Solutions for the tildeKj/tildeK,tildeR(lambda,K,Q,AH,BH,AN,BN) - tildeK = uK*K; tildeKj = uKj*Kj        
tildeKHK_K  = (KH_0/K_0)*( (tildeKH_K/KH_0) - (tildeK_K/K_0) );      
tildeKHK_Q  = (KH_0/K_0)*( (tildeKH_Q/KH_0) - (tildeK_Q/K_0) );      
tildeKHK_G  = (KH_0/K_0)*( (tildeKH_G/KH_0) - (tildeK_G/K_0) );       
                                                                     
tildeKNK_K  = (KN_0/K_0)*( (tildeKN_K/KN_0) - (tildeK_K/K_0) );      
tildeKNK_Q  = (KN_0/K_0)*( (tildeKN_Q/KN_0) - (tildeK_Q/K_0) );      
tildeKNK_G  = (KN_0/K_0)*( (tildeKN_G/KN_0) - (tildeK_G/K_0) );      

tildeR_K     = (RK*tildeKHK_K) + (KH_0/K_0)*tildeRH_K + (RK*tildeKNK_K) + (KN_0/K_0)*tildeRN_K;     
tildeR_Q     = (RK*tildeKHK_Q) + (KH_0/K_0)*tildeRH_Q + (RK*tildeKNK_Q) + (KN_0/K_0)*tildeRN_Q;     
tildeR_G     = (RK*tildeKHK_G) + (KH_0/K_0)*tildeRH_G + (RK*tildeKNK_G) + (KN_0/K_0)*tildeRN_G;     

% Solution for tildeYH(K,Q,G,Aj,Bj)/tildeYN(K,Q,G,Aj,Bj); 
% Solutions for the Real Sectoral Output tildeYj/tildeYR=(tildeYj/tildeYR)(K,Q,G,Aj,Bj)                           
tildeYHYN_K = (YH_0/YN_0)*( (tildeYH_K/YH_0) - (tildeYN_K/YN_0) );      
tildeYHYN_Q = (YH_0/YN_0)*( (tildeYH_Q/YH_0) - (tildeYN_Q/YN_0) );      
tildeYHYN_G = (YH_0/YN_0)*( (tildeYH_G/YH_0) - (tildeYN_G/YN_0) );      
                                                                            
tildeYHS_K  = (YH_0/YR_0)*( (tildeYH_K/YH_0) - (tildeYR_K/YR_0) );      
tildeYHS_Q  = (YH_0/YR_0)*( (tildeYH_Q/YH_0) - (tildeYR_Q/YR_0) );      
tildeYHS_G  = (YH_0/YR_0)*( (tildeYH_G/YH_0) - (tildeYR_G/YR_0) );        
                                                                        
tildeYNS_K  = (YN_0/YR_0)*( (tildeYN_K/YN_0) - (tildeYR_K/YR_0) );      
tildeYNS_Q  = (YN_0/YR_0)*( (tildeYN_Q/YN_0) - (tildeYR_Q/YR_0) );      
tildeYNS_G  = (YN_0/YR_0)*( (tildeYN_G/YN_0) - (tildeYR_G/YR_0) );      

% Solutions TFPj(K,Q,G,Aj,Bj);                                                     
TFPH_K      = (ZH_0/YH_0)*tildeYH_K - thetaH*(ZH_0/LH_0)*LH_K - (1-thetaH)*(ZH_0/KH_0)*KH_K;
TFPH_Q      = (ZH_0/YH_0)*tildeYH_Q - thetaH*(ZH_0/LH_0)*LH_Q - (1-thetaH)*(ZH_0/KH_0)*KH_Q;
TFPH_G      = (ZH_0/YH_0)*tildeYH_G - thetaH*(ZH_0/LH_0)*LH_G - (1-thetaH)*(ZH_0/KH_0)*KH_G;

TFPN_K      = (ZN_0/YN_0)*tildeYN_K - thetaN*(ZN_0/LN_0)*LN_K - (1-thetaN)*(ZN_0/KN_0)*KN_K;
TFPN_Q      = (ZN_0/YN_0)*tildeYN_Q - thetaN*(ZN_0/LN_0)*LN_Q - (1-thetaN)*(ZN_0/KN_0)*KN_Q;
TFPN_G      = (ZN_0/YN_0)*tildeYN_G - thetaN*(ZN_0/LN_0)*LN_G - (1-thetaN)*(ZN_0/KN_0)*KN_G;

TFP_K      =  omegaYH_0*(Z_0/ZH_0)*TFPH_K + (1-omegaYH_0)*(Z_0/ZN_0)*TFPN_K;
TFP_Q      =  omegaYH_0*(Z_0/ZH_0)*TFPH_Q + (1-omegaYH_0)*(Z_0/ZN_0)*TFPN_Q;
TFP_G      =  omegaYH_0*(Z_0/ZH_0)*TFPH_G + (1-omegaYH_0)*(Z_0/ZN_0)*TFPN_G;

TFPH_K_check      = ZH_0*uZH_K + (1-sLH_0)*ZH_0*uKH_K;
TFPH_Q_check      = ZH_0*uZH_Q + (1-sLH_0)*ZH_0*uKH_Q;
TFPH_G_check      = ZH_0*uZH_G + (1-sLH_0)*ZH_0*uKH_G;

TFPN_K_check      =  ZN_0*uZN_K + (1-sLN_0)*ZN_0*uKN_K;
TFPN_Q_check      =  ZN_0*uZN_Q + (1-sLN_0)*ZN_0*uKN_Q;
TFPN_G_check      =  ZN_0*uZN_G + (1-sLN_0)*ZN_0*uKN_G;

% Solutions for the relative return on capiral Rj/Pj(K,Q,G,Aj,Bj) -     
wRPH_1  = RPH_K + (RPH_Q*omega_21);                 
wRPH_2  = RPH_K + (RPH_Q*omega_22);                 
wRPN_1  = RPN_K + (RPN_Q*omega_21);                 
wRPN_2  = RPN_K + (RPN_Q*omega_22);                 
                                                    
wtildeRPH_1  = tildeRPH_K + (tildeRPH_Q*omega_21);  
wtildeRPH_2  = tildeRPH_K + (tildeRPH_Q*omega_22);  
wtildeRPN_1  = tildeRPN_K + (tildeRPN_Q*omega_21);  
wtildeRPN_2  = tildeRPN_K + (tildeRPN_Q*omega_22);  

% Relative TFP 
TFPR_K  = (TFPH_0/TFPN_0)*( (TFPH_K/TFPH_0) - (TFPN_K/TFPN_0) );
TFPR_Q  = (TFPH_0/TFPN_0)*( (TFPH_Q/TFPH_0) - (TFPN_Q/TFPN_0) );
TFPR_G  = (TFPH_0/TFPN_0)*( (TFPH_G/TFPH_0) - (TFPN_G/TFPN_0) );

uZR_K  = uZH_K - uZN_K;
uZR_Q  = uZH_Q - uZN_Q;
uZR_G  = uZH_G - uZN_G; 

% Aggregate capital labor ratio k = K/L 
k_K  = k_0*( (1/K_0) - (L_K/L_0) ); 
k_Q  = -k_0*(L_Q/L_0); 
k_G  = -k_0*(L_G/L_0); 

% Aggregate LIS
LIS_K  = sL_0*( (W_K/W_0) + (L_K/L_0)  - (Y_K/Y_0) );     
LIS_Q  = sL_0*( (W_Q/W_0) + (L_Q/L_0)  - (Y_Q/Y_0) );     
LIS_G  = sL_0*( (W_G/W_0) + (L_G/L_0)  - (Y_G/Y_0) );     

% Output share of non-tradables at current prices
tildeY_K   = Y_K + (PH_0*YH_0*uZH_K) + (PN_0*YN_0*uZN_K);    
tildeY_Q   = Y_Q + (PH_0*YH_0*uZH_Q) + (PN_0*YN_0*uZN_Q);    
tildeY_G   = Y_G + (PH_0*YH_0*uZH_G) + (PN_0*YN_0*uZN_G);    

omegaYN_K  = omegaYN_0*( (PN_K/PN_0) + (tildeYN_K/YN_0) - (tildeY_K/Y_0) );      
omegaYN_Q  = omegaYN_0*( (PN_Q/PN_0) + (tildeYN_Q/YN_0) - (tildeY_Q/Y_0) );      
omegaYN_G  = omegaYN_0*( (PN_G/PN_0) + (tildeYN_G/YN_0) - (tildeY_G/Y_0) );  

% Aggregate LIS
LIS_K  = sL_0*( (tildeW_K/W_0) + (L_K/L_0)  - (tildeY_K/Y_0) );     
LIS_Q  = sL_0*( (tildeW_Q/W_0) + (L_Q/L_0)  - (tildeY_Q/Y_0) );     
LIS_G  = sL_0*( (tildeW_G/W_0) + (L_G/L_0)  - (tildeY_G/Y_0) );     
                                                     
% Consumption 
CT       = C*varphi*((PT/PC)^(-phi));
C_check  = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1)); 
CT_check = ( (varphiH^(1/rho))*(CH^((rho-1)/rho)) + ((1-varphiH)^(1/rho))*(CF^((rho-1)/rho)) )^(rho/(rho-1));
omegaCH  = (PH*CH)/(PC*C); 
omegaCF  = (CF)/(PC*C);

% L_H, L_N and FOC for LH and LN 
Vut     = ( (vartheta^(-1/epsilon))*(LH^((epsilon+1)/epsilon)) + ((1-vartheta)^(-1/epsilon))*(LN^((epsilon+1)/epsilon)) ); 
L_check = Vut^(epsilon/(epsilon+1)); 
L_H     = ((vartheta)^(-1/epsilon))*(LH/L)^(1/epsilon); 
L_N     = ((1-vartheta)^(-1/epsilon))*(LN/L)^(1/epsilon);

% Investment 
I        = deltaK*K; 
IT       = deltaK*K*iota*((PIT/PI)^(-phiI));
I_check  = ( (iota^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-iota)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1)); 
IT_check = ( (iotaH^(1/rhoI))*(IH^((rhoI-1)/rhoI)) + ((1-iotaH)^(1/rhoI))*(IF^((rhoI-1)/rhoI)) )^(rhoI/(rhoI-1));  
I        = deltaK*K; 
EI       = PI*I; 
EIT      = (PH*IH) + IF; 
omegaI   = PI*I/Y;
omegaIH  = (PH*IH)/(PI*I);
omegaIF  = (IF)/(PI*I);

% Net exports, current account and saving
NX  = (PH*XH) - MF; 
CA  = (r*B) + (PH*XH) - MF; 
A   = B + (PI*K); 
Tax = G; 
Sav = (r*A) + (W*L) - (PC*C) - Tax; 

% Real Aggregate Wage 
WPC  = W/PC;
WHPC = WH/PC;
WNPC = WN/PC;

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WH); 
YHYN  = (YH/YN); 
LHLN  = (LH/LN);
                                                                         
% Sectoral ratios
omegaINYN = IN/YN; 
omegaIHYH = IH /YH; 
omegaIFYH = IF/YH;
omegaGHYH = GH / YH;
omegaGFYH = GF / (PH*YH);
omegaGNYN = GN / YN;
omegaGN   = (PN*GN) / G;
omegaYH   = (PH*YH) / Y;
omegaYN   = (PN*YN) /Y; 
omegaLH   = LH / L;
omegaLN   = LN / L;

% Targeted ratios
omegaC    = (PC*C) / Y;
omegaNX   =  NX / Y; 
omegaG    = (GH+PN*GN)/Y;
omegaB    = (r*B)/Y; 
omegaKY   = K/Y; 

% Confirmation
% Check the closure of the model
cond1  = PH*(1-thetaH)*(YH/KH)-RK;                               
cond2  = PN*(1-thetaN)*(YN/KN)-RK;                             
cond3  = PH*thetaH*(YH/LH)-WH;                                   
cond4  = PN*thetaN*(YN/LN)-WN;                              
cond5  = (LH*kH)+(LN*kN)-K;                                   
cond6  = RK-(deltaK+r)*PI;                                    
cond7  = YN-CN-GN-IN;                                         
cond8  = YH-CH-GH-IH-XH;                                   
cond9  = (B-B0) - ( (wB1/(r-nu_1)) + (wBG2/(xi+r)) );    
cond10  = DetJ - (nu_1*nu_2);                                   
cond11 = TrJ - (nu_1+nu_2);                                     
cond12 = (LH/LN) - (vartheta/(1-vartheta))*Omega^(-epsilon);  
cond13 = (CT/CN) - (varphi/(1-varphi))*(PN/PT)^(phi);               
cond14 = (PC*C) - ((PT*CT)+(PN*CN));                                
cond15 = (W*L) - ((WH*LH)+(WN*LN));                           
cond16 = gammaL*(L^(1/sigmaL))*L_H - (lambda*WH);               
cond17 = gammaL*(L^(1/sigmaL))*L_N - (lambda*WN);               
cond18 = Y - (PC*C) - G - (PI*I) + (r*B);                     
cond19 = Sav;                                                 
cond20 = (PC*C) - (CF+(PH*CH)+(PN*CN));                                
cond21 = (IT/IN) - (iota/(1-iota))*(PN/PIT)^(phiI);            
cond22 = (PI*I) - ((PIT*IT)+(PN*IN));                                
cond23 = (RK*K) - ((RKH*KH)+(RKN*KN));                        
cond24 = 1 - (omegaK + omegaL);    
cond25 = (CH/CF) - (varphiH/(1-varphiH))*(PH)^(-rho);    
cond26 = (PT*CT) - ((PH*CH)+CF); 
cond27 = (IH/IF) - (iotaH/(1-iotaH))*(PH)^(-rhoI);    
cond28 = (PIT*IT) - ((PH*IH)+IF); 
cond29 = r*B + (PH*XH) - MF; 
cond30 = r*B + (RK*K) + (W*L) - G - (PC*C) - (PI*I); 
 
% Define New steady-state values
kH_CD = kH; kN_CD = kN; PN_CD = PN; LH_CD = LH; K_CD = K; C_CD = C;  
LN_CD = LN; L_CD  = L; W_CD = W; P_CD = P; 
YH_CD = YH; YN_CD = YN; Y_CD = Y; KH_CD  = KH; KN_CD  = KN; G_CD = G;     
PC_CD = PC; alphaC_CD = alphaC; CN_CD = CN; CH_CD = CH;  
GH_CD = GH; GN_CD = GN; ZH_CD = ZH; ZN_CD = ZN; Z_CD = Z; 
AH_CD = AH; BH_CD = BH; AN_CD = AN; BN_CD = BN; 
LH_CD = LH; LN_CD = LN; KH_CD = KH; KN_CD = KN; WH_CD = WH; WN_CD = WN; 
Omega_CD = Omega; WPC_CD = WPC; WHPC_CD = WHPC; WNPC_CD = WNPC;
IF_CD = IF; CF_CD = CF; XH_CD = XH; MF_CD = MF; GF_CD = GF; PH_CD = PH; 
PT_CD = PT; PIT_CD = PIT; CT_CD = CT; IT_CD = IT; GT_CD = GT; 

YHYN_CD = YHYN; LHLN_CD = LHLN; IH_CD = IH; IN_CD = IN; PI_CD = PI; 
EI_CD = EI; CA_CD = CA; Sav_CD = Sav; NX_CD = NX; I_CD = I; A_CD = A; 
B_CD = B; lambda_CD  = lambda; RK_CD = RK; YR_CD = YR; 
yH_CD = yH; yN_CD = yN; 

omegaL_CD = omegaL; omegaK_CD = omegaK; omegaI_CD = omegaI; omegaINYN_CD = omegaINYN;
omegaIHYH_CD = omegaIHYH; omega_IFYH_CD = omegaIFYH; omegaGHYH_CD = omegaGHYH; 
omegaGFYH_CD = omegaGFYH; omegaGNYN_CD = omegaGNYN; omegaGN_CD = omegaGN;
omegaYH_CD = omegaYH; omegaYN_CD = omegaYN; omegaLH_CD = omegaLH; omegaLN_CD = omegaLN; 
omegaC_CD =omegaC; omegaNX_CD =omegaNX; omegaG_CD =omegaG; omegaB_CD =omegaB; 
omegaKY_CD = omegaKY; omegaIH_CD = omegaIH; omegaIF_CD = omegaIF; 
omegaGT_CD = omegaGT; omegaGH_CD = omegaGH; omegaGF_CD = omegaGF;
alphaL_CD = alphaL; alphaK_CD = alphaK; alphaC_CD = alphaC; 
alphaI_CD = alphaI; alphaH_CD = alphaH; alphaIH_CD = alphaIH;
omegaYHR_CD = omegaYHR; omegaYNR_CD = omegaYNR;
sLH_CD = sLH; sLN_CD = sLN; TFPH_CD = TFPH; TFPN_CD = TFPN; 
TFP_CD = TFP; sL_CD = sL; k_CD = k; 

% Steady-State Changes
dC       = C_CD - C_0; % Steady-state change of real consumption 
dK       = K_CD - K_0; % Steady-state change of real capital 
dL       = L_CD - L_0; % Steady-state change of employment 
dPN      = PN_CD - PN_0; % Steady-state change of non traded good prices
dPH      = PH_CD - PH_0; % Steady-state change of terms of trade (price of exports in terms if imports)
dP       = P_CD - P_0; % Steady-state change of non traded goods prices relative to tradable home goods prices
dB       = B_CD - B_0; % Steady-state change of traded bonds holding 
dlambda  = lambda_CD - lambda_0; % Steady-state change of marginal utility of wealth 
dY       = Y_CD - Y_0; % Steady-state change of GDP 
dYR      = YR_CD - Y_0; % Steady-state change of real GDP 
dA       = A_CD - A_0; % Steady-state change of financial wealth 
dW       = W_CD - W_0; % Steady-state change of the wage rate 
dWPC     = WPC_CD - WPC_0; % Steady-state change of the real aggregate wage W/PC 
dOmega   = Omega_CD - Omega_0; % Steady-state change of the sector wage ratio

dCH   = CH_CD - CH_0; % Steady-state change of CH
dCN   = CN_CD - CN_0; % Steady-state change of CN
dLH   = LH_CD - LH_0; % Steady-state change of real capital 
dLN   = LN_CD - LN_0; % Steady-state change of employment 
dKH   = KH_CD - KH_0; % Steady-state change of real capital 
dKN   = KN_CD - KN_0; % Steady-state change of employment 
dYH   = YH_CD - YH_0; % Steady-state change of YH
dYN   = YN_CD - YN_0; % Steady-state change of YN
dWH   = WH_CD - WH_0; % Steady-state change of WH
dWN   = WN_CD - WN_0; % Steady-state change of WN
dWHPC = WHPC_CD - WHPC_0; % Steady-state change of WH/PC
dWNPC = WNPC_CD - WNPC_0; % Steady-state change of WN/PC
dkH   = kH_CD - kH_0; % Steady-state change of kH 
dkN   = kN_CD - kN_0; % Steady-state change of kN
dLHLN = LHLN_CD - LHLN_0; % Steady-state change of LH/LN
dYHYN = YHYN_CD - YHYN_0; % Steady-state change of LH/LN
dsLH  = sLH_CD - sLH_0; % Steady-state change of labor income share in the home traded good sector
dsLN  = sLN_CD - sLN_0; % Steady-state change of labor income share in the non traded good sector

dGH   = GH_CD - GH_0; 
dGN   = GN_CD - GN_0; 
dGF   = GF_CD - GF_0; 
dG    = G_CD - G_0;
dTFPH = TFPH_CD - TFPH_0; 
dTFPN = TFPN_CD - TFPN_0; 
dTFP  = TFP_CD - TFP_0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Solution for investment PI*K, 
EK1   = PI + (K*omega_21); % Q(t)*K(t) - Q*K = EK1*X1(t) + EK2*X2(t)
EK2   = PI + (K*omega_22);
 
% Solution for the Relative Price of Non tradables P=P(K,Q,G,Aj,Bj)
wP_1   = P_K + (P_Q*omega_21); 
wP_2   = P_K + (P_Q*omega_22); 

% Solution for the Price of Non tradables PN=PN(K,Q,G,Aj,Bj);                                
wPN_1  =  PN_K + (PN_Q*omega_21);                                                                    
wPN_2  =  PN_K + (PN_Q*omega_22);  

% Solution for the TOT PH=PH(K,Q,G,Aj,Bj)
wPH_1  = PH_K + (PH_Q*omega_21); 
wPH_2  = PH_K + (PH_Q*omega_22);
                                                                                                  
% Solution for the Consumption Price index PC=PC(K,Q,G,Aj,Bj)                                         
wPC_1  =  PC_K + (PC_Q*omega_21);                                                                     
wPC_2  =  PC_K + (PC_Q*omega_22); 

% Solution for the Investment Price index PI=PI(K,Q,G,Aj,Bj)                                          
wPI_1  =  PI_K + (PI_Q*omega_21);                                                                     
wPI_2  =  PI_K + (PI_Q*omega_22); 

% Solution for capital and technology utilization rates uKj,uZj(K,Q,G,Aj,Bj)
wuKH_1  =  uKH_K + (uKH_Q*omega_21);
wuKH_2  =  uKH_K + (uKH_Q*omega_22);
wuKN_1  =  uKN_K + (uKN_Q*omega_21);
wuKN_2  =  uKN_K + (uKN_Q*omega_22);

wuK_1   =  uK_K + (uK_Q*omega_21);  
wuK_2   =  uK_K + (uK_Q*omega_22);  

wuZH_1  =  uZH_K + (uZH_Q*omega_21);
wuZH_2  =  uZH_K + (uZH_Q*omega_22);
wuZN_1  =  uZN_K + (uZN_Q*omega_21);
wuZN_2  =  uZN_K + (uZN_Q*omega_22);
                                                                                                                                                                                                                                                                                                                  
% Solution for Q(t)/PI(P(t))                                                                           
wQPI_1  = (omega_21/PI_0) - (wPI_1/PI_0);                                                                  
wQPI_2  = (omega_22/PI_0) - (wPI_2/PI_0); 
wQPI_G  = - (PI_G/PI_0);
                                                                                                    
% Solution for Consumption C=C(K,Q,G,Aj,Bj)                                                               
wC_1   = C_K + (C_Q*omega_21);                                                                          
wC_2   = C_K + (C_Q*omega_22);                                                           
                                                                                                       
% Solution for the Aggregate Wage Index W=W(K,Q,G,Aj,Bj)                                           
wW_1  =  W_K + (W_Q*omega_21);                                                                         
wW_2  =  W_K + (W_Q*omega_22);   

wtildeW_1  =  tildeW_K + (tildeW_Q*omega_21);                                                                         
wtildeW_2  =  tildeW_K + (tildeW_Q*omega_22);
                                                                                                       
% Solution for the Capital Rental Rate RK=R(K,Q,G,Aj,Bj)                                           
wR_1  =  R_K + (R_Q*omega_21);                                                                         
wR_2  =  R_K + (R_Q*omega_22);         

wtildeRH_1  =  tildeRH_K + (tildeRH_Q*omega_21);                                                                         
wtildeRH_2  =  tildeRH_K + (tildeRH_Q*omega_22);
wtildeRN_1  =  tildeRN_K + (tildeRN_Q*omega_21);                                                                         
wtildeRN_2  =  tildeRN_K + (tildeRN_Q*omega_22);

wtildeR_1  =  tildeR_K + (tildeR_Q*omega_21);                                                                         
wtildeR_2  =  tildeR_K + (tildeR_Q*omega_22);
                                                                                                       
% Solution for the Real Consumption Wage W(K,Q,G,Aj,Bj)/PC(P)                                      
wWPC_1  = WPC_K + (WPC_Q*omega_21);                                                               
wWPC_2  = WPC_K + (WPC_Q*omega_22);  

wtildeWPC_1  = tildeWPC_K + (tildeWPC_Q*omega_21);     
wtildeWPC_2  = tildeWPC_K + (tildeWPC_Q*omega_22);    
                                                                                                         
% Solution for Labor L=L(lambda,W)=L(K,Q,G,Aj,Bj)                                                     
wL_1  =  L_K + (L_Q*omega_21);                                                                         
wL_2  =  L_K + (L_Q*omega_22);      
                                                                                                     
% Solutions for the Sectoral Labor kj,K(K,Q,G,Aj,Bj)                                                 
wkH_1  =  kH_K + (kH_Q*omega_21);                                                                     
wkH_2  =  kH_K + (kH_Q*omega_22);                                                                                                                                                             
wkN_1  =  kN_K + (kN_Q*omega_21);                                                                     
wkN_2  =  kN_K + (kN_Q*omega_22);  

wtildekH_1  =  tildekH_K + (tildekH_Q*omega_21);  
wtildekH_2  =  tildekH_K + (tildekH_Q*omega_22);                                             
wtildekN_1  =  tildekN_K + (tildekN_Q*omega_21);  
wtildekN_2  =  tildekN_K + (tildekN_Q*omega_22);  

wtildeK_1  =  tildeK_K + (tildeK_Q*omega_21);                                                                     
wtildeK_2  =  tildeK_K + (tildeK_Q*omega_22);
                                                                                                       
% Solutions for the Sectoral Labor Lj=Lj(K,Q,G,Aj,Bj)                                                 
wLH_1  =  LH_K + (LH_Q*omega_21);                                                                     
wLH_2  =  LH_K + (LH_Q*omega_22);                                                     
                                                                                                       
wLN_1  =  LN_K + (LN_Q*omega_21);                                                                     
wLN_2  =  LN_K + (LN_Q*omega_22);                                                     
                                                                                                       
% Solution for Real GDP YR=YR(K,Q,G,Aj,Bj)                                                                                                                                                                                                                              
wYR_1  = YR_K + (YR_Q*omega_21);                            
wYR_2  = YR_K + (YR_Q*omega_22);

wtildeYR_1  = tildeYR_K + (tildeYR_Q*omega_21);                            
wtildeYR_2  = tildeYR_K + (tildeYR_Q*omega_22);

% Solutions for the Sectoral Output Yj=Yj(K,Q,G,Aj,Bj)                                                
wYH_1  = YH_K + (YH_Q*omega_21);                                                                      
wYH_2  = YH_K + (YH_Q*omega_22);                                                                                                                                                        
wYN_1  = YN_K + (YN_Q*omega_21);                                                                      
wYN_2  = YN_K + (YN_Q*omega_22);

wtildeYH_1  = tildeYH_K + (tildeYH_Q*omega_21);
wtildeYH_2  = tildeYH_K + (tildeYH_Q*omega_22);                                            
wtildeYN_1  = tildeYN_K + (tildeYN_Q*omega_21);
wtildeYN_2  = tildeYN_K + (tildeYN_Q*omega_22);

% Solutions for YH/YN,LH/LN,tildeYH/tildeYN(K,Q,G,Aj,Bj)
wYHYN_1  = YHYN_K + (YHYN_Q*omega_21);                                                                      
wYHYN_2  = YHYN_K + (YHYN_Q*omega_22);                                                                                                                                                       
wLHLN_1  = LHLN_K + (LHLN_Q*omega_21);                                                                      
wLHLN_2  = LHLN_K + (LHLN_Q*omega_22);

wtildeYHYN_1  = tildeYHYN_K + (tildeYHYN_Q*omega_21);                                                                      
wtildeYHYN_2  = tildeYHYN_K + (tildeYHYN_Q*omega_22); 

% Solutions for the Sectoral Wages Wj=Wj(K,Q,G,Aj,Bj)                                              
wWH_1  = WH_K + (WH_Q*omega_21);                                                                      
wWH_2  = WH_K + (WH_Q*omega_22);  
wWN_1  = WN_K + (WN_Q*omega_21);                                                                      
wWN_2  = WN_K + (WN_Q*omega_22);

wtildeWH_1  = tildeWH_K + (tildeWH_Q*omega_21);
wtildeWH_2  = tildeWH_K + (tildeWH_Q*omega_22);
wtildeWN_1  = tildeWN_K + (tildeWN_Q*omega_21);
wtildeWN_2  = tildeWN_K + (tildeWN_Q*omega_22);

% Solutions for the Real Sectoral Wages Wj(K,Q,G,Aj,Bj)/PC(K,Q,G,Aj,Bj)     
wWHPC_1  = WHPC_K + (WHPC_Q*omega_21);                 
wWHPC_2  = WHPC_K + (WHPC_Q*omega_22);                 
wWNPC_1  = WNPC_K + (WNPC_Q*omega_21);                 
wWNPC_2  = WNPC_K + (WNPC_Q*omega_22);                 
                                                       
wtildeWHPC_1  = tildeWHPC_K + (tildeWHPC_Q*omega_21);  
wtildeWHPC_2  = tildeWHPC_K + (tildeWHPC_Q*omega_22);  
wtildeWNPC_1  = tildeWNPC_K + (tildeWNPC_Q*omega_21);  
wtildeWNPC_2  = tildeWNPC_K + (tildeWNPC_Q*omega_22);       

% Solutions for the relative wages Wj/W: WjW=WjW(K,Q,G,Aj,Bj) -     
% Solution for Omega = WN(K,Q,G,Aj,Bj)/WH(K,Q,G,Aj,Bj) 
wWHW_1  = WHW_K + (WHW_Q*omega_21);                
wWHW_2  = WHW_K + (WHW_Q*omega_22);                
wWNW_1  = WNW_K + (WNW_Q*omega_21);                
wWNW_2  = WNW_K + (WNW_Q*omega_22);                
                                                   
wtildeWHW_1  = tildeWHW_K + (tildeWHW_Q*omega_21); 
wtildeWHW_2  = tildeWHW_K + (tildeWHW_Q*omega_22); 
wtildeWNW_1  = tildeWNW_K + (tildeWNW_Q*omega_21); 
wtildeWNW_2  = tildeWNW_K + (tildeWNW_Q*omega_22);                        
                                                                                             
wOmega_1  =  Omega_K + (Omega_Q*omega_21);                       
wOmega_2  =  Omega_K + (Omega_Q*omega_22);     

wtildeOmega_1  =  tildeOmega_K + (tildeOmega_Q*omega_21);  
wtildeOmega_2  =  tildeOmega_K + (tildeOmega_Q*omega_22);  
                                                                                                                                               
% Solution for YH(K,Q,G,Aj,Bj)/YN(K,Q,G,Aj,Bj), Solution for LH(K,Q,G,Aj,Bj)/LN(K,Q,G,Aj,Bj)                               
% Solutions for the Real Sectoral Output Yj/YR=(Yj/YR)(K,Q,G,Aj,Bj)          
% Solutions for the employment shares Lj/L=(Lj/L)(K,Q,G,Aj,Bj)               
% Solutions for the employment shares sLj=LISj(K,Q,G,Aj,Bj) -  

wLHLN_1  = LHLN_K + (LHLN_Q*omega_21);
wLHLN_2  = LHLN_K + (LHLN_Q*omega_22);
wYHYN_1  = YHYN_K + (YHYN_Q*omega_21);
wYHYN_2  = YHYN_K + (YHYN_Q*omega_22);
                                      
wLHS_1  = LHS_K + (LHS_Q*omega_21);   
wLHS_2  = LHS_K + (LHS_Q*omega_22);   
wLNS_1  = LNS_K + (LNS_Q*omega_21);   
wLNS_2  = LNS_K + (LNS_Q*omega_22);   
                                      
wYHS_1  = YHS_K + (YHS_Q*omega_21);   
wYHS_2  = YHS_K + (YHS_Q*omega_22);   
wYNS_1  = YNS_K + (YNS_Q*omega_21);   
wYNS_2  = YNS_K + (YNS_Q*omega_22);   

wtildeYHS_1  = tildeYHS_K + (tildeYHS_Q*omega_21); 
wtildeYHS_2  = tildeYHS_K + (tildeYHS_Q*omega_22); 
wtildeYNS_1  = tildeYNS_K + (tildeYNS_Q*omega_21); 
wtildeYNS_2  = tildeYNS_K + (tildeYNS_Q*omega_22); 

% sLj = Wj*Lj/(Pj*Yj) -                                                                                
wLISH_1  = LISH_K + (LISH_Q*omega_21);                                    
wLISH_2  = LISH_K + (LISH_Q*omega_22);                                                                                                                                                                
wLISN_1  = LISN_K + (LISN_Q*omega_21); 
wLISN_2  = LISN_K + (LISN_Q*omega_22);                                                      
                                                                                                 
% Solutions for the Kj/K: Kj/K=Kj/K(lambda,K,Q,AH,BH,AN,BN) -                                    
wKHK_1  = KHK_K + (KHK_Q*omega_21);  
wKHK_2  = KHK_K + (KHK_Q*omega_22);  
wKNK_1  = KNK_K + (KNK_Q*omega_21);  
wKNK_2  = KNK_K + (KNK_Q*omega_22); 

wtildeKHK_1  = tildeKHK_K + (tildeKHK_Q*omega_21);  
wtildeKHK_2  = tildeKHK_K + (tildeKHK_Q*omega_22);  
wtildeKNK_1  = tildeKNK_K + (tildeKNK_Q*omega_21);  
wtildeKNK_2  = tildeKNK_K + (tildeKNK_Q*omega_22);  

% Solutions for tildeZj,tildeZ(lambda,K,Q,AH,BH,AN,BN) -
wtildeZH_1  = tildeZH_K + (tildeZH_Q*omega_21);   
wtildeZH_2  = tildeZH_K + (tildeZH_Q*omega_22);                                                     
wtildeZN_1  = tildeZN_K + (tildeZN_Q*omega_21);   
wtildeZN_2  = tildeZN_K + (tildeZN_Q*omega_22);

wtildeZ_1   = tildeZ_K + (tildeZ_Q*omega_21); 
wtildeZ_2   = tildeZ_K + (tildeZ_Q*omega_22); 

% Solutions for TFPj,TFP(lambda,K,Q,AH,BH,AN,BN) -
wTFPH_1  = TFPH_K + (TFPH_Q*omega_21);
wTFPH_2  = TFPH_K + (TFPH_Q*omega_22);
wTFPN_1  = TFPN_K + (TFPN_Q*omega_21);
wTFPN_2  = TFPN_K + (TFPN_Q*omega_22);

wTFPH_1_check  = TFPH_K_check + (TFPH_Q_check*omega_21);
wTFPH_2_check  = TFPH_K_check + (TFPH_Q_check*omega_22);
wTFPN_1_check  = TFPN_K_check + (TFPN_Q_check*omega_21);
wTFPN_2_check  = TFPN_K_check + (TFPN_Q_check*omega_22);

wTFP_1   = TFP_K + (TFP_Q*omega_21);
wTFP_2   = TFP_K + (TFP_Q*omega_22);

wTFPR_1  = TFPR_K + (TFPR_Q*omega_21);  
wTFPR_2  = TFPR_K + (TFPR_Q*omega_22);  
wuZR_1   = uZR_K + (uZR_Q*omega_21);    
wuZR_2   = uZR_K + (uZR_Q*omega_22); 

% Solutions for the relative return on capiral Rj/Pj(K,Q,G,Aj,Bj) -     
wRPH_1  = RPH_K + (RPH_Q*omega_21);                 
wRPH_2  = RPH_K + (RPH_Q*omega_22);                 
wRPN_1  = RPN_K + (RPN_Q*omega_21);                 
wRPN_2  = RPN_K + (RPN_Q*omega_22);                 
                                                    
wtildeRPH_1  = tildeRPH_K + (tildeRPH_Q*omega_21);  
wtildeRPH_2  = tildeRPH_K + (tildeRPH_Q*omega_22);  
wtildeRPN_1  = tildeRPN_K + (tildeRPN_Q*omega_21);  
wtildeRPN_2  = tildeRPN_K + (tildeRPN_Q*omega_22);  

% Solutions for aggregate capital-labor ratio k, aggregate LIS sL, output
% share of non-tradables at current prices omegaYN
wk_1   =  k_K + (k_Q*omega_21);                                                                     
wk_2   =  k_K + (k_Q*omega_22); 

wLIS_1   =  LIS_K + (LIS_Q*omega_21); 
wLIS_2   =  LIS_K + (LIS_Q*omega_22); 

womegaYN_1   =  omegaYN_K + (omegaYN_Q*omega_21); 
womegaYN_2   =  omegaYN_K + (omegaYN_Q*omega_22); 
                                                     
% Transitional Paths
time0 = [Tm:Tu:0]; % Span of time t= [-20..0[
pathdGY0    = (omegaG_0 - omegaG_0) + 0*time0;
pathCY0     = (C_0 - C_0) + 0*time0;
pathdP0     = (P_0 - P_0) + 0*time0;
pathdPH0    = (PH_0 - PH_0) + 0*time0;
pathdPN0    = (PN_0 - PN_0) + 0*time0;
pathdZ0     = (Z_0 - Z_0) + 0*time0;
pathdZH0    = (ZH_0 - ZH_0) + 0*time0;
pathdZN0    = (ZN_0 - ZN_0) + 0*time0;
pathCAY0    = CA_0 + 0*time0;
pathdL0     = (L_0 - L_0) + 0*time0;
pathdK0     = (K_0 - K_0) + 0*time0;
pathdLH0    = (LH_0 - LH_0) + 0*time0;
pathdLN0    = (LN_0 - LN_0) + 0*time0;
pathdkH0    = (kH_0 - kH_0) + 0*time0;
pathdkN0    = (kN_0 - kN_0) + 0*time0;
pathdYH0    = (YH_0 - YH_0) + 0*time0;
pathdYN0    = (YN_0 - YN_0) + 0*time0;
pathIY0     = (I_0 - I_0) + 0*time0;
pathSY0     = CA_0 + 0*time0;
pathdW0     = (W_0 - W_0) + 0*time0;
pathdY0     = (Y_0 - Y_0) + 0*time0;
pathdWH0    = (WH_0 - WH_0) + 0*time0;
pathdWN0    = (WN_0 - WN_0) + 0*time0;
pathdOmega0 = (Omega_0 - Omega_0) + 0*time0;
pathdYHYN0  = (YHYN_0 - YHYN_0) + 0*time0;
pathdLHLN0  = (LHLN_0 - LHLN_0) + 0*time0;
pathdWPC0   = (WPC_0 - WPC_0) + 0*time0;
pathdQ0     = (PI_0 - PI_0) + 0*time0;
pathdR0     = (RK_0 - RK_0) + 0*time0;
pathdLISH0  = (sLH_0 - sLH_0) + 0*time0;
pathdLISN0  = (sLN_0 - sLN_0) + 0*time0;

time1        = [0:Tu:Tg]; % span of time t = [0..100]
VG           = exp(-xi*time1) - (1-barg)*exp(-chi*time1);
VG1          = exp(-xi*time1) - ThetaG_1*exp(-chi*time1);
VG2          = exp(-xi*time1) - ThetaG_2*exp(-chi*time1);

VG1prime      = xi*exp(-xi*time1) - chi*ThetaG_1*exp(-chi*time1);
VG2prime      = xi*exp(-xi*time1) - chi*ThetaG_2*exp(-chi*time1);
VGprime       = xi*exp(-xi*time1) - chi*(1-barg)*exp(-chi*time1);

VBG1prime     = xi*exp(-xi*time1) - chi*ThetaG_1prime*exp(-chi*time1);
VBG2prime     = xi*exp(-xi*time1) - chi*ThetaG_2prime*exp(-chi*time1);
VBGprime      = xi*exp(-xi*time1) - chi*ThetaG_prime*exp(-chi*time1);

VAH          = exp(-xiAH*time1) - (1-baraH)*exp(-chiAH*time1);
VBH          = exp(-xiBH*time1) - (1-barbH)*exp(-chiBH*time1);
VAN          = exp(-xiAN*time1) - (1-baraN)*exp(-chiAN*time1);
VBN          = exp(-xiBN*time1) - (1-barbN)*exp(-chiBN*time1);

X11  = (K0-K_CD) + GammaG_2*(1-ThetaG_2) - GammaG_1*(1-ThetaG_1);
X1   = X11*exp(nu_1*time1) + (GammaG_1*VG1);
X2   = -(GammaG_2*VG2);
%%%%%%%%% Transitional paths %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% Transitional paths %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

pathdGHY1    = ( PH_0*( (GH_0-GH_0) +  (GH_G*Y_0*VG) )/Y_0)*100;
pathdGNY1    = ( PN_0*( (GN_0-GN_0) +  (GN_G*Y_0*VG) )/Y_0)*100;
pathdGFY1    = ( ( (GF_0-GF_0) +  (GF_G*Y_0*VG) )/Y_0)*100;
pathdGY1     = ( ( (G_0-G_0) +  (VG*Y_0) )/Y_0)*100;
pathdAH1     = (( (AH_CD-AH_0) +  (VAH*AH_0) )/AH_0)*100;
pathdBH1     = (( (BH_CD-BH_0) +  (VBH*BH_0) )/BH_0)*100;
pathdAN1     = (( (AN_CD-AN_0) +  (VAN*AN_0) )/AN_0)*100;
pathdBN1     = (( (BN_CD-BN_0) +  (VBN*BN_0) )/BN_0)*100;
pathdZH1     = (sLH_0*(( (AH_CD-AH_0) +  (VAH*AH_0) )/AH_0) + (1-sLH_0)*(( (BH_CD-BH_0) +  (VBH*BH_0) )/BH_0) )*100;
pathdZN1     = (sLN_0*(( (AN_CD-AN_0) +  (VAN*AN_0) )/AN_0) + (1-sLN_0)*(( (BN_CD-BN_0) +  (VBN*BN_0) )/BN_0) )*100;
pathdFBTCH1  = ((1-sigmaH)/sigmaH)*( (( (BH_CD-BH_0) +  (VBH*BH_0) )/BH_0) - (( (AH_CD-AH_0) +  (VAH*AH_0) )/AH_0) )*100; 
pathdFBTCN1  = ((1-sigmaN)/sigmaN)*( (( (BN_CD-BN_0) +  (VBN*BH_0) )/BN_0) - (( (AN_CD-AN_0) +  (VAN*AN_0) )/AN_0) )*100;

pathdK1      = (((K_CD-K_0) + (X1 + X2) )/K_0)*100;
pathdQ1      = (((PI_CD-PI_0) + (omega_21*X1) + (omega_22*X2) )/PI_0)*100;
pathdP1      = (((P_CD-P_0) + (wP_1*X1) + (wP_2*X2) + (P_G*Y_0*VG) )/P_0)*100;
pathdPH1     = (((PH_CD-PH_0) + (wPH_1*X1) + (wPH_2*X2) + (PH_G*Y_0*VG) )/PH_0)*100;
pathdPN1     = (((PN_CD-PN_0) + (wPN_1*X1) + (wPN_2*X2) + (PN_G*Y_0*VG) )/PN_0)*100;
pathdCY1     = ( PC_0*((C_CD-C_0) + (wC_1*X1) + (wC_2*X2) + (C_G*Y_0*VG) )/Y_0 )*100;
pathdQPI1    = ( (wQPI_1*X1) + (wQPI_2*X2) + (wQPI_G*Y_0*VG) )*100;
pathdL1      = (((L_CD-L_0)  + (wL_1*X1) + (wL_2*X2) + (L_G*Y_0*VG) )/L_0)*100;
pathdLH1     = ( (WH_0/W_0)*( (LH_CD-LH_0) + (wLH_1*X1) + (wLH_2*X2) + (LH_G*Y_0*VG) )/L_0)*100;
pathdLN1     = ( (WN_0/W_0)*( (LN_CD-LN_0) + (wLN_1*X1) + (wLN_2*X2) + (LN_G*Y_0*VG) )/L_0)*100;
pathdW1      = (((W_CD-W_0) + (wW_1*X1) + (wW_2*X2) + (W_G*Y_0*VG) )/W_0)*100;
pathdR1      = (((RK_CD-RK_0) + (wR_1*X1) + (wR_2*X2) + (R_G*Y_0*VG) )/RK_0)*100;
pathdWPC1    = (((WPC_CD-WPC_0) + (wWPC_1*X1) + (wWPC_2*X2) + (WPC_G*Y_0*VG) )/WPC_0)*100;
pathdYR1     = (((YR_CD-Y_0) + (wYR_1*X1) + (wYR_2*X2) + (YR_G*Y_0*VG) )/Y_0)*100;
pathdYH1     = ( PH_0*((YH_CD-YH_0) + (wYH_1*X1) + (wYH_2*X2) + (YH_G*Y_0*VG) )/Y_0)*100;
pathdYN1     = ( PN_0*((YN_CD-YN_0) + (wYN_1*X1) + (wYN_2*X2) + (YN_G*Y_0*VG) )/Y_0)*100;
pathdWH1     = (((WH_CD-WH_0) + (wWH_1*X1) + (wWH_2*X2) + (WH_G*Y_0*VG) )/WH_0)*100;
pathdWN1     = (((WN_CD-WN_0) + (wWN_1*X1) + (wWN_2*X2) + (WN_G*Y_0*VG) )/WN_0)*100;
pathdWHPC1   = (((WHPC_CD-WHPC_0) + (wWHPC_1*X1) + (wWHPC_2*X2) + (WHPC_G*Y_0*VG) )/WHPC_0)*100;
pathdWNPC1   = (((WNPC_CD-WNPC_0) + (wWNPC_1*X1) + (wWNPC_2*X2) + (WNPC_G*Y_0*VG) )/WNPC_0)*100;
pathdRPH1     = ((((RK_CD/PH_CD)-(RK_0/PH_0)) + (wRPH_1*X1) + (wRPH_2*X2) + (RPH_G*Y_0*VG) )/(RK_0/PH_0))*100;
pathdRPN1     = ((((RK_CD/PN_CD)-(RK_0/PN_0)) + (wRPN_1*X1) + (wRPN_2*X2) + (RPN_G*Y_0*VG) )/(RK_0/PN_0))*100;

pathdOmega1  = (((Omega_CD-Omega_0) + (wOmega_1*X1) + (wOmega_2*X2) + (Omega_G*Y_0*VG) )/Omega_0)*100;
pathdYHYN1   = (PH_0/PN_0)*( ((YH_CD/YN_CD)-(YH_0/YN_0)) + (wYHYN_1*X1) + (wYHYN_2*X2) + (YHYN_G*Y_0*VG) )*100;
pathdLHLN1   = (WH_0/WN_0)*( ((LH_CD/LN_CD)-(LH_0/LN_0)) + (wLHLN_1*X1) + (wLHLN_2*X2) + (LHLN_G*Y_0*VG) )*100;
pathdLHS1    = (WH_0/W_0)*( ((LH_CD/L_CD)- (LH_0/L_0)) + (wLHS_1*X1) + (wLHS_2*X2) + (LHS_G*Y_0*VG) )*100;
pathdLNS1    = (WN_0/W_0)*( ((LN_CD/L_CD)- (LN_0/L_0)) + (wLNS_1*X1) + (wLNS_2*X2) + (LNS_G*Y_0*VG) )*100;
pathdYHS1    = PH_0*( ((YH_CD/YR_CD)- (YH_0/YR_0)) + (wYHS_1*X1) + (wYHS_2*X2) + (YHS_G*Y_0*VG) )*100;
pathdYNS1    = PN_0*( ((YN_CD/YR_CD)- (YN_0/YR_0)) + (wYNS_1*X1) + (wYNS_2*X2) + (YNS_G*Y_0*VG) )*100;
pathdWHW1    = (( ((WH_CD/W_CD)-(WH_0/W_0)) + (wWHW_1*X1) + (wWHW_2*X2) + (WHW_G*Y_0*VG) )/(WH_0/W_0) )*100;
pathdWNW1    = (( ((WN_CD/W_CD)-(WN_0/W_0)) + (wWNW_1*X1) + (wWNW_2*X2) + (WNW_G*Y_0*VG) )/(WN_0/W_0) )*100;
pathdKHK1    =  ( ((KH_CD/K_CD)-(KH_0/K_0)) + (wKHK_1*X1) + (wKHK_2*X2) + (KHK_G*Y_0*VG) )*100;
pathdKNK1    =  ( ((KN_CD/K_CD)-(KN_0/K_0)) + (wKNK_1*X1) + (wKNK_2*X2) + (KNK_G*Y_0*VG) )*100;

pathdkH1     = ( LH_0*((kH_CD-kH_0) + (wkH_1*X1) + (wkH_2*X2) + (kH_G*Y_0*VG) )/K_0)*100;
pathdkN1     = ( LN_0*((kN_CD-kN_0) + (wkN_1*X1) + (wkN_2*X2) + (kN_G*Y_0*VG) )/K_0)*100;
pathdLISH1   = ( (sLH_CD-sLH_0) + (wLISH_1*X1) + (wLISH_2*X2) + (LISH_G*Y_0*VG) )*100;
pathdLISN1   = ( (sLN_CD-sLN_0) + (wLISN_1*X1) + (wLISN_2*X2) + (LISN_G*Y_0*VG) )*100;

pathCAY1     = (( -nu_1*(wB1/(r-nu_1))*exp(nu_1*time1) + (N1*GammaG_1/(xi+r))*VBG1prime - (N2*GammaG_2/(xi+r))*VBG2prime + (B_G*Y_0/(xi+r))*VBGprime  )/Y_0 )*100;
pathSY1      = (( -nu_1*(wA1/(r-nu_1))*exp(nu_1*time1) + (L1*GammaG_1/(xi+r))*VBG1prime - (L2*GammaG_2/(xi+r))*VBG2prime + (A_G*Y_0/(xi+r))*VBGprime  )/Y_0 )*100;
pathIY1      = (( EK1*( nu_1*X11*exp(nu_1*time1) - (GammaG_1*VG1prime) ) + EK2*(GammaG_2*VG2prime) )/Y_0)*100;

%%%%%%%%% Transitional paths - including technology and capital utilization rates %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pathduKH1    = ( (wuKH_1*X1) + (wuKH_2*X2) + (uKH_G*Y_0*VG) )*100;
pathduKN1    = ( (wuKN_1*X1) + (wuKN_2*X2) + (uKN_G*Y_0*VG) )*100;
pathduK1     = ( (wuK_1*X1) + (wuK_2*X2) + (uK_G*Y_0*VG) )*100;
pathduZH1    = ( (wuZH_1*X1) + (wuZH_2*X2) + (uZH_G*Y_0*VG) )*100;
pathduZN1    = ( (wuZN_1*X1) + (wuZN_2*X2) + (uZN_G*Y_0*VG) )*100;
pathdtildeZH1 = (( (ZH_CD-ZH_0) + (wtildeZH_1*X1) + (wtildeZH_2*X2) + (tildeZH_G*Y_0*VG) )/ZH_0)*100;
pathdtildeZN1 = (( (ZN_CD-ZN_0) + (wtildeZN_1*X1) + (wtildeZN_2*X2) + (tildeZN_G*Y_0*VG) )/ZN_0)*100;
pathdtildeZ1  = (( (Z_CD-Z_0) + (wtildeZ_1*X1) + (wtildeZ_2*X2) + (tildeZ_G*Y_0*VG) )/Z_0)*100;
pathdTFPH1   = (( (TFPH_CD-TFPH_0) + (wTFPH_1*X1) + (wTFPH_2*X2) + (TFPH_G*Y_0*VG) )/ZH_0)*100;
pathdTFPN1   = (( (TFPN_CD-TFPN_0) + (wTFPN_1*X1) + (wTFPN_2*X2) + (TFPN_G*Y_0*VG) )/ZN_0)*100;
pathdTFP1    = (( (TFP_CD-TFP_0) + (wTFP_1*X1) + (wTFP_2*X2) + (TFP_G*Y_0*VG) )/TFP_0)*100;
pathdTFPH1_check   = (( (TFPH_CD-TFPH_0) + (wTFPH_1_check*X1) + (wTFPH_2_check*X2) + (TFPH_G_check*Y_0*VG) )/TFPH_0)*100;
pathdTFPN1_check   = (( (TFPN_CD-TFPN_0) + (wTFPN_1_check*X1) + (wTFPN_2_check*X2) + (TFPN_G_check*Y_0*VG) )/TFPN_0)*100;
pathdTFPR1   = (( ((TFPH_CD/TFPN_CD)-(TFPH_0/TFPN_0)) + (wTFPR_1*X1) + (wTFPR_2*X2) + (TFPR_G*Y_0*VG) )/(TFPH_0/TFPN_0))*100;
pathduZR1    = ( (wuZR_1*X1) + (wuZR_2*X2) + (uZR_G*Y_0*VG) )*100;

pathdtildeK1    = (( (K_CD-K_0) + (wtildeK_1*X1) + (wtildeK_2*X2) + (tildeK_G*Y_0*VG) )/K_0)*100;
pathdtildeW1    = (((W_CD-W_0) + (wtildeW_1*X1) + (wtildeW_2*X2) + (tildeW_G*Y_0*VG) )/W_0)*100;
pathdtildeR1    = (((RK_CD-RK_0) + (wtildeR_1*X1) + (wtildeR_2*X2) + (tildeR_G*Y_0*VG) )/RK_0)*100;
pathdtildeWPC1  = (((WPC_CD-WPC_0) + (wtildeWPC_1*X1) + (wtildeWPC_2*X2) + (tildeWPC_G*Y_0*VG) )/WPC_0)*100;
pathdtildeYR1   = (((YR_CD-Y_0) + (wtildeYR_1*X1) + (wtildeYR_2*X2) + (tildeYR_G*Y_0*VG) )/Y_0)*100;
pathdtildeYH1   = ( PH_0*((YH_CD-YH_0) + (wtildeYH_1*X1) + (wtildeYH_2*X2) + (tildeYH_G*Y_0*VG) )/Y_0)*100;
pathdtildeYN1   = ( PN_0*((YN_CD-YN_0) + (wtildeYN_1*X1) + (wtildeYN_2*X2) + (tildeYN_G*Y_0*VG) )/Y_0)*100;
pathdtildeWH1   = (((WH_CD-WH_0) + (wtildeWH_1*X1) + (wtildeWH_2*X2) + (tildeWH_G*Y_0*VG) )/WH_0)*100;
pathdtildeWN1   = (((WN_CD-WN_0) + (wtildeWN_1*X1) + (wtildeWN_2*X2) + (tildeWN_G*Y_0*VG) )/WN_0)*100;
pathdtildeWHPC1 = (((WHPC_CD-WHPC_0) + (wtildeWHPC_1*X1) + (wtildeWHPC_2*X2) + (tildeWHPC_G*Y_0*VG) )/WHPC_0)*100;
pathdtildeWNPC1 = (((WNPC_CD-WNPC_0) + (wtildeWNPC_1*X1) + (wtildeWNPC_2*X2) + (tildeWNPC_G*Y_0*VG) )/WNPC_0)*100;
pathdtildekH1   = ( LH_0*((kH_CD-kH_0) + (wtildekH_1*X1) + (wtildekH_2*X2) + (tildekH_G*Y_0*VG) )/K_0)*100;
pathdtildekN1   = ( LN_0*((kN_CD-kN_0) + (wtildekN_1*X1) + (wtildekN_2*X2) + (tildekN_G*Y_0*VG) )/K_0)*100;
pathdtildeRPH1  = ((((RK_CD/PH_CD)-(RK_0/PH_0)) + (wtildeRPH_1*X1) + (wtildeRPH_2*X2) + (tildeRPH_G*Y_0*VG) )/(RK_0/PH_0))*100;
pathdtildeRPN1  = ((((RK_CD/PN_CD)-(RK_0/PN_0)) + (wtildeRPN_1*X1) + (wtildeRPN_2*X2) + (tildeRPN_G*Y_0*VG) )/(RK_0/PN_0))*100;

pathdtildeOmega1 = (((Omega_CD-Omega_0) + (wtildeOmega_1*X1) + (wtildeOmega_2*X2) + (tildeOmega_G*Y_0*VG) )/Omega_0)*100;
pathdtildeYHYN1  = (PH_0/PN_0)*( ((YH_CD/YN_CD)-(YH_0/YN_0)) + (wtildeYHYN_1*X1) + (wtildeYHYN_2*X2) + (tildeYHYN_G*Y_0*VG) )*100;
pathdtildeYHS1   = PH_0*( ((YH_CD/YR_CD)- (YH_0/YR_0)) + (wtildeYHS_1*X1) + (wtildeYHS_2*X2) + (tildeYHS_G*Y_0*VG) )*100;
pathdtildeYNS1   = PN_0*( ((YN_CD/YR_CD)- (YN_0/YR_0)) + (wtildeYNS_1*X1) + (wtildeYNS_2*X2) + (tildeYNS_G*Y_0*VG) )*100;
pathdtildeWHW1   = (( ((WH_CD/W_CD)-(WH_0/W_0)) + (wtildeWHW_1*X1) + (wtildeWHW_2*X2) + (tildeWHW_G*Y_0*VG) )/(WH_0/W_0) )*100;
pathdtildeWNW1   = (( ((WN_CD/W_CD)-(WN_0/W_0)) + (wtildeWNW_1*X1) + (wtildeWNW_2*X2) + (tildeWNW_G*Y_0*VG) )/(WN_0/W_0) )*100;
pathdtildeKHK1   =  ( ((KH_CD/K_CD)-(KH_0/K_0)) + (wtildeKHK_1*X1) + (wtildeKHK_2*X2) + (tildeKHK_G*Y_0*VG) )*100;
pathdtildeKNK1   =  ( ((KN_CD/K_CD)-(KN_0/K_0)) + (wtildeKNK_1*X1) + (wtildeKNK_2*X2) + (tildeKNK_G*Y_0*VG) )*100;

% Decomposition: YHS, LNS, LISj
pathdYHS_TFPdiff1  = omegaYH_0*(1-omegaYH_0)*( (( (ZH_CD-ZH_0) + (wTFPH_1*X1) + (wTFPH_2*X2) + (TFPH_G*Y_0*VG) )/ZH_0) - (( (ZN_CD-ZN_0) + (wTFPN_1*X1) + (wTFPN_2*X2) + (TFPN_G*Y_0*VG) )/ZN_0) )*100;
pathdYHS_labdiff1  = omegaYH_0*(1-omegaYH_0)*(( ((LH_CD/LN_CD)-(LH_0/LN_0)) + (wLHLN_1*X1) + (wLHLN_2*X2) + (LHLN_G*Y_0*VG) )/(LH_0/LN_0) )*100;
pathdYHS_capdiff1  = omegaYH_0*(1-omegaYH_0)*( (1-sLH_0)*( ((kH_CD-kH_0) + (wkH_1*X1) + (wkH_2*X2) + (kH_G*Y_0*VG) )/kH_0 )  - (1-sLN_0)*( ((kN_CD-kN_0) + (wkN_1*X1) + (wkN_2*X2) + (kN_G*Y_0*VG) )/kN_0 ) )*100;

pathdYNS_TFPdiff1  = -pathdYHS_TFPdiff1;
pathdYNS_labdiff1  = -pathdYHS_labdiff1;
pathdYNS_capdiff1  = -pathdYHS_capdiff1;

pathdLNS_LISdiff1  = (1-alphaL_0)*(epsilon/(1+epsilon))*( (((sLN_CD-sLN_0) + (wLISN_1*X1) + (wLISN_2*X2) + (LISN_G*Y_0*VG) )/sLN_0) - (( (sL_CD-sL_0) + (wLIS_1*X1) + (wLIS_2*X2) + (LIS_G*Y_0*VG) )/sL_0) )*100;
pathdLNS_NTshare1  = (1-alphaL_0)*(epsilon/(1+epsilon))*(( (omegaYN_CD-omegaYN_0) + (womegaYN_1*X1) + (womegaYN_2*X2) + (omegaYN_G*Y_0*VG) )/omegaYN_0)*100;
pathdLNS_FBTCdiff1 = (1-alphaL_0)*alphaL_0*(epsilon/(1+epsilon))*( (1-sLN_0)*((1-sigmaN)/sigmaN)*( (( (BN_CD-BN_0) +  (VBN*BH_0) )/BN_0) - (( (AN_CD-AN_0) +  (VAN*AN_0) )/AN_0) ) - (1-sLH_0)*((1-sigmaH)/sigmaH)*( (( (BH_CD-BH_0) +  (VBH*BH_0) )/BH_0) - (( (AH_CD-AH_0) +  (VAH*AH_0) )/AH_0) ) )*100;

pathdLISH_FBTC1    = sLH_0*(1-sLH_0)*((1-sigmaH)/sigmaH)*( (( (BH_CD-BH_0) +  (VBH*BH_0) )/BH_0) - (( (AH_CD-AH_0) +  (VAH*AH_0) )/AH_0) )*100;
pathdLISH_cap1     = sLH_0*(1-sLH_0)*((1-sigmaH)/sigmaH)*(( (kH_CD-kH_0) + (wtildekH_1*X1) + (wtildekH_2*X2) + (tildekH_G*Y_0*VG) )/kH_0)*100;

pathdLISN_FBTC1    = sLN_0*(1-sLN_0)*((1-sigmaN)/sigmaN)*( (( (BN_CD-BN_0) +  (VBN*BN_0) )/BN_0) - (( (AN_CD-AN_0) +  (VAN*AN_0) )/AN_0) )*100;
pathdLISN_cap1     = sLN_0*(1-sLN_0)*((1-sigmaN)/sigmaN)*(( (kN_CD-kN_0) + (wtildekN_1*X1) + (wtildekN_2*X2) + (tildekN_G*Y_0*VG) )/kN_0)*100;

% IRF
timetemp = [time0 time1];
pathdGHY_CD   = [pathdGY0  pathdGHY1];
pathdGFY_CD   = [pathdGY0  pathdGFY1];
pathdGNY_CD   = [pathdGY0  pathdGNY1];
pathdGY_CD    = [pathdGY0  pathdGY1];
pathdQ_CD     = [pathdQ0  pathdQ1];
pathdQPI_CD   = [pathdQ0  pathdQPI1];
pathdPH_CD    = [pathdP0  pathdPH1];
pathdPN_CD    = [pathdP0  pathdPN1];
pathdP_CD     = [pathdP0  pathdP1]; 
pathdCY_CD    = [pathCY0  pathdCY1];                                             
pathdL_CD     = [pathdL0  pathdL1];
pathdK_CD     = [pathdK0  pathdK1];
pathdLH_CD    = [pathdLH0 pathdLH1];             
pathdLN_CD    = [pathdLN0 pathdLN1];  
pathdW_CD     = [pathdW0 pathdW1]; 
pathdR_CD     = [pathdR0 pathdR1]; 
pathdWPC_CD   = [pathdWPC0 pathdWPC1];  
pathdYR_CD    = [pathdY0 pathdYR1];
pathdYH_CD    = [pathdY0 pathdYH1];               
pathdYN_CD    = [pathdY0 pathdYN1];               
pathdWH_CD    = [pathdWH0  pathdWH1];              
pathdWN_CD    = [pathdWN0  pathdWN1]; 
pathdWHPC_CD  = [pathdWH0 pathdWHPC1];
pathdWNPC_CD  = [pathdWN0 pathdWNPC1];
pathdRPH_CD    = [pathdR0 pathdRPH1];
pathdRPN_CD    = [pathdR0 pathdRPN1];

pathdLHS_CD   = [pathdLH0 pathdLHS1];             
pathdLNS_CD   = [pathdLN0 pathdLNS1];
pathdYHS_CD   = [pathdY0 pathdYHS1];             
pathdYNS_CD   = [pathdY0 pathdYNS1];
pathdWHW_CD   = [pathdWH0 pathdWHW1];
pathdWNW_CD   = [pathdWN0 pathdWNW1];
pathdKHK_CD   = [pathdkH0 pathdKHK1];             
pathdKNK_CD   = [pathdkN0 pathdKNK1];

pathdkH_CD    = [pathdkH0 pathdkH1];             
pathdkN_CD    = [pathdkN0 pathdkN1];
pathdLISH_CD  = [pathdLISH0 pathdLISH1];             
pathdLISN_CD  = [pathdLISN0 pathdLISN1];

pathdOmega_CD = [pathdOmega0 pathdOmega1];         
pathdYHYN_CD  = [pathdYHYN0 pathdYHYN1];           
pathdLHLN_CD  = [pathdLHLN0 pathdLHLN1];

pathIY_CD     = [pathIY0  pathIY1];                        
pathCAY_CD    = [pathCAY0 pathCAY1];               
pathSY_CD     = [pathSY0  pathSY1];

% IRF including technology and capital utilization rates
pathduKH_CD   = [pathdkH0 pathduKH1];             
pathduKN_CD   = [pathdkN0 pathduKN1];
pathduK_CD    = [pathdkN0 pathduK1];
pathduZH_CD   = [pathdkH0 pathduZH1];             
pathduZN_CD   = [pathdkN0 pathduZN1];
pathdtildeZH_CD  = [pathdkH0 pathdtildeZH1];             
pathdtildeZN_CD  = [pathdkN0 pathdtildeZN1];
pathdtildeZ_CD   = [pathdkN0 pathdtildeZ1];
pathdTFPH_CD  = [pathdkH0 pathdTFPH1];             
pathdTFPN_CD  = [pathdkN0 pathdTFPN1];
pathdTFPH_check_CD  = [pathdkH0 pathdTFPH1_check];             
pathdTFPN_check_CD  = [pathdkN0 pathdTFPN1_check];
pathdTFP_CD   = [pathdkN0 pathdTFP1];
pathdTFPR_endo  = [pathdkH0 pathdTFPR1];
pathduZR_endo   = [pathdkN0 pathduZR1]; 

pathdtildeK_CD     = [pathdK0  pathdtildeK1];            
pathdtildeW_CD     = [pathdW0 pathdtildeW1];           
pathdtildeR_CD     = [pathdR0 pathdtildeR1];           
pathdtildeWPC_CD   = [pathdWPC0 pathdtildeWPC1];                  
pathdtildeYR_CD    = [pathdY0 pathdtildeYR1];          
pathdtildeYH_CD    = [pathdY0 pathdtildeYH1];          
pathdtildeYN_CD    = [pathdY0 pathdtildeYN1];          
pathdtildeWH_CD    = [pathdWH0  pathdtildeWH1];        
pathdtildeWN_CD    = [pathdWN0  pathdtildeWN1];        
pathdtildeWHPC_CD  = [pathdWH0 pathdtildeWHPC1];       
pathdtildeWNPC_CD  = [pathdWN0 pathdtildeWNPC1];    
pathdtildeRPH_CD    = [pathdR0  pathdtildeRPH1];        
pathdtildeRPN_CD    = [pathdR0  pathdtildeRPN1];

pathdtildeYHS_CD   = [pathdY0 pathdtildeYHS1];             
pathdtildeYNS_CD   = [pathdY0 pathdtildeYNS1];
pathdtildeWHW_CD   = [pathdWH0 pathdtildeWHW1];          
pathdtildeWNW_CD   = [pathdWN0 pathdtildeWNW1];          
pathdtildeKHK_CD   = [pathdkH0 pathdtildeKHK1];          
pathdtildeKNK_CD   = [pathdkN0 pathdtildeKNK1];          
                                                          
pathdtildekH_CD    = [pathdkH0 pathdtildekH1];           
pathdtildekN_CD    = [pathdkN0 pathdtildekN1];           
pathdtildeOmega_CD = [pathdOmega0 pathdtildeOmega1];     
pathdtildeYHYN_CD  = [pathdYHYN0 pathdtildeYHYN1];  

% DECOMPOSITION: IRF
pathdYHS_TFPdiff_CD  = [pathdK0 pathdYHS_TFPdiff1];    
pathdYHS_labdiff_CD  = [pathdK0 pathdYHS_labdiff1];    
pathdYHS_capdiff_CD  = [pathdK0 pathdYHS_capdiff1];    

pathdYNS_TFPdiff_CD  = [pathdK0 pathdYNS_TFPdiff1]; 
pathdYNS_labdiff_CD  = [pathdK0 pathdYNS_labdiff1]; 
pathdYNS_capdiff_CD  = [pathdK0 pathdYNS_capdiff1]; 
                                                         
pathdLNS_LISdiff_CD  = [pathdK0 pathdLNS_LISdiff1];    
pathdLNS_NTshare_CD  = [pathdK0 pathdLNS_NTshare1];    
pathdLNS_FBTCdiff_CD = [pathdK0 pathdLNS_FBTCdiff1];   
                                                         
pathdLISH_FBTC_CD    = [pathdK0 pathdLISH_FBTC1];      
pathdLISH_cap_CD     = [pathdK0 pathdLISH_cap1];       
                                                         
pathdLISN_FBTC_CD    = [pathdK0 pathdLISN_FBTC1];      
pathdLISN_cap_CD     = [pathdK0 pathdLISN_cap1]; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% Dynamic and steadty-state effects of a Temporary increase in G     %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Impact effects of fiscal shock: dynamic processes
VG0            = 1 - (1-barg);
VG10           = 1 - ThetaG_1;
VG20           = 1 - ThetaG_2;
VG1prime0      = xi - chi*ThetaG_1;
VG2prime0      = xi - chi*ThetaG_2;
VGprime0       = xi - chi*(1-barg);

VAH0           = 1 - (1-baraH);                  
VBH0           = 1 - (1-barbH);                  
VAN0           = 1 - (1-baraN);                  
VBN0           = 1 - (1-barbN);  

VBG1prime0     = xi - (chi*ThetaG_1prime);
VBG2prime0     = xi - (chi*ThetaG_2prime);
VBGprime0      = xi - (chi*ThetaG_prime);

X10   = X11 + (GammaG_1*VG10);
X20   = -(GammaG_2*VG20);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dGHYtime0_CD    = ( PH_0*( (GH_0-GH_0) +  (GH_G*Y_0*VG0) )/Y_0)*100;
dGNYtime0_CD    = ( PN_0*( (GN_0-GN_0) +  (GN_G*Y_0*VG0) )/Y_0)*100;
dGFYtime0_CD    = ( ( (GF_0-GF_0) +  (GF_G*Y_0*VG0) )/Y_0)*100;
dGYtime0_CD     = ( ( (G_0-G_0) +  (VG0*Y_0) )/Y_0)*100;
dAHtime0_CD     = (( (AH_CD-AH_0) +  (VAH0*AH_0) )/AH_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
dBHtime0_CD     = (( (BH_CD-BH_0) +  (VBH0*BH_0) )/BH_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
dANtime0_CD     = (( (AN_CD-AN_0) +  (VAN0*AN_0) )/AN_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
dBNtime0_CD     = (( (BN_CD-BN_0) +  (VBN0*BN_0) )/BN_0)*100;  
dZHtime0_CD     = (sLH_0*(( (AH_CD-AH_0) +  (VAH0*AH_0) )/AH_0) + (1-sLH_0)*(( (BH_CD-BH_0) +  (VBH0*BH_0) )/BH_0) )*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
dZNtime0_CD     = (sLN_0*(( (AN_CD-AN_0) +  (VAN0*AN_0) )/AN_0) + (1-sLN_0)*(( (BN_CD-BN_0) +  (VBN0*BN_0) )/BN_0) )*100; 
dFBTCHtime0_CD  = ((1-sigmaH)/sigmaH)*( (( (BH_CD-BH_0) +  (VBH0*BH_0) )/BH_0) - (( (AH_CD-AH_0) +  (VAH0*AH_0) )/AH_0) )*100; 
dFBTCNtime0_CD  = ((1-sigmaN)/sigmaN)*( (( (BN_CD-BN_0) +  (VBN0*BH_0) )/BN_0) - (( (AN_CD-AN_0) +  (VAN0*AN_0) )/AN_0) )*100; 

dKtime0_CD      = (((K_CD-K_0) + (X10 + X20) )/K_0)*100;
dQtime0_CD      = (((PI_CD-PI_0) + (omega_21*X10) + (omega_22*X20) )/PI_0)*100;
dPtime0_CD      = (((P_CD-P_0) + (wP_1*X10) + (wP_2*X20) + (P_G*Y_0*VG0) )/P_0)*100;
dPHtime0_CD     = (((PH_CD-PH_0) + (wPH_1*X10) + (wPH_2*X20) + (PH_G*Y_0*VG0) )/PH_0)*100;
dPNtime0_CD     = (((PN_CD-PN_0) + (wPN_1*X10) + (wPN_2*X20) + (PN_G*Y_0*VG0) )/PN_0)*100;
dCYtime0_CD     = ( PC_0*((C_CD-C_0) + (wC_1*X10) + (wC_2*X20) + (C_G*Y_0*VG0) )/Y_0 )*100;
dQPItime0_CD    = ( (wQPI_1*X10) + (wQPI_2*X20) + (wQPI_G*Y_0*VG0) )*100;
dLtime0_CD      = (((L_CD-L_0)  + (wL_1*X10) + (wL_2*X20) + (L_G*Y_0*VG0) )/L_0)*100;
dLHtime0_CD     = ( (WH_0/W_0)*((LH_CD-LH_0) + (wLH_1*X10) + (wLH_2*X20) + (LH_G*Y_0*VG0) )/L_0)*100;
dLNtime0_CD     = ( (WN_0/W_0)*((LN_CD-LN_0) + (wLN_1*X10) + (wLN_2*X20) + (LN_G*Y_0*VG0) )/L_0)*100;
dWtime0_CD      = (((W_CD-W_0) + (wW_1*X10) + (wW_2*X20) + (W_G*Y_0*VG0) )/W_0)*100;
dRtime0_CD      = (((RK_CD-RK_0) + (wR_1*X10) + (wR_2*X20) + (R_G*Y_0*VG0) )/RK_0)*100;
dWPCtime0_CD    = (((WPC_CD-WPC_0) + (wWPC_1*X10) + (wWPC_2*X20) + (WPC_G*Y_0*VG0) )/WPC_0)*100;
dYRtime0_CD     = (((YR_CD-Y_0) + (wYR_1*X10) + (wYR_2*X20) + (YR_G*Y_0*VG0) )/Y_0)*100;
dYHtime0_CD     = (PH_0*((YH_CD-YH_0) + (wYH_1*X10) + (wYH_2*X20) + (YH_G*Y_0*VG0) )/Y_0)*100;
dYNtime0_CD     = (PN_0*((YN_CD-YN_0) + (wYN_1*X10) + (wYN_2*X20) + (YN_G*Y_0*VG0) )/Y_0)*100;
dWHtime0_CD     = (((WH_CD-WH_0) + (wWH_1*X10) + (wWH_2*X20) + (WH_G*Y_0*VG0) )/WH_0)*100;
dWNtime0_CD     = (((WN_CD-WN_0) + (wWN_1*X10) + (wWN_2*X20) + (WN_G*Y_0*VG0) )/WN_0)*100;
dWHPCtime0_CD   = (((WHPC_CD-WHPC_0) + (wWHPC_1*X10) + (wWHPC_2*X20) + (WHPC_G*Y_0*VG0) )/WHPC_0)*100;
dWNPCtime0_CD   = (((WNPC_CD-WNPC_0) + (wWNPC_1*X10) + (wWNPC_2*X20) + (WNPC_G*Y_0*VG0) )/WNPC_0)*100;

dOmegatime0_CD  = (((Omega_CD-Omega_0) + (wOmega_1*X10) + (wOmega_2*X20) + (Omega_G*Y_0*VG0) )/Omega_0)*100;
dYHYNtime0_CD   = (PH_0/PN_0)*( ((YH_CD/YN_CD)-(YH_0/YN_0)) + (wYHYN_1*X10) + (wYHYN_2*X20) + (YHYN_G*Y_0*VG0) )*100;
dLHLNtime0_CD   = (WH_0/WN_0)*( ((LH_CD/LN_CD)-(LH_0/LN_0)) + (wLHLN_1*X10) + (wLHLN_2*X20) + (LHLN_G*Y_0*VG0) )*100;
dLHStime0_CD    = (WH_0/W_0)*( ((LH_CD/L_CD)- (LH_0/L_0)) + (wLHS_1*X10) + (wLHS_2*X20) + (LHS_G*Y_0*VG0) )*100;
dLNStime0_CD    = (WN_0/W_0)*( ((LN_CD/L_CD)- (LN_0/L_0)) + (wLNS_1*X10) + (wLNS_2*X20) + (LNS_G*Y_0*VG0) )*100;
dYHStime0_CD    = PH_0*( ((YH_CD/YR_CD)- (YH_0/YR_0)) + (wYHS_1*X10) + (wYHS_2*X20) + (YHS_G*Y_0*VG0) )*100;
dYNStime0_CD    = PN_0*( ((YN_CD/YR_CD)- (YN_0/YR_0)) + (wYNS_1*X10) + (wYNS_2*X20) + (YNS_G*Y_0*VG0) )*100;
dWHWtime0_CD    = (( ((WH_CD/W_CD)-(WH_0/W_0)) + (wWHW_1*X10) + (wWHW_2*X20) + (WHW_G*Y_0*VG0) )/(WH_0/W_0) )*100;
dWNWtime0_CD    = (( ((WN_CD/W_CD)-(WN_0/W_0)) + (wWNW_1*X10) + (wWNW_2*X20) + (WNW_G*Y_0*VG0) )/(WN_0/W_0) )*100;
dKHKtime0_CD    =  ( ((KH_CD/K_CD)-(KH_0/K_0)) + (wKHK_1*X10) + (wKHK_2*X20) + (KHK_G*Y_0*VG0) )*100;
dKNKtime0_CD    =  ( ((KN_CD/K_CD)-(KN_0/K_0)) + (wKNK_1*X10) + (wKNK_2*X20) + (KNK_G*Y_0*VG0) )*100;
dRPHtime0_CD    = ((((RK_CD/PH_CD)-(RK_0/PH_0)) + (wRPH_1*X10) + (wRPH_2*X20) + (RPH_G*Y_0*VG0) )/(RK_0/PH_0))*100;                                       
dRPNtime0_CD    = ((((RK_CD/PN_CD)-(RK_0/PN_0)) + (wRPN_1*X10) + (wRPN_2*X20) + (RPN_G*Y_0*VG0) )/(RK_0/PN_0))*100; 
dRtime0_CD      = ( ((RK_CD-RK_0) + (wR_1*X10) + (wR_2*X20) + (R_G*Y_0*VG0) )/RK_0)*100 

dkHtime0_CD     = ( LH_0*((kH_CD-kH_0) + (wkH_1*X10) + (wkH_2*X20) + (kH_G*Y_0*VG0) )/K_0)*100;
dkNtime0_CD     = ( LN_0*((kN_CD-kN_0) + (wkN_1*X10) + (wkN_2*X20) + (kN_G*Y_0*VG0) )/K_0)*100;
dLISHtime0_CD   = ( (sLH_CD-sLH_0) + (wLISH_1*X10) + (wLISH_2*X20) + (LISH_G*Y_0*VG0) )*100;
dLISNtime0_CD   = ( (sLN_CD-sLN_0) + (wLISN_1*X10) + (wLISN_2*X20) + (LISN_G*Y_0*VG0) )*100;

CAYtime0_CD     = (( -nu_1*(wB1/(r-nu_1)) + (N1*GammaG_1/(xi+r))*VBG1prime0 - (N2*GammaG_2/(xi+r))*VBG2prime0 + (B_G*Y_0/(xi+r))*VBGprime0  )/Y_0 )*100;
SYtime0_CD      = (( -nu_1*(wA1/(r-nu_1)) + (L1*GammaG_1/(xi+r))*VBG1prime0 - (L2*GammaG_2/(xi+r))*VBG2prime0 + (A_G*Y_0/(xi+r))*VBGprime0  )/Y_0 )*100;
IYtime0_CD      = (( EK1*( (nu_1*X11) - (GammaG_1*VG1prime0) ) + EK2*(GammaG_2*VG2prime0) )/Y_0)*100;

CAYtime0_CD_check = SYtime0_CD - IYtime0_CD;
%%%%%%%%%%%%%%%%% Including capital and technology utilization rates
%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
duKHtime0_CD        = ( (wuKH_1*X10) + (wuKH_2*X20) + (uKH_G*Y_0*VG0) )*100;
duKNtime0_CD        = ( (wuKN_1*X10) + (wuKN_2*X20) + (uKN_G*Y_0*VG0) )*100;
duKtime0_CD         = ( (wuK_1*X10) + (wuK_2*X20) + (uK_G*Y_0*VG0) )*100;
duZHtime0_CD        = ( (wuZH_1*X10) + (wuZH_2*X20) + (uZH_G*Y_0*VG0) )*100;
duZNtime0_CD        = ( (wuZN_1*X10) + (wuZN_2*X20) + (uZN_G*Y_0*VG0) )*100;
dtildeZHtime0_CD    = (( (ZH_CD-ZH_0) + (wtildeZH_1*X10) + (wtildeZH_2*X20) + (tildeZH_G*Y_0*VG0) )/ZH_0)*100;
dtildeZNtime0_CD    = (( (ZN_CD-ZN_0) + (wtildeZN_1*X10) + (wtildeZN_2*X20) + (tildeZN_G*Y_0*VG0) )/ZN_0)*100;
dtildeZtime0_CD     = (( (Z_CD-Z_0) + (wtildeZ_1*X10) + (wtildeZ_2*X20) + (tildeZ_G*Y_0*VG0) )/Z_0)*100;

dTFPHtime0_CD       = (( (ZH_CD-ZH_0) + (wTFPH_1*X10) + (wTFPH_2*X20) + (TFPH_G*Y_0*VG0) )/ZH_0)*100;                              
dTFPNtime0_CD       = (( (ZN_CD-ZN_0) + (wTFPN_1*X10) + (wTFPN_2*X20) + (TFPN_G*Y_0*VG0) )/ZN_0)*100;                              
dTFPtime0_CD        = (( (Z_CD-Z_0) + (wTFP_1*X10) + (wTFP_2*X20) + (TFP_G*Y_0*VG0) )/Z_0)*100;                                    
dTFPHtime0_check_CD   = (( (ZH_CD-ZH_0) + (wTFPH_1_check*X10) + (wTFPH_2_check*X20) + (TFPH_G_check*Y_0*VG0) )/ZH_0)*100;          
dTFPNtime0_check_CD   = (( (ZN_CD-ZN_0) + (wTFPN_1_check*X10) + (wTFPN_2_check*X20) + (TFPN_G_check*Y_0*VG0) )/ZN_0)*100;          
dTFPRtime0_CD       = (( ((ZH_CD/ZN_CD)-(ZH_0/ZN_0)) + (wTFPR_1*X10) + (wTFPR_2*X20) + (TFPR_G*Y_0*VG0) )/(ZH_0/ZN_0))*100;      
duZRtime0_CD        = ( (wuZR_1*X10) + (wuZR_2*X20) + (uZR_G*Y_0*VG0) )*100;  

dtildeKtime0_CD     = (( (K_CD-K_0) + (wtildeK_1*X10) + (wtildeK_2*X20) + (tildeK_G*Y_0*VG0) )/K_0)*100;
dtildeWtime0_CD     = (((W_CD-W_0) + (wtildeW_1*X10) + (wtildeW_2*X20) + (tildeW_G*Y_0*VG0) )/W_0)*100;
dtildeRtime0_CD     = (((RK_CD-RK_0) + (wtildeR_1*X10) + (wtildeR_2*X20) + (tildeR_G*Y_0*VG0) )/RK_0)*100;
dtildeWPCtime0_CD   = (((WPC_CD-WPC_0) + (wtildeWPC_1*X10) + (wtildeWPC_2*X20) + (tildeWPC_G*Y_0*VG0) )/WPC_0)*100;
dtildeYRtime0_CD    = (((YR_CD-Y_0) + (wtildeYR_1*X10) + (wtildeYR_2*X20) + (tildeYR_G*Y_0*VG0) )/Y_0)*100;
dtildeYHtime0_CD    = ( PH_0*((YH_CD-YH_0) + (wtildeYH_1*X10) + (wtildeYH_2*X20) + (tildeYH_G*Y_0*VG0) )/Y_0)*100;
dtildeYNtime0_CD    = ( PN_0*((YN_CD-YN_0) + (wtildeYN_1*X10) + (wtildeYN_2*X20) + (tildeYN_G*Y_0*VG0) )/Y_0)*100;
dtildeWHtime0_CD    = (((WH_CD-WH_0) + (wtildeWH_1*X10) + (wtildeWH_2*X20) + (tildeWH_G*Y_0*VG0) )/WH_0)*100;
dtildeWNtime0_CD    = (((WN_CD-WN_0) + (wtildeWN_1*X10) + (wtildeWN_2*X20) + (tildeWN_G*Y_0*VG0) )/WN_0)*100;
dtildeWHPCtime0_CD  = (((WHPC_CD-WHPC_0) + (wtildeWHPC_1*X10) + (wtildeWHPC_2*X20) + (tildeWHPC_G*Y_0*VG0) )/WHPC_0)*100;
dtildeWNPCtime0_CD  = (((WNPC_CD-WNPC_0) + (wtildeWNPC_1*X10) + (wtildeWNPC_2*X20) + (tildeWNPC_G*Y_0*VG0) )/WNPC_0)*100;
dtildekHtime0_CD    = ( LH_0*((kH_CD-kH_0) + (wtildekH_1*X10) + (wtildekH_2*X20) + (tildekH_G*Y_0*VG0) )/K_0)*100;
dtildekNtime0_CD    = ( LN_0*((kN_CD-kN_0) + (wtildekN_1*X10) + (wtildekN_2*X20) + (tildekN_G*Y_0*VG0) )/K_0)*100;

dtildeOmegatime0_CD = (((Omega_CD-Omega_0) + (wtildeOmega_1*X10) + (wtildeOmega_2*X20) + (tildeOmega_G*Y_0*VG0) )/Omega_0)*100;
dtildeYHYNtime0_CD  = (PH_0/PN_0)*( ((YH_CD/YN_CD)-(YH_0/YN_0)) + (wtildeYHYN_1*X10) + (wtildeYHYN_2*X20) + (tildeYHYN_G*Y_0*VG0) )*100;
dtildeYHStime0_CD   = PH_0*( ((YH_CD/YR_CD)- (YH_0/YR_0)) + (wtildeYHS_1*X10) + (wtildeYHS_2*X20) + (tildeYHS_G*Y_0*VG0) )*100;
dtildeYNStime0_CD   = PN_0*( ((YN_CD/YR_CD)- (YN_0/YR_0)) + (wtildeYNS_1*X10) + (wtildeYNS_2*X20) + (tildeYNS_G*Y_0*VG0) )*100;
dtildeWHWtime0_CD   = (( ((WH_CD/W_CD)-(WH_0/W_0)) + (wtildeWHW_1*X10) + (wtildeWHW_2*X20) + (tildeWHW_G*Y_0*VG0) )/(WH_0/W_0) )*100;
dtildeWNWtime0_CD   = (( ((WN_CD/W_CD)-(WN_0/W_0)) + (wtildeWNW_1*X10) + (wtildeWNW_2*X20) + (tildeWNW_G*Y_0*VG0) )/(WN_0/W_0) )*100;
dtildeKHKtime0_CD   =  ( ((KH_CD/K_CD)-(KH_0/K_0)) + (wtildeKHK_1*X10) + (wtildeKHK_2*X20) + (tildeKHK_G*Y_0*VG0) )*100;
dtildeKNKtime0_CD   =  ( ((KN_CD/K_CD)-(KN_0/K_0)) + (wtildeKNK_1*X10) + (wtildeKNK_2*X20) + (tildeKNK_G*Y_0*VG0) )*100;
dtildeRPHtime0_CD   = ((((RK_CD/PH_CD)-(RK_0/PH_0)) + (wtildeRPH_1*X10) + (wtildeRPH_2*X20) + (tildeRPH_G*Y_0*VG0) )/(RK_0/PH_0))*100;  
dtildeRPNtime0_CD   = ((((RK_CD/PN_CD)-(RK_0/PN_0)) + (wtildeRPN_1*X10) + (wtildeRPN_2*X20) + (tildeRPN_G*Y_0*VG0) )/(RK_0/PN_0))*100; 

% DECOMPOSITION
dYHS_TFPdifftime0_CD  = omegaYH_0*(1-omegaYH_0)*(( ((ZH_CD/ZN_CD)-(ZH_0/ZN_0)) + (wTFPR_1*X10) + (wTFPR_2*X20) + (TFPR_G*Y_0*VG0) )/(ZH_0/ZN_0))*100;
dYHS_labdifftime0_CD  = omegaYH_0*(1-omegaYH_0)*(( ((LH_CD/LN_CD)-(LH_0/LN_0)) + (wLHLN_1*X10) + (wLHLN_2*X20) + (LHLN_G*Y_0*VG0) )/(LH_0/LN_0) )*100;
dYHS_capdifftime0_CD  = omegaYH_0*(1-omegaYH_0)*( (1-sLH_0)*( ((kH_CD-kH_0) + (wkH_1*X10) + (wkH_2*X20) + (kH_G*Y_0*VG0) )/kH_0 ) - (1-sLN_0)*( ((kN_CD-kN_0) + (wkN_1*X10) + (wkN_2*X20) + (kN_G*Y_0*VG0) )/kN_0 ) )*100;
dYHStime0_check_CD    = dYHS_TFPdifftime0_CD + dYHS_labdifftime0_CD + dYHS_capdifftime0_CD;

dYNS_TFPdifftime0_CD  = -dYHS_TFPdifftime0_CD;                                                                                                                                  
dYNS_labdifftime0_CD  = -dYHS_labdifftime0_CD;                                                                                                                                                      
dYNS_capdifftime0_CD  = -dYHS_capdifftime0_CD; 
dYNStime0_check_CD    = dYNS_TFPdifftime0_CD + dYNS_labdifftime0_CD + dYNS_capdifftime0_CD;

dLNS_LISdifftime0_CD  = (1-alphaL_0)*(epsilon/(1+epsilon))*( (((sLN_CD-sLN_0) + (wLISN_1*X10) + (wLISN_2*X20) + (LISN_G*Y_0*VG0) )/sLN_0) - (( (sL_CD-sL_0) + (wLIS_1*X10) + (wLIS_2*X20) + (LIS_G*Y_0*VG0) )/sL_0) )*100;
dLNS_NTsharetime0_CD  = (1-alphaL_0)*(epsilon/(1+epsilon))*(( (omegaYN_CD-omegaYN_0) + (womegaYN_1*X10) + (womegaYN_2*X20) + (omegaYN_G*Y_0*VG0) )/omegaYN_0)*100;
dLNS_FBTCdifftime0_CD = (1-alphaL_0)*alphaL_0*(epsilon/(1+epsilon))*( (1-sLN_0)*((1-sigmaN)/sigmaN)*( (( (BN_CD-BN_0) +  (VBN0*BH_0) )/BN_0) - (( (AN_CD-AN_0) +  (VAN0*AN_0) )/AN_0) ) - (1-sLH_0)*((1-sigmaH)/sigmaH)*( (( (BH_CD-BH_0) +  (VBH0*BH_0) )/BH_0) - (( (AH_CD-AH_0) +  (VAH0*AH_0) )/AH_0) ) )*100;
dLNStime0_check_CD    = dLNS_LISdifftime0_CD + dLNS_NTsharetime0_CD;

dLISH_FBTCtime0_CD    = sLH_0*(1-sLH_0)*((1-sigmaH)/sigmaH)*( (( (BH_CD-BH_0) +  (VBH0*BH_0) )/BH_0) - (( (AH_CD-AH_0) +  (VAH0*AH_0) )/AH_0) )*100;
dLISH_captime0_CD     = sLH_0*(1-sLH_0)*((1-sigmaH)/sigmaH)*(( (kH_CD-kH_0) + (wtildekH_1*X10) + (wtildekH_2*X20) + (tildekH_G*Y_0*VG0) )/kH_0)*100;
dLISHtime0_check_CD   = dLISH_FBTCtime0_CD + dLISH_captime0_CD;

dLISN_FBTCtime0_CD    = sLN_0*(1-sLN_0)*((1-sigmaN)/sigmaN)*( (( (BN_CD-BN_0) +  (VBN0*BN_0) )/BN_0) - (( (AN_CD-AN_0) +  (VAN0*AN_0) )/AN_0) )*100;
dLISN_captime0_CD     = sLN_0*(1-sLN_0)*((1-sigmaN)/sigmaN)*(( (kN_CD-kN_0) + (wtildekN_1*X10) + (wtildekN_2*X20) + (tildekN_G*Y_0*VG0) )/kN_0)*100;
dLISNtime0_check_CD   = dLISN_FBTCtime0_CD + dLISN_captime0_CD;

% DECOMPOSITION t=5
% Cumulative responses t=5: 6 periods
tcumul       = 5;
t6           = [0:Tu:tcumul]; % span of time t = [0..5]
VGt6         = exp(-xi*t6) - (1-barg)*exp(-chi*t6);
VG1t6        = exp(-xi*t6) - ThetaG_1*exp(-chi*t6);
VG2t6        = exp(-xi*t6) - ThetaG_2*exp(-chi*t6);
VAHt6        = exp(-xiAH*t6) - (1-baraH)*exp(-chiAH*t6);
VBHt6        = exp(-xiBH*t6) - (1-barbH)*exp(-chiBH*t6);
VANt6        = exp(-xiAN*t6) - (1-baraN)*exp(-chiAN*t6);
VBNt6        = exp(-xiBN*t6) - (1-barbN)*exp(-chiBN*t6);

X1t6   = X11*exp(nu_1*t6) + (GammaG_1*VG1t6);
X2t6   = -(GammaG_2*VG2t6);

% Decomposition: YHS, LNS, LISj
dLNScum          = (WN_0/W_0)*( ((LN_CD/L_CD)- (LN_0/L_0)) + (wLNS_1*X1t6) + (wLNS_2*X2t6) + (LNS_G*Y_0*VGt6) )*100;
dtildeYHScum     = PH_0*( ((YH_CD/YR_CD)- (YH_0/YR_0)) + (wtildeYHS_1*X1t6) + (wtildeYHS_2*X2t6) + (tildeYHS_G*Y_0*VGt6) )*100;
dLISHcum         = ( (sLH_CD-sLH_0) + (wLISH_1*X1t6) + (wLISH_2*X2t6) + (LISH_G*Y_0*VGt6) )*100;
dLISNcum         = ( (sLN_CD-sLN_0) + (wLISN_1*X1t6) + (wLISN_2*X2t6) + (LISN_G*Y_0*VGt6) )*100;
dtildeYNScum     = PN_0*( ((YN_CD/YR_CD)- (YN_0/YR_0)) + (wtildeYNS_1*X1t6) + (wtildeYNS_2*X2t6) + (tildeYNS_G*Y_0*VGt6)  )*100;

dYHS_TFPdiffcum  = omegaYH_0*(1-omegaYH_0)*( (( (ZH_CD-ZH_0) + (wTFPH_1*X1t6) + (wTFPH_2*X2t6) + (TFPH_G*Y_0*VGt6) )/ZH_0) - (( (ZN_CD-ZN_0) + (wTFPN_1*X1t6) + (wTFPN_2*X2t6) + (TFPN_G*Y_0*VGt6) )/ZN_0) )*100;
dYHS_labdiffcum  = omegaYH_0*(1-omegaYH_0)*(( ((LH_CD/LN_CD)-(LH_0/LN_0)) + (wLHLN_1*X1t6) + (wLHLN_2*X2t6) + (LHLN_G*Y_0*VGt6) )/(LH_0/LN_0) )*100;
dYHS_capdiffcum  = omegaYH_0*(1-omegaYH_0)*( (1-sLH_0)*( ((kH_CD-kH_0) + (wkH_1*X1t6) + (wkH_2*X2t6) + (kH_G*Y_0*VGt6) )/kH_0 )  - (1-sLN_0)*( ((kN_CD-kN_0) + (wkN_1*X1t6) + (wkN_2*X2t6) + (kN_G*Y_0*VGt6) )/kN_0 ) )*100;

dYNS_TFPdiffcum  = - dYHS_TFPdiffcum;
dYNS_labdiffcum  = - dYHS_labdiffcum;
dYNS_capdiffcum  = - dYHS_capdiffcum;

dLNS_LISdiffcum  = (1-alphaL_0)*(epsilon/(1+epsilon))*( (((sLN_CD-sLN_0) + (wLISN_1*X1t6) + (wLISN_2*X2t6) + (LISN_G*Y_0*VGt6) )/sLN_0) - (( (sL_CD-sL_0) + (wLIS_1*X1t6) + (wLIS_2*X2t6) + (LIS_G*Y_0*VGt6) )/sL_0) )*100;
%dLNS_LISdiffcum  = (1-alphaL_0)*alphaL_0*(epsilon/(1+epsilon))*( (((sLN_CD-sLN_0) + (wLISN_1*X1t6) + (wLISN_2*X2t6) + (LISN_G*Y_0*VGt6) + (LISN_AH*AH_0*VAHt6) + (LISN_BH*BH_0*VBHt6) + (LISN_AN*AN_0*VANt6) + (LISN_BN*BN_0*VBNt6))/sLN_0) - (( (sLH_CD-sLH_0) + (wLISH_1*X1t6) + (wLISH_2*X2t6) + (LISH_G*Y_0*VGt6) + (LISH_AH*AH_0*VAHt6) + (LISH_BH*BH_0*VBHt6) + (LISH_AN*AN_0*VANt6) + (LISH_BN*BN_0*VBNt6) )/sLH_0) )*100;
dLNS_NTsharecum  = (1-alphaL_0)*(epsilon/(1+epsilon))*(( (omegaYN_CD-omegaYN_0) + (womegaYN_1*X1t6) + (womegaYN_2*X2t6) + (omegaYN_G*Y_0*VGt6) )/omegaYN_0)*100;
dLNS_FBTCdiffcum = (1-alphaL_0)*alphaL_0*(epsilon/(1+epsilon))*( (1-sLN_0)*((1-sigmaN)/sigmaN)*( (( (BN_CD-BN_0) +  (VBNt6*BH_0) )/BN_0) - (( (AN_CD-AN_0) +  (VANt6*AN_0) )/AN_0) ) - (1-sLH_0)*((1-sigmaH)/sigmaH)*( (( (BH_CD-BH_0) +  (VBHt6*BH_0) )/BH_0) - (( (AH_CD-AH_0) +  (VAHt6*AH_0) )/AH_0) ) )*100;

dLISH_FBTCcum    = sLH_0*(1-sLH_0)*((1-sigmaH)/sigmaH)*( (( (BH_CD-BH_0) +  (VBHt6*BH_0) )/BH_0) - (( (AH_CD-AH_0) +  (VAHt6*AH_0) )/AH_0) )*100;
dLISH_capcum     = sLH_0*(1-sLH_0)*((1-sigmaH)/sigmaH)*(( (kH_CD-kH_0) + (wtildekH_1*X1t6) + (wtildekH_2*X2t6) + (tildekH_G*Y_0*VGt6) )/kH_0)*100;

dLISN_FBTCcum    = sLN_0*(1-sLN_0)*((1-sigmaN)/sigmaN)*( (( (BN_CD-BN_0) +  (VBNt6*BN_0) )/BN_0) - (( (AN_CD-AN_0) +  (VANt6*AN_0) )/AN_0) )*100;
dLISN_capcum     = sLN_0*(1-sLN_0)*((1-sigmaN)/sigmaN)*(( (kN_CD-kN_0) + (wtildekN_1*X1t6) + (wtildekN_2*X2t6) + (tildekN_G*Y_0*VGt6) )/kN_0)*100;

dLNScum_t         = cumsum(dLNScum);
dLNScum_CD      = dLNScum_t(6);
dtildeYHScum_t    = cumsum(dtildeYHScum);
dtildeYHScum_CD = dtildeYHScum_t(6);
dLISHcum_t        = cumsum(dLISHcum);
dLISHcum_CD     = dLISHcum_t(6);
dLISNcum_t        = cumsum(dLISNcum);
dLISNcum_CD     = dLISNcum_t(6);
dtildeYNScum_t    = cumsum(dtildeYNScum);
dtildeYNScum_CD = dtildeYNScum_t(6);   

dLISH_FBTCcum_t       = cumsum(dLISH_FBTCcum);
dLISH_FBTCcum_CD    = dLISH_FBTCcum_t(6);
dLISH_capcum_t        = cumsum(dLISH_capcum);
dLISH_capcum_CD     = dLISH_capcum_t(6);
dLISHcum_check_CD   = dLISH_FBTCcum_CD + dLISH_capcum_CD;

dLISN_FBTCcum_t       = cumsum(dLISN_FBTCcum);
dLISN_FBTCcum_CD    = dLISN_FBTCcum_t(6);
dLISN_capcum_t        = cumsum(dLISN_capcum);
dLISN_capcum_CD     = dLISN_capcum_t(6);
dLISNcum_check_CD   = dLISN_FBTCcum_CD + dLISN_capcum_CD;

dYHS_TFPdiffcum_t     = cumsum(dYHS_TFPdiffcum);
dYHS_TFPdiffcum_CD  = dYHS_TFPdiffcum_t(6);
dYHS_labdiffcum_t     = cumsum(dYHS_labdiffcum);
dYHS_labdiffcum_CD  = dYHS_labdiffcum_t(6);
dYHS_capdiffcum_t     = cumsum(dYHS_capdiffcum);
dYHS_capdiffcum_CD  = dYHS_capdiffcum_t(6);
dYHScum_check_CD    = dYHS_TFPdiffcum_CD + dYHS_labdiffcum_CD + dYHS_capdiffcum_CD;

dYNS_TFPdiffcum_t     = cumsum(dYNS_TFPdiffcum);                                            
dYNS_TFPdiffcum_CD  = dYNS_TFPdiffcum_t(6);                                               
dYNS_labdiffcum_t     = cumsum(dYNS_labdiffcum);                                            
dYNS_labdiffcum_CD  = dYNS_labdiffcum_t(6);                                               
dYNS_capdiffcum_t     = cumsum(dYNS_capdiffcum);                                            
dYNS_capdiffcum_CD  = dYNS_capdiffcum_t(6);                                               
dYNScum_check_CD    = dYNS_TFPdiffcum_CD + dYNS_labdiffcum_CD + dYNS_capdiffcum_CD; 

dLNS_LISdiffcum_t     = cumsum(dLNS_LISdiffcum);
dLNS_LISdiffcum_CD  = dLNS_LISdiffcum_t(6);
dLNS_NTsharecum_t     = cumsum(dLNS_NTsharecum);
dLNS_NTsharecum_CD  = dLNS_NTsharecum_t(6);
dLNS_FBTCdiffcum_t     = cumsum(dLNS_FBTCdiffcum);
dLNS_FBTCdiffcum_CD  = dLNS_FBTCdiffcum_t(6);
dLNScum_check_CD    = dLNS_LISdiffcum_CD + dLNS_NTsharecum_CD;

% Steady-state changes and impact effects - scaled to their initial values 
hatlambda_CD       = (dlambda/lambda_0)*100; 
dCoverY_CD         = ((PC_0*dC)/Y_0)*100; % Rate of change of the real consumption
dGNY_CD            = PN_0*(dGN/Y_0)*100; % Change in GN
dGHY_CD            = PH_0*(dGH/Y_0)*100; % Change in GH
dGFY_CD            = (dGF/Y_0)*100; % Change in GH
dGY_CD             = (dG/Y_0)*100; % Chane in G
hatL_CD            = (dL/L_0)*100; % Rate of change of employment
hatK_CD            = (dK/K_0)*100; % Rate of change of the stock of foreign assets
dLHoverL_CD        = (WH_0/W_0)*(dLH/L_0)*100; % Rate of change of LH
dLNoverL_CD        = (WN_0/W_0)*(dLN/L_0)*100; % Rate of change of LN
dLHLN_CD           = (WH_0/WN_0)*((LH/LN)-(LH_0/LN_0))*100; %  Change of LH/LN
hatPH_CD           = (dPH/PH_0)*100; % Rate of change of PH
hatPN_CD           = (dPN/PN_0)*100; % Rate of change of PN
hatP_CD            = (dP/P_0)*100; % Rate of change of PN/PH
dBoverY_CD         = (dB/Y_0)*100; % Rate of change of the stock of foreign assets
dAoverY_CD         = (dA/Y_0)*100; % Rate of change of the stock of financial assets
hatW_CD            = (dW/W_0)*100; % Rate of change of wage
hatWPC_CD          = (dWPC/WPC_0)*100; % Rate of change of Real Aggregate Wage W/pc
hatY_CD            = (dY/Y_0)*100; % Rate of change of GDP
hatYR_CD           = ((YR-Y_0)/Y_0)*100; % Rate of change of Real GDP
dYHoverY_CD        = (PH_0*dYH/Y_0)*100; % Rate of change of YH
dYNoverY_CD        = (PN_0*dYN/Y_0)*100; % Rate of change of YN
dYHYN_CD           = (PH_0/PN_0)*((YH/YN)-(YH_0/YN_0))*100; % Rate of change of YH/YN
hatWH_CD           = (dWH/WH_0)*100; % Rate of change of WH
hatWN_CD           = (dWN/WN_0)*100; % Rate of change of WN
hatOmega_CD        = (dOmega/Omega_0)*100; % Rate of change of omega
hatWHPC_CD         = (dWHPC/WHPC_0)*100; % Rate of change of WH/PC
hatWNPC_CD         = (dWNPC/WNPC_0)*100; % Rate of change of WN/PC
dkH_CD             = LH_0*(dkH/K_0)*100; % Rate of change of kH
dkN_CD             = LN_0*(dkN/K_0)*100; % Rate of change of kN
dLHS_CD            = (WH_0/W_0)*((LH/L)-(LH_0/L_0))*100; % change in  the labor share of T
dLNS_CD            = (WN_0/W_0)*((LN/L)-(LN_0/L_0))*100; % change in the labor share of NT
dYHS_CD            = PH_0*((YH/YR)-(YH_0/YR_0))*100; % change in the output share of T
dYNS_CD            = PN_0*((YN/YR)-(YN_0/YR_0))*100; % change in the output share of NT
dLISH_CD           = (sLH_CD-sLH_0)*100; % Change in the labor income share H
dLISN_CD           = (sLN_CD-sLN_0)*100; % Change in the labor income share N
dWHW_CD            = (((WH/W)-(WH_0/W_0))/((WH_0/W_0)))*100; % Change in the relative wage H
dWNW_CD            = (((WN/W)-(WN_0/W_0))/((WH_0/W_0)))*100; % Change in the relative wage N
dKHK_CD            = ((KH/K)-(KH_0/K_0))*100; % Change in the capital share of H
dKNK_CD            = ((KN/K)-(KN_0/K_0))*100; % Change in the capital share of N

disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                    Final Steady State with kH > kN');
disp('                           The Benchmark: ');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (benchmark)');
disp(sprintf('thetaH  : %5.2f   thetaN   : %5.2f',thetaH,thetaN));
disp(sprintf('sigmaC  : %5.2f   phi      : %5.2f  varphi : %5.2f',sigmaC,phi,varphi));
disp(sprintf('rho     : %5.2f   varphiH  : %5.2f ',rho,varphiH));
disp(sprintf('phiI    : %5.2f   iota     : %5.2f ',phiI,iota)); 
disp(sprintf('rhoI    : %5.2f   iotaH    : %5.2f ',rhoI,iotaH))
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f ',sigmaL,gammaL));
disp(sprintf('epsilon : %5.2f   vartheta : %5.2f',epsilon,vartheta));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('ZH      : %5.2f   ZN       : %5.2f',ZH,ZN));
disp(sprintf('TFPH    : %5.2f   TFPN     : %5.2f',TFPH,TFPN));
disp(sprintf('omegaYH : %5.2f   Z        : %5.2f TFP        : %5.2f',omegaYH,Z,TFP));
disp(sprintf('GH      : %5.2f   GN       : %5.2f',GH,GN));
disp(sprintf('GF      : %5.2f   G        : %5.2f',GF,G));
disp(' ');

disp(' ');
disp('The production side (benchmark)');
disp(sprintf('kH       : %9.3f    kN   : %9.3f',kH,kN));
disp(sprintf('LH       : %9.3f    LN   : %9.3f',LH,LN));
disp(sprintf('KH       : %9.3f    KN   : %9.3f',KH,KN));
disp(sprintf('YH       : %9.3f    YN   : %9.3f',YH,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('L_check  : %9.3f   ',L_check));
disp(sprintf('alphaL   : %9.3f   ',alphaL));

disp(' ');
disp('The demand side (benchmark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('CT       :   %7.3f  CT_check : %9.3f',CT,CT_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('PT       :   %7.3f    alphaH : %9.3f',PT,alphaH));
disp(sprintf('CH       :   %7.3f    CN     : %9.3f',CH,CN));
disp(sprintf('CF       :   %7.3f',CF));


disp('The demand side (benchmark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('PIT      :   %7.3f   alphaIH : %9.3f',PIT,alphaIH));
disp(sprintf('IH       :   %7.3f    IN     : %9.3f IF     : %9.3f',IH,IN,IF));
disp(sprintf('EI       :   %7.3f    EIT    : %9.3f',EI,EIT));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector H');
disp(sprintf('Gross output (YH)  : %9.3f',YH));
disp(sprintf('WH                 : %9.3f',WH));
disp(sprintf('Profit             : %9.10f',PiH));

disp(' ');
disp('Wealth');
disp(sprintf('K      :   %5.3f    B  :   %5.6f',K,B));
disp(sprintf('lambda :   %5.15f   A  :   %5.3f',lambda,A));
disp(sprintf('Sav    :   %5.10f   CA :   %5.10f',Sav,CA));

disp('Linearization');
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_Q : %5.4f',Upsilon_K,Upsilon_Q));
disp(sprintf('Sigma_K   :  %5.4f  Sigma_Q   : %5.4f',Sigma_K,Sigma_Q));
disp(sprintf('Upsilon_G :  %5.4f  Sigma_G   : %5.4f',Upsilon_G,Sigma_G));
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));
disp(sprintf('B_G       :  %5.4f  A_G       : %5.4f',B_G,A_G));
disp(sprintf('A_K       :  %5.4f  A_Q       : %5.4f',A_K,A_Q));

disp(' ');
disp('Eigenvalues and Eigenvectors');
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu_1,nu_2));
disp(sprintf('N1         :   %5.6f    H1       : %5.6f',N1,H1));
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));

disp('Eigenvectors');
disp(sprintf('omega11    :   %5.6f  omega12    : %5.6f',omega_11,omega_12));
disp(sprintf('omega21    :   %5.6f  omega22    : %5.6f',omega_21,omega_22));

disp('Partial derivatives of Lj'); 
disp(sprintf('LN_Q       :   %7.6f  LH_Q       : %9.6f',LN_Q,LH_Q));         
disp(sprintf('LN_K       :   %7.6f  LH_K       : %9.6f',LN_K,LH_K));         
disp(sprintf('LN_G       :   %7.6f  LH_G       : %9.6f',LN_G,LH_G));         
                                                                               
disp('Partial derivatives of Lj/L');                                        
disp(sprintf('LNS_Q       :   %7.6f  LHS_Q       : %9.6f',LNS_Q,LHS_Q));     
disp(sprintf('LNS_K       :   %7.6f  LHS_K       : %9.6f',LNS_K,LHS_K));     
disp(sprintf('LNS_G       :   %7.6f  LHS_G       : %9.6f',LNS_G,LHS_G));     

disp('Partial derivatives of Yj');                                                          
disp(sprintf('YN_Q       :   %7.6f  YH_Q       : %9.6f',YN_Q,YH_Q));                        
disp(sprintf('YN_K       :   %7.6f  YH_K       : %9.6f',YN_K,YH_K));                        
disp(sprintf('YN_G       :   %7.6f  YH_G       : %9.6f',YN_G,YH_G));                                             
                                                                                            
disp('Partial derivatives of tildeYj');                                                     
disp(sprintf('tildeYN_Q       :   %7.6f  tildeYH_Q       : %9.6f',tildeYN_Q,tildeYH_Q));    
disp(sprintf('tildeYN_K       :   %7.6f  tildeYH_K       : %9.6f',tildeYN_K,tildeYH_K));    
disp(sprintf('tildeYN_G       :   %7.6f  tildeYH_G       : %9.6f',tildeYN_G,tildeYH_G));        

disp('Partial derivatives of Yj/YR');                                                             
disp(sprintf('YNS_Q       :   %7.6f  YHS_Q       : %9.6f',YNS_Q,YHS_Q));                          
disp(sprintf('YNS_K       :   %7.6f  YHS_K       : %9.6f',YNS_K,YHS_K));                          
disp(sprintf('YNS_G       :   %7.6f  YHS_G       : %9.6f',YNS_G,YHS_G));    

disp('Partial derivatives of tildeYj/tildeYR');                                                   
disp(sprintf('tildeYNS_Q       :   %7.6f  tildeYHS_Q       : %9.6f',tildeYNS_Q,tildeYHS_Q));      
disp(sprintf('tildeYNS_K       :   %7.6f  tildeYHS_K       : %9.6f',tildeYNS_K,tildeYHS_K));      
disp(sprintf('tildeYNS_G       :   %7.6f  tildeYHS_G       : %9.6f',tildeYNS_G,tildeYHS_G));      

disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('YH / Y    :  %5.3f      PN*YN / Y  : %5.3f',omegaYH,omegaYN));
disp(sprintf('LH / L    :  %5.3f      LN / L    : %5.3f',omegaLH,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('PN*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GH / YH     :  %5.3f  GN / YN    :  %5.3f  (PN*GN)/G  : %5.3f',omegaGHYH,omegaGNYN,omegaGN));
disp(sprintf('(PH*GH)/G   :  %5.3f  GF / G     :  %5.3f  GT/G       : %5.3f',omegaGH,omegaGF,omegaGT));
disp(sprintf('IN / YN     :  %5.3f  IH / YH    :  %5.3f  (r*B)/Y    : %5.3f',omegaINYN,omegaIHYH,omegaB));
disp(sprintf('IF / YH     :  %5.3f  GF / YH    :  %5.3f',omegaIFYH,omegaGFYH));
disp(sprintf('WN*LN/W*L   :  %5.3f RN*KN/R*K   :  %5.3f',alphaL,alphaK));
disp(sprintf('PIT*IT/PI*I :  %5.3f PT*CT/PC*C  :  %5.3f',alphaI,alphaC));
disp(sprintf('PH*IH/PT*IT :  %5.3f PH*CH/PT*CT :  %5.3f',alphaIH,alphaH));
disp(sprintf('PH*IH/PI*I  :  %5.3f PH*CH/PC*C  :  %5.3f',omegaIH,omegaCH));
disp(sprintf('IF/PI*I     :  %5.3f    CF/PC*C  :  %5.3f',omegaIF,omegaCF));
disp(sprintf('W*L/Y       :  %5.3f R*K/Y       :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y         :  %5.3f',omegaKY));
disp(' ');
disp(' ');
disp(sprintf('Marginal product of KH = RT       : %9.16f   ',cond1));
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));
disp(sprintf('Marginal product of LH = WH       : %9.16f   ',cond3));
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));
disp(sprintf('Resource contraint for capital    : %9.16f   ',cond5));
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));
disp(sprintf('Market clearing condition good H  : %9.16f   ',cond8));
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));
disp(sprintf('Relative labor  LH/LN             : %9.16f   ',cond12));
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));
disp(sprintf('FOC -V_L*(dL/dLH) = lambda*WH     : %9.16f   ',cond16));
disp(sprintf('FOC -V_L*(dL/dLN) = lambda*WN     : %9.16f   ',cond17));
disp(sprintf('Global market clearing condition  : %9.16f   ',cond18));
disp(sprintf('Private Savings                   : %9.16f   ',cond19));
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond20));
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond21));
disp(sprintf('Investment expenditure check      : %9.16f   ',cond22));
disp(sprintf('Capital income R*K                : %9.16f   ',cond23));
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond24));
disp(sprintf('relative consumption  CH/CF       : %9.16f   ',cond25));
disp(sprintf('Consumption expenditure in T PT*CT: %9.16f   ',cond26));
disp(sprintf('relative investment   IH/IF       : %9.16f   ',cond27));
disp(sprintf('Investment expenditure in T PIT*JT: %9.16f   ',cond28));
disp(sprintf('Current account                   : %9.16f   ',cond29));
disp(sprintf('Current account                   : %9.16f   ',cond30));


disp('-------------------------------------------------------------------------------------------------------- ');
disp('                       Increase in gN : Impact and Steady State Changes (after a rise in gN)     ');
disp('-------------------------------------------------------------------------------------------------------- ');
disp('-------------------------------------------------------------------------------------------------------- ');
disp('                               |     Temporary   |');
disp('-------------------------------------------------------------------------------------------------------- ');
disp(' ');

disp(' ');
disp(' Steady State Deviations ( = (x-x0)/x0 where x0 is the value of x at the initial steady state)  ');
disp(sprintf('hatlambda_CD        :         |           |%10.3f',hatlambda_CD));
disp(sprintf('dGY_CD              :         |           |%10.3f',dGY_CD));
disp(sprintf('dGHY_CD             :         |           |%10.3f',dGHY_CD));
disp(sprintf('dGNY_CD             :         |           |%10.3f',dGNY_CD));
disp(sprintf('dCoverY_CD          :         |           |%10.3f',dCoverY_CD));
disp(sprintf('dLoverL_CD          :         |           |%10.3f',hatL_CD));
disp(sprintf('dYRoverY_CD         :         |           |%10.3f',hatYR_CD));
disp(sprintf('dKoverK_CD          :         |           |%10.3f',hatK_CD));
disp(sprintf('dLHoverL_CD         :         |           |%10.3f',dLHoverL_CD));
disp(sprintf('dLNover_CD          :         |           |%10.3f',dLNoverL_CD));
disp(sprintf('dLHLN_CD            :         |           |%10.3f',dLHLN_CD));
disp(sprintf('dYHoverY_CD         :         |           |%10.3f',dYHoverY_CD));
disp(sprintf('dYNoverY_CD         :         |           |%10.3f',dYNoverY_CD));
disp(sprintf('dYHYN_CD            :         |           |%10.3f',dYHYN_CD));
disp(sprintf('hatPH_CD            :         |           |%10.3f',hatPH_CD));
disp(sprintf('hatPN_CD            :         |           |%10.3f',hatPN_CD));
disp(sprintf('hatP_CD             :         |           |%10.3f',hatP_CD));
disp(sprintf('dBoverY_CD          :         |           |%10.3f',dBoverY_CD));
disp(sprintf('dAoverY_CD          :         |           |%10.3f',dAoverY_CD));
disp(sprintf('dWoverW_CD          :         |           |%10.3f',hatW_CD));
disp(sprintf('dWPCoverWPC_CD      :         |           |%10.3f',hatWPC_CD));
disp(sprintf('dWHoverWH_CD        :         |           |%10.3f',hatWH_CD));
disp(sprintf('dWNoverWN_CD        :         |           |%10.3f',hatWN_CD));
disp(sprintf('hatOmega_CD         :         |           |%10.3f',hatOmega_CD));
disp(sprintf('dWHPCoverWHPC_CD    :         |           |%10.3f',hatWHPC_CD));
disp(sprintf('dWNPCoverWNPC_CD    :         |           |%10.3f',hatWNPC_CD));
disp(sprintf('dkHoverK_CD         :         |           |%10.3f',dkH_CD));
disp(sprintf('dkNoverK_CD         :         |           |%10.3f',dkN_CD));
disp(sprintf('dLHS_CD             :         |           |%10.3f',dLHS_CD));
disp(sprintf('dLNS_CD             :         |           |%10.3f',dLNS_CD));
disp(sprintf('dYHS_CD             :         |           |%10.3f',dYHS_CD));
disp(sprintf('dYNS_CD             :         |           |%10.3f',dYNS_CD));
disp(sprintf('dLISH_CD            :         |           |%10.3f',dLISH_CD));
disp(sprintf('dLISN_CD            :         |           |%10.3f',dLISN_CD));
disp(sprintf('dWHW_CD             :         |           |%10.3f',dWHW_CD));
disp(sprintf('dWNW_CD             :         |           |%10.3f',dWNW_CD));

%disp(' ');
disp('                                           Initial responses ');
disp(sprintf('dGYtime0_CD        :                |                 |%10.3f',dGYtime0_CD));
disp(sprintf('dGHYtime0_CD       :                |                 |%10.3f',dGHYtime0_CD));
disp(sprintf('dGNYtime0_CD       :                |                 |%10.3f',dGNYtime0_CD));
disp('                                           Initial responses ');
disp(sprintf('dCYtime0_CD        :                |                 |%10.3f',dCYtime0_CD));
disp(sprintf('dLtime0_CD         :                |                 |%10.3f',dLtime0_CD));
disp(sprintf('dLHtime0_CD        :                |                 |%10.3f',dLHtime0_CD));
disp(sprintf('dLNtime0_CD        :                |                 |%10.3f',dLNtime0_CD));
disp(sprintf('dLHLNtime0_CD      :                |                 |%10.3f',dLHLNtime0_CD));
disp(sprintf('dYRtime0_CD        :                |                 |%10.3f',dYRtime0_CD));
disp(sprintf('dYHtime0_CD        :                |                 |%10.3f',dYHtime0_CD));
disp(sprintf('dYNtime0_CD        :                |                 |%10.3f',dYNtime0_CD));
disp(sprintf('dYHYNtime0_CD      :                |                 |%10.3f',dYHYNtime0_CD));
disp(sprintf('dPHtime0_CD        :                |                 |%10.3f',dPHtime0_CD));
disp(sprintf('dPNtime0_CD        :                |                 |%10.3f',dPNtime0_CD));
disp(sprintf('dPtime0_CD         :                |                 |%10.3f',dPtime0_CD));
disp(sprintf('dSYtime0_CD        :                |                 |%10.3f',SYtime0_CD));
disp(sprintf('dIYtime0_CD        :                |                 |%10.3f',IYtime0_CD));
disp(sprintf('dCAYtime0_CD       :                |                 |%10.5f',CAYtime0_CD)); 
disp(sprintf('dCAYtime0_CD_check :                |                 |%10.5f',CAYtime0_CD_check)); 
fprintf('dWtime0_CD         :                |                 |%10.3f\n',dWtime0_CD);
disp(sprintf('dWPCtime0_CD       :                |                 |%10.3f',dWPCtime0_CD));
disp(sprintf('dWHtime0_CD        :                |                 |%10.3f',dWHtime0_CD));
disp(sprintf('dWNtime0_CD        :                |                 |%10.3f',dWNtime0_CD));
disp(sprintf('dOmegatime0_CD     :                |                 |%10.3f',dOmegatime0_CD));
disp(sprintf('dWHPCtime0_CD      :                |                 |%10.3f',dWHPCtime0_CD));
disp(sprintf('dWNPCtime0_CD      :                |                 |%10.3f',dWNPCtime0_CD));
disp(sprintf('dkHKtime0_CD       :                |                 |%10.3f',dkHtime0_CD));
disp(sprintf('dkNKtime0_CD       :                |                 |%10.3f',dkNtime0_CD));
disp(sprintf('dLHStime0_CD       :                |                 |%10.3f',dLHStime0_CD));
disp(sprintf('dLNStime0_CD       :                |                 |%10.3f',dLNStime0_CD));
disp(sprintf('dYHStime0_CD       :                |                 |%10.3f',dYHStime0_CD));
disp(sprintf('dYNStime0_CD       :                |                 |%10.3f',dYNStime0_CD));
disp(sprintf('dWHWtime0_CD       :                |                 |%10.3f',dWHWtime0_CD));
disp(sprintf('dWNWtime0_CD       :                |                 |%10.3f',dWNWtime0_CD));
disp(sprintf('dLISHtime0_CD      :                |                 |%10.3f',dLISHtime0_CD));
disp(sprintf('dLISNtime0_CD      :                |                 |%10.3f',dLISNtime0_CD));
disp(sprintf('dKHKtime0_CD       :                |                 |%10.3f',dKHKtime0_CD));   
disp(sprintf('dKNKtime0_CD       :                |                 |%10.3f',dKNKtime0_CD)); 
disp(sprintf('dRtime0_CD         :                |                 |%10.3f',dRtime0_CD));
disp(sprintf('dRPHtime0_CD       :                |                 |%10.3f',dRPHtime0_CD));   
disp(sprintf('dRPNtime0_CD       :                |                 |%10.3f',dRPNtime0_CD));

disp('                Initial responses including capital and technology utilization rates');
disp(sprintf('duKHtime0_CD            :                |                 |%10.3f',duKHtime0_CD));     
disp(sprintf('duKNtime0_CD            :                |                 |%10.3f',duKNtime0_CD));     
disp(sprintf('duKtime0_CD             :                |                 |%10.3f',duKtime0_CD));      
disp(sprintf('duZHtime0_CD            :                |                 |%10.3f',duZHtime0_CD));     
disp(sprintf('duZNtime0_CD            :                |                 |%10.3f',duZNtime0_CD));     
disp(sprintf('dtildeZHtime0_CD        :                |                 |%10.3f',dtildeZHtime0_CD)); 
disp(sprintf('dtildeZNtime0_CD        :                |                 |%10.3f',dtildeZNtime0_CD)); 
disp(sprintf('dtildeZtime0_CD         :                |                 |%10.3f',dtildeZtime0_CD)); 
disp(sprintf('dTFPHtime0_CD           :                |                 |%10.3f',dTFPHtime0_CD));
disp(sprintf('dTFPNtime0_CD           :                |                 |%10.3f',dTFPNtime0_CD));
disp(sprintf('dTFPtime0_CD            :                |                 |%10.3f',dTFPtime0_CD));
disp(sprintf('dTFPHtime0_check_CD     :                |                 |%10.3f',dTFPHtime0_check_CD));
disp(sprintf('dTFPNtime0_check_CD     :                |                 |%10.3f',dTFPNtime0_check_CD));
disp(sprintf('dTFPRtime0_CD           :                |                 |%10.3f',dTFPRtime0_CD));
disp(sprintf('duZRtime0_CD            :                |                 |%10.3f',duZRtime0_CD));
disp(sprintf('dtildeYRtime0_CD        :                |                 |%10.3f',dtildeYRtime0_CD));               
disp(sprintf('dtildeYHtime0_CD        :                |                 |%10.3f',dtildeYHtime0_CD));               
disp(sprintf('dtildeYNtime0_CD        :                |                 |%10.3f',dtildeYNtime0_CD));               
disp(sprintf('dtildeYHYNtime0_CD      :                |                 |%10.3f',dtildeYHYNtime0_CD));             
disp(sprintf('dtildeWtime0_CD         :                |                 |%10.3f',dtildeWtime0_CD));                
disp(sprintf('dtildeWPCtime0_CD       :                |                 |%10.3f',dtildeWPCtime0_CD));              
disp(sprintf('dtildeWHtime0_CD        :                |                 |%10.3f',dtildeWHtime0_CD));               
disp(sprintf('dtildeWNtime0_CD        :                |                 |%10.3f',dtildeWNtime0_CD));               
disp(sprintf('dtildeOmegatime0_CD     :                |                 |%10.3f',dtildeOmegatime0_CD));            
disp(sprintf('dtildeWHPCtime0_CD      :                |                 |%10.3f',dtildeWHPCtime0_CD));             
disp(sprintf('dtildeWNPCtime0_CD      :                |                 |%10.3f',dtildeWNPCtime0_CD));             
disp(sprintf('dtildekHKtime0_CD       :                |                 |%10.3f',dtildekHtime0_CD));               
disp(sprintf('dtildekNKtime0_CD       :                |                 |%10.3f',dtildekNtime0_CD));               
disp(sprintf('dtildeYHStime0_CD       :                |                 |%10.3f',dtildeYHStime0_CD));              
disp(sprintf('dtildeYNStime0_CD       :                |                 |%10.3f',dtildeYNStime0_CD));              
disp(sprintf('dtildeWHWtime0_CD       :                |                 |%10.3f',dtildeWHWtime0_CD));              
disp(sprintf('dtildeWNWtime0_CD       :                |                 |%10.3f',dtildeWNWtime0_CD));     
disp(sprintf('dtildeRPHtime0_CD       :                |                 |%10.3f',dtildeRPHtime0_CD)); 
disp(sprintf('dtildeRPNtime0_CD       :                |                 |%10.3f',dtildeRPNtime0_CD));

disp('Decomposition of sectoral shares: cumul t=0');
disp('Decomposition of tildeYH/tildeYR');                                                                                                                
disp(sprintf('dtildeYHStime0_CD       :                |                 |%10.3f',dtildeYHStime0_CD));            
disp(sprintf('dYHS_TFPdifftime0_CD    :                |                 |%10.3f',dYHS_TFPdifftime0_CD));         
disp(sprintf('dYHS_labdifftime0_CD    :                |                 |%10.3f',dYHS_labdifftime0_CD));         
disp(sprintf('dYHS_capdifftime0_CD    :                |                 |%10.3f',dYHS_capdifftime0_CD));         
disp(sprintf('dtildeYHStime0_check_CD :                |                 |%10.3f',dYHStime0_check_CD));   
disp('Decomposition of tildeYN/tildeYR');      
disp(sprintf('dtildeYNStime0_CD       :                |                 |%10.3f',dtildeYNStime0_CD));     
disp(sprintf('dYNS_TFPdifftime0_CD    :                |                 |%10.3f',dYNS_TFPdifftime0_CD));  
disp(sprintf('dYNS_labdifftime0_CD    :                |                 |%10.3f',dYNS_labdifftime0_CD));  
disp(sprintf('dYNS_capdifftime0_CD    :                |                 |%10.3f',dYNS_capdifftime0_CD));  
disp(sprintf('dtildeYNStime0_check_CD :                |                 |%10.3f',dYNStime0_check_CD)); 
disp('Decomposition of LN/L');                                                                                                                    
disp(sprintf('dLNStime0_CD            :                |                 |%10.3f',dLNStime0_CD));           
disp(sprintf('dLNS_NTsharetime0_CD    :                |                 |%10.3f',dLNS_NTsharetime0_CD));   
disp(sprintf('dLNS_LISdifftime0_CD    :                |                 |%10.3f',dLNS_LISdifftime0_CD));   
disp(sprintf('dLNS_FBTCdifftime0_CD   :                |                 |%10.3f',dLNS_FBTCdifftime0_CD));  
disp(sprintf('dLNStime0_check_CD      :                |                 |%10.3f',dLNStime0_check_CD));               
disp('Decomposition of LISH');                                                                                                                    
disp(sprintf('dLISHtime0_CD           :                |                 |%10.3f',dLISHtime0_CD));        
disp(sprintf('dLISH_FBTCtime0_CD      :                |                 |%10.3f',dLISH_FBTCtime0_CD));   
disp(sprintf('dLISH_captime0_CD       :                |                 |%10.3f',dLISH_captime0_CD));    
disp(sprintf('dLISHtime0_check_CD     :                |                 |%10.3f',dLISHtime0_check_CD));              
disp('Decomposition of LISH');                                                                                                                      
disp(sprintf('dLISNtime0_CD           :                |                 |%10.3f',dLISNtime0_CD));                
disp(sprintf('dLISN_FBTCtime0_CD      :                |                 |%10.3f',dLISN_FBTCtime0_CD));           
disp(sprintf('dLISN_captime0_CD       :                |                 |%10.3f',dLISN_captime0_CD));            
disp(sprintf('dLISNtime0_check_CD     :                |                 |%10.3f',dLISNtime0_check_CD));   

disp('Decomposition of sectoral shares: cumul t=0..5');  
disp('Decomposition of tildeYH/tildeYR');                                                                         
disp(sprintf('dtildeYHScum_CD       :                |                 |%10.3f',dtildeYHScum_CD));            
disp(sprintf('dYHS_TFPdiffcum_CD    :                |                 |%10.3f',dYHS_TFPdiffcum_CD));         
disp(sprintf('dYHS_labdiffcum_CD    :                |                 |%10.3f',dYHS_labdiffcum_CD));         
disp(sprintf('dYHS_capdiffcum_CD    :                |                 |%10.3f',dYHS_capdiffcum_CD));         
disp(sprintf('dtildeYHScum_check_CD :                |                 |%10.3f',dYHScum_check_CD)); 
disp('Decomposition of tildeYN/tildeYR');      
disp(sprintf('dtildeYNScum_CD       :                |                 |%10.3f',dtildeYNScum_CD));    
disp(sprintf('dYNS_TFPdiffcum_CD    :                |                 |%10.3f',dYNS_TFPdiffcum_CD)); 
disp(sprintf('dYNS_labdiffcum_CD    :                |                 |%10.3f',dYNS_labdiffcum_CD)); 
disp(sprintf('dYNS_capdiffcum_CD    :                |                 |%10.3f',dYNS_capdiffcum_CD)); 
disp(sprintf('dtildeYNScum_check_CD :                |                 |%10.3f',dYNScum_check_CD));  
disp('Decomposition of LN/L');                                                                                    
disp(sprintf('dLNScum_CD            :                |                 |%10.3f',dLNScum_CD));                 
disp(sprintf('dLNS_NTsharecum_CD    :                |                 |%10.3f',dLNS_NTsharecum_CD));         
disp(sprintf('dLNS_LISdiffcum_CD    :                |                 |%10.3f',dLNS_LISdiffcum_CD));         
disp(sprintf('dLNS_FBTCdiffcum_CD   :                |                 |%10.3f',dLNS_FBTCdiffcum_CD));        
disp(sprintf('dLNScum_check_CD      :                |                 |%10.3f',dLNScum_check_CD));           
disp('Decomposition of LISH');                                                                                    
disp(sprintf('dLISHcum_CD           :                |                 |%10.3f',dLISHcum_CD));                
disp(sprintf('dLISH_FBTCcum_CD      :                |                 |%10.3f',dLISH_FBTCcum_CD));           
disp(sprintf('dLISH_capcum_CD       :                |                 |%10.3f',dLISH_capcum_CD));            
disp(sprintf('dLISHcum_check_CD     :                |                 |%10.3f',dLISHcum_check_CD));          
disp('Decomposition of LISH');                                                                                    
disp(sprintf('dLISNcum_CD           :                |                 |%10.3f',dLISNcum_CD));                
disp(sprintf('dLISN_FBTCcum_CD      :                |                 |%10.3f',dLISN_FBTCcum_CD));           
disp(sprintf('dLISN_capcum_CD       :                |                 |%10.3f',dLISN_capcum_CD));            
disp(sprintf('dLISNcum_check_CD     :                |                 |%10.3f',dLISNcum_check_CD));      

                                                                                                                     
disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
%disp(sprintf('nuX  : %5.3f',nuX_tot));
disp(sprintf('YH / Y    :  %5.3f     PN*YN / Y  : %5.3f',omegaYH_0,omegaYN_0));
disp(sprintf('LH / L    :  %5.3f      LN / L    : %5.3f',omegaLH_0,omegaLN_0));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC_0,omegaNX_0));
disp(sprintf('PI*I / Y  :  %5.3f      G / Y     : %5.3f',omegaI_0,omegaG_0));
disp(' ');
disp(sprintf('GH / YH     :  %5.3f  GN / YN    :  %5.3f  (PN*GN)/G  : %5.3f',omegaGHYH_0,omegaGNYN_0,omegaGN_0));
disp(sprintf('(PH*GH)/G   :  %5.3f  GF / G     :  %5.3f    GT/G     : %5.3f',omegaGH_0,omegaGF_0,omegaGT_0));
disp(sprintf('IN / YN     :  %5.3f  IH / YH    :  %5.3f',omegaINYN_0,omegaIHYH_0));
disp(sprintf('IF / YH     :  %5.3f  GF / YH    :  %5.3f',omegaIFYH_0,omegaGFYH_0))
disp(sprintf('WN*LN/W*L   :  %5.3f RN*KN/R*K   :  %5.3f',alphaL_0,alphaK_0));
disp(sprintf('PT*IT/PI*I  :  %5.3f PT*CT/PC*C  :  %5.3f',alphaI_0,alphaC_0));
disp(sprintf('PH*IH/PT*IT :  %5.3f PH*CH/PT*CT :  %5.3f',alphaIH_0,alphaH_0));
disp(sprintf('PH*IH/PI*I  :  %5.3f PH*CH/PC*C  :  %5.3f',omegaIH_0,omegaCH_0));
disp(sprintf('IF/PI*I     :  %5.3f    CF/PC*C  :  %5.3f',omegaIF_0,omegaCF_0));
disp(sprintf('PH*XH/Y     :  %5.3f    XH / YH  :  %5.3f',omegaXHY_0,omegaXHYH_0));
disp(sprintf('W*L/PN*Y    :  %5.3f R*K/PN*Y    :  %5.3f',omegaL_0,omegaK_0));
disp(sprintf('K/Y         :  %5.3f (r*B)/Y     :  %5.3f',omegaKY_0,omegaB_0));
disp(' ');
disp(sprintf('A_0       :  %5.4f  A_G       : %5.4f GF_G       : %5.4f',A_0,A_G,GF_G));
disp(sprintf('A_K       :  %5.4f  A_Q       : %5.4f',A_K,A_Q));
disp(sprintf('L1        :  %5.4f  L2        : %5.4f',L1,L2));
disp(sprintf('wA1       :  %5.4f  wAG2      : %5.4f',wA1,wAG2));
disp(sprintf('GammaG1   :  %5.4f  GammaG2   : %5.4f',GammaG_1,GammaG_2));
disp(sprintf('VBG1prime0:  %5.4f VBG2prime0 : %5.4f VBGprime0   : %5.4f',VBG1prime0,VBG2prime0,VBGprime0));


%clear