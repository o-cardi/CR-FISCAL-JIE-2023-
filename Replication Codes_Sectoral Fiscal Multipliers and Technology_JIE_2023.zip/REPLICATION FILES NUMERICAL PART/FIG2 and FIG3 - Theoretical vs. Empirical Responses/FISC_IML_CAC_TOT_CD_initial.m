global sigmaC phi varphi rho varphiH
global phiI iota rhoI iotaH 
global ex nuX
global epsilon vartheta 
global gammaL sigmaL
global r deltaK kappa
global thetaH thetaN
global omegaG omegaGN omegaGH %GH GN GF
%global xi1H xi1N chi1H chi1N
global xi2H xi2N chi2H chi2N
global B0 K0 ZH ZN  

% Maxim duration for graphics
Tg = 10;
       
% Minim duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% Cobb-Douglas    %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ZH_0         = 1.00;  
ZN_0         = 1.00;
omegaG       = 0.191; 
omegaGN      = 0.8; 
omegaGH      = 0.9;
thetaH_0     = 0.631; 
thetaN_0     = 0.687; 
sigmaL_0     = 1; 
gammaL       = 1; 
sigmaC_0     = 1;  
phi_0        = 0.77;
varphi_0     = 0.463; 
rho_0        = 1.5;  
varphiH_0    = 0.734; 
epsilon_0    = 0.83; 
vartheta_0   = 0.405;
phiI_0       = 1.000001;                    
iota_0       = 0.31;  
rhoI_0       = 1.5;  
iotaH_0      = 0.517; 
kappa        = 17; 
ex           = 1; 
nuX          = 1.7;

r            = 0.03; 
beta         = r; 
deltaK       = 0.078;

B0           = 0;
K0           = 0;

ZH           = ZH_0;       
ZN           = ZN_0;       
thetaH       = thetaH_0;   
thetaN       = thetaN_0;   
sigmaC       = sigmaC_0;  
sigmaL       = sigmaL_0;   
phi          = phi_0;     
varphi       = varphi_0;  
rho          = rho_0;     
varphiH      = varphiH_0;
phiI         = phiI_0;    
iota         = iota_0; 
rhoI         = rhoI_0;    
iotaH        = iotaH_0;
epsilon      = epsilon_0;  
vartheta     = vartheta_0;   

filename = 'Calibration_Shock_2021_recons';                                                                                            
sheet    = 8;                                                                                                                                          
xlRange  = 'C3:K5';                                                                                                                                 
parameters = xlsread(filename,sheet,xlRange)                                                                                                                                                                                                                                               
chi2H    = 0.8; %0.7 technology utilization adjustment cost in the traded sector                                                                                                                          
chi2N    = 2.85;  % technology utilization adjustment cost in the non-traded sector                                                                                                                         
xi2H     = 0.27;  %0.27 capital utilization adustment costs in the traded sector                                                                                                                              
xi2N     = 0.03;  %0.02 capital utilization adustment costs in the non-traded sector
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C_ini        = 1.367  ; % Consumption 
L_ini        = 1.054  ; % Labor supply 
kH_ini       = 6.137  ; % Capital-labor ratio in sector H
WH_ini       = 3.382  ; % Wage rate in sector H
WN_ini       = 3.809  ; % Wage rate in sector N
W_ini        = 3.644  ; % Aggregate wage index
kN_ini       = 5.411  ; % Capital-labor ratio in sector N
PN_ini       = 2.881  ; % Relative price of non tradables
K_ini        = 5.978  ; % Stock of capital
PH_ini       = 2.295  ; % Terms of trade
B_ini        = 0.028  ; % Stock of traded Bonds
alphaL_ini   = 0.345  ; % Non tradable share of compensation of employees
PC_ini       = 2.400  ; % Aggregate consumption price index
PT_ini       = 1.959  ; % Consumption price index for tradables
CN_ini       = 0.631  ; % Consumption in non tradables 
CH_ini       = 0.495  ; % Consumption in tradables 
CF_ini       = 0.328  ; % Consumption in foreign goods 
alphaC_ini   = 0.446  ; % Tradable content of consumption expenditure
alphaH_ini   = 0.776  ; % Home goods content of consumption expenditure on traded goods
PI_ini       = 2.307  ; % Aggregate investment price index
PIT_ini      = 1.604  ; % Investment price index for traded goods
IN_ini       = 0.277  ; % Non traded investment
IH_ini       = 0.110  ; % Home goods investment
IF_ini       = 0.235  ; % Foreign goods investment
alphaI_ini   = 0.379  ; % Tradable content of investment expenditure
alphaIH_ini  = 0.517  ; % Home goods content of investment expenditure on traded goods
LH_ini       = 0.391  ; % Labor in sector H
LN_ini       = 0.661  ; % Labor in sector N 
GF_ini       = 0.03   ; % Government spending in foreign goods
GH_ini       = 0.05   ; % Government spending in home goods
GN_ini       = 0.35   ; % Government spending in non tradables 
YH_ini       = 0.898  ; % Output of home traded goods
YN_ini       = 1.255  ; % Output of non traded goods
XH_ini       = 0.245  ; % Exports of home traded goods
MF_ini       = 0.562  ; % Imports of foreign goods
RK_ini       = 0.307  ; % Return on capital
xi1H_ini     = 0.1337 ; % Parameter of traded capital utilization cost function: xi1H*(uKH-1)+(xi2H/2)*(uKH-1)^2
xi1N_ini     = 0.1065 ; % Parameter of non-traded capital utilization cost function
chi1H_ini    = 0.898  ; % Parameter of traded technology utilization cost function: chi1H*(uZH-1)+(chi2H/2)*(uZH-1)^2
chi1N_ini    = 1.255  ; % Parameter of non-traded technology utilization cost function
lambda_ini   = 0.967  ; % Intertemporal Solvency Condition         
                                                          
x0 =[C_ini L_ini kH_ini WH_ini WN_ini W_ini kN_ini PN_ini K_ini PH_ini B_ini alphaL_ini PC_ini PT_ini CN_ini CH_ini CF_ini alphaC_ini alphaH_ini PI_ini PIT_ini IN_ini IH_ini IF_ini alphaI_ini alphaIH_ini LH_ini LN_ini GF_ini GN_ini GH_ini YH_ini YN_ini XH_ini MF_ini RK_ini xi1H_ini xi1N_ini chi1H_ini chi1N_ini lambda_ini];
[x,fval,exitflag]=fsolve('IML_CAC_TOT_SS0',x0,optimset('display','off','TolFun',1e-011));

C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kH      = x(3)  ; % Capital-labor ratio in sector H
WH      = x(4)  ; % Wage rate in sector H
WN      = x(5)  ; % Wage rate in sector N
W       = x(6)  ; % Aggregate wage index
kN      = x(7)  ; % Capital-labor ratio in sector N
PN      = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
PH      = x(10) ; % Terms of trade : PH/PF with PF = numeraire
B       = x(11) ; % Stock of Traded Bonds
alphaL  = x(12) ; % Output per worker in sector N 
PC      = x(13) ; % Aggregate consumption price index
PT      = x(14) ; % Consumption price index for tradables
CN      = x(15) ; % Consumption in non tradables 
CH      = x(16) ; % Consumption in tradables 
CF      = x(17) ; % Consumption goods imports
alphaC  = x(18) ; % Tradable content of consumption expenditure 
alphaH  = x(19) ; % Home goods content of consumption expenditure on traded goods
PI      = x(20) ; % Aggregate investment price index
PIT     = x(21) ; % Investment price index for tradables
IN      = x(22) ; % Non tradable investment
IH      = x(23) ; % Investment in home goods
IF      = x(24) ; % Investment in foreign goods
alphaI  = x(25) ; % Tradable content of investment expenditure
alphaIH = x(26) ; % Home goods content of investment expenditure
LH      = x(27) ; % Labor in sector H
LN      = x(28) ; % Labor in sector N 
GF      = x(29) ; % Government spending in foreign goods
GN      = x(30) ; % Government spending in non tradables 
GH      = x(31) ; % Government spending in home traded goods
YH      = x(32) ; % Output of home traded goods
YN      = x(33) ; % Output of non traded goods
XH      = x(34) ; % Exports of home traded goods
MF      = x(35) ; % Imports of foreign goods
RK      = x(36) ; % Return on capital
xi1H    = x(37) ; % Parameter of traded capital utilization cost function: xi1H*(uKH-1)+(xi2H/2)*(uKH-1)^2
xi1N    = x(38) ; % Parameter of non-traded capital utilization cost function
chi1H   = x(39) ; % Parameter of traded technology utilization cost function: chi1H*(uZH-1)+(chi2H/2)*(uZH-1)^2
chi1N   = x(40) ; % Parameter of non-traded technology utilization cost function
lambda  = x(41) ; % Intertemporal Solvency Condition  

% VA per hours worked
yH     = YH/LH; 
yN     = YN/LN; 

% Sectoral outputs and sectoral profits   
KH  = LH*kH;  
RK  = PH*(1-thetaH)*(YH/KH); 
PiH = (PH*YH) - (RK*KH) - (WH*LH);
  
KN  = LN*kN;   
PiN = (PN*YN) - (RK*KN) - (WN*LN);

% Capital rental rates
RKH = PH*(1-thetaH)*(YH/KH); 
RKN = PN*(1-thetaN)*(YN/KN);

% Labor income share in the home traded good and non traded good sector
sLH = WH*LH/(PH*YH);
sLN = WN*LN/(PN*YN);

% Partial derivatives of LH and LN
LH_1lamb   = sigmaL*LH/lambda; 
LN_1lamb   = sigmaL*LN/lambda;

% LHj = partial Lj/partial Wj: Lj=Lj(WH,WN,uZH,uZN)
LH_WH   = (LH/WH)*( epsilon*(1-alphaL) + (sigmaL*alphaL) );
LH_1uZH = LH*( epsilon*(1-alphaL) + (sigmaL*alphaL) );
LH_WN   = (LH/WN)*(1-alphaL)*(sigmaL-epsilon); 
LH_1uZN = LH*(1-alphaL)*(sigmaL-epsilon); 
LN_WH   = (LN/WH)*alphaL*(sigmaL-epsilon); 
LN_1uZH = LN*alphaL*(sigmaL-epsilon);
LN_WN   = (LN/WN)*( (epsilon*alphaL) + sigmaL*(1-alphaL) );  
LN_1uZN = LN*( (epsilon*alphaL) + sigmaL*(1-alphaL) ); 
LH_1lamb = sigmaL*LH/lambda; 
LN_1lamb = sigmaL*LN/lambda;

% Solving for kH, kN, WH, WN as functions of (PH, PN, K, uKH, uKN, uZH, uZN)
Psi_WH   = ( (kH*LH_WH) + (kN*LN_WH) );
Psi_WN   = ( (kH*LH_WN) + (kN*LN_WN) );
Psi_uZH  = ((kH*LH_1uZH) + (kN*LN_1uZH)); 
Psi_uZN  = ((kH*LH_1uZN) + (kN*LN_1uZN)); 
Psi_lamb = ( (kH*LH_1lamb) + (kN*LN_1lamb) );

d11 = -(thetaH/kH); 
d12 = (thetaN/kN);
d13 = 0;
d14 = 0;
d21 = ((1-thetaH)/kH); 
d22 = 0;  
d23 = -(1/WH); 
d24 = 0; 
d31 = 0; 
d32 = ((1-thetaN)/kN);
d33 = 0; 
d34 = -(1/WN);
d41 = LH; 
d42 = LN; 
d43 = Psi_WH; 
d44 = Psi_WN; 

% PN, PH, K, uKH, uKN, uZH, uZN, lambda
e11  = (1/PN);
e12  = -(1/PH);
e13  = 0;
e14  = thetaH;
e15  = -thetaN;
e16  = 0;
e17  = 0;
e18  = 0;

e21  = 0;
e22  = -(1/PH);
e23  = 0;
e24  = -(1-thetaH);
e25  = 0;
e26  = 0;
e27  = 0;
e28  = 0;

e31  = -(1/PN);
e32  = 0;
e33  = 0;
e34  = 0;
e35  = -(1-thetaN);
e36  = 0;
e37  = 0;
e38  = 0;

e41  = 0;
e42  = 0;
e43  = 1;
e44  = 0;
e45  = 0;
e46  = -Psi_uZH;
e47  = -Psi_uZN;
e48  = -Psi_lamb;

M1 = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X1 = [e11 e12 e13 e14 e15 e16 e17 e18; e21 e22 e23 e24 e25 e26 e27 e28; e31 e32 e33 e34 e35 e36 e37 e38; e41 e42 e43 e44 e45 e46 e47 e48];
JST1 = inv(M1);
MST1 = JST1*X1;
kH_1PN = MST1(1,1); kH_1PH = MST1(1,2); kH_1K = MST1(1,3); kH_uKH = MST1(1,4); kH_uKN = MST1(1,5); kH_uZH = MST1(1,6); kH_uZN = MST1(1,7); kH_1lambda = MST1(1,8);
kN_1PN = MST1(2,1); kN_1PH = MST1(2,2); kN_1K = MST1(2,3); kN_uKH = MST1(2,4); kN_uKN = MST1(2,5); kN_uZH = MST1(2,6); kN_uZN = MST1(2,7); kN_1lambda = MST1(2,8);
WH_1PN = MST1(3,1); WH_1PH = MST1(3,2); WH_1K = MST1(3,3); WH_uKH = MST1(3,4); WH_uKN = MST1(3,5); WH_uZH = MST1(3,6); WH_uZN = MST1(3,7); WH_1lambda = MST1(3,8);
WN_1PN = MST1(4,1); WN_1PH = MST1(4,2); WN_1K = MST1(4,3); WN_uKH = MST1(4,4); WN_uKN = MST1(4,5); WN_uZH = MST1(4,6); WN_uZN = MST1(4,7); WN_1lambda = MST1(4,8);

% Solving for sectoral labor and sectoral output - Lj,yj,Yj,Kj(PN,PH,K,uKj,uZj)
LH_1PN = (LH_WH*WH_1PN) + (LH_WN*WN_1PN);
LH_1PH = (LH_WH*WH_1PH) + (LH_WN*WN_1PH);
LH_1K  = (LH_WH*WH_1K)  + (LH_WN*WN_1K);
LH_uKH = (LH_WH*WH_uKH) + (LH_WN*WN_uKH);
LH_uKN = (LH_WH*WH_uKN) + (LH_WN*WN_uKN);
LH_uZH = LH_1uZH + (LH_WH*WH_uZH) + (LH_WN*WN_uZH);
LH_uZN = LH_1uZN + (LH_WH*WH_uZN) + (LH_WN*WN_uZN);
LH_1lambda = LH_1lamb + (LH_WH*WH_1lambda) + (LH_WN*WN_1lambda);

LN_1PN = (LN_WH*WH_1PN) + (LN_WN*WN_1PN);
LN_1PH = (LN_WH*WH_1PH) + (LN_WN*WN_1PH);
LN_1K  = (LN_WH*WH_1K)  + (LN_WN*WN_1K);
LN_uKH = (LN_WH*WH_uKH) + (LN_WN*WN_uKH);
LN_uKN = (LN_WH*WH_uKN) + (LN_WN*WN_uKN);
LN_uZH = LN_1uZH + (LN_WH*WH_uZH) + (LN_WN*WN_uZH);
LN_uZN = LN_1uZN + (LN_WH*WH_uZN) + (LN_WN*WN_uZN);
LN_1lambda = LN_1lamb + (LN_WH*WH_1lambda) + (LN_WN*WN_1lambda);

yH_1PN = (yH/kH)*(1-thetaH)*kH_1PN;
yH_1PH = (yH/kH)*(1-thetaH)*kH_1PH;
yH_1K  = (yH/kH)*(1-thetaH)*kH_1K;
yH_uKH = yH*(1-thetaH) + (yH/kH)*(1-thetaH)*kH_uKH;
yH_uKN = (yH/kH)*(1-thetaH)*kH_uKN;
yH_uZH = (yH/kH)*(1-thetaH)*kH_uZH;
yH_uZN = (yH/kH)*(1-thetaH)*kH_uZN;
yH_1lambda  = (yH/kH)*(1-thetaH)*kH_1lambda;

yN_1PN = (yN/kN)*(1-thetaN)*kN_1PN;
yN_1PH = (yN/kN)*(1-thetaN)*kN_1PH;
yN_1K  = (yN/kN)*(1-thetaN)*kN_1K;
yN_uKH = (yN/kN)*(1-thetaN)*kN_uKH;
yN_uKN = yN*(1-thetaN) + (yN/kN)*(1-thetaN)*kN_uKN;
yN_uZH = (yN/kN)*(1-thetaN)*kN_uZH;
yN_uZN = (yN/kN)*(1-thetaN)*kN_uZN;
yN_1lambda  = (yN/kN)*(1-thetaN)*kN_1lambda;

YH_1PN = (LH*yH_1PN) + (yH*LH_1PN);
YH_1PH = (LH*yH_1PH) + (yH*LH_1PH);
YH_1K  = (LH*yH_1K) + (yH*LH_1K);
YH_uKH = (LH*yH_uKH) + (yH*LH_uKH);
YH_uKN = (LH*yH_uKN) + (yH*LH_uKN);
YH_uZH = (LH*yH_uZH) + (yH*LH_uZH);
YH_uZN = (LH*yH_uZN) + (yH*LH_uZN);
YH_1lambda = (LH*yH_1lambda) + (yH*LH_1lambda);

YN_1PN = (LN*yN_1PN) + (yN*LN_1PN);
YN_1PH = (LN*yN_1PH) + (yN*LN_1PH);
YN_1K  = (LN*yN_1K) + (yN*LN_1K);
YN_uKH = (LN*yN_uKH) + (yN*LN_uKH);
YN_uKN = (LN*yN_uKN) + (yN*LN_uKN);
YN_uZH = (LN*yN_uZH) + (yN*LN_uZH);
YN_uZN = (LN*yN_uZN) + (yN*LN_uZN);
YN_1lambda = (LN*yN_1lambda) + (yN*LN_1lambda);

KH_1PN = (LH*kH_1PN) + (kH*LH_1PN);
KH_1PH = (LH*kH_1PH) + (kH*LH_1PH);
KH_1K  = (LH*kH_1K) + (kH*LH_1K);
KH_uKH = (LH*kH_uKH) + (kH*LH_uKH);
KH_uKN = (LH*kH_uKN) + (kH*LH_uKN);
KH_uZH = (LH*kH_uZH) + (kH*LH_uZH);
KH_uZN = (LH*kH_uZN) + (kH*LH_uZN);
KH_1lambda = (LH*kH_1lambda) + (kH*LH_1lambda);

KN_1PN = (LN*kN_1PN) + (kN*LN_1PN);
KN_1PH = (LN*kN_1PH) + (kN*LN_1PH);
KN_1K  = (LN*kN_1K) + (kN*LN_1K);
KN_uKH = (LN*kN_uKH) + (kN*LN_uKH);
KN_uKN = (LN*kN_uKN) + (kN*LN_uKN);
KN_uZH = (LN*kN_uZH) + (kN*LN_uZH);
KN_uZN = (LN*kN_uZN) + (kN*LN_uZN);
KN_1lambda = (LN*kN_1lambda) + (kN*LN_1lambda);

% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH)
CN_PN = - (CN/PN)*( (alphaC*phi) + sigmaC*(1-alphaC) ); 
CN_PH = (CN/PH)*alphaC*alphaH*(phi-sigmaC); 
CH_PN = (CH/PN)*(phi-sigmaC)*(1-alphaC); 
CH_PH = -(CH/PH)*( rho*(1-alphaH) + alphaH*( phi*(1-alphaC) + (sigmaC*alphaC) ) ); 
CF_PN = (CF/PN)*(1-alphaC)*(phi-sigmaC); 
CF_PH = (CF/PH)*alphaH*(rho - (phi*(1-alphaC)+(sigmaC*alphaC))); 

CH_1lambda = -(CH/lambda)*sigmaC; 
CN_1lambda = -(CN/lambda)*sigmaC;
CF_1lambda = -(CF/lambda)*sigmaC;

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_K  = deltaK; 
J_Q  = K*v_1Q; 
J_PN = K*v_PN; 
J_PH = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q)
I     = deltaK*K; 
JN_PN = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K = (IN/I)*J_K; 
JN_1Q = (IN/I)*J_Q; 

JH_PN =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_K; 
JH_1Q  = (IH/I)*J_Q; 

JF_PN = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_K; 
JF_1Q  = (IF/I)*J_Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH  = -(XH/PH)*nuX; 

% Solving for capital and technology utilization rates: uKH, uKN, uZH, uZN; uKj,uZj(PN,PH,K)
f11 = ((xi2H/xi1H) + thetaH) + thetaH*(kH_uKH/kH);
f12 = thetaH*(kH_uKN/kH);
f13 = (thetaH*(kH_uZH/kH)-1);
f14 = thetaH*(kH_uZN/kH);
f21 = thetaN*(kN_uKH/kN);
f22 = ((xi2N/xi1N) + thetaN) + thetaN*(kN_uKN/kN);
f23 = thetaN*(kN_uZH/kN);
f24 = (thetaN*(kN_uZN/kN)-1);
f31 = -YH_uKH;
f32 = -YH_uKN;
f33 = (chi2H-YH_uZH);
f34 = -YH_uZN;
f41 = -YN_uKH;
f42 = -YN_uKN;
f43 = -YN_uZH;
f44 = (chi2N-YN_uZN);

% PN, PH, K,
g11 = -thetaH*(kH_1PN/kH);       
g12 = -thetaH*(kH_1PH/kH);       
g13 = -thetaH*(kH_1K/kH);        
g14 = -thetaH*(kH_1lambda/kH);   
                                 
g21 = -thetaN*(kN_1PN/kN);       
g22 = -thetaN*(kN_1PH/kN);       
g23 = -thetaN*(kN_1K/kN);        
g24 = -thetaN*(kN_1lambda/kN);   

g31 = YH_1PN;
g32 = YH_1PH;
g33 = YH_1K;
g34 = YH_1lambda;

g41 = YN_1PN;
g42 = YN_1PH;
g43 = YN_1K;
g44 = YN_1lambda;

M2 = [f11 f12 f13 f14; f21 f22 f23 f24; f31 f32 f33 f34; f41 f42 f43 f44];
X2 = [g11 g12 g13 g14; g21 g22 g23 g24; g31 g32 g33 g34; g41 g42 g43 g44];
JST2 = inv(M2);
MST2 = JST2*X2;

uKH_PN = MST2(1,1); uKH_PH = MST2(1,2); uKH_1K = MST2(1,3); uKH_1lambda = MST2(1,4);
uKN_PN = MST2(2,1); uKN_PH = MST2(2,2); uKN_1K = MST2(2,3); uKN_1lambda = MST2(2,4);
uZH_PN = MST2(3,1); uZH_PH = MST2(3,2); uZH_1K = MST2(3,3); uZH_1lambda = MST2(3,4);
uZN_PN = MST2(4,1); uZN_PH = MST2(4,2); uZN_1K = MST2(4,3); uZN_1lambda = MST2(4,4);

% Solving for sectoral labor and sectoral output - kj,Wj,Lj,yj,Yj,Kj(lambda,K,PH,PN,AH,BH,AN,BN)
kH_2K  = kH_1K + (kH_uKH*uKH_1K) + (kH_uKN*uKN_1K) + (kH_uZH*uZH_1K) + (kH_uZN*uZN_1K);
kH_PH  = kH_1PH + (kH_uKH*uKH_PH) + (kH_uKN*uKN_PH) + (kH_uZH*uZH_PH) + (kH_uZN*uZN_PH);
kH_PN  = kH_1PN + (kH_uKH*uKH_PN) + (kH_uKN*uKN_PN) + (kH_uZH*uZH_PN) + (kH_uZN*uZN_PN);
kH_2lambda = kH_1lambda + (kH_uKH*uKH_1lambda) + (kH_uKN*uKN_1lambda) + (kH_uZH*uZH_1lambda) + (kH_uZN*uZN_1lambda);

kN_2K  = kN_1K + (kN_uKH*uKH_1K) + (kN_uKN*uKN_1K) + (kN_uZH*uZH_1K) + (kN_uZN*uZN_1K);
kN_PH  = kN_1PH + (kN_uKH*uKH_PH) + (kN_uKN*uKN_PH) + (kN_uZH*uZH_PH) + (kN_uZN*uZN_PH);
kN_PN  = kN_1PN + (kN_uKH*uKH_PN) + (kN_uKN*uKN_PN) + (kN_uZH*uZH_PN) + (kN_uZN*uZN_PN);
kN_2lambda = kN_1lambda + (kN_uKH*uKH_1lambda) + (kN_uKN*uKN_1lambda) + (kN_uZH*uZH_1lambda) + (kN_uZN*uZN_1lambda);

WH_2K  = WH_1K + (WH_uKH*uKH_1K) + (WH_uKN*uKN_1K) + (WH_uZH*uZH_1K) + (WH_uZN*uZN_1K);
WH_PH  = WH_1PH + (WH_uKH*uKH_PH) + (WH_uKN*uKN_PH) + (WH_uZH*uZH_PH) + (WH_uZN*uZN_PH);
WH_PN  = WH_1PN + (WH_uKH*uKH_PN) + (WH_uKN*uKN_PN) + (WH_uZH*uZH_PN) + (WH_uZN*uZN_PN);
WH_2lambda = WH_1lambda + (WH_uKH*uKH_1lambda) + (WH_uKN*uKN_1lambda) + (WH_uZH*uZH_1lambda) + (WH_uZN*uZN_1lambda);

WN_2K = WN_1K + (WN_uKH*uKH_1K) + (WN_uKN*uKN_1K) + (WN_uZH*uZH_1K) + (WN_uZN*uZN_1K);
WN_PH = WN_1PH + (WN_uKH*uKH_PH) + (WN_uKN*uKN_PH) + (WN_uZH*uZH_PH) + (WN_uZN*uZN_PH);
WN_PN = WN_1PN + (WN_uKH*uKH_PN) + (WN_uKN*uKN_PN) + (WN_uZH*uZH_PN) + (WN_uZN*uZN_PN);
WN_2lambda = WN_1lambda + (WN_uKH*uKH_1lambda) + (WN_uKN*uKN_1lambda) + (WN_uZH*uZH_1lambda) + (WN_uZN*uZN_1lambda);

LH_2K = LH_1K + (LH_uKH*uKH_1K) + (LH_uKN*uKN_1K) + (LH_uZH*uZH_1K) + (LH_uZN*uZN_1K);
LH_PH = LH_1PH + (LH_uKH*uKH_PH) + (LH_uKN*uKN_PH) + (LH_uZH*uZH_PH) + (LH_uZN*uZN_PH);
LH_PN = LH_1PN + (LH_uKH*uKH_PN) + (LH_uKN*uKN_PN) + (LH_uZH*uZH_PN) + (LH_uZN*uZN_PN);
LH_2lambda = LH_1lambda + (LH_uKH*uKH_1lambda) + (LH_uKN*uKN_1lambda) + (LH_uZH*uZH_1lambda) + (LH_uZN*uZN_1lambda);

LN_2K = LN_1K + (LN_uKH*uKH_1K) + (LN_uKN*uKN_1K) + (LN_uZH*uZH_1K) + (LN_uZN*uZN_1K);
LN_PH = LN_1PH + (LN_uKH*uKH_PH) + (LN_uKN*uKN_PH) + (LN_uZH*uZH_PH) + (LN_uZN*uZN_PH);
LN_PN = LN_1PN + (LN_uKH*uKH_PN) + (LN_uKN*uKN_PN) + (LN_uZH*uZH_PN) + (LN_uZN*uZN_PN);
LN_2lambda = LN_1lambda + (LN_uKH*uKH_1lambda) + (LN_uKN*uKN_1lambda) + (LN_uZH*uZH_1lambda) + (LN_uZN*uZN_1lambda);

YH_2K = YH_1K + (YH_uKH*uKH_1K) + (YH_uKN*uKN_1K) + (YH_uZH*uZH_1K) + (YH_uZN*uZN_1K);
YH_PH = YH_1PH + (YH_uKH*uKH_PH) + (YH_uKN*uKN_PH) + (YH_uZH*uZH_PH) + (YH_uZN*uZN_PH);
YH_PN = YH_1PN + (YH_uKH*uKH_PN) + (YH_uKN*uKN_PN) + (YH_uZH*uZH_PN) + (YH_uZN*uZN_PN);
YH_2lambda = YH_1lambda + (YH_uKH*uKH_1lambda) + (YH_uKN*uKN_1lambda) + (YH_uZH*uZH_1lambda) + (YH_uZN*uZN_1lambda);

YN_2K = YN_1K + (YN_uKH*uKH_1K) + (YN_uKN*uKN_1K) + (YN_uZH*uZH_1K) + (YN_uZN*uZN_1K);
YN_PH = YN_1PH + (YN_uKH*uKH_PH) + (YN_uKN*uKN_PH) + (YN_uZH*uZH_PH) + (YN_uZN*uZN_PH);
YN_PN = YN_1PN + (YN_uKH*uKH_PN) + (YN_uKN*uKN_PN) + (YN_uZH*uZH_PN) + (YN_uZN*uZN_PN);
YN_2lambda = YN_1lambda + (YN_uKH*uKH_1lambda) + (YN_uKN*uKN_1lambda) + (YN_uZH*uZH_1lambda) + (YN_uZN*uZN_1lambda);

KH_2K = KH_1K + (KH_uKH*uKH_1K) + (KH_uKN*uKN_1K) + (KH_uZH*uZH_1K) + (KH_uZN*uZN_1K);
KH_PH = KH_1PH + (KH_uKH*uKH_PH) + (KH_uKN*uKN_PH) + (KH_uZH*uZH_PH) + (KH_uZN*uZN_PH);
KH_PN = KH_1PN + (KH_uKH*uKH_PN) + (KH_uKN*uKN_PN) + (KH_uZH*uZH_PN) + (KH_uZN*uZN_PN);
KH_2lambda = KH_1lambda + (KH_uKH*uKH_1lambda) + (KH_uKN*uKN_1lambda) + (KH_uZH*uZH_1lambda) + (KH_uZN*uZN_1lambda);

KN_2K = KN_1K + (KN_uKH*uKH_1K) + (KN_uKN*uKN_1K) + (KN_uZH*uZH_1K) + (KN_uZN*uZN_1K);
KN_PH = KN_1PH + (KN_uKH*uKH_PH) + (KN_uKN*uKN_PH) + (KN_uZH*uZH_PH) + (KN_uZN*uZN_PH);
KN_PN = KN_1PN + (KN_uKH*uKH_PN) + (KN_uKN*uKN_PN) + (KN_uZH*uZH_PN) + (KN_uZN*uZN_PN);
KN_2lambda = KN_1lambda + (KN_uKH*uKH_1lambda) + (KN_uKN*uKN_1lambda) + (KN_uZH*uZH_1lambda) + (KN_uZN*uZN_1lambda);

% Partial Derivatives Gj=Gj(G)
GN_G   = omegaGN/PN;
GH_G   = (1-omegaGN)*(omegaGH/PH);
GF_G   = (1-omegaGN)*(1-omegaGH);

% Solving for traded and non-traded prices: PH,PN(K,Q,G,AH,BH,AN,BN,lambda)
h11 = (YN_PH - CN_PH - JN_PH) - (KN*xi1N*uKN_PH);
h12 = (YN_PN - CN_PN - JN_PN) - (KN*xi1N*uKN_PN);
h21 = (YH_PH - CH_PH - JH_PH - XH_PH) - (KH*xi1H*uKH_PH);
h22 = (YH_PN - CH_PN - JH_PN) - (KH*xi1H*uKH_PN);

% K,Q,G,AH,BH,AN,BN,lambda
k11 = -(YN_2K - JN_1K - (KN*xi1N*uKN_1K));
k12 = JN_1Q;
k13 = GN_G;
k14 = -((YN_2lambda - CN_1lambda) - (KN*xi1N*uKN_1lambda));

k21 = -(YH_2K - JH_1K - (KH*xi1H*uKH_1K));
k22 = JH_1Q;
k23 = GH_G;
k24 = -((YH_2lambda - CH_1lambda) - (KH*xi1H*uKH_1lambda));

M3 = [h11 h12; h21 h22];
X3 = [k11 k12 k13 k14; k21 k22 k23 k24];
JST3 = inv(M3);
MST3 = JST3*X3;

PH_K = MST3(1,1); PH_Q = MST3(1,2); PH_G = MST3(1,3); PH_lambda = MST3(1,4);
PN_K = MST3(2,1); PN_Q = MST3(2,2); PN_G = MST3(2,3); PN_lambda = MST3(2,4);

% Solving for capital-labor ratios kj=kj(K,Q,G,Aj,Bj) -                                 
% sectoral labor Lj=Lj(K,Q,G,Aj,Bj) - sectoral output                                   
% Yj=Yj(K,Q,G,Aj,Bj) - Final Solutions                                                  
kH_K = kH_2K + (kH_PH*PH_K) + (kH_PN*PN_K);                                             
kH_Q = (kH_PH*PH_Q) + (kH_PN*PN_Q);                                                     
kH_G = (kH_PH*PH_G) + (kH_PN*PN_G);                                                     
kH_lambda = kH_2lambda + (kH_PH*PH_lambda) + (kH_PN*PN_lambda);                         
                                                                                        
kN_K = kN_2K + (kN_PH*PH_K) + (kN_PN*PN_K);                                             
kN_Q = (kN_PH*PH_Q) + (kN_PN*PN_Q);                                                     
kN_G = (kN_PH*PH_G) + (kN_PN*PN_G);                                                     
kN_lambda = kN_2lambda + (kN_PH*PH_lambda) + (kN_PN*PN_lambda);                         
                                                                                        
LH_K  = LH_2K + (LH_PH*PH_K) + (LH_PN*PN_K);                                            
LH_Q  = (LH_PH*PH_Q) + (LH_PN*PN_Q);                                                    
LH_G  = (LH_PH*PH_G) + (LH_PN*PN_G);                                                    
LH_lambda = LH_2lambda + (LH_PH*PH_lambda) + (LH_PN*PN_lambda);                         
                                                                                        
LN_K = LN_2K + (LN_PH*PH_K) + (LN_PN*PN_K);                                             
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);                                                     
LN_G = (LN_PH*PH_G) + (LN_PN*PN_G);                                                     
LN_lambda = LN_2lambda + (LN_PH*PH_lambda) + (LN_PN*PN_lambda);                         
                                                                                        
YH_K = YH_2K + (YH_PH*PH_K) + (YH_PN*PN_K);                                             
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q);                                                     
YH_G = (YH_PH*PH_G) + (YH_PN*PN_G);                                                     
YH_lambda = YH_2lambda + (YH_PH*PH_lambda) + (YH_PN*PN_lambda);                         
                                                                                        
YN_K = YN_2K + (YN_PH*PH_K) + (YN_PN*PN_K);                                             
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);                                                     
YN_G = (YN_PH*PH_G) + (YN_PN*PN_G);                                                     
YN_lambda = YN_2lambda + (YN_PH*PH_lambda) + (YN_PN*PN_lambda);                         
                                                                                        
KH_K  = KH_2K + (KH_PH*PH_K) + (KH_PN*PN_K);                                            
KH_Q  = (KH_PH*PH_Q) + (KH_PN*PN_Q);                                                    
KH_G  = (KH_PH*PH_G) + (KH_PN*PN_G);                                                    
KH_lambda = KH_2lambda + (KH_PH*PH_lambda) + (KH_PN*PN_lambda);                         
                                                                                        
KN_K = KN_2K + (KN_PH*PH_K) + (KN_PN*PN_K);                                             
KN_Q = (KN_PH*PH_Q) + (KN_PN*PN_Q);                                                     
KN_G = (KN_PH*PH_G) + (KN_PN*PN_G);                                                     
KN_lambda = KN_2lambda + (KN_PH*PH_lambda) + (KN_PN*PN_lambda);                         
                                                                                        
uKH_K  = uKH_1K + (uKH_PH*PH_K) + (uKH_PN*PN_K);                                        
uKH_Q  = (uKH_PH*PH_Q) + (uKH_PN*PN_Q);                                                 
uKH_G  = (uKH_PH*PH_G) + (uKH_PN*PN_G);                                                 
uKH_lambda = uKH_1lambda + (uKH_PH*PH_lambda) + (uKH_PN*PN_lambda);                     
                                                                                        
uKN_K = uKN_1K + (uKN_PH*PH_K) + (uKN_PN*PN_K);                                         
uKN_Q = (uKN_PH*PH_Q) + (uKN_PN*PN_Q);                                                  
uKN_G = (uKN_PH*PH_G) + (uKN_PN*PN_G);                                                  
uKN_lambda = uKN_1lambda + (uKN_PH*PH_lambda) + (uKN_PN*PN_lambda);                     
                                                                                        
uZH_K  = uZH_1K + (uZH_PH*PH_K) + (uZH_PN*PN_K);                                        
uZH_Q  = (uZH_PH*PH_Q) + (uZH_PN*PN_Q);                                                 
uZH_G  = (uZH_PH*PH_G) + (uZH_PN*PN_G);                                                 
uZH_lambda = uZH_1lambda + (uZH_PH*PH_lambda) + (uZH_PN*PN_lambda);                     
                                                                                        
uZN_K = uZN_1K + (uZN_PH*PH_K) + (uZN_PN*PN_K);                                         
uZN_Q = (uZN_PH*PH_Q) + (uZN_PN*PN_Q);                                                  
uZN_G = (uZN_PH*PH_G) + (uZN_PN*PN_G);                                                  
uZN_lambda = uZN_1lambda + (uZN_PH*PH_lambda) + (uZN_PN*PN_lambda);                     
                                                                                        
% Solving for consumption Cj=Cj(lambda,K,Q,G), investment inputs
% Jj=Jj(K,Q,G), imports MF=MF(lambda,K,Q,G), exports
%XH=XH(K,Q,G)- Final Solutions
CH_K      = (CH_PH*PH_K) + (CH_PN*PN_K);
CH_Q      = (CH_PH*PH_Q) + (CH_PN*PN_Q);
CH_G      = (CH_PH*PH_G) + (CH_PN*PN_G);
CH_lambda = CH_1lambda + (CH_PH*PH_lambda) + (CH_PN*PN_lambda);

CN_K      = (CN_PH*PH_K) + (CN_PN*PN_K);
CN_Q      = (CN_PH*PH_Q) + (CN_PN*PN_Q);
CN_G      = (CN_PH*PH_G) + (CN_PN*PN_G);
CN_lambda = CN_1lambda + (CN_PH*PH_lambda) + (CN_PN*PN_lambda);

CF_K      = (CF_PH*PH_K) + (CF_PN*PN_K);
CF_Q      = (CF_PH*PH_Q) + (CF_PN*PN_Q);
CF_G      = (CF_PH*PH_G) + (CF_PN*PN_G);
CF_lambda = CF_1lambda + (CF_PH*PH_lambda) + (CF_PN*PN_lambda);

JH_K       = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K);
JH_Q       = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q);
JH_G       = (JH_PH*PH_G) + (JH_PN*PN_G);
JH_lambda  = (JH_PH*PH_lambda) + (JH_PN*PN_lambda);

JN_K       = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K);
JN_Q       = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q);
JN_G       = (JN_PH*PH_G) + (JN_PN*PN_G);
JN_lambda  = (JN_PH*PH_lambda) + (JN_PN*PN_lambda);

JF_K       = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K);
JF_Q       = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q);
JF_G       = (JF_PH*PH_G) + (JF_PN*PN_G);
JF_lambda  = (JF_PH*PH_lambda) + (JF_PN*PN_lambda);

XH_K      = XH_PH*PH_K;
XH_Q      = XH_PH*PH_Q;
XH_G      = XH_PH*PH_G;
XH_lambda = XH_PH*PH_lambda;

MF_K      = (CF_K + JF_K);
MF_Q      = (CF_Q + JF_Q);
MF_G      = (CF_G + JF_G);
MF_lambda = (CF_lambda + JF_lambda);

% Solving for sectoral wages - Wj=Wj(K,Q,G)
WH_K = WH_2K + (WH_PH*PH_K) + (WH_PN*PN_K);
WH_Q = (WH_PH*PH_Q) + (WH_PN*PN_Q);
WH_G = (WH_PH*PH_G) + (WH_PN*PN_G);
WH_lambda = WH_2lambda + (WH_PH*PH_lambda) + (WH_PN*PN_lambda);

WN_K = WN_2K + (WN_PH*PH_K) + (WN_PN*PN_K);
WN_Q = (WN_PH*PH_Q) + (WN_PN*PN_Q);
WN_G = (WN_PH*PH_G) + (WN_PN*PN_G);
WN_lambda = WN_2lambda + (WN_PH*PH_lambda) + (WN_PN*PN_lambda);

% Solutions tildeWj,tildeRj,tildeKj,tildeYj(K,Q,G); tildeWj=uZj*Wj;
% tildeRj=RK*uZj; tildeKj=uKj*Kj; tildeYj=uZj*Yj;
tildeWH_K  = WH_K + (WH*uZH_K);
tildeWH_Q  = WH_Q + (WH*uZH_Q);
tildeWH_G  = WH_G + (WH*uZH_G);
tildeWH_lambda = WH_lambda + (WH*uZH_lambda);

tildeWN_K  = WN_K + (WN*uZN_K);
tildeWN_Q  = WN_Q + (WN*uZN_Q);
tildeWN_G  = WN_G + (WN*uZN_G);
tildeWN_lambda = WN_lambda + (WN*uZN_lambda);

% Solution for tildeW(K,Q,G) - tildeW(tildeWH,tildeWN)
tildeW_WH      = (W/WH)*alphaL;
tildeW_WN      = (W/WN)*(1-alphaL);
tildeW_K       = (tildeW_WH*tildeWH_K)  + (tildeW_WN*tildeWN_K);
tildeW_Q       = (tildeW_WH*tildeWH_Q)  + (tildeW_WN*tildeWN_Q);
tildeW_G       = (tildeW_WH*tildeWH_G)  + (tildeW_WN*tildeWN_G);
tildeW_lambda  = (tildeW_WH*tildeWH_lambda) + (tildeW_WN*tildeWN_lambda);

% Solution for L as function L=L(K,Q,G)
L_1lambda = sigmaL*(L/lambda);
L_W  = sigmaL*(L/W);
L_WH = sigmaL*L*alphaL/WH;
L_WN = sigmaL*L*(1-alphaL)/WN;
L_K  = (L_WH*tildeWH_K)  + (L_WN*tildeWN_K);
L_Q  = (L_WH*tildeWH_Q)  + (L_WN*tildeWN_Q);
L_G  = (L_WH*tildeWH_G)  + (L_WN*tildeWN_G);
L_lambda  = L_1lambda + (L_WH*tildeWH_lambda) + (L_WN*tildeWN_lambda);

% Solution for C as function C=C(K,Q,G)
C_1lambda  = -sigmaC*(C/lambda);
C_PH       = -sigmaC*alphaC*alphaH*(C/PH);
C_PN       = -sigmaC*(1-alphaC)*(C/PN);
C_K        = (C_PH*PH_K) + (C_PN*PN_K);
C_Q        = (C_PH*PH_Q) + (C_PN*PN_Q);
C_G        = (C_PH*PH_G) + (C_PN*PN_G);
C_lambda   = C_1lambda + (C_PH*PH_lambda) + (C_PN*PN_lambda);

% Solution for PC=PC(PH,PN) - PC = PC(K,Q,G)
PC_K       = (PC/PH)*alphaC*alphaH*PH_K + (PC/PN)*(1-alphaC)*PN_K;
PC_Q       = (PC/PH)*alphaC*alphaH*PH_Q + (PC/PN)*(1-alphaC)*PN_Q;
PC_G       = (PC/PH)*alphaC*alphaH*PH_G + (PC/PN)*(1-alphaC)*PN_G;
PC_lambda  = (PC/PH)*alphaC*alphaH*PH_lambda + (PC/PN)*(1-alphaC)*PN_lambda;

% Solution for PI=PI(PH,PN) - PI = PI(K,Q,G)
PI_K       = (PI/PH)*alphaI*alphaIH*PH_K + (PI/PN)*(1-alphaI)*PN_K;
PI_Q       = (PI/PH)*alphaI*alphaIH*PH_Q + (PI/PN)*(1-alphaI)*PN_Q;
PI_G       = (PI/PH)*alphaI*alphaIH*PH_G + (PI/PN)*(1-alphaI)*PN_G;
PI_lambda  = (PI/PH)*alphaI*alphaIH*PH_lambda + (PI/PN)*(1-alphaI)*PN_lambda;

% Solution for GE=PH*GH + PN*GN + GF - G = G(K,Q,G)
G_K        = (PH_K*GH) + (PN_K*GN);
G_Q        = (PH_Q*GH) + (PN_Q*GN);
G_G        = (PH_G*GH) + (PN_G*GN) + (PH*GH_G) + (PN*GN_G) + GF_G;
G_lambda   = (PH_lambda*GH) + (PN_lambda*GN);

% Solution for the price of non traded goods in terms of home traded goods
% - P = P(K,Q,G,Aj,Bj);
P    = PN/PH;
P_K  = (P/PN)*PN_K - (P/PH)*PH_K;
P_Q  = (P/PN)*PN_Q - (P/PH)*PH_Q;
P_G  = (P/PN)*PN_G - (P/PH)*PH_G;
P_lambda = (P/PN)*PN_lambda - (P/PH)*PH_lambda;

% GDP and output shares in real terms
Y   = (PH*YH) +(PN*YN);

% Solution for Y as function Y=Y(K,Q,lambda,GH,GN)
Y_K       = (PH_K*YH) + (PH*YH_K) + (PN_K*YN) + (PN*YN_K);
Y_Q       = (PH_Q*YH) + (PH*YH_Q) + (PN_Q*YN) + (PN*YN_Q);
Y_G       = (PH_G*YH) + (PH*YH_G) + (PN_G*YN) + (PN*YN_G);
Y_lambda  = (PH_lambda*YH) + (PH*YH_lambda) + (PN_lambda*YN) + (PN*YN_lambda);

% Marginal revenue of capital R = PH*partial YH/partial KH.
% R=R(K,Q,G,Aj,Bj,lambda)
R_K = (RK/PH)*PH_K - (RK/kH)*thetaH*kH_K - RK*thetaH*uKH_K; 
R_Q = (RK/PH)*PH_Q - (RK/kH)*thetaH*kH_Q - RK*thetaH*uKH_Q; 
R_G = (RK/PH)*PH_G - (RK/kH)*thetaH*kH_G - RK*thetaH*uKH_G;
R_lambda = (RK/PH)*PH_lambda - (RK/kH)*thetaH*kH_lambda - RK*thetaH*uKH_lambda;

% Solving for investment function I/K = v(Q/PI)+delta_K -
% v=v(K,Q,G,Aj,Bj,lambda) final solution
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q);
v_K  = (v_PN*PN_K) + (v_PH*PH_K);
v_G  = (v_PN*PN_G) + (v_PH*PH_G);
v_lambda = (v_PN*PN_lambda) + (v_PH*PH_lambda);

% Elements of the Jacobian Matrix 
Upsilon_K = (I/IN)*(YN_K-CN_K-(KN*xi1N*uKN_K)) - deltaK + alphaI*phiI*I*( (PN_K/PN) - (alphaIH/PH)*PH_K );                                                                        
Upsilon_Q = (I/IN)*(YN_Q-CN_Q-(KN*xi1N*uKN_Q)) + alphaI*phiI*I*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );
Sigma_K   = -(R_K-(RK/K)+(RK/K)*((KH*uKH_K)+(KN*uKN_K)+(KH*uZH_K)+(KN*uZN_K)+(KH_K+KN_K))-(PH*KH/K)*xi1H*uKH_K-(PN*KN/K)*xi1N*uKN_K + (PI*kappa*v_K*deltaK) ); 
Sigma_Q   = (r+deltaK)-( R_Q+(RK/K)*((KH*uKH_Q)+(KN*uKN_Q))+(RK/K)*((KH*uZH_Q)+(KN*uZN_Q))+(RK/K)*(KH_Q+KN_Q)-(PH*KH/K)*xi1H*uKH_Q-(PN*KN/K)*xi1N*uKN_Q + (PI*kappa*v_Q*deltaK) ); 

x11 = Upsilon_K;                                                                         
x12 = Upsilon_Q;                                                                                                                                                                                                                     
x21 = Sigma_K;                        
x22 = Sigma_Q;    

J = [x11 x12; x21 x22];
[V,nu]=eig(J)
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu1 = nu_sorted(1,1); 
nu2 = nu_sorted(2,2); 
omega11 = V_sorted(1,1)/V_sorted(1,1); 
omega21 = V_sorted(2,1)/V_sorted(1,1); 
omega12 = V_sorted(1,2)/V_sorted(1,2); 
omega22 = V_sorted(2,2)/V_sorted(1,2); 
TrJ = trace(J); 
DetJ = det(J); 

% Intertemporal solvency condition - lambda - dotB = Xi(lambda,K,P,Q);
% Xi_Q=0
B_K   = (PH_K*XH) + (PH*XH_K) - MF_K; 
B_Q   = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
N1    = (B_K + (B_Q*omega21));
H1    = N1/(nu1-r); 

% Government spending 
G       = (PH*GH) + (PN*GN) + GF;   
GT      = GF + (PH*GH); 
omegaGT = GT/G; 
omegaGH = (PH*GH)/G; 
omegaGF = GF/G; 

% Investment 
IT       = deltaK*K*iota*((PIT/PI)^(-phiI));
I_check  = ( (iota^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-iota)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1)); 
IT_check = ( (iotaH^(1/rhoI))*(IH^((rhoI-1)/rhoI)) + ((1-iotaH)^(1/rhoI))*(IF^((rhoI-1)/rhoI)) )^(rhoI/(rhoI-1));  
I        = deltaK*K; 
EI       = PI*I; 
EIT      = (PH*IH) + IF; 
omegaI   = PI*I/Y;
omegaIH  = (PH*IH)/(PI*I);
omegaIF  = (IF)/(PI*I);

% Net exports, current account and saving
NX  = (PH*XH) - MF;  
CA  = (r*B) + (PH*XH) - MF; 
A   = B + (PI*K); 
Tax = G; 
Sav = (r*A) + (W*L) - (PC*C) - Tax; 

% Real Aggregate Wage 
WPC  = W/PC;
WHPC = WH/PC;
WNPC = WN/PC;
RKPC = RK/PC;

% Labor income and Capital income shares
EL      = W*L; 
omegaL  = EL/Y; 
EK      = RK*K; 
omegaK  = EK/Y;
alphaK  = (RKN*KN)/(RK*K); 

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WH); 
YHYN  = (YH/YN); 
LHLN  = (LH/LN);

% Consumption 
CT       = C*varphi*((PT/PC)^(-phi));
C_check  = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1)); 
CT_check = ( (varphiH^(1/rho))*(CH^((rho-1)/rho)) + ((1-varphiH)^(1/rho))*(CF^((rho-1)/rho)) )^(rho/(rho-1));
omegaCH  = (PH*CH)/(PC*C); 
omegaCF  = (CF)/(PC*C);

% L_H, L_N and FOC for LH and LN 
Vut     = ( (vartheta^(-1/epsilon))*(LH^((epsilon+1)/epsilon)) + ((1-vartheta)^(-1/epsilon))*(LN^((epsilon+1)/epsilon)) ); 
L_check = Vut^(epsilon/(epsilon+1)); 
L_H     = ((vartheta)^(-1/epsilon))*(LH/L)^(1/epsilon); 
L_N     = ((1-vartheta)^(-1/epsilon))*(LN/L)^(1/epsilon);

% Sectoral ratios
omegaINYN = IN/YN; 
omegaIHYH = IH /YH; 
omegaIFYH =  IF/YH;
omegaGHYH = GH / YH;
omegaGFYH = GF / (PH*YH);
omegaGNYN = GN / YN;
omegaGN   = (PN*GN) / G;
omegaYH   = (PH*YH) / Y;
omegaYN   = (PN*YN) /Y; 
omegaLH   = LH / L;
omegaLN   = LN / L; 
omegaXHY  = (PH*XH) / Y; 
omegaXHYH = XH / YH;

% Targeted ratios
omegaC    = (PC*C) / Y;
omegaNX   =  NX / Y; 
omegaG    = G/Y;
omegaB    = (r*B)/Y; 
omegaKY   = K/Y; 

% Technology
Z  = (ZH^omegaYH)*(ZN^(1-omegaYH));

% TFP
TFPH = YH/((LH^thetaH)*(KH^(1-thetaH))); 
TFPN = YN/((LH^thetaN)*(KH^(1-thetaN))); 
TFP  = (TFPH^omegaYH)*(TFPN^(1-omegaYH));

% Check the closure of the model
cond1  = PH*(1-thetaH)*(YH/KH)-RK;                               
cond2  = PN*(1-thetaN)*(YN/KN)-RK;                             
cond3  = PH*thetaH*(YH/LH)-WH;                                   
cond4  = PN*thetaN*(YN/LN)-WN;                                 
cond5  = (LH*kH)+(LN*kN)-K;                                   
cond6  = RK-(deltaK+r)*PI;                                    
cond7  = YN-CN-GN-IN;                                         
cond8  = YH-CH-GH-IH-XH;                                   
cond9  = (B-B0) - H1*(K-K0);                                  
cond10  = DetJ - (nu1*nu2);                                   
cond11 = TrJ - (nu1+nu2);                                     
cond12 = (LH/LN) - (vartheta/(1-vartheta))*Omega^(-epsilon);  
cond13 = (CT/CN) - (varphi/(1-varphi))*(PN/PT)^(phi);               
cond14 = (PC*C) - ((PT*CT)+(PN*CN));                                
cond15 = (W*L) - ((WH*LH)+(WN*LN));                           
cond16 = gammaL*(L^(1/sigmaL))*L_H - (lambda*WH);               
cond17 = gammaL*(L^(1/sigmaL))*L_N - (lambda*WN);               
cond18 = Y - (PC*C) - G - (PI*I) + (r*B);                     
cond19 = Sav;                                                 
cond20 = (PC*C) - (CF+(PH*CH)+(PN*CN));                                
cond21 = (IT/IN) - (iota/(1-iota))*(PN/PIT)^(phiI);            
cond22 = (PI*I) - ((PIT*IT)+(PN*IN));                                
cond23 = (RK*K) - ((RKH*KH)+(RKN*KN));                        
cond24 = 1 - (omegaK + omegaL);    
cond25 = (CH/CF) - (varphiH/(1-varphiH))*(PH)^(-rho);    
cond26 = (PT*CT) - ((PH*CH)+CF); 
cond27 = (IH/IF) - (iotaH/(1-iotaH))*(PH)^(-rhoI);    
cond28 = (PIT*IT) - ((PH*IH)+IF); 
cond29 = r*B + (PH*XH) - MF; 
cond30 = r*B + (RK*K) + (W*L) - G - (PC*C) - (PI*I); 
cond31 = RK - PI*(r+deltaK);
 
disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                     Initial Steady State with kH > kN');
disp('                           The Benchmark: ');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (benchmark)');
disp(sprintf('thetaH  : %5.2f   thetaN   : %5.2f',thetaH,thetaN));
disp(sprintf('sLH     : %5.2f   sLN      : %5.2f',sLH,sLN));
disp(sprintf('sigmaC  : %5.2f   phi      : %5.2f  varphi : %5.2f',sigmaC,phi,varphi));
disp(sprintf('rho     : %5.2f   varphiH  : %5.2f ',rho,varphiH));
disp(sprintf('phiI    : %5.2f   iota     : %5.2f ',phiI,iota)); 
disp(sprintf('rhoI    : %5.2f   iotaH    : %5.2f ',rhoI,iotaH))
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f ',sigmaL,gammaL));
disp(sprintf('epsilon : %5.2f   vartheta : %5.2f',epsilon,vartheta));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('ZH      : %5.2f   ZN       : %5.2f',ZH,ZN));
disp(sprintf('TFPH    : %5.2f   TFPN     : %5.2f',TFPH,TFPN));
disp(sprintf('omegaYH : %5.2f   Z        : %5.2f TFP        : %5.2f',omegaYH,Z,TFP));
disp(sprintf('GH      : %5.2f   GN       : %5.2f',GH,GN));
disp(sprintf('GF      : %5.2f   G        : %5.2f',GF,G));
disp(' ');

disp(' ');
disp('The production side (benchmark)');
disp(sprintf('kH       : %9.3f    kN   : %9.3f',kH,kN));
disp(sprintf('LH       : %9.3f    LN   : %9.3f',LH,LN));
disp(sprintf('KH       : %9.3f    KN   : %9.3f',KH,KN));
disp(sprintf('YH       : %9.3f    YN   : %9.3f',YH,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('L_check  : %9.3f   ',L_check));
disp(sprintf('alphaL   : %9.3f   ',alphaL));

disp(' ');
disp('The demand side (benchmark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('CT       :   %7.3f  CT_check : %9.3f',CT,CT_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('PT       :   %7.3f    alphaH : %9.3f',PT,alphaH));
disp(sprintf('CH       :   %7.3f    CN     : %9.3f',CH,CN));
disp(sprintf('CF       :   %7.3f',CF));

disp('The demand side (benchmark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('PIT      :   %7.3f   alphaIH : %9.3f',PIT,alphaIH));
disp(sprintf('IH       :   %7.3f    IN     : %9.3f',IH,IN));
disp(sprintf('EI       :   %7.3f    EIT    : %9.3f',EI,EIT));

disp('Export and import (benchmark)');
disp(sprintf('XH        :   %7.3f   MF : %9.3f',XH,MF));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector H');
disp(sprintf('Gross output (YH)  : %9.3f',YH));
disp(sprintf('WH                 : %9.3f',WH));
disp(sprintf('Profit             : %9.10f',PiH));

disp('Price of Non Tradables in terms of Imports');                                                                
disp(' ');                                                                                      
disp('Relative Prices');  
disp(sprintf('PN_K       : %5.4f   PN_Q       : %5.4f',PN_K,PN_Q));                                 
disp(sprintf('PN_G       :  %5.4f  PN_lambda  : %5.4f',PN_G,PN_lambda));  
disp(sprintf('PH_K       : %5.4f   PH_Q       : %5.4f',PH_K,PH_Q));                                 
disp(sprintf('PH_G       :  %5.4f  PH_lambda  : %5.4f',PH_G,PH_lambda));                        
                                                                                               
disp(' ');                                                                                      
disp('Partial derivatives CH and CN');                                                          
disp(sprintf('CN_K        :   %7.3f  CH_K      : %9.3f',CN_K,CH_K));                            
disp(sprintf('CN_Q        :   %7.3f  CH_Q      : %9.3f',CN_Q,CH_Q));                            
disp(sprintf('CN_lamb     :   %7.3f  CH_lamb   : %9.3f',CN_lambda,CH_lambda));                  
disp(sprintf('CN_G        :   %7.3f  CH_G      : %9.3f',CN_G,CH_G)); 
disp(sprintf('CN_lamb     :   %7.3f  CH_lamb   : %9.3f',CN_lambda,CH_lambda));                                                                                                                                                                                                                  
disp('Partial derivatives LH and LN');                                                          
disp(sprintf('LN_WH       :   %7.3f  LH_WH      : %9.3f',LN_WH,LH_WH));                         
disp(sprintf('LN_WN       :   %7.3f  LH_WN      : %9.3f',LN_WN,LH_WN));                         
disp(sprintf('LN_lamb     :   %7.3f  LH_lamb    : %9.3f',LN_lambda,LH_lambda));                 
disp(sprintf('LN_G        :   %7.3f  LH_G       : %9.3f',LN_G,LH_G));  
                                                                                                
disp('Partial derivatives kH and kN');                                                          
disp(sprintf('kN_Q       :   %7.6f  kH_Q       : %9.6f',kN_Q,kH_Q));                            
disp(sprintf('kN_K       :   %7.6f  kH_K       : %9.6f',kN_K,kH_K));                            
disp(sprintf('kN_lambda  :   %7.3f  kH_lambda  : %9.3f',kN_lambda,kH_lambda));                  
disp(sprintf('kN_G       :   %7.6f  kH_G       : %9.6f',kN_G,kH_G));   
                                                                                              
disp('Partial derivatives WH and WN');                                                          
disp(sprintf('WN_Q       :   %7.6f  WH_Q       : %9.6f',WN_Q,WH_Q));                            
disp(sprintf('WN_K       :   %7.6f  WH_K       : %9.6f',WN_K,WH_K));                            
disp(sprintf('WN_lambda  :   %7.3f  WH_lambda  : %9.3f',WN_lambda,WH_lambda));                  
disp(sprintf('WN_G       :   %7.6f  WH_G       : %9.6f',WN_G,WH_G)); 
                                                                                               
disp('Partial derivatives LH and LN');                                                          
disp(sprintf('LN_Q       :   %7.6f  LH_Q       : %9.6f',LN_Q,LH_Q));                            
disp(sprintf('LN_K       :   %7.6f  LH_K       : %9.6f',LN_K,LH_K));                            
disp(sprintf('LN_lambda  :   %7.3f  LH_lambda  : %9.3f',LN_lambda,LH_lambda));                  
disp(sprintf('LN_G       :   %7.6f  LH_G       : %9.6f',LN_G,LH_G)); 

disp('Partial derivatives Yj');  
disp(sprintf('YN_1PN     :   %7.6f  YN_1PH     : %9.6f',YN_1PN,YN_1PH));
disp(sprintf('YN_1K      :   %7.6f  YN_1lambda : %9.6f',YN_1K,YN_1lambda));
disp(sprintf('YN_uKH     :   %7.6f  YN_uKN     : %9.6f',YN_uKH,YN_uKN));
disp(sprintf('YN_uZH     :   %7.6f  YH_uZN     : %9.6f',YN_uZH,YN_uZN));
disp(' ');
disp(sprintf('YH_1PN     :   %7.6f  YH_1PH     : %9.6f',YH_1PN,YH_1PH));
disp(sprintf('YH_1K      :   %7.6f  YH_1lambda : %9.6f',YH_1K,YH_1lambda));
disp(sprintf('YH_uKH     :   %7.6f  YH_uKN     : %9.6f',YH_uKH,YH_uKN));
disp(sprintf('YH_uZH     :   %7.6f  YH_uZN     : %9.6f',YH_uZH,YH_uZN));
disp(' ');

disp(sprintf('YN_Q       :   %7.6f  YH_Q       : %9.6f',YN_Q,YH_Q));                            
disp(sprintf('YN_K       :   %7.6f  YH_K       : %9.6f',YN_K,YH_K));                            
disp(sprintf('YN_lambda  :   %7.3f  YH_lambda  : %9.3f',YN_lambda,YH_lambda));                  
disp(sprintf('YN_G       :   %7.6f  YH_G       : %9.6f',YN_G,YH_G));
                                                                                                
disp('Partial derivatives of Y');                                                               
disp(sprintf('Y_Q        :   %7.3f  Y_K        : %9.3f',Y_Q,Y_K));  
disp(sprintf('Y_G        :   %7.3f  Y_lambda   : %9.3f',Y_G,Y_lambda));                                                                          
                                                                         
disp('Partial derivatives of L');
disp(sprintf('L_H        :   %7.3f  L_N        : %9.3f',L_H,L_N));

disp('Partial derivatives of L');                                                               
disp(sprintf('L_Q        :   %7.3f  L_K        : %9.3f',L_Q,L_K));                              
disp(sprintf('L_G        :   %7.3f ',L_G));      
disp(sprintf('L_lambda   :   %7.3f  tildeW_lambda   : %9.3f',L_lambda,tildeW_lambda));  

disp('Partial derivatives of uKj');  
disp(sprintf('uKN_Q       :   %7.6f  uKH_Q       : %9.6f',uKN_Q,uKH_Q));             
disp(sprintf('uKN_K       :   %7.6f  uKH_K       : %9.6f',uKN_K,uKH_K));             
disp(sprintf('uKN_lambda  :   %7.3f  uKH_lambda  : %9.3f',uKN_lambda,uKH_lambda));   
disp(sprintf('uKN_G       :   %7.6f  uKH_G       : %9.6f',uKN_G,uKH_G));             
  
disp('Partial derivatives of uZj');  
disp(sprintf('uZN_Q       :   %7.6f  uZH_Q       : %9.6f',uZN_Q,uZH_Q));            
disp(sprintf('uZN_K       :   %7.6f  uZH_K       : %9.6f',uZN_K,uZH_K));            
disp(sprintf('uZN_lambda  :   %7.3f  uZH_lambda  : %9.3f',uZN_lambda,uZH_lambda));  
disp(sprintf('uZN_G       :   %7.6f  uZH_G       : %9.6f',uZN_G,uZH_G));            
                                                                                                       
disp('Partial derivatives of W');                                                               
disp(sprintf('tildeW_WH       :   %7.3f  tildeW_WN       : %9.3f',tildeW_WH,tildeW_WN));   
disp(sprintf('tildeW_Q        :   %7.3f  tildeW_K        : %9.3f',tildeW_Q,tildeW_K));          
disp(sprintf('tildeW_G        :   %7.3f',tildeW_G));                                          
disp(' ');
disp('Wealth');
disp(sprintf('K      :   %5.3f    B  :   %5.6f',K,B));
disp(sprintf('lambda :   %5.15f   A  :   %5.3f',lambda,A));
disp(sprintf('Sav    :   %5.10f   CA :   %5.10f',Sav,CA));

disp(' ');                                                                                      
disp('Linearization');                                                                          
disp(sprintf('R_lambda  :  %5.4f  R_K       : %5.4f   R_Q     : %5.4f',R_lambda,R_K,R_Q));      
disp(sprintf('R_G       :  %5.4f',R_G));
disp(sprintf('P_K       : %5.4f   P_Q       : %5.4f',P_K,P_Q));                                 
disp(sprintf('P_G       :  %5.4f',P_G));     
disp(sprintf('v_K       :  %5.4f  v_Q       : %5.4f',v_K,v_Q));                                 
disp(sprintf('v_G       :  %5.4f',v_G));          
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_Q : %5.4f',Upsilon_K,Upsilon_Q));                     
disp(sprintf('Sigma_K   :  %5.4f  Sigma_Q   : %5.4f',Sigma_K,Sigma_Q));                         
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));  
                                                                                                
disp(' ');
disp('Eigenvalues and Eigenvectors');
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu1,nu2));
disp(sprintf('omega11    :   %5.6f  omega12    : %5.6f',omega11,omega12));
disp(sprintf('omega21    :   %5.6f  omega22    : %5.6f',omega21,omega22));
disp(sprintf('N1         :   %5.6f    H1       : %5.6f',N1,H1));
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));

disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('YH / Y    :  %5.3f      PN*YN / Y  : %5.3f',omegaYH,omegaYN));
disp(sprintf('LH / L    :  %5.3f      LN / L    : %5.3f',omegaLH,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('PN*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GH / YH     :  %5.3f  GN / YN    :  %5.3f  (PN*GN)/G  : %5.3f',omegaGHYH,omegaGNYN,omegaGN));
disp(sprintf('(PH*GH)/G   :  %5.3f  GF / G     :  %5.3f  GT/G       : %5.3f',omegaGH,omegaGF,omegaGT));
disp(sprintf('IN / YN     :  %5.3f  IH / YH    :  %5.3f  (r*B)/Y    : %5.3f',omegaINYN,omegaIHYH,omegaB));
disp(sprintf('IF / YH     :  %5.3f  GF / YH    :  %5.3f',omegaIFYH,omegaGFYH));
disp(sprintf('WN*LN/W*L   :  %5.3f RN*KN/R*K   :  %5.3f',alphaL,alphaK));
disp(sprintf('PIT*IT/PI*I :  %5.3f PT*CT/PC*C  :  %5.3f',alphaI,alphaC));
disp(sprintf('PH*IH/PT*IT :  %5.3f PH*CH/PT*CT :  %5.3f',alphaIH,alphaH));
disp(sprintf('PH*IH/PI*I  :  %5.3f PH*CH/PC*C  :  %5.3f',omegaIH,omegaCH));
disp(sprintf('IF/PI*I     :  %5.3f    CF/PC*C  :  %5.3f',omegaIF,omegaCF));
disp(sprintf('PH*XH/Y  :  %5.3f       XH / YH  :  %5.3f',omegaXHY,omegaXHYH));
disp(sprintf('W*L/Y       :  %5.3f R*K/Y       :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y         :  %5.3f',omegaKY));

disp(' ');
disp(sprintf('Marginal product of KH = RT       : %9.16f   ',cond1));
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));
disp(sprintf('Marginal product of LH = WH       : %9.16f   ',cond3));
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));
disp(sprintf('Resource contraint for capital    : %9.16f   ',cond5));
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));
disp(sprintf('Market clearing condition good H  : %9.16f   ',cond8));
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));
disp(sprintf('Relative labor  LH/LN             : %9.16f   ',cond12));
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));
disp(sprintf('FOC -V_L*(dL/dLH) = lambda*WH     : %9.16f   ',cond16));
disp(sprintf('FOC -V_L*(dL/dLN) = lambda*WN     : %9.16f   ',cond17));
disp(sprintf('Global market clearing condition  : %9.16f   ',cond18));
disp(sprintf('Private Savings                   : %9.16f   ',cond19));
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond20));
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond21));
disp(sprintf('Investment expenditure check      : %9.16f   ',cond22));
disp(sprintf('Capital income R*K                : %9.16f   ',cond23));
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond24));
disp(sprintf('relative consumption  CH/CF       : %9.16f   ',cond25));
disp(sprintf('Consumption expenditure in T PT*CT: %9.16f   ',cond26));
disp(sprintf('relative investment   IH/IF       : %9.16f   ',cond27));
disp(sprintf('Investment expenditure in T PIT*JT: %9.16f   ',cond28));
disp(sprintf('Current account                   : %9.16f   ',cond29));
disp(sprintf('Current account                   : %9.16f   ',cond30));

kH_0CD = kH;  kN_0CD = kN; PN_0CD = PN; LH_0CD = LH; K_0CD = K; C_0CD = C;                       
LN_0CD  = LN; L_0CD = L; W_0CD = W; P_0CD = P;                                                   
YH_0CD  = YH; YN_0CD  = YN; Y_0CD  = Y; KH_0CD  = KH; KN_0CD  = KN; G_0CD = G;                   
PC_0CD = PC; alphaC_0CD = alphaC; CN_0CD = CN; CH_0CD = CH;                                      
ZH_0CD = ZH; ZN_0CD = ZN; Z_0CD = Z; GH_0CD = GH; GN_0CD = GN;                                   
LH_0CD = LH; LN_0CD = LN; KH_0CD = KH; KN_0CD = KN; WH_0CD = WH; WN_0CD = WN;                    
Omega_0CD = Omega; YHYN_0CD = YHYN; LHLN_0CD = LHLN;                                             
IF_0CD = IF; CF_0CD = CF; XH_0CD = XH; MF_0CD = MF; GF_0CD = GF; PH_0CD = PH;                    
PT_0CD = PT; PIT_0CD = PIT; CT_0CD = CT; IT_0CD = IT; GT_0CD = GT;                               
                                                                                                 
CA_0CD = CA; Sav_0CD = Sav; NX_0CD = NX; I_0CD = I; lambda_0CD  = lambda; A_0CD = A;             
B_0CD = B; IN_0CD = IN; IH_0CD = IH; PI_0CD = PI; alphaI_0CD = alphaI; EI_0CD = EI;              
WPC_0CD = WPC; WHPC_0CD = WHPC; WNPC_0CD = WNPC; alphaL_0CD = alphaL; RK_0CD = RK;               
                                                                                                 
omegaL_0CD = omegaL; omegaK_0CD = omegaK; omegaI_0CD = omegaI; omegaINYN_0CD = omegaINYN;        
omegaIHYH_0CD = omegaIHYH; omega_IFYH_0CD = omegaIFYH; omegaGHYH_0CD = omegaGHYH;                
omegaGFYH_0CD = omegaGFYH; omegaGNYN_0CD = omegaGNYN; omegaGN_0CD = omegaGN;                     
omegaYH_0CD = omegaYH; omegaYN_0CD = omegaYN; omegaLH_0CD = omegaLH; omegaLN_0CD = omegaLN;      
omegaC_0CD =omegaC; omegaNX_0CD =omegaNX; omegaG_0CD =omegaG; omegaB_0CD =omegaB;                
omegaIFYH_0CD = omegaIFYH; omegaGFYH_0CD = omegaGFYH; omegaIH_0CD = omegaIH;                     
omegaCH_0CD = omegaCH; omegaIF_0CD = omegaIF; omegaCF_0CD = omegaCF;                             
omegaGT_0CD = omegaGT; omegaGH_0CD = omegaGH; omegaGF_0CD = omegaGF;                             
omegaKY_0CD = omegaKY; omegaIH_0CD = omegaIH; omegaIF_0CD = omegaIF;                             
omegaXHY_0CD = omegaXHY; omegaXHYH_0CD = omegaXHYH;                                              
alphaL_0CD = alphaL; alphaK_0CD = alphaK; alphaC_0CD = alphaC;                                   
alphaI_0CD = alphaI; alphaH_0CD = alphaH; alphaIH_0CD = alphaIH;                                 
sLH_0CD = sLH; sLN_0CD = sLN; H1_0CD = H1; 
TFPH_0CD = TFPH; TFPN_0CD = TFPN; TFP_0CD = TFP; Z_0CD = Z; 
                                                                                                                                                                                                                                            

