clc
clear


% Maximum duration for graphics
Tg = 10;
       
% Minimum duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;

FISC_IML_CAC_TOT_CD_NOTECH;
FISC_IML_CAC_TOT_CES_TECH; 

%time0    = [Tm:Tu:0];
%time1    = [0:Tu:Tg]; % span of time t = [0..100]
%timetemp = [time0 time1];

%%%%%%%%%%% Impulse functions %%%%%%%%%% 

%%%%% LP-GOV                                                                                                                                          
[xdata1]=xlsread('LP_LGOV.xlsx');   %scaling=[1 1 1];                                                                                                   
namvar= char('IRF_LGOV');  nbPVAR  = 1;                                                                                                                
                                                                                                                                                      
[obs nbvar1]=size(xdata1);                                                                                                                            
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=8)     
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)                                             
nvar1     = nbvar1/3;                       % number of variables included in VAR                                                                     
irf1      = xdata1(1:obs,nvar1+1:2*nvar1);    % IRF of variables                                                                                      
lowerb1   = xdata1(1:obs,1:nvar1);           % lower bound of IRF                                                                                     
upperb1   = xdata1(1:obs,2*nvar1+1:3*nvar1);  % upper bound of IRF                                                                                    
                                                                                                                                                      
%%%%% LP-GDP
[xdata2]=xlsread('LP_LYR.xlsx');   %scaling=[1 1 1];              
namvar= char('IRF_LYR');  nbPVAR  = 2;

[obs nbvar2]=size(xdata2);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=8) 
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar2     = nbvar2/3;                       % number of variables included in VAR
irf2      = xdata2(1:obs,nvar2+1:2*nvar2);    % IRF of variables 
lowerb2   = xdata2(1:obs,1:nvar2);           % lower bound of IRF
upperb2   = xdata2(1:obs,2*nvar2+1:3*nvar2);  % upper bound of IRF

%%%%% LP-L
[xdata3]=xlsread('LP_LABH.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LABH');  nbPVAR  = 1;

[obs nbvar3]=size(xdata3);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=8)
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar3     = nbvar3/3;                       % number of variables included in VAR
irf3      = xdata3(1:obs,nvar3+1:2*nvar3);    % IRF of variables
lowerb3   = xdata3(1:obs,1:nvar3);           % lower bound of IRF
upperb3   = xdata3(1:obs,2*nvar3+1:3*nvar3);  % upper bound of IRF

%%%%% LP_PNPH
[xdata9]=xlsread('LP_LRPNT.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LRPNT');  nbPVAR  = 1;

[obs nbvar9]=size(xdata9);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=9)
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar9     = nbvar9/3;                       % number of variables included in VAR
irf9      = xdata9(1:obs,nvar9+1:2*nvar9);    % IRF of variables
lowerb9   = xdata9(1:obs,1:nvar9);           % lower bound of IRF
upperb9   = xdata9(1:obs,2*nvar9+1:3*nvar9);  % upper bound of IRF

%%%%% LP_PHPF
[xdata10]=xlsread('LP_LRPTPTstar.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LRPHPHSTARG');  nbPVAR  = 1;

[obs nbvar10]=size(xdata10);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=9)
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar10     = nbvar10/3;                       % number of variables included in VAR
irf10      = xdata10(1:obs,nvar10+1:2*nvar10);    % IRF of variables
lowerb10   = xdata10(1:obs,1:nvar10);           % lower bound of IRF
upperb10   = xdata10(1:obs,2*nvar10+1:3*nvar10);  % upper bound of IRF

%%%%% LP_YN
[xdata11]=xlsread('LP_LYN.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LYN'); nbPVAR  = 1;

[obs nbvar11]=size(xdata11);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=9)
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar11     = nbvar11/3;                       % number of variables included in VAR
irf11      = xdata11(1:obs,nvar11+1:2*nvar11);    % IRF of variables
lowerb11   = xdata11(1:obs,1:nvar11);           % lower bound of IRF
upperb11   = xdata11(1:obs,2*nvar11+1:3*nvar11);  % upper bound of IRF

%%%%% LP_LN
[xdata12]=xlsread('LP_LHN.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LHN');  nbPVAR  = 1;

[obs nbvar12]=size(xdata12);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=9)
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar12     = nbvar12/3;                       % number of variables included in VAR
irf12      = xdata12(1:obs,nvar12+1:2*nvar12);    % IRF of variables
lowerb12   = xdata12(1:obs,1:nvar12);           % lower bound of IRF
upperb12   = xdata12(1:obs,2*nvar12+1:3*nvar12);  % upper bound of IRF

%%%%% LP_YNS
[xdata14]=xlsread('LP_LYNY.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LYNY');  nbPVAR  = 1;

[obs nbvar14]=size(xdata14);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=9)
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar14     = nbvar14/3;                       % number of variables included in VAR
irf14      = xdata14(1:obs,nvar14+1:2*nvar14);    % IRF of variables
lowerb14   = xdata14(1:obs,1:nvar14);           % lower bound of IRF
upperb14   = xdata14(1:obs,2*nvar14+1:3*nvar14);  % upper bound of IRF

%%%%% LP_LNS
[xdata15]=xlsread('LP_LHNH.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LHNH');  nbPVAR  = 1;

[obs nbvar15]=size(xdata15);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=9)
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar15     = nbvar15/3;                       % number of variables included in VAR
irf15      = xdata15(1:obs,nvar15+1:2*nvar15);    % IRF of variables
lowerb15   = xdata15(1:obs,1:nvar15);           % lower bound of IRF
upperb15   = xdata15(1:obs,2*nvar15+1:3*nvar15);  % upper bound of IRF

%%%%% LP_WNW
[xdata16]=xlsread('LP_LRWNW.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LRWNW');  nbPVAR  = 1;

[obs nbvar16]=size(xdata16);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=9)
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar16     = nbvar16/3;                       % number of variables included in VAR
irf16      = xdata16(1:obs,nvar16+1:2*nvar16);    % IRF of variables
lowerb16   = xdata16(1:obs,1:nvar16);           % lower bound of IRF
upperb16   = xdata16(1:obs,2*nvar16+1:3*nvar16);  % upper bound of IRF

%%%%% LP_YH
[xdata17]=xlsread('LP_LYT.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LYT');  nbPVAR  = 1;

[obs nbvar17]=size(xdata17);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=9)
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar17     = nbvar17/3;                       % number of variables included in VAR
irf17      = xdata17(1:obs,nvar17+1:2*nvar17);    % IRF of variables
lowerb17   = xdata17(1:obs,1:nvar17);           % lower bound of IRF
upperb17   = xdata17(1:obs,2*nvar17+1:3*nvar17);  % upper bound of IRF

%%%%% LP_LH
[xdata18]=xlsread('LP_LHT.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LHT');  nbPVAR  = 1;

[obs nbvar18]=size(xdata18);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=9)
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar18     = nbvar18/3;                       % number of variables included in VAR
irf18      = xdata18(1:obs,nvar18+1:2*nvar18);    % IRF of variables
lowerb18   = xdata18(1:obs,1:nvar18);           % lower bound of IRF
upperb18   = xdata18(1:obs,2*nvar18+1:3*nvar18);  % upper bound of IRF

%%%%% LP_YHY
[xdata20]=xlsread('LP_LYTY.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LYTY');  nbPVAR  = 1;

[obs nbvar20]=size(xdata20);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=9)
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar20     = nbvar20/3;                       % number of variables included in VAR
irf20      = xdata20(1:obs,nvar20+1:2*nvar20);    % IRF of variables
lowerb20   = xdata20(1:obs,1:nvar20);           % lower bound of IRF
upperb20   = xdata20(1:obs,2*nvar20+1:3*nvar20);  % upper bound of IRF

%%%%% LP_LHL
[xdata21]=xlsread('LP_LHTH.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LHTH');  nbPVAR  = 1;

[obs nbvar21]=size(xdata21);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=9)
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar21     = nbvar21/3;                       % number of variables included in VAR
irf21      = xdata21(1:obs,nvar21+1:2*nvar21);    % IRF of variables
lowerb21   = xdata21(1:obs,1:nvar21);           % lower bound of IRF
upperb21   = xdata21(1:obs,2*nvar21+1:3*nvar21);  % upper bound of IRF

%%%%% LP_WHW
[xdata22]=xlsread('LP_LRWTW.xlsx');   %scaling=[1 1 1];
namvar= char('IRF_LRWTW');  nbPVAR  = 1;

[obs nbvar22]=size(xdata22);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=9)
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar22     = nbvar22/3;                       % number of variables included in VAR
irf22      = xdata22(1:obs,nvar22+1:2*nvar22);    % IRF of variables
lowerb22   = xdata22(1:obs,1:nvar22);           % lower bound of IRF
upperb22   = xdata22(1:obs,2*nvar22+1:3*nvar22);  % upper bound of IRF


%%%%%%%%%%% Impulse functions %%%%%%%%%% 

figure(1)
%subplot(3,2,1)
hold on
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb1(1:11,1)',fliplr(lowerb1(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdGY_endo(2:12),'-ks','LineWidth',5);
plot(timetemp(2:12),pathdGY_notech(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf1(1:11,1)','blue','LineWidth',3);
%plot(timetemp(2:12),lowerb1(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb1(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
legend('Technology channel','No technology channel','LP (data)'); %title('Government spending, G');

figure(2)
%subplot(3,2,2)
hold on
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb2(1:11,1)',fliplr(lowerb2(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdtildeYR_endo(2:12),'-ks','LineWidth',5);
plot(timetemp(2:12),pathdtildeYR_notech(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf2(1:11,1)','blue','LineWidth',3);
%plot(timetemp(2:12),lowerb2(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb2(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation in % of initial steady-state');  %title('Real GDP, YR'); 
legend('Technology channel','No technology channel','LP (data)'); 

figure(3)
%subplot(3,2,3)
hold on
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb3(1:11,1)',fliplr(lowerb3(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdL_endo(2:12),'-ks','LineWidth',5);
plot(timetemp(2:12),pathdL_notech(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf3(1:11,1)','blue','LineWidth',3);
%plot(timetemp(2:12),lowerb3(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb3(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation in % of steady-state');  %title('Aggregate Hours Worked, L'); 
legend('Technology channel','No technology channel','LP (data)'); 

figure(4)
%subplot(2,2,1)
hold on
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb18(1:11,1)',fliplr(lowerb18(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdLH_endo(2:12),'-ks','LineWidth',5);
plot(timetemp(2:12),pathdLH_notech(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf18(1:11,1)','blue','LineWidth',3);
%plot(timetemp(2:12),lowerb18(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb18(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation from initial steady-state');  %title('Traded hours worked, LH');
legend('Technology channel','No technology channel','LP (data)'); 

figure(5)
%subplot(2,2,1)
hold on
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb12(1:11,1)',fliplr(lowerb12(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdLN_endo(2:12),'-ks','LineWidth',5);
plot(timetemp(2:12),pathdLN_notech(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf12(1:11,1)','blue','LineWidth',3);
%plot(timetemp(2:12),lowerb12(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb12(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation from initial steady-state');  %title('Non traded output, LN');
legend('Technology channel','No technology channel','LP (data)'); 

figure(6)
%subplot(2,2,1)
hold on
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb15(1:11,1)',fliplr(lowerb15(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdLNS_endo(2:12),'-ks','LineWidth',5);
plot(timetemp(2:12),pathdLNS_notech(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf15(1:11,1)','blue','LineWidth',3);
%plot(timetemp(2:12),lowerb15(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb15(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation from initial steady-state');  %title('Non Traded Hours Worked Share, nu^L,N');
legend('Technology channel','No technology channel','LP (data)'); 

figure(7)
%subplot(2,2,1)
hold on
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb17(1:11,1)',fliplr(lowerb17(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdtildeYH_endo(2:12),'-ks','LineWidth',5);
plot(timetemp(2:12),pathdtildeYH_notech(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf17(1:11,1)','blue','LineWidth',3);
%plot(timetemp(2:12),lowerb17(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb17(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation from initial steady-state');  %title('Traded value added, tildeYH');
legend('Technology channel','No technology channel','LP (data)'); 

figure(8)
%subplot(2,2,1)
hold on
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb11(1:11,1)',fliplr(lowerb11(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdtildeYN_endo(2:12),'-ks','LineWidth',5);
plot(timetemp(2:12),pathdtildeYN_notech(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf11(1:11,1)','blue','LineWidth',3);
%plot(timetemp(2:12),lowerb11(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb11(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation from initial steady-state');  %title('Non traded output, tildeYN');
legend('Technology channel','No technology channel','LP (data)');

figure(9)
%subplot(2,2,1)
hold on
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb14(1:11,1)',fliplr(lowerb14(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdtildeYNS_endo(2:12),'-ks','LineWidth',5);
plot(timetemp(2:12),pathdtildeYNS_notech(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf14(1:11,1)','blue','LineWidth',3);
%plot(timetemp(2:12),lowerb14(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb14(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation from initial steady-state');  %title('Non Traded Real Value Added Share, nu^Y,N');
legend('Technology channel','No technology channel','LP (data)'); 

figure(10)
hold on
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb16(1:11,1)',fliplr(lowerb16(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdtildeWNW_endo(2:12),'-ks','LineWidth',5);
plot(timetemp(2:12),pathdtildeWNW_notech(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf16(1:11,1)','blue','LineWidth',3);
%plot(timetemp(2:12),lowerb16(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb16(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
legend('Technology channel','No technology channel','LP (data)'); 


figure(11)
hold on
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb10(1:11,1)',fliplr(lowerb10(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdPH_endo(2:12),'-ks','LineWidth',5);
plot(timetemp(2:12),pathdPH_notech(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf10(1:11,1)','blue','LineWidth',3);
%plot(timetemp(2:12),lowerb10(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb10(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation in % of initial steady-state');  %title('Terms of Trade, PH/PH*'); 
legend('Technology channel','No technology channel','LP (data)'); 


%subplot(2,2,2)
figure(12)
hold on
xpoints=[timetemp(2:12),fliplr(timetemp(2:12))];
area=[upperb9(1:11,1)',fliplr(lowerb9(1:11,1)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timetemp(2:12),pathdP_endo(2:12),'-ks','LineWidth',5);
plot(timetemp(2:12),pathdP_notech(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timetemp(2:12),irf9(1:11,1)','blue','LineWidth',3);
%plot(timetemp(2:12),lowerb9(1:11,1)','blue','LineWidth',2,'LineStyle','--');
%plot(timetemp(2:12),upperb9(1:11,1)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation in % of initial steady-state');  %title('Relative Price, P = PN/PH'); 
legend('Technology channel','No technology channel','LP (data)'); 




clear

