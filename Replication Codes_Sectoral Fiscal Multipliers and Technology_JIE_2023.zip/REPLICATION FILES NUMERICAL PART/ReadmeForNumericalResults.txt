Data and Replication Codes for 'Sectoral Fiscal Multipliers and Technology in Open Economy' by Olivier Cardi and Romain Restout, May 2023

The Folder 'NUMERICAL RESULTS' comprises three folders: 

1) the folder 'TABLE2-Cumulative Effects on Technology' contains all Matlab codes (plus 'Calibration_Shock_2021_recons.xlsx' that contains the shock process) to generate Table 2 in the main text (Table 2 in section 4.3). To generate the table in the main text, run 'TABLE.m' file

NO CAC: Capital adjustment costs; 
CAC: Capital adjustment costs; 
TOT: Terms of trade; 
IML: Imperfect mobility of labor; 
PML: Perfect mobility of labor
CD: Cobb-Douglas production functions and Hicks neutral technological change
CES: Constant elasticity of substitution production functions; 
FBTC: Factor-biased technological change
NOTECH: Cost of adjusting technology utilization prohibitive, i.e., we let chi_2^j tend towards infinity
nocaput: No endogenous intensity in the use of physical capital, i.e., we let xi_2^j tend towards infinity

Model variants considered (the last model is the baseline model): 
PML_NOCAC_NOTECH; Simplest model with CD production functions, PML, exogenous TOT. 
PML_CAC_NOTECH; Model with CD production functions, CAC, PML, exogenous TOT. 
PML_CAC_nocaput; Model with CD production functions, CAC, PML, exogenous TOT, endogenous technology utilization.
PML_CAC; Model with CD production functions, CAC, PML, exogenous TOT, endogenous capital and technology utilization.
IML_CAC; Model with CD production functions, CAC, IML, exogenous TOT, endogenous capital and technology utilization.
FISC_IML_CAC_TOT_CD: Model with CD production functions, CAC, IML, endogenous TOT, endogenous capital and technology utilization.
FISC_IML_CAC_TOT_nocaput_CD: Model with CD production functions, CAC, IML, endogenous TOT, endogenous technology utilization. We shut down endogenous 
capital utilization.
FISC_IML_CAC_TOT_CES_FBTC_nocaput: Same model as the baaseline except that we shut down endogenous capital utilization. 
FISC_IML_CAC_TOT_CES_FBTC: Baseline model with CES production functions, CAC, IML, endogenous TOT, endogenous capital and technology utilization. 

The CES economy is normalized by using the Cobb-Douglas economy as the normalization point. 
FISC_IML_CAC_TOT_CD_initial: Model with Cobb-Douglas production functions which generates the initial steady-state which is considered as the reference point for the CES economy (i.e., ensures that ratios are unchanged when we modify the elasticity of substitution between 
capital and labor). 
FISC_IML_CAC_TOT_CD_initial_nocaput: Same model as the previous one except the initial steady-state which is generated is the one where we abstract 
from endogenous capital utilization. 

All extensions of Matlab codes '_initial' compute the initial steady-state
All extensions of Matlab codes '_temp' compute the final steady-state
Note that technically, the assumption beta = world interest rate requires the joint determination of the transition and the steady state because the marginal utility of wealth must remain constant and thus must jump initially to fulfill the intertemporal solvency condition which is a function of eigenvalues and eigenvectors. 

2) the folder 'TABLE3-Impact and Cumulative Effects of an Increase in G' contains all Matlab codes (plus 'Calibration_Shock_2021_recons.xlsx' that contains the shock process) to generate Table 3 in the main text (Table 3 in section 4.3). To generate the table in the main text, run 'TABLE.m' file. 

FISC_IML_CAC_TOT_CD_NOTECH: Same model as the baseline except that we shut down endogenous capital and technology utilization rates by letting xi_2^j ad chi_2^j tend toward infinity, and we impose Cobb-Douglas production functions (and thus technological change is Hicks-netral). 
FISC_IML_CAC_TOT_CES_TECH: Baseline model with CES production functions, CAC, IML, endogenous TOT, endogenous capital and technology utilization. 


3) the folder 'FIG2 and FIG3 - Theoretical vs. Empirical Responses' contains all Matlab codes (plus 'Calibration_Shock_2021_recons.xlsx' that contains the shock process) to generate theoretical responses from the baseline model (black line with squares) and from the restricted model (dashed red lines) and contrast them with empirical responses obtained from the SVAR. Just run 'IRF_TECH_FIG2.m' to generate FIGURE 2 and 'IRF_FIG3.m' to generate FIGURE 3 in the main text. 

4) the folder 'FIGURE_TAX - Public Debt and Distortionary Taxation' contains all Matlab codes (plus 'Calibration_Shock_2021_recons.xlsx' that contains the shock process) to generate theoretical responses from the baseline model with lump-sum taxation (black line with squares) and from the model with public debt and distortionary (labor and consumption) taxation (dashed red lines) and contrast them with empirical responses obtained from the SVAR. Just run 'IRF_Tax_vs_NoTax_MAIN.m' to generate IRFs for value added and hours worked and 'IRF_TAX.m' to generate IRFs of Figure 39 in Online Appendix. 