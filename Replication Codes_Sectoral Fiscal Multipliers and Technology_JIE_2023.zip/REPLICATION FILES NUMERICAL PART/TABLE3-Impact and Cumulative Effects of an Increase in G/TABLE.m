%clc
%clear

% Maxim duration for graphics
Tg = 100;
       
% Minim duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;

FISC_IML_CAC_TOT_CD_NOTECH;
FISC_IML_CAC_TOT_CES_TECH; 

%%%%%%%%%% Table of Results %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp('A - Aggregate Multipliers');
disp(sprintf('dGYtime             |%10.2f   |%10.2f  |%10.2f  |%10.2f |',dGYtime0_tech,dGYtime0_notech,dGYcum_tech,dGYcum_notech));
disp(sprintf('dL                  |%10.2f   |%10.2f  |%10.2f  |%10.2f |',dLtime0_tech,dLtime0_notech,dtildeYRcum_tech,dtildeYRcum_notech));
disp(sprintf('dtildeYR            |%10.2f   |%10.2f  |%10.2f  |%10.2f |',dtildeYRtime0_tech,dtildeYRtime0_notech,dLcum_tech,dLcum_notech));

disp(' '); disp('B - Sectoral Labor');
disp(sprintf('dLH                 |%10.2f   |%10.2f  |%10.2f  |%10.2f |',dLHtime0_tech,dLHtime0_notech,dLHcum_tech,dLHcum_notech));
disp(sprintf('dLN                 |%10.2f   |%10.2f  |%10.2f  |%10.2f |',dLNtime0_tech,dLNtime0_notech,dLNcum_tech,dLNcum_notech));
disp(sprintf('dLNS                |%10.2f   |%10.2f  |%10.2f  |%10.2f |',dLNStime0_tech,dLNStime0_notech,dLNScum_tech,dLNScum_notech));
disp('Decomposition of LN/L');
disp(sprintf('dLNS_NTshare        |%10.2f   |%10.2f  |%10.2f  |%10.2f |',dLNS_NTsharetime0_tech,dLNS_NTsharetime0_notech,dLNS_NTsharecum_tech,dLNS_NTsharecum_notech));
disp(sprintf('dLNS_capdiff        |%10.2f   |%10.2f  |%10.2f  |%10.2f |',dLNS_capdifftime0_tech,dLNS_capdifftime0_notech,dLNS_capdiffcum_tech,dLNS_capdiffcum_notech));
disp(sprintf('dLNS_FBTCdiff       |%10.2f   |%10.2f  |%10.2f  |%10.2f |',dLNS_FBTCdifftime0_tech,dLNS_FBTCdifftime0_notech,dLNS_FBTCdiffcum_tech,dLNS_FBTCdiffcum_notech));
disp(sprintf('dLNS_check          |%10.2f   |%10.2f  |%10.2f  |%10.2f |',dLNStime0_doublecheck_tech,dLNStime0_doublecheck_notech,dLNScum_doublecheck_tech,dLNScum_doublecheck_notech));

disp(' '); disp('C - Sectoral Value Added');
disp(sprintf('dtildeYH            |%10.2f   |%10.2f  |%10.2f  |%10.2f |',dtildeYHtime0_tech,dtildeYHtime0_notech,dtildeYHcum_tech,dtildeYHcum_notech));
disp(sprintf('dtildeYN            |%10.2f   |%10.2f  |%10.2f  |%10.2f |',dtildeYNtime0_tech,dtildeYNtime0_notech,dtildeYNcum_tech,dtildeYNcum_notech));
disp(sprintf('dtildeYNS           |%10.2f   |%10.2f  |%10.2f  |%10.2f |',dtildeYNStime0_tech,dtildeYNStime0_notech,dtildeYNScum_tech,dtildeYNScum_notech));
disp('Decomposition of tildeYN/tildeYR');
disp(sprintf('dYNS_TFPdiff        |%10.2f   |%10.2f  |%10.2f  |%10.2f |',dYNS_TFPdifftime0_tech,dYNS_TFPdifftime0_notech,dYNS_TFPdiffcum_tech,dYNS_TFPdiffcum_notech));
disp(sprintf('dYNS_labdiff        |%10.2f   |%10.2f  |%10.2f  |%10.2f |',dYNS_labdifftime0_tech,dYNS_labdifftime0_notech,dYNS_labdiffcum_tech,dYNS_labdiffcum_notech));
disp(sprintf('dYNS_capdiff        |%10.2f   |%10.2f  |%10.2f  |%10.2f |',dYNS_capdifftime0_tech,dYNS_capdifftime0_notech,dYNS_capdiffcum_tech,dYNS_capdiffcum_notech));
disp(sprintf('dYNS_check          |%10.2f   |%10.2f  |%10.2f  |%10.2f |',dYNStime0_check_tech,dYNStime0_check_notech,dYNScum_check_tech,dYNScum_check_notech));

clear 