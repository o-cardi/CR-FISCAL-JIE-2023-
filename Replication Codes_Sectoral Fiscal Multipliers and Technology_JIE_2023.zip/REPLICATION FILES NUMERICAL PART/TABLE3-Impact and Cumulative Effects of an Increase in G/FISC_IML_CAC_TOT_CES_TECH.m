%clc
%clear

global sigmaC phi varphi rho varphiH
global phiI iota rhoI iotaH 
global ex nuX
global epsilon vartheta 
global gammaL sigmaL
global r deltaK kappa
global omegaG omegaGN omegaGH GH GN GF
global BH BN AH AN gammaH gammaN sigmaH sigmaN
global xi1H xi1N chi1H chi1N
global xi2H xi2N chi2H chi2N
global B0 K0 Y_0 AH_0 BH_0 AN_0 BN_0 
global barg baraH barbH baraN barbN xi chi xiAH chiAH xiBH chiBH xiAN chiAN xiBN chiBN

% Maxim duration for graphics
Tg = 10;
       
% Minim duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;

FISC_IML_CAC_TOT_CD_initial; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% CES and FBTC  - NORMALIZATION with CD  %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sigmaH_0     = 0.638;                                                                                                       
sigmaN_0     = 0.799; 
gammaH_0     = sLH_0CD*( sLH_0CD + (1-sLH_0CD)*(kH_0CD^((1-sigmaH_0)/sigmaH_0)) )^(-1);                           
gammaN_0     = sLN_0CD*( sLN_0CD + (1-sLN_0CD)*(kN_0CD^((1-sigmaN_0)/sigmaN_0)) )^(-1);                              
ZH_0         = (YH_0CD/LH_0CD)*( gammaH_0 + (1-gammaH_0)*(kH_0CD^((sigmaH_0 - 1)/sigmaH_0)) )^(sigmaH_0/(1-sigmaH_0));      
ZN_0         = (YN_0CD/LN_0CD)*( gammaN_0 + (1-gammaN_0)*(kN_0CD^((sigmaN_0 - 1)/sigmaN_0)) )^(sigmaN_0/(1-sigmaN_0));      
AH_0         = ZH_0;                                                                                                        
AN_0         = ZN_0;                                                                                                        
BH_0         = ZH_0;                                                                                                        
BN_0         = ZN_0; 

omegaG       = 0.191; 
omegaGN      = 0.8; 
omegaGH      = 0.9;
sigmaL_0     = 1;
gammaL       = 1; 
sigmaC_0     = 1;  
phi_0        = 0.77; 
varphi_0     = alphaC_0CD*( alphaC_0CD + (1-alphaC_0CD)*((PN_0CD/PT_0CD)^(phi_0 -1)) )^(-1); 
rho_0        = 1.5;  
varphiH_0    = alphaH_0CD*( alphaH_0CD + (1-alphaH_0CD)*((PH_0CD)^(1-rho_0)) )^(-1); 
epsilon_0    = 0.83; 
vartheta_0   = alphaL_0CD*( alphaL_0CD + (1-alphaL_0CD)*((WH_0CD/WN_0CD)^(1+epsilon_0)) )^(-1); 
phiI_0       = 1.000001;                    
iota_0       = 0.31;  
rhoI_0       = 1.5;  
iotaH_0      = alphaIH_0CD*( alphaIH_0CD + (1-alphaIH_0CD)*((PH_0CD)^(1-rhoI_0)) )^(-1);
kappa        = 17; 
nuX          = 1.7;
ex           = omegaXHY_0CD*Y_0CD*(PH_0CD)^(nuX-1);

r            = 0.03; 
beta         = r; 
deltaK       = (omegaI_0CD/PI_0CD)*(Y_0CD/K_0CD); 

B0           = Y_0CD*(omegaC_0CD+omegaI_0CD+omegaG-1)/r;                                                               
K0           = K_0CD + ((B0 - B_0CD)/H1_0CD); 
 
AH           = AH_0;       
AN           = AN_0;  
BH           = BH_0;       
BN           = BN_0;
gammaH       = gammaH_0;   
gammaN       = gammaN_0;  
sigmaH       = sigmaH_0;   
sigmaN       = sigmaN_0;    
sigmaC       = sigmaC_0;   
sigmaL       = sigmaL_0;   
phi          = phi_0;     
varphi       = varphi_0;  
rho          = rho_0;     
varphiH      = varphiH_0;
phiI         = phiI_0;    
iota         = iota_0; 
rhoI         = rhoI_0;    
iotaH        = iotaH_0;
epsilon      = epsilon_0;  
vartheta     = vartheta_0; 

filename = 'Calibration_Shock_2021_recons';                                                                                             
sheet    = 8;                                                                                                                                          
xlRange  = 'C3:K5';                                                                                                                                 
parameters = xlsread(filename,sheet,xlRange);                                                                                                                                                                                                                                               
chi2H    = 0.8; %0.7 technology utilization adjustment cost in the traded sector                                                                                                                          
chi2N    = 2.85;  % 4 technology utilization adjustment cost in the non-traded sector                                                                                                                         
xi2H     = 0.27;  %0.27 capital utilization adustment costs in the traded sector                                                                                                                              
xi2N     = 0.03;  % 0.02 capital utilization adustment costs in the non-traded sector
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C_ini        = 1.367  ; % Consumption 
L_ini        = 1.054  ; % Labor supply 
kH_ini       = 6.137  ; % Capital-labor ratio in sector H
WH_ini       = 3.382  ; % Wage rate in sector H
WN_ini       = 3.809  ; % Wage rate in sector N
W_ini        = 3.644  ; % Aggregate wage index
kN_ini       = 5.411  ; % Capital-labor ratio in sector N
PN_ini       = 2.881  ; % Relative price of non tradables
K_ini        = 5.978  ; % Stock of capital
PH_ini       = 2.295  ; % Terms of trade
B_ini        = 0.028  ; % Stock of traded Bonds
alphaL_ini   = 0.345  ; % Non tradable share of compensation of employees
PC_ini       = 2.400  ; % Aggregate consumption price index
PT_ini       = 1.959  ; % Consumption price index for tradables
CN_ini       = 0.631  ; % Consumption in non tradables 
CH_ini       = 0.495  ; % Consumption in tradables 
CF_ini       = 0.328  ; % Consumption in foreign goods 
alphaC_ini   = 0.446  ; % Tradable content of consumption expenditure
alphaH_ini   = 0.776  ; % Home goods content of consumption expenditure on traded goods
PI_ini       = 2.307  ; % Aggregate investment price index
PIT_ini      = 1.604  ; % Investment price index for traded goods
IN_ini       = 0.277  ; % Non traded investment
IH_ini       = 0.110  ; % Home goods investment
IF_ini       = 0.235  ; % Foreign goods investment
alphaI_ini   = 0.379  ; % Tradable content of investment expenditure
alphaIH_ini  = 0.517  ; % Home goods content of investment expenditure on traded goods
LH_ini       = 0.391  ; % Labor in sector H
LN_ini       = 0.661  ; % Labor in sector N 
GF_ini       = 0.03   ; % Government spending in foreign goods
GH_ini       = 0.05   ; % Government spending in home goods
GN_ini       = 0.35   ; % Government spending in non tradables 
yH_ini       = 1.5    ; % Output of home traded goods per worker
YH_ini       = 0.898  ; % Output of home traded goods
yN_ini       = 1.6    ; % Output of non traded goods per worker
YN_ini       = 1.255  ; % Output of non traded goods
XH_ini       = 0.245  ; % Exports of home traded goods
MF_ini       = 0.562  ; % Imports of foreign goods
RK_ini       = 0.307  ; % Return on capital
xi1H_ini     = 0.1337 ; % Parameter of traded capital utilization cost function: xi1H*(uKH-1)+(xi2H/2)*(uKH-1)^2
xi1N_ini     = 0.1065 ; % Parameter of non-traded capital utilization cost function
chi1H_ini    = 0.898  ; % Parameter of traded technology utilization cost function: chi1H*(uZH-1)+(chi2H/2)*(uZH-1)^2
chi1N_ini    = 1.255  ; % Parameter of non-traded technology utilization cost function
lambda_ini   = 0.967  ; % Intertemporal Solvency Condition         
                                                          
x0 =[C_ini L_ini kH_ini WH_ini WN_ini W_ini kN_ini PN_ini K_ini PH_ini B_ini alphaL_ini PC_ini PT_ini CN_ini CH_ini CF_ini alphaC_ini alphaH_ini PI_ini PIT_ini IN_ini IH_ini IF_ini alphaI_ini alphaIH_ini LH_ini LN_ini GF_ini GN_ini GH_ini yH_ini YH_ini yN_ini YN_ini XH_ini MF_ini RK_ini xi1H_ini xi1N_ini chi1H_ini chi1N_ini lambda_ini];
[x,~,exitflag]=fsolve('IML_CAC_TOT_CES_SS0',x0,optimset('display','off','TolFun',1e-011));

C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kH      = x(3)  ; % Capital-labor ratio in sector H
WH      = x(4)  ; % Wage rate in sector H
WN      = x(5)  ; % Wage rate in sector N
W       = x(6)  ; % Aggregate wage index
kN      = x(7)  ; % Capital-labor ratio in sector N
PN      = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
PH      = x(10) ; % Terms of trade : PH/PF with PF = numeraire
B       = x(11) ; % Stock of Traded Bonds
alphaL  = x(12) ; % Output per worker in sector N 
PC      = x(13) ; % Aggregate consumption price index
PT      = x(14) ; % Consumption price index for tradables
CN      = x(15) ; % Consumption in non tradables 
CH      = x(16) ; % Consumption in tradables 
CF      = x(17) ; % Consumption goods imports
alphaC  = x(18) ; % Tradable content of consumption expenditure 
alphaH  = x(19) ; % Home goods content of consumption expenditure 
PI      = x(20) ; % Aggregate investment price index
PIT     = x(21) ; % Investment price index for tradables
IN      = x(22) ; % Non tradable investment
IH      = x(23) ; % Investment in home goods
IF      = x(24) ; % Investment in foreign goods
alphaI  = x(25) ; % Tradable content of investment expenditure
alphaIH = x(26) ; % Home goods content of investment expenditure
LH      = x(27) ; % Labor in sector H
LN      = x(28) ; % Labor in sector N 
GF      = x(29) ; % Government spending in foreign goods
GN      = x(30) ; % Government spending in non tradables 
GH      = x(31) ; % Government spending in home traded goods
yH      = x(32) ; % Output of home traded goods per worker
YH      = x(33) ; % Output of home traded goods
yN      = x(34) ; % Output of non traded goods per worker
YN      = x(35) ; % Output of non traded goods
XH      = x(36) ; % Exports of home traded goods
MF      = x(37) ; % Imports of foreign goods
RK      = x(38) ; % Return on capital
xi1H    = x(39) ; % Parameter of traded capital utilization cost function: xi1H*(uKH-1)+(xi2H/2)*(uKH-1)^2
xi1N    = x(40) ; % Parameter of non-traded capital utilization cost function
chi1H   = x(41) ; % Parameter of traded technology utilization cost function: chi1H*(uZH-1)+(chi2H/2)*(uZH-1)^2
chi1N   = x(42) ; % Parameter of non-traded technology utilization cost function
lambda  = x(43) ; % Intertemporal Solvency Condition      

% Sectoral outputs and sectoral profits   
KH  = LH*kH;  
PiH = (PH*YH) - (RK*KH) - (WH*LH);
  
KN  = LN*kN;   
PiN = (PN*YN) - (RK*KN) - (WN*LN);

% Labor income share in the home traded good and non traded good sector
sLH = gammaH*(AH/yH)^((sigmaH-1)/sigmaH);
sLN = gammaN*(AN/yN)^((sigmaN-1)/sigmaN); 
Y   = (PH*YH) +(PN*YN);
sL  = W*L/Y; 
k   = K/L; 

% LHj = partial Lj/partial Wj: Lj=Lj(WH,WN,uZH,uZN)
LH_WH   = (LH/WH)*( epsilon*(1-alphaL) + (sigmaL*alphaL) );
LH_1uZH = LH*( epsilon*(1-alphaL) + (sigmaL*alphaL) );
LH_WN   = (LH/WN)*(1-alphaL)*(sigmaL-epsilon); 
LH_1uZN = LH*(1-alphaL)*(sigmaL-epsilon); 
LN_WH   = (LN/WH)*alphaL*(sigmaL-epsilon); 
LN_1uZH = LN*alphaL*(sigmaL-epsilon);
LN_WN   = (LN/WN)*( (epsilon*alphaL) + sigmaL*(1-alphaL) );  
LN_1uZN = LN*( (epsilon*alphaL) + sigmaL*(1-alphaL) ); 
LH_1lamb = sigmaL*LH/lambda; 
LN_1lamb = sigmaL*LN/lambda;

% Solving for kH, kN, WH, WN as functions of (PH, PN, K, uKH, uKN, uZH, uZN,
% AH, BH, AN, BN)
Psi_WH   = ( (kH*LH_WH) + (kN*LN_WH) );
Psi_WN   = ( (kH*LH_WN) + (kN*LN_WN) );
Psi_uZH  = ((kH*LH_1uZH) + (kN*LN_1uZH)); 
Psi_uZN  = ((kH*LH_1uZN) + (kN*LN_1uZN)); 
Psi_lamb = ( (kH*LH_1lamb) + (kN*LN_1lamb) ); 

d11 = -(1/sigmaH)*(sLH/kH); 
d12 = (1/sigmaN)*(sLN/kN);
d13 = 0;
d14 = 0;
d21 = (1/sigmaH)*((1-sLH)/kH); 
d22 = 0;  
d23 = -(1/WH); 
d24 = 0; 
d31 = 0; 
d32 = (1/sigmaN)*((1-sLN)/kN);
d33 = 0; 
d34 = -(1/WN);
d41 = LH; 
d42 = LN; 
d43 = Psi_WH; 
d44 = Psi_WN; 

% PN, PH, K, uKH, uKN, uZH, uZN, AH, BH, AN, BN, lambda
e11  = (1/PN); 
e12  = -(1/PH);
e13  = 0;
e14  = (sLH/sigmaH); 
e15  = -(sLN/sigmaN); 
e16  = 0;
e17  = 0;
e18  = -(1/sigmaH)*(sLH/AH); 
e19  = -(1/sigmaH)*((sigmaH-sLH)/BH);
e110 = (1/sigmaN)*(sLN/AN); 
e111 = (1/sigmaN)*((sigmaN-sLN)/BN);
e112 = 0; 

e21  = 0; 
e22  = -(1/PH); 
e23  = 0;
e24  = -((1-sLH)/sigmaH);
e25  = 0;
e26  = 0;
e27  = 0;
e28 = -(1/sigmaH)*(((sigmaH-1)+sLH)/AH); 
e29 = -(1/sigmaH)*((1-sLH)/BH); 
e210 = 0;
e211 = 0; 
e212 = 0;

e31  = -(1/PN); 
e32  = 0; 
e33  = 0;
e34  = 0;
e35  = -((1-sLN)/sigmaN);
e36  = 0;
e37  = 0;
e38  = 0; 
e39  = 0; 
e310 = -(1/sigmaN)*(((sigmaN-1)+sLN)/AN); 
e311 = -(1/sigmaN)*((1-sLN)/BN); 
e312 = 0; 

e41  = 0; 
e42  = 0; 
e43  = 1;
e44  = 0; 
e45  = 0;
e46  = -Psi_uZH; 
e47  = -Psi_uZN;
e48  = 0; 
e49  = 0;
e410 = 0;
e411 = 0; 
e412 = -Psi_lamb;
    
M1 = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X1 = [e11 e12 e13 e14 e15 e16 e17 e18 e19 e110 e111 e112; e21 e22 e23 e24 e25 e26 e27 e28 e29 e210 e211 e212; e31 e32 e33 e34 e35 e36 e37 e38 e39 e310 e311 e312; e41 e42 e43 e44 e45 e46 e47 e48 e49 e410 e411 e412];
JST1 = inv(M1);
MST1 = JST1*X1;
kH_1PN = MST1(1,1); kH_1PH = MST1(1,2); kH_1K = MST1(1,3); kH_uKH = MST1(1,4); kH_uKN = MST1(1,5); kH_uZH = MST1(1,6); kH_uZN = MST1(1,7); kH_1AH = MST1(1,8); kH_1BH = MST1(1,9); kH_1AN = MST1(1,10); kH_1BN = MST1(1,11); kH_1lambda = MST1(1,12); 
kN_1PN = MST1(2,1); kN_1PH = MST1(2,2); kN_1K = MST1(2,3); kN_uKH = MST1(2,4); kN_uKN = MST1(2,5); kN_uZH = MST1(2,6); kN_uZN = MST1(2,7); kN_1AH = MST1(2,8); kN_1BH = MST1(2,9); kN_1AN = MST1(2,10); kN_1BN = MST1(2,11); kN_1lambda = MST1(2,12); 
WH_1PN = MST1(3,1); WH_1PH = MST1(3,2); WH_1K = MST1(3,3); WH_uKH = MST1(3,4); WH_uKN = MST1(3,5); WH_uZH = MST1(3,6); WH_uZN = MST1(3,7); WH_1AH = MST1(3,8); WH_1BH = MST1(3,9); WH_1AN = MST1(3,10); WH_1BN = MST1(3,11); WH_1lambda = MST1(3,12); 
WN_1PN = MST1(4,1); WN_1PH = MST1(4,2); WN_1K = MST1(4,3); WN_uKH = MST1(4,4); WN_uKN = MST1(4,5); WN_uZH = MST1(4,6); WN_uZN = MST1(4,7); WN_1AH = MST1(4,8); WN_1BH = MST1(4,9); WN_1AN = MST1(4,10); WN_1BN = MST1(4,11); WN_1lambda = MST1(4,12); 

% Solving for sectoral labor and sectoral output - Lj,yj,Yj,Kj(PN,PH,K,uKj,uZj)
LH_1PN = (LH_WH*WH_1PN) + (LH_WN*WN_1PN);
LH_1PH = (LH_WH*WH_1PH) + (LH_WN*WN_1PH);
LH_1K  = (LH_WH*WH_1K)  + (LH_WN*WN_1K);
LH_uKH = (LH_WH*WH_uKH) + (LH_WN*WN_uKH);
LH_uKN = (LH_WH*WH_uKN) + (LH_WN*WN_uKN);
LH_uZH = LH_1uZH + (LH_WH*WH_uZH) + (LH_WN*WN_uZH);
LH_uZN = LH_1uZN + (LH_WH*WH_uZN) + (LH_WN*WN_uZN);
LH_1AH = (LH_WH*WH_1AH) + (LH_WN*WN_1AH);
LH_1BH = (LH_WH*WH_1BH) + (LH_WN*WN_1BH);
LH_1AN = (LH_WH*WH_1AN) + (LH_WN*WN_1AN);
LH_1BN = (LH_WH*WH_1BN) + (LH_WN*WN_1BN);
LH_1lambda = LH_1lamb + (LH_WH*WH_1lambda) + (LH_WN*WN_1lambda);

LN_1PN = (LN_WH*WH_1PN) + (LN_WN*WN_1PN);
LN_1PH = (LN_WH*WH_1PH) + (LN_WN*WN_1PH);
LN_1K  = (LN_WH*WH_1K)  + (LN_WN*WN_1K);
LN_uKH = (LN_WH*WH_uKH) + (LN_WN*WN_uKH);
LN_uKN = (LN_WH*WH_uKN) + (LN_WN*WN_uKN);
LN_uZH = LN_1uZH + (LN_WH*WH_uZH) + (LN_WN*WN_uZH);
LN_uZN = LN_1uZN + (LN_WH*WH_uZN) + (LN_WN*WN_uZN);
LN_1AH = (LN_WH*WH_1AH) + (LN_WN*WN_1AH);
LN_1BH = (LN_WH*WH_1BH) + (LN_WN*WN_1BH);
LN_1AN = (LN_WH*WH_1AN) + (LN_WN*WN_1AN);
LN_1BN = (LN_WH*WH_1BN) + (LN_WN*WN_1BN);
LN_1lambda = LN_1lamb + (LN_WH*WH_1lambda) + (LN_WN*WN_1lambda);

yH_1PN = (yH/kH)*(1-sLH)*kH_1PN;
yH_1PH = (yH/kH)*(1-sLH)*kH_1PH;
yH_1K  = (yH/kH)*(1-sLH)*kH_1K;
yH_uKH = yH*(1-sLH) + (yH/kH)*(1-sLH)*kH_uKH;
yH_uKN = (yH/kH)*(1-sLH)*kH_uKN;
yH_uZH = (yH/kH)*(1-sLH)*kH_uZH;
yH_uZN = (yH/kH)*(1-sLH)*kH_uZN;
yH_1AH = (yH/AH)*sLH + (yH/kH)*(1-sLH)*kH_1AH; 
yH_1BH =  yH*(1-sLH)*( (1/BH) + (kH_1BH/kH) );  
yH_1AN =  (yH/kH)*(1-sLH)*kH_1AN;
yH_1BN =  (yH/kH)*(1-sLH)*kH_1BN;
yH_1lambda  = (yH/kH)*(1-sLH)*kH_1lambda; 

yN_1PN = (yN/kN)*(1-sLN)*kN_1PN;
yN_1PH = (yN/kN)*(1-sLN)*kN_1PH;
yN_1K  = (yN/kN)*(1-sLN)*kN_1K;
yN_uKH = (yN/kN)*(1-sLN)*kN_uKH;
yN_uKN = yN*(1-sLN) + (yN/kN)*(1-sLN)*kN_uKN;
yN_uZH = (yN/kN)*(1-sLN)*kN_uZH;
yN_uZN = (yN/kN)*(1-sLN)*kN_uZN;
yN_1AH = (yN/kN)*(1-sLN)*kN_1AH;
yN_1BH = (yN/kN)*(1-sLN)*kN_1BH;
yN_1AN = (yN/AN)*sLN + (yN/kN)*(1-sLN)*kN_1AN;
yN_1BN =  yN*(1-sLN)*( (1/BN) + (kN_1BN/kN) ); 
yN_1lambda  = (yN/kN)*(1-sLN)*kN_1lambda; 

YH_1PN = (LH*yH_1PN) + (yH*LH_1PN);
YH_1PH = (LH*yH_1PH) + (yH*LH_1PH);
YH_1K  = (LH*yH_1K) + (yH*LH_1K);
YH_uKH = (LH*yH_uKH) + (yH*LH_uKH);
YH_uKN = (LH*yH_uKN) + (yH*LH_uKN);
YH_uZH = (LH*yH_uZH) + (yH*LH_uZH);
YH_uZN = (LH*yH_uZN) + (yH*LH_uZN);
YH_1AH = (LH*yH_1AH) + (yH*LH_1AH);
YH_1BH = (LH*yH_1BH) + (yH*LH_1BH);
YH_1AN = (LH*yH_1AN) + (yH*LH_1AN);
YH_1BN = (LH*yH_1BN) + (yH*LH_1BN);
YH_1lambda = (LH*yH_1lambda) + (yH*LH_1lambda);

YN_1PN = (LN*yN_1PN) + (yN*LN_1PN);
YN_1PH = (LN*yN_1PH) + (yN*LN_1PH);
YN_1K  = (LN*yN_1K) + (yN*LN_1K);
YN_uKH = (LN*yN_uKH) + (yN*LN_uKH);
YN_uKN = (LN*yN_uKN) + (yN*LN_uKN);
YN_uZH = (LN*yN_uZH) + (yN*LN_uZH);
YN_uZN = (LN*yN_uZN) + (yN*LN_uZN);
YN_1AH = (LN*yN_1AH) + (yN*LN_1AH);
YN_1BH = (LN*yN_1BH) + (yN*LN_1BH);
YN_1AN = (LN*yN_1AN) + (yN*LN_1AN);
YN_1BN = (LN*yN_1BN) + (yN*LN_1BN);
YN_1lambda = (LN*yN_1lambda) + (yN*LN_1lambda);

KH_1PN = (LH*kH_1PN) + (kH*LH_1PN);
KH_1PH = (LH*kH_1PH) + (kH*LH_1PH);
KH_1K  = (LH*kH_1K) + (kH*LH_1K);
KH_uKH = (LH*kH_uKH) + (kH*LH_uKH);
KH_uKN = (LH*kH_uKN) + (kH*LH_uKN);
KH_uZH = (LH*kH_uZH) + (kH*LH_uZH);
KH_uZN = (LH*kH_uZN) + (kH*LH_uZN);
KH_1AH = (LH*kH_1AH) + (kH*LH_1AH);             
KH_1BH = (LH*kH_1BH) + (kH*LH_1BH);             
KH_1AN = (LH*kH_1AN) + (kH*LH_1AN);             
KH_1BN = (LH*kH_1BN) + (kH*LH_1BN);             
KH_1lambda = (LH*kH_1lambda) + (kH*LH_1lambda); 

KN_1PN = (LN*kN_1PN) + (kN*LN_1PN);
KN_1PH = (LN*kN_1PH) + (kN*LN_1PH);
KN_1K  = (LN*kN_1K) + (kN*LN_1K);
KN_uKH = (LN*kN_uKH) + (kN*LN_uKH);
KN_uKN = (LN*kN_uKN) + (kN*LN_uKN);
KN_uZH = (LN*kN_uZH) + (kN*LN_uZH);
KN_uZN = (LN*kN_uZN) + (kN*LN_uZN);
KN_1AH = (LN*kN_1AH) + (kN*LN_1AH);                   
KN_1BH = (LN*kN_1BH) + (kN*LN_1BH);                   
KN_1AN = (LN*kN_1AN) + (kN*LN_1AN);                   
KN_1BN = (LN*kN_1BN) + (kN*LN_1BN);                   
KN_1lambda = (LN*kN_1lambda) + (kN*LN_1lambda);       

% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH)
CN_PN = - (CN/PN)*( (alphaC*phi) + sigmaC*(1-alphaC) ); 
CN_PH = (CN/PH)*alphaC*alphaH*(phi-sigmaC); 
CH_PN = (CH/PN)*(phi-sigmaC)*(1-alphaC); 
CH_PH = -(CH/PH)*( rho*(1-alphaH) + alphaH*( phi*(1-alphaC) + (sigmaC*alphaC) ) ); 
CF_PN = (CF/PN)*(1-alphaC)*(phi-sigmaC); 
CF_PH = (CF/PH)*alphaH*(rho - (phi*(1-alphaC)+(sigmaC*alphaC))); 

CH_1lambda = -(CH/lambda)*sigmaC; 
CN_1lambda = -(CN/lambda)*sigmaC;
CF_1lambda = -(CF/lambda)*sigmaC; 

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_K  = deltaK; 
J_Q  = K*v_1Q; 
J_PN = K*v_PN; 
J_PH = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q)
I      = deltaK*K; 
JN_PN  = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH  = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K  = (IN/I)*J_K; 
JN_1Q  = (IN/I)*J_Q; 

JH_PN  =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH  = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_K; 
JH_1Q  = (IH/I)*J_Q; 

JF_PN  = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH  = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_K; 
JF_1Q  = (IF/I)*J_Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH  = -(XH/PH)*nuX; 

% Solving for capital and technology utilization rates: uKH, uKN, uZH, uZN, uKj,uZj(PN,PH,K)
f11 = ((xi2H/xi1H) + (sLH/sigmaH)) + (sLH/sigmaH)*(kH_uKH/kH);
f12 = (sLH/sigmaH)*(kH_uKN/kH);
f13 = ((sLH/sigmaH)*(kH_uZH/kH)-1);
f14 = (sLH/sigmaH)*(kH_uZN/kH);
f21 = (sLN/sigmaN)*(kN_uKH/kN);
f22 = ((xi2N/xi1N) + (sLN/sigmaN)) + (sLN/sigmaN)*(kN_uKN/kN);
f23 = (sLN/sigmaN)*(kN_uZH/kN);
f24 = ((sLN/sigmaN)*(kN_uZN/kN)-1);
f31 = -YH_uKH;
f32 = -YH_uKN;
f33 = (chi2H-YH_uZH);
f34 = -YH_uZN;
f41 = -YN_uKH;
f42 = -YN_uKN;
f43 = -YN_uZH;
f44 = (chi2N-YN_uZN);

% PN, PH, K, AH, BH, AN, BN
g11 = -(sLH/sigmaH)*(kH_1PN/kH);
g12 = -(sLH/sigmaH)*(kH_1PH/kH);
g13 = -(sLH/sigmaH)*(kH_1K/kH);
g14 = (sLH/sigmaH)*( (1/AH) - (kH_1AH/kH) ); 
g15 = (1/sigmaH)*( ((sigmaH-sLH)/BH) - sLH*(kH_1BH/kH) );
g16 = -(sLH/sigmaH)*(kH_1AN/kH);
g17 = -(sLH/sigmaH)*(kH_1BN/kH);
g18 = -(sLH/sigmaH)*(kH_1lambda/kH);

g21 = -(sLN/sigmaN)*(kN_1PN/kN);
g22 = -(sLN/sigmaN)*(kN_1PH/kN);
g23 = -(sLN/sigmaN)*(kN_1K/kN);
g24 = -(sLN/sigmaN)*(kN_1AH/kN);
g25 = -(sLN/sigmaN)*(kN_1BH/kN);
g26 = (sLN/sigmaN)*( (1/AN) - (kN_1AN/kN) ); 
g27 = (1/sigmaN)*( ((sigmaN-sLN)/BN) - sLN*(kN_1BN/kN) );
g28 = -(sLN/sigmaN)*(kN_1lambda/kN);

g31 = YH_1PN;      
g32 = YH_1PH;      
g33 = YH_1K;       
g34 = YH_1AH;      
g35 = YH_1BH;      
g36 = YH_1AN;      
g37 = YH_1BN;      
g38 = YH_1lambda;  
                   
g41 = YN_1PN;      
g42 = YN_1PH;      
g43 = YN_1K;       
g44 = YN_1AH;      
g45 = YN_1BH;      
g46 = YN_1AN;      
g47 = YN_1BN;      
g48 = YN_1lambda;  

M2 = [f11 f12 f13 f14; f21 f22 f23 f24; f31 f32 f33 f34; f41 f42 f43 f44];
X2 = [g11 g12 g13 g14 g15 g16 g17 g18; g21 g22 g23 g24 g25 g26 g27 g28; g31 g32 g33 g34 g35 g36 g37 g38; g41 g42 g43 g44 g45 g46 g47 g48];
JST2 = inv(M2);
MST2 = JST2*X2;

uKH_PN = MST2(1,1); uKH_PH = MST2(1,2); uKH_1K = MST2(1,3); uKH_1AH = MST2(1,4); uKH_1BH = MST2(1,5); uKH_1AN = MST2(1,6); uKH_1BN = MST2(1,7); uKH_1lambda = MST2(1,8);
uKN_PN = MST2(2,1); uKN_PH = MST2(2,2); uKN_1K = MST2(2,3); uKN_1AH = MST2(2,4); uKN_1BH = MST2(2,5); uKN_1AN = MST2(2,6); uKN_1BN = MST2(2,7); uKN_1lambda = MST2(2,8);
uZH_PN = MST2(3,1); uZH_PH = MST2(3,2); uZH_1K = MST2(3,3); uZH_1AH = MST2(3,4); uZH_1BH = MST2(3,5); uZH_1AN = MST2(3,6); uZH_1BN = MST2(3,7); uZH_1lambda = MST2(3,8);
uZN_PN = MST2(4,1); uZN_PH = MST2(4,2); uZN_1K = MST2(4,3); uZN_1AH = MST2(4,4); uZN_1BH = MST2(4,5); uZN_1AN = MST2(4,6); uZN_1BN = MST2(4,7); uZN_1lambda = MST2(4,8);

% Solving for sectoral labor and sectoral output - kj,Wj,Lj,yj,Yj,Kj(lambda,K,PH,PN,AH,BH,AN,BN) 
kH_2K  = kH_1K + (kH_uKH*uKH_1K) + (kH_uKN*uKN_1K) + (kH_uZH*uZH_1K) + (kH_uZN*uZN_1K); 
kH_PH  = kH_1PH + (kH_uKH*uKH_PH) + (kH_uKN*uKN_PH) + (kH_uZH*uZH_PH) + (kH_uZN*uZN_PH);
kH_PN  = kH_1PN + (kH_uKH*uKH_PN) + (kH_uKN*uKN_PN) + (kH_uZH*uZH_PN) + (kH_uZN*uZN_PN);
kH_2AH = kH_1AH + (kH_uKH*uKH_1AH) + (kH_uKN*uKN_1AH) + (kH_uZH*uZH_1AH) + (kH_uZN*uZN_1AH); 
kH_2BH = kH_1BH + (kH_uKH*uKH_1BH) + (kH_uKN*uKN_1BH) + (kH_uZH*uZH_1BH) + (kH_uZN*uZN_1BH); 
kH_2AN = kH_1AN + (kH_uKH*uKH_1AN) + (kH_uKN*uKN_1AN) + (kH_uZH*uZH_1AN) + (kH_uZN*uZN_1AN); 
kH_2BN = kH_1BN + (kH_uKH*uKH_1BN) + (kH_uKN*uKN_1BN) + (kH_uZH*uZH_1BN) + (kH_uZN*uZN_1BN); 
kH_2lambda = kH_1lambda + (kH_uKH*uKH_1lambda) + (kH_uKN*uKN_1lambda) + (kH_uZH*uZH_1lambda) + (kH_uZN*uZN_1lambda);

kN_2K  = kN_1K + (kN_uKH*uKH_1K) + (kN_uKN*uKN_1K) + (kN_uZH*uZH_1K) + (kN_uZN*uZN_1K);     
kN_PH  = kN_1PH + (kN_uKH*uKH_PH) + (kN_uKN*uKN_PH) + (kN_uZH*uZH_PH) + (kN_uZN*uZN_PH);
kN_PN  = kN_1PN + (kN_uKH*uKH_PN) + (kN_uKN*uKN_PN) + (kN_uZH*uZH_PN) + (kN_uZN*uZN_PN);
kN_2AH = kN_1AH + (kN_uKH*uKH_1AH) + (kN_uKN*uKN_1AH) + (kN_uZH*uZH_1AH) + (kN_uZN*uZN_1AH); 
kN_2BH = kN_1BH + (kN_uKH*uKH_1BH) + (kN_uKN*uKN_1BH) + (kN_uZH*uZH_1BH) + (kN_uZN*uZN_1BH); 
kN_2AN = kN_1AN + (kN_uKH*uKH_1AN) + (kN_uKN*uKN_1AN) + (kN_uZH*uZH_1AN) + (kN_uZN*uZN_1AN); 
kN_2BN = kN_1BN + (kN_uKH*uKH_1BN) + (kN_uKN*uKN_1BN) + (kN_uZH*uZH_1BN) + (kN_uZN*uZN_1BN); 
kN_2lambda = kN_1lambda + (kN_uKH*uKH_1lambda) + (kN_uKN*uKN_1lambda) + (kN_uZH*uZH_1lambda) + (kN_uZN*uZN_1lambda); 

WH_2K  = WH_1K + (WH_uKH*uKH_1K) + (WH_uKN*uKN_1K) + (WH_uZH*uZH_1K) + (WH_uZN*uZN_1K);  
WH_PH  = WH_1PH + (WH_uKH*uKH_PH) + (WH_uKN*uKN_PH) + (WH_uZH*uZH_PH) + (WH_uZN*uZN_PH); 
WH_PN  = WH_1PN + (WH_uKH*uKH_PN) + (WH_uKN*uKN_PN) + (WH_uZH*uZH_PN) + (WH_uZN*uZN_PN);
WH_2AH = WH_1AH + (WH_uKH*uKH_1AH) + (WH_uKN*uKN_1AH) + (WH_uZH*uZH_1AH) + (WH_uZN*uZN_1AH);
WH_2BH = WH_1BH + (WH_uKH*uKH_1BH) + (WH_uKN*uKN_1BH) + (WH_uZH*uZH_1BH) + (WH_uZN*uZN_1BH);
WH_2AN = WH_1AN + (WH_uKH*uKH_1AN) + (WH_uKN*uKN_1AN) + (WH_uZH*uZH_1AN) + (WH_uZN*uZN_1AN);
WH_2BN = WH_1BN + (WH_uKH*uKH_1BN) + (WH_uKN*uKN_1BN) + (WH_uZH*uZH_1BN) + (WH_uZN*uZN_1BN);
WH_2lambda = WH_1lambda + (WH_uKH*uKH_1lambda) + (WH_uKN*uKN_1lambda) + (WH_uZH*uZH_1lambda) + (WH_uZN*uZN_1lambda);

WN_2K = WN_1K + (WN_uKH*uKH_1K) + (WN_uKN*uKN_1K) + (WN_uZH*uZH_1K) + (WN_uZN*uZN_1K);  
WN_PH = WN_1PH + (WN_uKH*uKH_PH) + (WN_uKN*uKN_PH) + (WN_uZH*uZH_PH) + (WN_uZN*uZN_PH); 
WN_PN = WN_1PN + (WN_uKH*uKH_PN) + (WN_uKN*uKN_PN) + (WN_uZH*uZH_PN) + (WN_uZN*uZN_PN);
WN_2AH = WN_1AH + (WN_uKH*uKH_1AH) + (WN_uKN*uKN_1AH) + (WN_uZH*uZH_1AH) + (WN_uZN*uZN_1AH);                          
WN_2BH = WN_1BH + (WN_uKH*uKH_1BH) + (WN_uKN*uKN_1BH) + (WN_uZH*uZH_1BH) + (WN_uZN*uZN_1BH);                          
WN_2AN = WN_1AN + (WN_uKH*uKH_1AN) + (WN_uKN*uKN_1AN) + (WN_uZH*uZH_1AN) + (WN_uZN*uZN_1AN);                          
WN_2BN = WN_1BN + (WN_uKH*uKH_1BN) + (WN_uKN*uKN_1BN) + (WN_uZH*uZH_1BN) + (WN_uZN*uZN_1BN);                          
WN_2lambda = WN_1lambda + (WN_uKH*uKH_1lambda) + (WN_uKN*uKN_1lambda) + (WN_uZH*uZH_1lambda) + (WN_uZN*uZN_1lambda);  

LH_2K = LH_1K + (LH_uKH*uKH_1K) + (LH_uKN*uKN_1K) + (LH_uZH*uZH_1K) + (LH_uZN*uZN_1K);  
LH_PH = LH_1PH + (LH_uKH*uKH_PH) + (LH_uKN*uKN_PH) + (LH_uZH*uZH_PH) + (LH_uZN*uZN_PH); 
LH_PN = LH_1PN + (LH_uKH*uKH_PN) + (LH_uKN*uKN_PN) + (LH_uZH*uZH_PN) + (LH_uZN*uZN_PN);   
LH_2AH = LH_1AH + (LH_uKH*uKH_1AH) + (LH_uKN*uKN_1AH) + (LH_uZH*uZH_1AH) + (LH_uZN*uZN_1AH);                          
LH_2BH = LH_1BH + (LH_uKH*uKH_1BH) + (LH_uKN*uKN_1BH) + (LH_uZH*uZH_1BH) + (LH_uZN*uZN_1BH);                          
LH_2AN = LH_1AN + (LH_uKH*uKH_1AN) + (LH_uKN*uKN_1AN) + (LH_uZH*uZH_1AN) + (LH_uZN*uZN_1AN);                          
LH_2BN = LH_1BN + (LH_uKH*uKH_1BN) + (LH_uKN*uKN_1BN) + (LH_uZH*uZH_1BN) + (LH_uZN*uZN_1BN);                          
LH_2lambda = LH_1lambda + (LH_uKH*uKH_1lambda) + (LH_uKN*uKN_1lambda) + (LH_uZH*uZH_1lambda) + (LH_uZN*uZN_1lambda);  

LN_2K = LN_1K + (LN_uKH*uKH_1K) + (LN_uKN*uKN_1K) + (LN_uZH*uZH_1K) + (LN_uZN*uZN_1K);  
LN_PH = LN_1PH + (LN_uKH*uKH_PH) + (LN_uKN*uKN_PH) + (LN_uZH*uZH_PH) + (LN_uZN*uZN_PH); 
LN_PN = LN_1PN + (LN_uKH*uKH_PN) + (LN_uKN*uKN_PN) + (LN_uZH*uZH_PN) + (LN_uZN*uZN_PN);
LN_2AH = LN_1AH + (LN_uKH*uKH_1AH) + (LN_uKN*uKN_1AH) + (LN_uZH*uZH_1AH) + (LN_uZN*uZN_1AH);                         
LN_2BH = LN_1BH + (LN_uKH*uKH_1BH) + (LN_uKN*uKN_1BH) + (LN_uZH*uZH_1BH) + (LN_uZN*uZN_1BH);                         
LN_2AN = LN_1AN + (LN_uKH*uKH_1AN) + (LN_uKN*uKN_1AN) + (LN_uZH*uZH_1AN) + (LN_uZN*uZN_1AN);                         
LN_2BN = LN_1BN + (LN_uKH*uKH_1BN) + (LN_uKN*uKN_1BN) + (LN_uZH*uZH_1BN) + (LN_uZN*uZN_1BN);                         
LN_2lambda = LN_1lambda + (LN_uKH*uKH_1lambda) + (LN_uKN*uKN_1lambda) + (LN_uZH*uZH_1lambda) + (LN_uZN*uZN_1lambda); 

YH_2K = YH_1K + (YH_uKH*uKH_1K) + (YH_uKN*uKN_1K) + (YH_uZH*uZH_1K) + (YH_uZN*uZN_1K);   
YH_PH = YH_1PH + (YH_uKH*uKH_PH) + (YH_uKN*uKN_PH) + (YH_uZH*uZH_PH) + (YH_uZN*uZN_PH);  
YH_PN = YH_1PN + (YH_uKH*uKH_PN) + (YH_uKN*uKN_PN) + (YH_uZH*uZH_PN) + (YH_uZN*uZN_PN); 
YH_2AH = YH_1AH + (YH_uKH*uKH_1AH) + (YH_uKN*uKN_1AH) + (YH_uZH*uZH_1AH) + (YH_uZN*uZN_1AH);                         
YH_2BH = YH_1BH + (YH_uKH*uKH_1BH) + (YH_uKN*uKN_1BH) + (YH_uZH*uZH_1BH) + (YH_uZN*uZN_1BH);                         
YH_2AN = YH_1AN + (YH_uKH*uKH_1AN) + (YH_uKN*uKN_1AN) + (YH_uZH*uZH_1AN) + (YH_uZN*uZN_1AN);                         
YH_2BN = YH_1BN + (YH_uKH*uKH_1BN) + (YH_uKN*uKN_1BN) + (YH_uZH*uZH_1BN) + (YH_uZN*uZN_1BN);                         
YH_2lambda = YH_1lambda + (YH_uKH*uKH_1lambda) + (YH_uKN*uKN_1lambda) + (YH_uZH*uZH_1lambda) + (YH_uZN*uZN_1lambda); 

YN_2K = YN_1K + (YN_uKH*uKH_1K) + (YN_uKN*uKN_1K) + (YN_uZH*uZH_1K) + (YN_uZN*uZN_1K);   
YN_PH = YN_1PH + (YN_uKH*uKH_PH) + (YN_uKN*uKN_PH) + (YN_uZH*uZH_PH) + (YN_uZN*uZN_PH);  
YN_PN = YN_1PN + (YN_uKH*uKH_PN) + (YN_uKN*uKN_PN) + (YN_uZH*uZH_PN) + (YN_uZN*uZN_PN); 
YN_2AH = YN_1AH + (YN_uKH*uKH_1AH) + (YN_uKN*uKN_1AH) + (YN_uZH*uZH_1AH) + (YN_uZN*uZN_1AH);                        
YN_2BH = YN_1BH + (YN_uKH*uKH_1BH) + (YN_uKN*uKN_1BH) + (YN_uZH*uZH_1BH) + (YN_uZN*uZN_1BH);                        
YN_2AN = YN_1AN + (YN_uKH*uKH_1AN) + (YN_uKN*uKN_1AN) + (YN_uZH*uZH_1AN) + (YN_uZN*uZN_1AN);                        
YN_2BN = YN_1BN + (YN_uKH*uKH_1BN) + (YN_uKN*uKN_1BN) + (YN_uZH*uZH_1BN) + (YN_uZN*uZN_1BN);                        
YN_2lambda = YN_1lambda + (YN_uKH*uKH_1lambda) + (YN_uKN*uKN_1lambda) + (YN_uZH*uZH_1lambda) + (YN_uZN*uZN_1lambda);

KH_2K = KH_1K + (KH_uKH*uKH_1K) + (KH_uKN*uKN_1K) + (KH_uZH*uZH_1K) + (KH_uZN*uZN_1K);  
KH_PH = KH_1PH + (KH_uKH*uKH_PH) + (KH_uKN*uKN_PH) + (KH_uZH*uZH_PH) + (KH_uZN*uZN_PH); 
KH_PN = KH_1PN + (KH_uKH*uKH_PN) + (KH_uKN*uKN_PN) + (KH_uZH*uZH_PN) + (KH_uZN*uZN_PN);   
KH_2AH = KH_1AH + (KH_uKH*uKH_1AH) + (KH_uKN*uKN_1AH) + (KH_uZH*uZH_1AH) + (KH_uZN*uZN_1AH);                        
KH_2BH = KH_1BH + (KH_uKH*uKH_1BH) + (KH_uKN*uKN_1BH) + (KH_uZH*uZH_1BH) + (KH_uZN*uZN_1BH);                        
KH_2AN = KH_1AN + (KH_uKH*uKH_1AN) + (KH_uKN*uKN_1AN) + (KH_uZH*uZH_1AN) + (KH_uZN*uZN_1AN);                        
KH_2BN = KH_1BN + (KH_uKH*uKH_1BN) + (KH_uKN*uKN_1BN) + (KH_uZH*uZH_1BN) + (KH_uZN*uZN_1BN);                        
KH_2lambda = KH_1lambda + (KH_uKH*uKH_1lambda) + (KH_uKN*uKN_1lambda) + (KH_uZH*uZH_1lambda) + (KH_uZN*uZN_1lambda);

KN_2K = KN_1K + (KN_uKH*uKH_1K) + (KN_uKN*uKN_1K) + (KN_uZH*uZH_1K) + (KN_uZN*uZN_1K);  
KN_PH = KN_1PH + (KN_uKH*uKH_PH) + (KN_uKN*uKN_PH) + (KN_uZH*uZH_PH) + (KN_uZN*uZN_PH); 
KN_PN = KN_1PN + (KN_uKH*uKH_PN) + (KN_uKN*uKN_PN) + (KN_uZH*uZH_PN) + (KN_uZN*uZN_PN); 
KN_2AH = KN_1AH + (KN_uKH*uKH_1AH) + (KN_uKN*uKN_1AH) + (KN_uZH*uZH_1AH) + (KN_uZN*uZN_1AH);                        
KN_2BH = KN_1BH + (KN_uKH*uKH_1BH) + (KN_uKN*uKN_1BH) + (KN_uZH*uZH_1BH) + (KN_uZN*uZN_1BH);                        
KN_2AN = KN_1AN + (KN_uKH*uKH_1AN) + (KN_uKN*uKN_1AN) + (KN_uZH*uZH_1AN) + (KN_uZN*uZN_1AN);                        
KN_2BN = KN_1BN + (KN_uKH*uKH_1BN) + (KN_uKN*uKN_1BN) + (KN_uZH*uZH_1BN) + (KN_uZN*uZN_1BN);                        
KN_2lambda = KN_1lambda + (KN_uKH*uKH_1lambda) + (KN_uKN*uKN_1lambda) + (KN_uZH*uZH_1lambda) + (KN_uZN*uZN_1lambda);

% Partial Derivatives Gj=Gj(G) 
GN_G   = omegaGN/PN; 
GH_G   = (1-omegaGN)*(omegaGH/PH);
GF_G   = (1-omegaGN)*(1-omegaGH);

% Solving for traded and non-traded prices: PH,PN(K,Q,G,AH,BH,AN,BN,lambda)     
h11 = (YN_PH - CN_PH - JN_PH) - (KN*xi1N*uKN_PH);           
h12 = (YN_PN - CN_PN - JN_PN) - (KN*xi1N*uKN_PN);           
h21 = (YH_PH - CH_PH - JH_PH - XH_PH) - (KH*xi1H*uKH_PH);   
h22 = (YH_PN - CH_PN - JH_PN) - (KH*xi1H*uKH_PN);           
                                                            
% K,Q,G,AH,BH,AN,BN,lambda                                                       
k11 = -(YN_2K - JN_1K - (KN*xi1N*uKN_1K));                  
k12 = JN_1Q;    
k13 = GN_G;
k14 = -(YN_2AH - (KN*xi1N*uKN_1AH));                        
k15 = -(YN_2BH - (KN*xi1N*uKN_1BH));                        
k16 = -(YN_2AN - (KN*xi1N*uKN_1AN));                        
k17 = -(YN_2BN - (KN*xi1N*uKN_1BN));                        
k18 = -((YN_2lambda - CN_1lambda) - (KN*xi1N*uKN_1lambda)); 

k21 = -(YH_2K - JH_1K - (KH*xi1H*uKH_1K));                  
k22 = JH_1Q;  
k23 = GH_G;
k24 = -(YH_2AH - (KH*xi1H*uKH_1AH));                         
k25 = -(YH_2BH - (KH*xi1H*uKH_1BH));                         
k26 = -(YH_2AN - (KH*xi1H*uKH_1AN));                         
k27 = -(YH_2BN - (KH*xi1H*uKH_1BN));                         
k28 = -((YH_2lambda - CH_1lambda) - (KH*xi1H*uKH_1lambda));  
                                                            
M3 = [h11 h12; h21 h22];                                    
X3 = [k11 k12 k13 k14 k15 k16 k17 k18; k21 k22 k23 k24 k25 k26 k27 k28];                                    
JST3 = inv(M3);                                             
MST3 = JST3*X3;                                             
                                                            
PH_K = MST3(1,1); PH_Q = MST3(1,2); PH_G = MST3(1,3); PH_AH = MST3(1,4); PH_BH = MST3(1,5); PH_AN = MST3(1,6); PH_BN = MST3(1,7); PH_lambda = MST3(1,8); 
PN_K = MST3(2,1); PN_Q = MST3(2,2); PN_G = MST3(2,3); PN_AH = MST3(2,4); PN_BH = MST3(2,5); PN_AN = MST3(2,6); PN_BN = MST3(2,7); PN_lambda = MST3(2,8);                         

% Solving for capital-labor ratios kj=kj(K,Q,G,Aj,Bj) - 
% sectoral labor Lj=Lj(K,Q,G,Aj,Bj) - sectoral output 
% Yj=Yj(K,Q,G,Aj,Bj) - Final Solutions
kH_K = kH_2K + (kH_PH*PH_K) + (kH_PN*PN_K); 
kH_Q = (kH_PH*PH_Q) + (kH_PN*PN_Q);
kH_G = (kH_PH*PH_G) + (kH_PN*PN_G);
kH_AH = kH_2AH + (kH_PH*PH_AH) + (kH_PN*PN_AH);
kH_BH = kH_2BH + (kH_PH*PH_BH) + (kH_PN*PN_BH);
kH_AN = kH_2AN + (kH_PH*PH_AN) + (kH_PN*PN_AN);
kH_BN = kH_2BN + (kH_PH*PH_BN) + (kH_PN*PN_BN);
kH_lambda = kH_2lambda + (kH_PH*PH_lambda) + (kH_PN*PN_lambda);

kN_K = kN_2K + (kN_PH*PH_K) + (kN_PN*PN_K);
kN_Q = (kN_PH*PH_Q) + (kN_PN*PN_Q); 
kN_G = (kN_PH*PH_G) + (kN_PN*PN_G);
kN_AH = kN_2AH + (kN_PH*PH_AH) + (kN_PN*PN_AH);
kN_BH = kN_2BH + (kN_PH*PH_BH) + (kN_PN*PN_BH);
kN_AN = kN_2AN + (kN_PH*PH_AN) + (kN_PN*PN_AN); 
kN_BN = kN_2BN + (kN_PH*PH_BN) + (kN_PN*PN_BN);
kN_lambda = kN_2lambda + (kN_PH*PH_lambda) + (kN_PN*PN_lambda); 

LH_K  = LH_2K + (LH_PH*PH_K) + (LH_PN*PN_K); 
LH_Q  = (LH_PH*PH_Q) + (LH_PN*PN_Q); 
LH_G  = (LH_PH*PH_G) + (LH_PN*PN_G);
LH_AH = LH_2AH + (LH_PH*PH_AH) + (LH_PN*PN_AH); 
LH_BH = LH_2BH + (LH_PH*PH_BH) + (LH_PN*PN_BH);
LH_AN = LH_2AN + (LH_PH*PH_AN) + (LH_PN*PN_AN); 
LH_BN = LH_2BN + (LH_PH*PH_BN) + (LH_PN*PN_BN);
LH_lambda = LH_2lambda + (LH_PH*PH_lambda) + (LH_PN*PN_lambda); 

LN_K = LN_2K + (LN_PH*PH_K) + (LN_PN*PN_K);
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);
LN_G = (LN_PH*PH_G) + (LN_PN*PN_G); 
LN_AH = LN_2AH + (LN_PH*PH_AH) + (LN_PN*PN_AH); 
LN_BH = LN_2BH + (LN_PH*PH_BH) + (LN_PN*PN_BH);
LN_AN = LN_2AN + (LN_PH*PH_AN) + (LN_PN*PN_AN); 
LN_BN = LN_2BN + (LN_PH*PH_BN) + (LN_PN*PN_BN);
LN_lambda = LN_2lambda + (LN_PH*PH_lambda) + (LN_PN*PN_lambda); 

YH_K = YH_2K + (YH_PH*PH_K) + (YH_PN*PN_K); 
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q); 
YH_G = (YH_PH*PH_G) + (YH_PN*PN_G);
YH_AH = YH_2AH + (YH_PH*PH_AH) + (YH_PN*PN_AH);
YH_BH = YH_2BH + (YH_PH*PH_BH) + (YH_PN*PN_BH);
YH_AN = YH_2AN + (YH_PH*PH_AN) + (YH_PN*PN_AN);
YH_BN = YH_2BN + (YH_PH*PH_BN) + (YH_PN*PN_BN);
YH_lambda = YH_2lambda + (YH_PH*PH_lambda) + (YH_PN*PN_lambda);  

YN_K = YN_2K + (YN_PH*PH_K) + (YN_PN*PN_K);
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);
YN_G = (YN_PH*PH_G) + (YN_PN*PN_G);
YN_AH = YN_2AH + (YN_PH*PH_AH) + (YN_PN*PN_AH);
YN_BH = YN_2BH + (YN_PH*PH_BH) + (YN_PN*PN_BH);
YN_AN = YN_2AN + (YN_PH*PH_AN) + (YN_PN*PN_AN);
YN_BN = YN_2BN + (YN_PH*PH_BN) + (YN_PN*PN_BN);
YN_lambda = YN_2lambda + (YN_PH*PH_lambda) + (YN_PN*PN_lambda); 

KH_K  = KH_2K + (KH_PH*PH_K) + (KH_PN*PN_K);                     
KH_Q  = (KH_PH*PH_Q) + (KH_PN*PN_Q);                             
KH_G  = (KH_PH*PH_G) + (KH_PN*PN_G);                             
KH_AH = KH_2AH + (KH_PH*PH_AH) + (KH_PN*PN_AH);                  
KH_BH = KH_2BH + (KH_PH*PH_BH) + (KH_PN*PN_BH);                  
KH_AN = KH_2AN + (KH_PH*PH_AN) + (KH_PN*PN_AN);                  
KH_BN = KH_2BN + (KH_PH*PH_BN) + (KH_PN*PN_BN);                  
KH_lambda = KH_2lambda + (KH_PH*PH_lambda) + (KH_PN*PN_lambda);  
                                                                 
KN_K = KN_2K + (KN_PH*PH_K) + (KN_PN*PN_K);                      
KN_Q = (KN_PH*PH_Q) + (KN_PN*PN_Q);                              
KN_G = (KN_PH*PH_G) + (KN_PN*PN_G);                              
KN_AH = KN_2AH + (KN_PH*PH_AH) + (KN_PN*PN_AH);                  
KN_BH = KN_2BH + (KN_PH*PH_BH) + (KN_PN*PN_BH);                  
KN_AN = KN_2AN + (KN_PH*PH_AN) + (KN_PN*PN_AN);                  
KN_BN = KN_2BN + (KN_PH*PH_BN) + (KN_PN*PN_BN);                  
KN_lambda = KN_2lambda + (KN_PH*PH_lambda) + (KN_PN*PN_lambda); 

uKH_K  = uKH_1K + (uKH_PH*PH_K) + (uKH_PN*PN_K);                     
uKH_Q  = (uKH_PH*PH_Q) + (uKH_PN*PN_Q);                              
uKH_G  = (uKH_PH*PH_G) + (uKH_PN*PN_G);                              
uKH_AH = uKH_1AH + (uKH_PH*PH_AH) + (uKH_PN*PN_AH);                  
uKH_BH = uKH_1BH + (uKH_PH*PH_BH) + (uKH_PN*PN_BH);                  
uKH_AN = uKH_1AN + (uKH_PH*PH_AN) + (uKH_PN*PN_AN);                  
uKH_BN = uKH_1BN + (uKH_PH*PH_BN) + (uKH_PN*PN_BN);                  
uKH_lambda = uKH_1lambda + (uKH_PH*PH_lambda) + (uKH_PN*PN_lambda);  
                                                                     
uKN_K = uKN_1K + (uKN_PH*PH_K) + (uKN_PN*PN_K);                      
uKN_Q = (uKN_PH*PH_Q) + (uKN_PN*PN_Q);                               
uKN_G = (uKN_PH*PH_G) + (uKN_PN*PN_G);                               
uKN_AH = uKN_1AH + (uKN_PH*PH_AH) + (uKN_PN*PN_AH);                  
uKN_BH = uKN_1BH + (uKN_PH*PH_BH) + (uKN_PN*PN_BH);                  
uKN_AN = uKN_1AN + (uKN_PH*PH_AN) + (uKN_PN*PN_AN);                  
uKN_BN = uKN_1BN + (uKN_PH*PH_BN) + (uKN_PN*PN_BN);                  
uKN_lambda = uKN_1lambda + (uKN_PH*PH_lambda) + (uKN_PN*PN_lambda);  

uZH_K  = uZH_1K + (uZH_PH*PH_K) + (uZH_PN*PN_K);                         
uZH_Q  = (uZH_PH*PH_Q) + (uZH_PN*PN_Q);                                  
uZH_G  = (uZH_PH*PH_G) + (uZH_PN*PN_G);                                  
uZH_AH = uZH_1AH + (uZH_PH*PH_AH) + (uZH_PN*PN_AH);                      
uZH_BH = uZH_1BH + (uZH_PH*PH_BH) + (uZH_PN*PN_BH);                      
uZH_AN = uZH_1AN + (uZH_PH*PH_AN) + (uZH_PN*PN_AN);                      
uZH_BN = uZH_1BN + (uZH_PH*PH_BN) + (uZH_PN*PN_BN);                      
uZH_lambda = uZH_1lambda + (uZH_PH*PH_lambda) + (uZH_PN*PN_lambda);      
                                                                         
uZN_K = uZN_1K + (uZN_PH*PH_K) + (uZN_PN*PN_K);                          
uZN_Q = (uZN_PH*PH_Q) + (uZN_PN*PN_Q);                                   
uZN_G = (uZN_PH*PH_G) + (uZN_PN*PN_G);                                   
uZN_AH = uZN_1AH + (uZN_PH*PH_AH) + (uZN_PN*PN_AH);                      
uZN_BH = uZN_1BH + (uZN_PH*PH_BH) + (uZN_PN*PN_BH);                      
uZN_AN = uZN_1AN + (uZN_PH*PH_AN) + (uZN_PN*PN_AN);                      
uZN_BN = uZN_1BN + (uZN_PH*PH_BN) + (uZN_PN*PN_BN);                      
uZN_lambda = uZN_1lambda + (uZN_PH*PH_lambda) + (uZN_PN*PN_lambda);      

% Solving for consumption Cj=Cj(lambda,K,Q,G,Aj,Bj), investment inputs 
% Jj=Jj(K,Q,GH,GN), imports MF=MF(lambda,K,Q,G,Aj,Bj), exports 
%XH=XH(K,Q,G,Aj,Bj)- Final Solutions
CH_K      = (CH_PH*PH_K) + (CH_PN*PN_K);
CH_Q      = (CH_PH*PH_Q) + (CH_PN*PN_Q);
CH_G      = (CH_PH*PH_G) + (CH_PN*PN_G);
CH_AH     = (CH_PH*PH_AH) + (CH_PN*PN_AH);
CH_BH     = (CH_PH*PH_BH) + (CH_PN*PN_BH);
CH_AN     = (CH_PH*PH_AN) + (CH_PN*PN_AN);
CH_BN     = (CH_PH*PH_BN) + (CH_PN*PN_BN);
CH_lambda = CH_1lambda + (CH_PH*PH_lambda) + (CH_PN*PN_lambda);

CN_K      = (CN_PH*PH_K) + (CN_PN*PN_K);
CN_Q      = (CN_PH*PH_Q) + (CN_PN*PN_Q);
CN_G      = (CN_PH*PH_G) + (CN_PN*PN_G);
CN_AH     = (CN_PH*PH_AH) + (CN_PN*PN_AH);
CN_BH     = (CN_PH*PH_BH) + (CN_PN*PN_BH);
CN_AN     = (CN_PH*PH_AN) + (CN_PN*PN_AN);   
CN_BN     = (CN_PH*PH_BN) + (CN_PN*PN_BN);
CN_lambda = CN_1lambda + (CN_PH*PH_lambda) + (CN_PN*PN_lambda);

CF_K      = (CF_PH*PH_K) + (CF_PN*PN_K);
CF_Q      = (CF_PH*PH_Q) + (CF_PN*PN_Q);
CF_G      = (CF_PH*PH_G) + (CF_PN*PN_G);
CF_AH     = (CF_PH*PH_AH) + (CF_PN*PN_AH);
CF_BH     = (CF_PH*PH_BH) + (CF_PN*PN_BH);
CF_AN     = (CF_PH*PH_AN) + (CF_PN*PN_AN); 
CF_BN     = (CF_PH*PH_BN) + (CF_PN*PN_BN);
CF_lambda = CF_1lambda + (CF_PH*PH_lambda) + (CF_PN*PN_lambda);

JH_K       = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K);
JH_Q       = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q);
JH_G       = (JH_PH*PH_G) + (JH_PN*PN_G);
JH_AH      = (JH_PH*PH_AH) + (JH_PN*PN_AH);
JH_BH      = (JH_PH*PH_BH) + (JH_PN*PN_BH);
JH_AN      = (JH_PH*PH_AN) + (JH_PN*PN_AN);
JH_BN      = (JH_PH*PH_BN) + (JH_PN*PN_BN);
JH_lambda  = (JH_PH*PH_lambda) + (JH_PN*PN_lambda);

JN_K       = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K);
JN_Q       = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q);
JN_G       = (JN_PH*PH_G) + (JN_PN*PN_G);
JN_AH      = (JN_PH*PH_AH) + (JN_PN*PN_AH); 
JN_BH      = (JN_PH*PH_BH) + (JN_PN*PN_BH);
JN_AN      = (JN_PH*PH_AN) + (JN_PN*PN_AN);   
JN_BN      = (JN_PH*PH_BN) + (JN_PN*PN_BN);
JN_lambda  = (JN_PH*PH_lambda) + (JN_PN*PN_lambda);

JF_K       = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K);
JF_Q       = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q);
JF_G       = (JF_PH*PH_G) + (JF_PN*PN_G);
JF_AH      = (JF_PH*PH_AH) + (JF_PN*PN_AH);   
JF_BH      = (JF_PH*PH_BH) + (JF_PN*PN_BH);
JF_AN      = (JF_PH*PH_AN) + (JF_PN*PN_AN);   
JF_BN      = (JF_PH*PH_BN) + (JF_PN*PN_BN); 
JF_lambda  = (JF_PH*PH_lambda) + (JF_PN*PN_lambda);

XH_K      = XH_PH*PH_K;
XH_Q      = XH_PH*PH_Q;
XH_G      = XH_PH*PH_G;
XH_AH     = XH_PH*PH_AH;
XH_BH     = XH_PH*PH_BH;
XH_AN     = XH_PH*PH_AN;
XH_BN     = XH_PH*PH_BN;
XH_lambda = XH_PH*PH_lambda;

MF_K      = (CF_K + JF_K);
MF_Q      = (CF_Q + JF_Q);
MF_G      = (CF_G + JF_G);
MF_AH     = (CF_AH + JF_AH);
MF_BH     = (CF_BH + JF_BH);
MF_AN     = (CF_AN + JF_AN); 
MF_BN     = (CF_BN + JF_BN);
MF_lambda = (CF_lambda + JF_lambda);
 
% Solving for sectoral wages - Wj=Wj(K,Q,G,Aj,Bj)
WH_K = WH_2K + (WH_PH*PH_K) + (WH_PN*PN_K);                       
WH_Q = (WH_PH*PH_Q) + (WH_PN*PN_Q);                               
WH_G = (WH_PH*PH_G) + (WH_PN*PN_G);                               
WH_AH = WH_2AH + (WH_PH*PH_AH) + (WH_PN*PN_AH);                   
WH_BH = WH_2BH + (WH_PH*PH_BH) + (WH_PN*PN_BH);                   
WH_AN = WH_2AN + (WH_PH*PH_AN) + (WH_PN*PN_AN);                   
WH_BN = WH_2BN + (WH_PH*PH_BN) + (WH_PN*PN_BN);                   
WH_lambda = WH_2lambda + (WH_PH*PH_lambda) + (WH_PN*PN_lambda);   
                                                                  
WN_K = WN_2K + (WN_PH*PH_K) + (WN_PN*PN_K);                       
WN_Q = (WN_PH*PH_Q) + (WN_PN*PN_Q);                               
WN_G = (WN_PH*PH_G) + (WN_PN*PN_G);                               
WN_AH = WN_2AH + (WN_PH*PH_AH) + (WN_PN*PN_AH);                   
WN_BH = WN_2BH + (WN_PH*PH_BH) + (WN_PN*PN_BH);                   
WN_AN = WN_2AN + (WN_PH*PH_AN) + (WN_PN*PN_AN);                   
WN_BN = WN_2BN + (WN_PH*PH_BN) + (WN_PN*PN_BN);                   
WN_lambda = WN_2lambda + (WN_PH*PH_lambda) + (WN_PN*PN_lambda);   

% Solutions tildeWj,tildeRj,tildeKj,tildeYj(K,Q,G,Aj,Bj); tildeWj=uZj*Wj;
% tildeRj=RK*uZj; tildeKj=uKj*Kj; tildeYj=uZj*Yj; 
tildeWH_K  = WH_K + (WH*uZH_K); 
tildeWH_Q  = WH_Q + (WH*uZH_Q);
tildeWH_G  = WH_G + (WH*uZH_G);
tildeWH_AH = WH_AH + (WH*uZH_AH);
tildeWH_BH = WH_BH + (WH*uZH_BH);
tildeWH_AN = WH_AN + (WH*uZH_AN);
tildeWH_BN = WH_BN + (WH*uZH_BN);
tildeWH_lambda = WH_lambda + (WH*uZH_lambda);

tildeWN_K  = WN_K + (WN*uZN_K);    
tildeWN_Q  = WN_Q + (WN*uZN_Q);    
tildeWN_G  = WN_G + (WN*uZN_G);    
tildeWN_AH = WN_AH + (WN*uZN_AH);  
tildeWN_BH = WN_BH + (WN*uZN_BH);  
tildeWN_AN = WN_AN + (WN*uZN_AN);  
tildeWN_BN = WN_BN + (WN*uZN_BN);
tildeWN_lambda = WN_lambda + (WN*uZN_lambda);

% Solution for tildeW(K,Q,G,Aj,Bj) - tildeW(tildeWH,tildeWN) 
tildeW_WH      = (W/WH)*alphaL;                                            
tildeW_WN      = (W/WN)*(1-alphaL);                                        
tildeW_K       = (tildeW_WH*tildeWH_K)  + (tildeW_WN*tildeWN_K);           
tildeW_Q       = (tildeW_WH*tildeWH_Q)  + (tildeW_WN*tildeWN_Q);           
tildeW_G       = (tildeW_WH*tildeWH_G)  + (tildeW_WN*tildeWN_G);           
tildeW_AH      = (tildeW_WH*tildeWH_AH) + (tildeW_WN*tildeWN_AH);          
tildeW_BH      = (tildeW_WH*tildeWH_BH) + (tildeW_WN*tildeWN_BH);          
tildeW_AN      = (tildeW_WH*tildeWH_AN) + (tildeW_WN*tildeWN_AN);          
tildeW_BN      = (tildeW_WH*tildeWH_BN) + (tildeW_WN*tildeWN_BN);          
tildeW_lambda  = (tildeW_WH*tildeWH_lambda) + (tildeW_WN*tildeWN_lambda);  
 
% Solution for L as function L=L(K,Q,G,Aj,Bj)
L_1lambda = sigmaL*(L/lambda);
L_W  = sigmaL*(L/W); 
L_WH = sigmaL*L*alphaL/WH; 
L_WN = sigmaL*L*(1-alphaL)/WN; 
L_K  = (L_WH*tildeWH_K)  + (L_WN*tildeWN_K);                            
L_Q  = (L_WH*tildeWH_Q)  + (L_WN*tildeWN_Q);                            
L_G  = (L_WH*tildeWH_G)  + (L_WN*tildeWN_G);                            
L_AH = (L_WH*tildeWH_AH) + (L_WN*tildeWN_AH);                           
L_BH = (L_WH*tildeWH_BH) + (L_WN*tildeWN_BH);                           
L_AN = (L_WH*tildeWH_AN) + (L_WN*tildeWN_AN);                           
L_BN = (L_WH*tildeWH_BN) + (L_WN*tildeWN_BN);                           
L_lambda  = L_1lambda + (L_WH*tildeWH_lambda) + (L_WN*tildeWN_lambda);  

% Solution for C as function C=C(K,Q,G,Aj,Bj) 
% Solution for C as function C=C(lambda,K,Q,AH,BH,AN,BN) 
C_1lambda  = -sigmaC*(C/lambda); 
C_PH       = -sigmaC*alphaC*alphaH*(C/PH); 
C_PN       = -sigmaC*(1-alphaC)*(C/PN); 
C_K        = (C_PH*PH_K) + (C_PN*PN_K); 
C_Q        = (C_PH*PH_Q) + (C_PN*PN_Q);
C_G        = (C_PH*PH_G) + (C_PN*PN_G); 
C_AH       = (C_PH*PH_AH) + (C_PN*PN_AH);
C_BH       = (C_PH*PH_BH) + (C_PN*PN_BH);
C_AN       = (C_PH*PH_AN) + (C_PN*PN_AN);
C_BN       = (C_PH*PH_BN) + (C_PN*PN_BN);
C_lambda   = C_1lambda + (C_PH*PH_lambda) + (C_PN*PN_lambda);

% Solution for PC=PC(PH,PN) - PC = PC(K,Q,G,Aj,Bj)
PC_K       = (PC/PH)*alphaC*alphaH*PH_K + (PC/PN)*(1-alphaC)*PN_K; 
PC_Q       = (PC/PH)*alphaC*alphaH*PH_Q + (PC/PN)*(1-alphaC)*PN_Q;
PC_G       = (PC/PH)*alphaC*alphaH*PH_G + (PC/PN)*(1-alphaC)*PN_G;
PC_AH      = (PC/PH)*alphaC*alphaH*PH_AH + (PC/PN)*(1-alphaC)*PN_AH;
PC_BH      = (PC/PH)*alphaC*alphaH*PH_BH + (PC/PN)*(1-alphaC)*PN_BH;
PC_AN      = (PC/PH)*alphaC*alphaH*PH_AN + (PC/PN)*(1-alphaC)*PN_AN;
PC_BN      = (PC/PH)*alphaC*alphaH*PH_BN + (PC/PN)*(1-alphaC)*PN_BN;
PC_lambda  = (PC/PH)*alphaC*alphaH*PH_lambda + (PC/PN)*(1-alphaC)*PN_lambda;

% Solution for PI=PI(PH,PN) - PI = PI(K,Q,G,Aj,Bj)
PI_K       = (PI/PH)*alphaI*alphaIH*PH_K + (PI/PN)*(1-alphaI)*PN_K; 
PI_Q       = (PI/PH)*alphaI*alphaIH*PH_Q + (PI/PN)*(1-alphaI)*PN_Q;
PI_G       = (PI/PH)*alphaI*alphaIH*PH_G + (PI/PN)*(1-alphaI)*PN_G;  
PI_AH      = (PI/PH)*alphaI*alphaIH*PH_AH + (PI/PN)*(1-alphaI)*PN_AH;
PI_BH      = (PI/PH)*alphaI*alphaIH*PH_BH + (PI/PN)*(1-alphaI)*PN_BH;
PI_AN      = (PI/PH)*alphaI*alphaIH*PH_AN + (PI/PN)*(1-alphaI)*PN_AN;
PI_BN      = (PI/PH)*alphaI*alphaIH*PH_BN + (PI/PN)*(1-alphaI)*PN_BN;
PI_lambda  = (PI/PH)*alphaI*alphaIH*PH_lambda + (PI/PN)*(1-alphaI)*PN_lambda;

% Solution for GE=PH*GH + PN*GN + GF - G = G(K,Q,G,Aj,Bj)
G_K        = (PH_K*GH) + (PN_K*GN); 
G_Q        = (PH_Q*GH) + (PN_Q*GN);
G_G        = (PH_G*GH) + (PN_G*GN) + (PH*GH_G) + (PN*GN_G) + GF_G;   
G_AH       = (PH_AH*GH) + (PN_AH*GN);
G_BH       = (PH_BH*GH) + (PN_BH*GN);
G_AN       = (PH_AN*GH) + (PN_AN*GN);
G_BN       = (PH_BN*GH) + (PN_BN*GN);
G_lambda   = (PH_lambda*GH) + (PN_lambda*GN);

% Capital rental rates
RKH = PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((YH/KH)^(1/sigmaH)); 
RKN = PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((YN/KN)^(1/sigmaN));

% Solution for the price of non traded goods in terms of home traded goods
% - P = P(K,Q,G,Aj,Bj); 
P    = PN/PH; 
P_K  = (P/PN)*PN_K - (P/PH)*PH_K; 
P_Q  = (P/PN)*PN_Q - (P/PH)*PH_Q;
P_G  = (P/PN)*PN_G - (P/PH)*PH_G; 
P_AH = (P/PN)*PN_AH - (P/PH)*PH_AH;
P_BH = (P/PN)*PN_BH - (P/PH)*PH_BH;
P_AN = (P/PN)*PN_AN - (P/PH)*PH_AN;
P_BN = (P/PN)*PN_BN - (P/PH)*PH_BN;
P_lambda = (P/PN)*PN_lambda - (P/PH)*PH_lambda;

% GDP and output shares in real terms
Y   = (PH*YH) +(PN*YN);

% Solution for Y as function Y=Y(K,Q,lambda,GH,GN) 
Y_K       = (PH_K*YH) + (PH*YH_K) + (PN_K*YN) + (PN*YN_K); 
Y_Q       = (PH_Q*YH) + (PH*YH_Q) + (PN_Q*YN) + (PN*YN_Q);
Y_G       = (PH_G*YH) + (PH*YH_G) + (PN_G*YN) + (PN*YN_G);
Y_AH      = (PH_AH*YH) + (PH*YH_AH) + (PN_AH*YN) + (PN*YN_AH);
Y_BH      = (PH_BH*YH) + (PH*YH_BH) + (PN_BH*YN) + (PN*YN_BH);
Y_AN      = (PH_AN*YH) + (PH*YH_AN) + (PN_AN*YN) + (PN*YN_AN);
Y_BN      = (PH_BN*YH) + (PH*YH_BN) + (PN_BN*YN) + (PN*YN_BN);
Y_lambda  = (PH_lambda*YH) + (PH*YH_lambda) + (PN_lambda*YN) + (PN*YN_lambda);

% Marginal revenue of capital R = PH*partial YH/partial KH.
% R=R(K,Q,G,Aj,Bj,lambda) 
R_K  = (RK/PH)*PH_K - (RK/kH)*(sLH/sigmaH)*kH_K - RK*(sLH/sigmaH)*uKH_K; 
R_Q  = (RK/PH)*PH_Q - (RK/kH)*(sLH/sigmaH)*kH_Q - RK*(sLH/sigmaH)*uKH_Q;
R_G  = (RK/PH)*PH_G - (RK/kH)*(sLH/sigmaH)*kH_G - RK*(sLH/sigmaH)*uKH_G;
R_AH = (RK/PH)*PH_AH - (RK/kH)*(sLH/sigmaH)*kH_AH - RK*(sLH/sigmaH)*uKH_AH + (RK/AH)*(sLH/sigmaH);
R_BH = (RK/PH)*PH_BH - (RK/kH)*(sLH/sigmaH)*kH_BH - RK*(sLH/sigmaH)*uKH_BH + (RK/BH)*((sigmaH-sLH)/sigmaH);
R_AN = (RK/PH)*PH_AN - (RK/kH)*(sLH/sigmaH)*kH_AN - RK*(sLH/sigmaH)*uKH_AN; 
R_BN = (RK/PH)*PH_BN - (RK/kH)*(sLH/sigmaH)*kH_BN - RK*(sLH/sigmaH)*uKH_BN;
R_lambda = (RK/PH)*PH_lambda - (RK/kH)*(sLH/sigmaH)*kH_lambda - RK*(sLH/sigmaH)*uKH_lambda;

% Solving for investment function I/K = v(Q/PI)+delta_K - 
% v=v(K,Q,G,Aj,Bj,lambda) final solution
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q); 
v_K  = (v_PN*PN_K) + (v_PH*PH_K); 
v_G  = (v_PN*PN_G) + (v_PH*PH_G); 
v_AH = (v_PN*PN_AH) + (v_PH*PH_AH); 
v_BH = (v_PN*PN_BH) + (v_PH*PH_BH); 
v_AN = (v_PN*PN_AN) + (v_PH*PH_AN);
v_BN = (v_PN*PN_BN) + (v_PH*PH_BN);
v_lambda = (v_PN*PN_lambda) + (v_PH*PH_lambda);

% Elements of the Jacobian Matrix 
Upsilon_K = (I/IN)*(YN_K-CN_K-(KN*xi1N*uKN_K)) - deltaK + alphaI*phiI*I*( (PN_K/PN) - (alphaIH/PH)*PH_K );                                                                        
Upsilon_Q = (I/IN)*(YN_Q-CN_Q-(KN*xi1N*uKN_Q)) + alphaI*phiI*I*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );
Sigma_K   = -(R_K-(RK/K)+(RK/K)*((KH*uKH_K)+(KN*uKN_K)+(KH*uZH_K)+(KN*uZN_K)+(KH_K+KN_K))-(PH*KH/K)*xi1H*uKH_K-(PN*KN/K)*xi1N*uKN_K + (PI*kappa*v_K*deltaK) ); 
Sigma_Q   = (r+deltaK)-( R_Q+(RK/K)*((KH*uKH_Q)+(KN*uKN_Q)+(KH*uZH_Q)+(KN*uZN_Q)+(KH_Q+KN_Q))-(PH*KH/K)*xi1H*uKH_Q-(PN*KN/K)*xi1N*uKN_Q + (PI*kappa*v_Q*deltaK) ); 

x11 = Upsilon_K;                                                                         
x12 = Upsilon_Q;                                                                                                                                                                                                                     
x21 = Sigma_K;                        
x22 = Sigma_Q;    

J = [x11 x12; x21 x22];
[V,nu]=eig(J)
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu1 = nu_sorted(1,1); 
nu2 = nu_sorted(2,2); 
omega11 = V_sorted(1,1)/V_sorted(1,1); 
omega21 = V_sorted(2,1)/V_sorted(1,1); 
omega12 = V_sorted(1,2)/V_sorted(1,2); 
omega22 = V_sorted(2,2)/V_sorted(1,2); 
TrJ = trace(J); 
DetJ = det(J); 

% Intertemporal solvency condition - lambda - dotB = Xi(lambda,K,P,Q);
% Xi_Q=0
B_K   = (PH_K*XH) + (PH*XH_K) - MF_K; 
B_Q   = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
N1    = (B_K + (B_Q*omega21));
H1    = N1/(nu1-r); 

% Government spending 
G       = (PH*GH) + (PN*GN) + GF;   
GT      = GF + (PH*GH); 
omegaGT = GT/G; 
omegaGH = (PH*GH)/GT; 
omegaGF = GF/G; 

% Investment 
IT       = deltaK*K*iota*((PIT/PI)^(-phiI));
I_check  = ( (iota^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-iota)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1)); 
IT_check = ( (iotaH^(1/rhoI))*(IH^((rhoI-1)/rhoI)) + ((1-iotaH)^(1/rhoI))*(IF^((rhoI-1)/rhoI)) )^(rhoI/(rhoI-1));  
I        = deltaK*K; 
EI       = PI*I; 
EIT      = (PH*IH) + IF; 
omegaI   = PI*I/Y;
omegaIH  = (PH*IH)/(PI*I);
omegaIF  = (IF)/(PI*I);

% Net exports, current account and saving
NX  = (PH*XH) - MF;  
CA  = (r*B) + (PH*XH) - MF; 
A   = B + (PI*K); 
Tax = G; 
Sav = (r*A) + (W*L) - (PC*C) - Tax; 

% Real Aggregate Wage 
WPC  = W/PC;
WHPC = WH/PC;
WNPC = WN/PC;
RKPC = RK/PC;

% Labor income and Capital income shares
EL      = W*L; 
omegaL  = EL/Y; 
EK      = RK*K; 
omegaK  = EK/Y;
alphaK  = (RKH*KH)/(RK*K); 

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WH); 
YHYN  = (YH/YN); 
LHLN  = (LH/LN);

% Consumption 
CT       = C*varphi*((PT/PC)^(-phi));
C_check  = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1)); 
CT_check = ( (varphiH^(1/rho))*(CH^((rho-1)/rho)) + ((1-varphiH)^(1/rho))*(CF^((rho-1)/rho)) )^(rho/(rho-1));
omegaCH  = (PH*CH)/(PC*C); 
omegaCF  = (CF)/(PC*C);

% L_H, L_N and FOC for LH and LN 
Vut     = ( (vartheta^(-1/epsilon))*(LH^((epsilon+1)/epsilon)) + ((1-vartheta)^(-1/epsilon))*(LN^((epsilon+1)/epsilon)) ); 
L_check = Vut^(epsilon/(epsilon+1)); 
L_H     = ((vartheta)^(-1/epsilon))*(LH/L)^(1/epsilon); 
L_N     = ((1-vartheta)^(-1/epsilon))*(LN/L)^(1/epsilon);

% Sectoral ratios
omegaINYN = IN/YN; 
omegaIHYH = IH /YH; 
omegaIFYH =  IF/YH;
omegaGHYH = GH / YH;
omegaGFYH = GF / (PH*YH);
omegaGNYN = GN / YN;
omegaGN   = (PN*GN) / G;
omegaYH   = (PH*YH) / Y;
omegaYN   = (PN*YN) /Y; 
omegaLH   = LH / L;
omegaLN   = LN / L; 
omegaXHY  = (PH*XH) / Y; 
omegaXHYH = XH / YH;

% Targeted ratios
omegaC    = (PC*C) / Y;
omegaNX   =  NX / Y; 
omegaG    = G/Y;
omegaB    = (r*B)/Y; 
omegaKY   = K/Y; 

% Technology
ZH = ((AH)^(sLH))*((BH)^(1-sLH)); 
ZN = ((AN)^(sLN))*((BN)^(1-sLN)); 
Z  = (ZH^omegaYH)*(ZN^(1-omegaYH));

% TFP
TFPH = YH/(gammaH*(LH^((sigmaH-1)/sigmaH)) + (1-gammaH)*(KH^((sigmaH-1)/sigmaH)) )^(sigmaH/(sigmaH-1)); 
TFPN = YN/(gammaN*(LN^((sigmaN-1)/sigmaN)) + (1-gammaN)*(KN^((sigmaN-1)/sigmaN)) )^(sigmaN/(sigmaN-1)); 
TFP  = (TFPH^omegaYH)*(TFPN^(1-omegaYH));

% Check the closure of the model
cond1  = PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((YH/KH)^(1/sigmaH))-RK;                               
cond2  = PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((YN/KN)^(1/sigmaN))-RK;                             
cond3  = PH*gammaH*(AH^((sigmaH-1)/sigmaH))*(yH^(1/sigmaH))-WH;                                   
cond4  = PN*gammaN*(AN^((sigmaN-1)/sigmaN))*(yN^(1/sigmaN))-WN;                                 
cond5  = (LH*kH)+(LN*kN)-K;                                   
cond6  = RK-(deltaK+r)*PI;                                    
cond7  = YN-CN-GN-IN;                                         
cond8  = YH-CH-GH-IH-XH;                                   
cond9  = (B-B0) - H1*(K-K0);                                  
cond10  = DetJ - (nu1*nu2);                                   
cond11 = TrJ - (nu1+nu2);                                     
cond12 = (LH/LN) - (vartheta/(1-vartheta))*Omega^(-epsilon);  
cond13 = (CT/CN) - (varphi/(1-varphi))*(PN/PT)^(phi);               
cond14 = (PC*C) - ((PT*CT)+(PN*CN));                                
cond15 = (W*L) - ((WH*LH)+(WN*LN));                           
cond16 = gammaL*(L^(1/sigmaL))*L_H - (lambda*WH);               
cond17 = gammaL*(L^(1/sigmaL))*L_N - (lambda*WN);               
cond18 = Y - (PC*C) - G - (PI*I) + (r*B);                     
cond19 = Sav;                                                 
cond20 = (PC*C) - (CF+(PH*CH)+(PN*CN));                                
cond21 = (IT/IN) - (iota/(1-iota))*(PN/PIT)^(phiI);            
cond22 = (PI*I) - ((PIT*IT)+(PN*IN));                                
cond23 = (RK*K) - ((RKH*KH)+(RKN*KN));                        
cond24 = 1 - (omegaK + omegaL);    
cond25 = (CH/CF) - (varphiH/(1-varphiH))*(PH)^(-rho);    
cond26 = (PT*CT) - ((PH*CH)+CF); 
cond27 = (IH/IF) - (iotaH/(1-iotaH))*(PH)^(-rhoI);    
cond28 = (PIT*IT) - ((PH*IH)+IF); 
cond29 = r*B + (PH*XH) - MF; 
cond30 = r*B + (RK*K) + (W*L) - G - (PC*C) - (PI*I); 
cond31 = RK - PI*(r+deltaK);
 
disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                     Initial Steady State with kH > kN');
disp('                           The exomark: ');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (exomark)');
disp(sprintf('sigmaH  : %5.2f   gammaH   : %5.2f',sigmaH,gammaH));
disp(sprintf('sigmaN  : %5.2f   gammaN   : %5.2f',sigmaN,gammaN));
disp(sprintf('sLH     : %5.2f   sLN      : %5.2f',sLH,sLN));
disp(sprintf('sigmaC  : %5.2f   phi      : %5.2f  varphi : %5.2f',sigmaC,phi,varphi));
disp(sprintf('rho     : %5.2f   varphiH  : %5.2f',rho,varphiH));
disp(sprintf('phiI    : %5.2f   iota     : %5.2f',phiI,iota)); 
disp(sprintf('rhoI    : %5.2f   iotaH    : %5.2f',rhoI,iotaH))
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f',sigmaL,gammaL));
disp(sprintf('epsilon : %5.2f   vartheta : %5.2f',epsilon,vartheta));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('AH      : %5.2f   BH       : %5.2f',AH,BH));
disp(sprintf('AN      : %5.2f   BN       : %5.2f',AN,BN));
disp(sprintf('ZH      : %5.2f   ZN       : %5.2f',ZH,ZN));
disp(sprintf('TFPH    : %5.2f   TFPN     : %5.2f',TFPH,TFPN));
disp(sprintf('omegaYH : %5.2f   Z        : %5.2f TFP        : %5.2f',omegaYH,Z,TFP));
disp(sprintf('GH      : %5.2f   GN       : %5.2f',GH,GN));
disp(sprintf('GF      : %5.2f   G        : %5.2f',GF,G));
disp(' ');

disp(' ');
disp('The production side (exomark)');
disp(sprintf('kH       : %9.3f    kN   : %9.3f',kH,kN));
disp(sprintf('LH       : %9.3f    LN   : %9.3f',LH,LN));
disp(sprintf('KH       : %9.3f    KN   : %9.3f',KH,KN));
disp(sprintf('YH       : %9.3f    YN   : %9.3f',YH,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('L_check  : %9.3f   ',L_check));
disp(sprintf('alphaL   : %9.3f   ',alphaL));

disp(' ');
disp('The demand side (exomark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('CT       :   %7.3f  CT_check : %9.3f',CT,CT_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('PT       :   %7.3f    alphaH : %9.3f',PT,alphaH));
disp(sprintf('CH       :   %7.3f    CN     : %9.3f',CH,CN));
disp(sprintf('CF       :   %7.3f',CF));

disp('The demand side (exomark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('PIT      :   %7.3f   alphaIH : %9.3f',PIT,alphaIH));
disp(sprintf('IH       :   %7.3f    IN     : %9.3f',IH,IN));
disp(sprintf('EI       :   %7.3f    EIT    : %9.3f',EI,EIT));

disp('Export and import (exomark)');
disp(sprintf('XH        :   %7.3f   MF : %9.3f',XH,MF));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('RK                 : %9.3f',RK));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector H');
disp(sprintf('Gross output (YH)  : %9.3f',YH));
disp(sprintf('WH                 : %9.3f',WH));
disp(sprintf('Profit             : %9.10f',PiH));

disp('Price of Non Tradables in terms of Imports');                                                                
disp(sprintf('PN_Q        :   %7.3f  PN_K        : %9.3f',PN_Q,PN_K));                          
disp(sprintf('PN_G        :   %7.3f',PN_G)); 
disp(sprintf('PN_AH       :   %7.3f  PN_BH       : %9.3f',PN_AH,PN_BH));
disp(sprintf('PN_AN       :   %7.3f  PN_BN       : %9.3f',PN_AN,PN_BN));
                                                                                                
disp('Terms of Trade');                                                                                            
disp(sprintf('PH_Q        :   %7.3f  PH_K        : %9.3f',PH_Q,PH_K));                          
disp(sprintf('PH_G        :   %7.3f',PH_G));                        
disp(sprintf('PH_AH       :   %7.3f  PH_BH       : %9.3f',PH_AH,PH_BH));
disp(sprintf('PH_AN       :   %7.3f  PH_BN       : %9.3f',PH_AN,PH_BN));                                                                                                

disp(' ');                                                                                      
disp('Partial derivatives CH and CN');                                                          
disp(sprintf('CN_K        :   %7.3f  CH_K      : %9.3f',CN_K,CH_K));                            
disp(sprintf('CN_Q        :   %7.3f  CH_Q      : %9.3f',CN_Q,CH_Q));                            
disp(sprintf('CN_lamb     :   %7.3f  CH_lamb   : %9.3f',CN_lambda,CH_lambda));                  
disp(sprintf('CN_G        :   %7.3f  CH_G      : %9.3f',CN_G,CH_G)); 
disp(sprintf('CN_lamb     :   %7.3f  CH_lamb   : %9.3f',CN_lambda,CH_lambda));
disp(sprintf('CN_AH       :   %7.3f  CH_AH     : %9.3f',CN_AH,CH_AH));
disp(sprintf('CN_BH       :   %7.3f  CH_BH     : %9.3f',CN_BH,CH_BH));
disp(sprintf('CN_AN       :   %7.3f  CH_AN     : %9.3f',CN_AN,CH_AN));
disp(sprintf('CN_BN       :   %7.3f  CH_BN     : %9.3f',CN_BN,CH_BN));                          
                                                                                                
                                                                                                
disp('Partial derivatives LH and LN');                                                          
disp(sprintf('LN_WH       :   %7.3f  LH_WH      : %9.3f',LN_WH,LH_WH));                         
disp(sprintf('LN_WN       :   %7.3f  LH_WN      : %9.3f',LN_WN,LH_WN));                         
disp(sprintf('LN_lamb     :   %7.3f  LH_lamb    : %9.3f',LN_lambda,LH_lambda));                 
disp(sprintf('LN_G        :   %7.3f  LH_G       : %9.3f',LN_G,LH_G));  
disp(sprintf('LN_AH       :   %7.3f  LH_AH      : %9.3f',LN_AH,LH_AH));
disp(sprintf('LN_BH       :   %7.3f  LH_BH      : %9.3f',LN_BH,LH_BH));
disp(sprintf('LN_AN       :   %7.3f  LH_AN      : %9.3f',LN_AN,LH_AN));
disp(sprintf('LN_BN       :   %7.3f  LH_BN      : %9.3f',LN_BN,LH_BN));
                                                                                                
disp('Partial derivatives kH and kN');                                                          
disp(sprintf('kN_Q       :   %7.6f  kH_Q       : %9.6f',kN_Q,kH_Q));                            
disp(sprintf('kN_K       :   %7.6f  kH_K       : %9.6f',kN_K,kH_K));                            
disp(sprintf('kN_lambda  :   %7.3f  kH_lambda  : %9.3f',kN_lambda,kH_lambda));                  
disp(sprintf('kN_G       :   %7.6f  kH_G       : %9.6f',kN_G,kH_G));   
disp(sprintf('kN_AH      :   %7.6f  kH_AH      : %9.6f',kN_AH,kH_AH));
disp(sprintf('kN_BH      :   %7.6f  kH_BH      : %9.6f',kN_BH,kH_BH));
disp(sprintf('kN_AN      :   %7.6f  kH_AN      : %9.6f',kN_AN,kH_AN));
disp(sprintf('kN_BN      :   %7.6f  kH_BN      : %9.6f',kN_BN,kH_BN));
                                                                                                
disp('Partial derivatives WH and WN');                                                          
disp(sprintf('WN_Q       :   %7.6f  WH_Q       : %9.6f',WN_Q,WH_Q));                            
disp(sprintf('WN_K       :   %7.6f  WH_K       : %9.6f',WN_K,WH_K));                            
disp(sprintf('WN_lambda  :   %7.3f  WH_lambda  : %9.3f',WN_lambda,WH_lambda));                  
disp(sprintf('WN_G       :   %7.6f  WH_G       : %9.6f',WN_G,WH_G)); 
disp(sprintf('WN_AH      :   %7.6f  WH_AH      : %9.6f',WN_AH,WH_AH));
disp(sprintf('WN_BH      :   %7.6f  WH_BH      : %9.6f',WN_BH,WH_BH));
disp(sprintf('WN_AN      :   %7.6f  WH_AN      : %9.6f',WN_AN,WH_AN));
disp(sprintf('WN_BN      :   %7.6f  WH_BN      : %9.6f',WN_BN,WH_BN));
                                                                                                
disp('Partial derivatives LH and LN');                                                          
disp(sprintf('LN_Q       :   %7.6f  LH_Q       : %9.6f',LN_Q,LH_Q));                            
disp(sprintf('LN_K       :   %7.6f  LH_K       : %9.6f',LN_K,LH_K));                            
disp(sprintf('LN_lambda  :   %7.3f  LH_lambda  : %9.3f',LN_lambda,LH_lambda));                  
disp(sprintf('LN_G       :   %7.6f  LH_G       : %9.6f',LN_G,LH_G)); 
disp(sprintf('LN_AH      :   %7.6f  LH_AH      : %9.6f',LN_AH,LH_AH));
disp(sprintf('LN_BH      :   %7.6f  LH_BH      : %9.6f',LN_BH,LH_BH));
disp(sprintf('LN_AN      :   %7.6f  LH_AN      : %9.6f',LN_AN,LH_AN));
disp(sprintf('LN_BN      :   %7.6f  LH_BN      : %9.6f',LN_BN,LH_BN));

                                                                                                
disp('Partial derivatives Yj');  
disp(sprintf('YN_1PN     :   %7.6f  YN_1PH     : %9.6f',YN_1PN,YN_1PH));
disp(sprintf('YN_1K      :   %7.6f  YN_1lambda : %9.6f',YN_1K,YN_1lambda));
disp(sprintf('YN_1AH     :   %7.6f  YN_1BH     : %9.6f',YN_1AH,YN_1BH));
disp(sprintf('YN_1AN     :   %7.6f  YN_1BN     : %9.6f',YN_1AN,YH_1BN));
disp(sprintf('YN_uKH     :   %7.6f  YN_uKN     : %9.6f',YN_uKH,YN_uKN));
disp(sprintf('YN_uZH     :   %7.6f  YH_uZN     : %9.6f',YN_uZH,YN_uZN));
disp(' ');
disp(sprintf('YH_1PN     :   %7.6f  YH_1PH     : %9.6f',YH_1PN,YH_1PH));
disp(sprintf('YH_1K      :   %7.6f  YH_1lambda : %9.6f',YH_1K,YH_1lambda));
disp(sprintf('YH_1AH     :   %7.6f  YH_1BH     : %9.6f',YH_1AH,YH_1BH));
disp(sprintf('YH_1AN     :   %7.6f  YH_1BN     : %9.6f',YH_1AN,YH_1BN));
disp(sprintf('YH_uKH     :   %7.6f  YH_uKN     : %9.6f',YH_uKH,YH_uKN));
disp(sprintf('YH_uZH     :   %7.6f  YH_uZN     : %9.6f',YH_uZH,YH_uZN));
disp(' ');

disp(sprintf('YN_Q       :   %7.6f  YH_Q       : %9.6f',YN_Q,YH_Q));                            
disp(sprintf('YN_K       :   %7.6f  YH_K       : %9.6f',YN_K,YH_K));                            
disp(sprintf('YN_lambda  :   %7.3f  YH_lambda  : %9.3f',YN_lambda,YH_lambda));                  
disp(sprintf('YN_G       :   %7.6f  YH_G       : %9.6f',YN_G,YH_G));
disp(sprintf('YN_AH      :   %7.6f  YH_AH      : %9.6f',YN_AH,YH_AH));
disp(sprintf('YN_BH      :   %7.6f  YH_BH      : %9.6f',YN_BH,YH_BH));
disp(sprintf('YN_AN      :   %7.6f  YH_AN      : %9.6f',YN_AN,YH_AN));
disp(sprintf('YN_BN      :   %7.6f  YH_BN      : %9.6f',YN_BN,YH_BN));
                                                                                                
disp('Partial derivatives of Y');                                                               
disp(sprintf('Y_Q        :   %7.3f  Y_K        : %9.3f',Y_Q,Y_K));  
disp(sprintf('Y_AH       :   %7.3f  Y_BH       : %9.3f',Y_AH,Y_BH));
disp(sprintf('Y_AN       :   %7.3f  Y_BN       : %9.3f',Y_AN,Y_BN));
disp(sprintf('Y_G        :   %7.3f  Y_lambda   : %9.3f',Y_G,Y_lambda));                                                                          
                                                                                                
disp('Partial derivatives of L');                                                               
disp(sprintf('L_H        :   %7.3f  L_N        : %9.3f',L_H,L_N));                              
                                                                                                
disp('Partial derivatives of L');                                                               
disp(sprintf('L_Q        :   %7.3f  L_K        : %9.3f',L_Q,L_K));                              
disp(sprintf('L_G        :   %7.3f ',L_G));      
disp(sprintf('L_AH       :   %7.3f  L_BH       : %9.3f',L_AH,L_BH));
disp(sprintf('L_AN       :   %7.3f  L_BN       : %9.3f',L_AN,L_BN));
disp(sprintf('L_lambda   :   %7.3f  tildeW_lambda   : %9.3f',L_lambda,tildeW_lambda));  

disp('Partial derivatives of uKj');  
disp(sprintf('uKN_Q       :   %7.6f  uKH_Q       : %9.6f',uKN_Q,uKH_Q));             
disp(sprintf('uKN_K       :   %7.6f  uKH_K       : %9.6f',uKN_K,uKH_K));             
disp(sprintf('uKN_lambda  :   %7.3f  uKH_lambda  : %9.3f',uKN_lambda,uKH_lambda));   
disp(sprintf('uKN_G       :   %7.6f  uKH_G       : %9.6f',uKN_G,uKH_G));             
disp(sprintf('uKN_AH      :   %7.6f  uKH_AH      : %9.6f',uKN_AH,uKH_AH));           
disp(sprintf('uKN_BH      :   %7.6f  uKH_BH      : %9.6f',uKN_BH,uKH_BH));           
disp(sprintf('uKN_AN      :   %7.6f  uKH_AN      : %9.6f',uKN_AN,uKH_AN));           
disp(sprintf('uKN_BN      :   %7.6f  uKH_BN      : %9.6f',uKN_BN,uKH_BN));  

disp('Partial derivatives of uZj');  
disp(sprintf('uZN_Q       :   %7.6f  uZH_Q       : %9.6f',uZN_Q,uZH_Q));            
disp(sprintf('uZN_K       :   %7.6f  uZH_K       : %9.6f',uZN_K,uZH_K));            
disp(sprintf('uZN_lambda  :   %7.3f  uZH_lambda  : %9.3f',uZN_lambda,uZH_lambda));  
disp(sprintf('uZN_G       :   %7.6f  uZH_G       : %9.6f',uZN_G,uZH_G));            
disp(sprintf('uZN_AH      :   %7.6f  uZH_AH      : %9.6f',uZN_AH,uZH_AH));          
disp(sprintf('uZN_BH      :   %7.6f  uZH_BH      : %9.6f',uZN_BH,uZH_BH));          
disp(sprintf('uZN_AN      :   %7.6f  uZH_AN      : %9.6f',uZN_AN,uZH_AN));          
disp(sprintf('uZN_BN      :   %7.6f  uZH_BN      : %9.6f',uZN_BN,uZH_BN));          
                                                                                                
disp('Partial derivatives of W');                                                               
disp(sprintf('tildeW_WH       :   %7.3f  tildeW_WN       : %9.3f',tildeW_WH,tildeW_WN));   
disp(sprintf('tildeW_Q        :   %7.3f  tildeW_K        : %9.3f',tildeW_Q,tildeW_K));          
disp(sprintf('tildeW_G        :   %7.3f',tildeW_G));                                       
disp(sprintf('tildeW_AH       :   %7.3f  tildeW_BH       : %9.3f',tildeW_AH,tildeW_BH));   
disp(sprintf('tildeW_AN       :   %7.3f  tildeW_BN       : %9.3f',tildeW_AN,tildeW_BN));   
                                                                                                
disp(' ');                                                                                      
disp('Wealth');                                                                                 
disp(sprintf('K      :   %5.3f    B  :   %5.6f',K,B));                                          
disp(sprintf('lambda :   %5.15f   A  :   %5.3f',lambda,A));                                     
disp(sprintf('Sav    :   %5.10f   CA :   %5.10f',Sav,CA));  

disp(' ');                                                                                      
disp('Relative Prices');  
disp(sprintf('PN_K       : %5.4f   PN_Q       : %5.4f',PN_K,PN_Q));                                 
disp(sprintf('PN_G       :  %5.4f  PN_lambda  : %5.4f',PN_G,PN_lambda));  
disp(sprintf('PH_K       : %5.4f   PH_Q       : %5.4f',PH_K,PH_Q));                                 
disp(sprintf('PH_G       :  %5.4f  PH_lambda  : %5.4f',PH_G,PH_lambda)); 
                                                                                                
disp(' ');                                                                                      
disp('Linearization');                                                                          
disp(sprintf('R_lambda  :  %5.4f  R_K       : %5.4f   R_Q     : %5.4f',R_lambda,R_K,R_Q));      
disp(sprintf('R_G       :  %5.4f',R_G));
disp(sprintf('R_AH      :  %5.4f  R_BH      : %5.4f',R_AH,R_BH));
disp(sprintf('R_AN      :  %5.4f  R_BN      : %5.4f',R_AN,R_BN));
disp(sprintf('P_K       : %5.4f   P_Q       : %5.4f',P_K,P_Q));                                 
disp(sprintf('P_G       :  %5.4f',P_G));     
disp(sprintf('P_AH      :  %5.4f  P_BH      : %5.4f',P_AH,P_BH));
disp(sprintf('P_AN      :  %5.4f  P_BN      : %5.4f',P_AN,P_BN));
disp(sprintf('v_K       :  %5.4f  v_Q       : %5.4f',v_K,v_Q));                                 
disp(sprintf('v_G       :  %5.4f',v_G));          
disp(sprintf('v_AH      :  %5.4f  v_BH      : %5.4f',v_AH,v_BH));
disp(sprintf('v_AN      :  %5.4f  v_BN      : %5.4f',v_AN,v_BN));
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_Q : %5.4f',Upsilon_K,Upsilon_Q));                     
disp(sprintf('Sigma_K   :  %5.4f  Sigma_Q   : %5.4f',Sigma_K,Sigma_Q));                         
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));  
                                                                                                
disp(' ');
disp('Eigenvalues and Eigenvectors');
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu1,nu2));
disp(sprintf('omega11    :   %5.6f  omega12    : %5.6f',omega11,omega12));
disp(sprintf('omega21    :   %5.6f  omega22    : %5.6f',omega21,omega22));
disp(sprintf('N1         :   %5.6f    H1       : %5.6f',N1,H1));
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));

disp(' ');
disp('Steady State Equilibrium ratios (exomark)');
disp(sprintf('YH / Y    :  %5.3f      PN*YN / Y  : %5.3f',omegaYH,omegaYN));
disp(sprintf('LH / L    :  %5.3f      LN / L    : %5.3f',omegaLH,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('PN*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GH / YH     :  %5.3f  GN / YN    :  %5.3f  (PN*GN)/G  : %5.3f',omegaGHYH,omegaGNYN,omegaGN));
disp(sprintf('(PH*GH)/GT  :  %5.3f  GF / G     :  %5.3f  GT/G       : %5.3f',omegaGH,omegaGF,omegaGT));
disp(sprintf('IN / YN     :  %5.3f  IH / YH    :  %5.3f  (r*B)/Y    : %5.3f',omegaINYN,omegaIHYH,omegaB));
disp(sprintf('IF / YH     :  %5.3f  GF / YH    :  %5.3f',omegaIFYH,omegaGFYH));
disp(sprintf('WN*LN/W*L   :  %5.3f RN*KN/R*K   :  %5.3f',alphaL,alphaK));
disp(sprintf('PIT*IT/PI*I :  %5.3f PT*CT/PC*C  :  %5.3f',alphaI,alphaC));
disp(sprintf('PH*IH/PT*IT :  %5.3f PH*CH/PT*CT :  %5.3f',alphaIH,alphaH));
disp(sprintf('PH*IH/PI*I  :  %5.3f PH*CH/PC*C  :  %5.3f',omegaIH,omegaCH));
disp(sprintf('IF/PI*I     :  %5.3f    CF/PC*C  :  %5.3f',omegaIF,omegaCF));
disp(sprintf('PH*XH/Y  :  %5.3f       XH / YH  :  %5.3f',omegaXHY,omegaXHYH));
disp(sprintf('W*L/Y       :  %5.3f R*K/Y       :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y         :  %5.3f',omegaKY));

disp(' ');
disp(sprintf('Marginal product of KH = RT       : %9.16f   ',cond1));
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));
disp(sprintf('Marginal product of LH = WH       : %9.16f   ',cond3));
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));
disp(sprintf('Resource contraint for capital    : %9.16f   ',cond5));
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));
disp(sprintf('Market clearing condition good H  : %9.16f   ',cond8));
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));
disp(sprintf('Relative labor  LH/LN             : %9.16f   ',cond12));
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));
disp(sprintf('FOC -V_L*(dL/dLH) = lambda*WH     : %9.16f   ',cond16));
disp(sprintf('FOC -V_L*(dL/dLN) = lambda*WN     : %9.16f   ',cond17));
disp(sprintf('Global market clearing condition  : %9.16f   ',cond18));
disp(sprintf('Private Savings                   : %9.16f   ',cond19));
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond20));
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond21));
disp(sprintf('Investment expenditure check      : %9.16f   ',cond22));
disp(sprintf('Capital income R*K                : %9.16f   ',cond23));
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond24));
disp(sprintf('relative consumption  CH/CF       : %9.16f   ',cond25));
disp(sprintf('Consumption expenditure in T PT*CT: %9.16f   ',cond26));
disp(sprintf('relative investment   IH/IF       : %9.16f   ',cond27));
disp(sprintf('Investment expenditure in T PIT*JT: %9.16f   ',cond28));
disp(sprintf('Current account                   : %9.16f   ',cond29));
disp(sprintf('Current account                   : %9.16f   ',cond30));

kH_0 = kH;  kN_0 = kN; PN_0 = PN; LH_0 = LH; K_0 = K; C_0 = C;  
LN_0  = LN; L_0 = L; W_0 = W; P_0 = P; 
YH_0  = YH; YN_0  = YN; Y_0  = Y; YR_0 = Y_0; KH_0  = KH; KN_0  = KN; G_0 = G;     
PC_0 = PC; alphaC_0 = alphaC; CN_0 = CN; CH_0 = CH;  
ZH_0 = ZH; ZN_0 = ZN; 
AH_0 = AH; BH_0 = BH; AN_0 = AN; BN_0 = BN; Z_0 = Z; GH_0 = GH; GN_0 = GN; 
LH_0 = LH; LN_0 = LN; KH_0 = KH; KN_0 = KN; WH_0 = WH; WN_0 = WN; 
Omega_0 = Omega; YHYN_0 = YHYN; LHLN_0 = LHLN;
IF_0 = IF; CF_0 = CF; XH_0 = XH; MF_0 = MF; GF_0 = GF; PH_0 = PH; 
PT_0 = PT; PIT_0 = PIT; CT_0 = CT; IT_0 = IT; GT_0 = GT; 

CA_0 = CA; Sav_0 = Sav; NX_0 = NX; I_0 = I; lambda_0  = lambda; A_0 = A; 
B_0 = B; IN_0 = IN; IH_0 = IH; PI_0 = PI; alphaI_0 = alphaI; EI_0 = EI; 
WPC_0 = WPC; WHPC_0 = WHPC; WNPC_0 = WNPC; alphaL_0 = alphaL; RK_0 = RK; 
yH_0 = yH; yN_0 = yN; 

omegaL_0 = omegaL; omegaK_0 = omegaK; omegaI_0 = omegaI; omegaINYN_0 = omegaINYN;
omegaIHYH_0 = omegaIHYH; omega_IFYH_0 = omegaIFYH; omegaGHYH_0 = omegaGHYH; 
omegaGFYH_0 = omegaGFYH; omegaGNYN_0 = omegaGNYN; omegaGN_0 = omegaGN;
omegaYH_0 = omegaYH; omegaYN_0 = omegaYN; omegaLH_0 = omegaLH; omegaLN_0 = omegaLN; 
omegaC_0 =omegaC; omegaNX_0 =omegaNX; omegaG_0 =omegaG; omegaB_0 =omegaB; 
omegaIFYH_0 = omegaIFYH; omegaGFYH_0 = omegaGFYH; omegaIH_0 = omegaIH; 
omegaCH_0 = omegaCH; omegaIF_0 = omegaIF; omegaCF_0 = omegaCF; 
omegaGT_0 = omegaGT; omegaGH_0 = omegaGH; omegaGF_0 = omegaGF; 
omegaKY_0 = omegaKY; omegaIH_0 = omegaIH; omegaIF_0 = omegaIF;
omegaXHY_0 = omegaXHY; omegaXHYH_0 = omegaXHYH; 
alphaL_0 = alphaL; alphaK_0 = alphaK; alphaC_0 = alphaC; 
alphaI_0 = alphaI; alphaH_0 = alphaH; alphaIH_0 = alphaIH; 
sLH_0 = sLH; sLN_0 = sLN; sigmaH_0 = sigmaH; sigmaN_0 = sigmaN;  
TFPH_0 = TFPH; TFPN_0 = TFPN; TFP_0 = TFP; sL_0 = sL; k_0 = k;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  Temporary Fiscal Shock                          %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
B0       = B_0;
K0       = K_0; 
GH       = GH_0; 
GN       = GN_0; 
GF       = GF_0; 
AH       = AH_0; 
BH       = BH_0; 
AN       = AN_0;
BN       = BN_0;   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Endogenous response of G, Aj, Bj to an exogenous government spending shock 
barg     = parameters(1,1);  
baraH    = parameters(1,2);  
barbH    = parameters(1,3);  
baraN    = parameters(1,4);  
barbN    = parameters(1,5);  
xi       = parameters(2,1);  
chi      = parameters(3,1);  
xiAH     = parameters(2,2);  
chiAH    = parameters(3,2);  
xiBH     = parameters(2,3);  
chiBH    = parameters(3,3);  
xiAN     = parameters(2,4);  
chiAN    = parameters(3,4);  
xiBN     = parameters(2,5);  
chiBN    = parameters(3,5);  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                                                                                                                                                                                                     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x0 =[C_0 L_0 kH_0 WH_0 WN_0 W_0 kN_0 PN_0 K_0 PH_0 B_0 alphaL_0 PC_0 PT_0 CN_0 CH_0 CF_0 PI_0 PIT_0 IN_0 IH_0 IF_0 LH_0 LN_0 yH_0 YH_0 yN_0 YN_0 XH_0 MF_0 lambda_0];
[x,fval,exitflag]=fsolve('IML_CAC_TOT_CES_temp',x0,optimset('display','off','TolFun',1e-011));
C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kH      = x(3)  ; % Capital-labor ratio in sector H
WH      = x(4)  ; % Wage rate in sector H
WN      = x(5)  ; % Wage rate in sector N
W       = x(6)  ; % Aggregate wage index
kN      = x(7)  ; % Capital-labor ratio in sector N
PN      = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
PH      = x(10) ; % Terms of trade : PH/PF with PF = numeraire
B       = x(11) ; % Stock of Traded Bonds
alphaL  = x(12) ; % Output per worker in sector H
PC      = x(13) ; % Aggregate consumption price index
PT      = x(14) ; % Consumption price index for tradables
CN      = x(15) ; % Consumption in non tradables 
CH      = x(16) ; % Consumption in tradables 
CF      = x(17) ; % Consumption goods imports
PI      = x(18) ; % Aggregate investment price index
PIT     = x(19) ; % Investment price index for tradables
IN      = x(20) ; % Non tradable investment
IH      = x(21) ; % Investment in home goods
IF      = x(22) ; % Investment in foreign goods
LH      = x(23) ; % Labor in sector H
LN      = x(24) ; % Labor in sector N 
yH      = x(25) ; % Output of home traded goods per worker
YH      = x(26) ; % Output of home traded goods
yN      = x(27) ; % Output of non traded goods per worker
YN      = x(28) ; % Output of non traded goods
XH      = x(29) ; % Exports of home traded goods
MF      = x(30) ; % Imports of foreign goods
lambda  = x(31) ; % Marginal utility of wealth lambda

% Shares
I       = deltaK*K;
alphaC  = varphi*(PT/PC)^(1-phi);
alphaH  = varphiH*(PH/PT)^(1-rho);
alphaI  = iota*(PIT/PI)^(1-phiI);
alphaIH = iotaH*(PH/PIT)^(1-rhoI);

% Technology
ZH = ((AH)^(sLH_0))*((BH)^(1-sLH_0)); 
ZN = ((AN)^(sLN_0))*((BN)^(1-sLN_0)); 
Z  = (ZH^omegaYH_0)*(ZN^(1-omegaYH_0));

% Nominal and Real GDP
Y  = (PH*YH) +(PN*YN);
YR = (PH_0*YH) + (PN_0*YN); 

% VA shares in real terms
omegaYHR = (PH_0*YH)/YR; 
omegaYNR = (PN_0*YN)/YR; 

% TFP
TFPH = YH/(gammaH*(LH^((sigmaH-1)/sigmaH)) + (1-gammaH)*(KH^((sigmaH-1)/sigmaH)) )^(sigmaH/(sigmaH-1)); 
TFPN = YN/(gammaN*(LN^((sigmaN-1)/sigmaN)) + (1-gammaN)*(KN^((sigmaN-1)/sigmaN)) )^(sigmaN/(sigmaN-1)); 
TFP  = (TFPH^omegaYH)*(TFPN^(1-omegaYH));

% Capital rental rates
RKH = PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((YH/KH)^(1/sigmaH)); 
RKN = PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((YN/KN)^(1/sigmaN)); 

% Sectoral outputs and sectoral profits   
KH  = LH*kH;  
RK  = PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((YH/KH)^(1/sigmaH)); 
PiH = (PH*YH) - (RK*KH) - (WH*LH);
  
KN  = LN*kN;   
PiN = (PN*YN) - (RK*KN) - (WN*LN);

% Labor income share in the home traded good and non traded good sector
sLH = gammaH*(AH/yH)^((sigmaH-1)/sigmaH);
sLN = gammaN*(AN/yN)^((sigmaN-1)/sigmaN); 
sL  = W*L/Y; 
k   = K/L; 

% LHj = partial Lj/partial Wj: Lj=Lj(WH,WN,uZH,uZN)
LH_WH   = (LH/WH)*( epsilon*(1-alphaL) + (sigmaL*alphaL) );
LH_1uZH = LH*( epsilon*(1-alphaL) + (sigmaL*alphaL) );
LH_WN   = (LH/WN)*(1-alphaL)*(sigmaL-epsilon); 
LH_1uZN = LH*(1-alphaL)*(sigmaL-epsilon); 
LN_WH   = (LN/WH)*alphaL*(sigmaL-epsilon); 
LN_1uZH = LN*alphaL*(sigmaL-epsilon);
LN_WN   = (LN/WN)*( (epsilon*alphaL) + sigmaL*(1-alphaL) );  
LN_1uZN = LN*( (epsilon*alphaL) + sigmaL*(1-alphaL) ); 
LH_1lamb = sigmaL*LH/lambda; 
LN_1lamb = sigmaL*LN/lambda;

% Solving for kH, kN, WH, WN as functions of (PH, PN, K, uKH, uKN, uZH, uZN,
% AH, BH, AN, BN)
Psi_WH   = ( (kH*LH_WH) + (kN*LN_WH) );
Psi_WN   = ( (kH*LH_WN) + (kN*LN_WN) );
Psi_uZH  = ((kH*LH_1uZH) + (kN*LN_1uZH)); 
Psi_uZN  = ((kH*LH_1uZN) + (kN*LN_1uZN)); 

d11 = -(1/sigmaH)*(sLH/kH); 
d12 = (1/sigmaN)*(sLN/kN);
d13 = 0;
d14 = 0;
d21 = (1/sigmaH)*((1-sLH)/kH); 
d22 = 0;  
d23 = -(1/WH); 
d24 = 0; 
d31 = 0; 
d32 = (1/sigmaN)*((1-sLN)/kN);
d33 = 0; 
d34 = -(1/WN);
d41 = LH; 
d42 = LN; 
d43 = Psi_WH; 
d44 = Psi_WN; 

% PN, PH, K, uKH, uKN, uZH, uZN, AH, BH, AN, BN, lambda
e11  = (1/PN); 
e12  = -(1/PH);
e13  = 0;
e14  = (sLH/sigmaH); 
e15  = -(sLN/sigmaN); 
e16  = 0;
e17  = 0;
e18  = -(1/sigmaH)*(sLH/AH); 
e19  = -(1/sigmaH)*((sigmaH-sLH)/BH);
e110 = (1/sigmaN)*(sLN/AN); 
e111 = (1/sigmaN)*((sigmaN-sLN)/BN);

e21  = 0; 
e22  = -(1/PH); 
e23  = 0;
e24  = -((1-sLH)/sigmaH);
e25  = 0;
e26  = 0;
e27  = 0;
e28 = -(1/sigmaH)*(((sigmaH-1)+sLH)/AH); 
e29 = -(1/sigmaH)*((1-sLH)/BH); 
e210 = 0;
e211 = 0; 

e31  = -(1/PN); 
e32  = 0; 
e33  = 0;
e34  = 0;
e35  = -((1-sLN)/sigmaN);
e36  = 0;
e37  = 0;
e38  = 0; 
e39  = 0; 
e310 = -(1/sigmaN)*(((sigmaN-1)+sLN)/AN); 
e311 = -(1/sigmaN)*((1-sLN)/BN); 

e41  = 0; 
e42  = 0; 
e43  = 1;
e44  = 0; 
e45  = 0;
e46  = -Psi_uZH; 
e47  = -Psi_uZN;
e48  = 0; 
e49  = 0;
e410 = 0;
e411 = 0; 
    
M1 = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X1 = [e11 e12 e13 e14 e15 e16 e17 e18 e19 e110 e111; e21 e22 e23 e24 e25 e26 e27 e28 e29 e210 e211; e31 e32 e33 e34 e35 e36 e37 e38 e39 e310 e311; e41 e42 e43 e44 e45 e46 e47 e48 e49 e410 e411];
JST1 = inv(M1);
MST1 = JST1*X1;
kH_1PN = MST1(1,1); kH_1PH = MST1(1,2); kH_1K = MST1(1,3); kH_uKH = MST1(1,4); kH_uKN = MST1(1,5); kH_uZH = MST1(1,6); kH_uZN = MST1(1,7); kH_1AH = MST1(1,8); kH_1BH = MST1(1,9); kH_1AN = MST1(1,10); kH_1BN = MST1(1,11); 
kN_1PN = MST1(2,1); kN_1PH = MST1(2,2); kN_1K = MST1(2,3); kN_uKH = MST1(2,4); kN_uKN = MST1(2,5); kN_uZH = MST1(2,6); kN_uZN = MST1(2,7); kN_1AH = MST1(2,8); kN_1BH = MST1(2,9); kN_1AN = MST1(2,10); kN_1BN = MST1(2,11); 
WH_1PN = MST1(3,1); WH_1PH = MST1(3,2); WH_1K = MST1(3,3); WH_uKH = MST1(3,4); WH_uKN = MST1(3,5); WH_uZH = MST1(3,6); WH_uZN = MST1(3,7); WH_1AH = MST1(3,8); WH_1BH = MST1(3,9); WH_1AN = MST1(3,10); WH_1BN = MST1(3,11); 
WN_1PN = MST1(4,1); WN_1PH = MST1(4,2); WN_1K = MST1(4,3); WN_uKH = MST1(4,4); WN_uKN = MST1(4,5); WN_uZH = MST1(4,6); WN_uZN = MST1(4,7); WN_1AH = MST1(4,8); WN_1BH = MST1(4,9); WN_1AN = MST1(4,10); WN_1BN = MST1(4,11); 
    
% Solving for sectoral labor and sectoral output - Lj,yj,Yj,Kj(PN,PH,K,uKj,uZj)
LH_1PN = (LH_WH*WH_1PN) + (LH_WN*WN_1PN);
LH_1PH = (LH_WH*WH_1PH) + (LH_WN*WN_1PH);
LH_1K  = (LH_WH*WH_1K)  + (LH_WN*WN_1K);
LH_uKH = (LH_WH*WH_uKH) + (LH_WN*WN_uKH);
LH_uKN = (LH_WH*WH_uKN) + (LH_WN*WN_uKN);
LH_uZH = LH_1uZH + (LH_WH*WH_uZH) + (LH_WN*WN_uZH);
LH_uZN = LH_1uZN + (LH_WH*WH_uZN) + (LH_WN*WN_uZN);
LH_1AH = (LH_WH*WH_1AH) + (LH_WN*WN_1AH);
LH_1BH = (LH_WH*WH_1BH) + (LH_WN*WN_1BH);
LH_1AN = (LH_WH*WH_1AN) + (LH_WN*WN_1AN);
LH_1BN = (LH_WH*WH_1BN) + (LH_WN*WN_1BN);

LN_1PN = (LN_WH*WH_1PN) + (LN_WN*WN_1PN);
LN_1PH = (LN_WH*WH_1PH) + (LN_WN*WN_1PH);
LN_1K  = (LN_WH*WH_1K)  + (LN_WN*WN_1K);
LN_uKH = (LN_WH*WH_uKH) + (LN_WN*WN_uKH);
LN_uKN = (LN_WH*WH_uKN) + (LN_WN*WN_uKN);
LN_uZH = LN_1uZH + (LN_WH*WH_uZH) + (LN_WN*WN_uZH);
LN_uZN = LN_1uZN + (LN_WH*WH_uZN) + (LN_WN*WN_uZN);
LN_1AH = (LN_WH*WH_1AH) + (LN_WN*WN_1AH);
LN_1BH = (LN_WH*WH_1BH) + (LN_WN*WN_1BH);
LN_1AN = (LN_WH*WH_1AN) + (LN_WN*WN_1AN);
LN_1BN = (LN_WH*WH_1BN) + (LN_WN*WN_1BN);

yH_1PN = (yH/kH)*(1-sLH)*kH_1PN;
yH_1PH = (yH/kH)*(1-sLH)*kH_1PH;
yH_1K  = (yH/kH)*(1-sLH)*kH_1K;
yH_uKH = yH*(1-sLH) + (yH/kH)*(1-sLH)*kH_uKH;
yH_uKN = (yH/kH)*(1-sLH)*kH_uKN;
yH_uZH = (yH/kH)*(1-sLH)*kH_uZH;
yH_uZN = (yH/kH)*(1-sLH)*kH_uZN;
yH_1AH = (yH/AH)*sLH + (yH/kH)*(1-sLH)*kH_1AH; 
yH_1BH =  yH*(1-sLH)*( (1/BH) + (kH_1BH/kH) );  
yH_1AN =  (yH/kH)*(1-sLH)*kH_1AN;
yH_1BN =  (yH/kH)*(1-sLH)*kH_1BN;

yN_1PN = (yN/kN)*(1-sLN)*kN_1PN;
yN_1PH = (yN/kN)*(1-sLN)*kN_1PH;
yN_1K  = (yN/kN)*(1-sLN)*kN_1K;
yN_uKH = (yN/kN)*(1-sLN)*kN_uKH;
yN_uKN = yN*(1-sLN) + (yN/kN)*(1-sLN)*kN_uKN;
yN_uZH = (yN/kN)*(1-sLN)*kN_uZH;
yN_uZN = (yN/kN)*(1-sLN)*kN_uZN;
yN_1AH = (yN/kN)*(1-sLN)*kN_1AH;
yN_1BH = (yN/kN)*(1-sLN)*kN_1BH;
yN_1AN = (yN/AN)*sLN + (yN/kN)*(1-sLN)*kN_1AN;
yN_1BN =  yN*(1-sLN)*( (1/BN) + (kN_1BN/kN) ); 

YH_1PN = (LH*yH_1PN) + (yH*LH_1PN);
YH_1PH = (LH*yH_1PH) + (yH*LH_1PH);
YH_1K  = (LH*yH_1K) + (yH*LH_1K);
YH_uKH = (LH*yH_uKH) + (yH*LH_uKH);
YH_uKN = (LH*yH_uKN) + (yH*LH_uKN);
YH_uZH = (LH*yH_uZH) + (yH*LH_uZH);
YH_uZN = (LH*yH_uZN) + (yH*LH_uZN);
YH_1AH = (LH*yH_1AH) + (yH*LH_1AH);
YH_1BH = (LH*yH_1BH) + (yH*LH_1BH);
YH_1AN = (LH*yH_1AN) + (yH*LH_1AN);
YH_1BN = (LH*yH_1BN) + (yH*LH_1BN);

YN_1PN = (LN*yN_1PN) + (yN*LN_1PN);
YN_1PH = (LN*yN_1PH) + (yN*LN_1PH);
YN_1K  = (LN*yN_1K) + (yN*LN_1K);
YN_uKH = (LN*yN_uKH) + (yN*LN_uKH);
YN_uKN = (LN*yN_uKN) + (yN*LN_uKN);
YN_uZH = (LN*yN_uZH) + (yN*LN_uZH);
YN_uZN = (LN*yN_uZN) + (yN*LN_uZN);
YN_1AH = (LN*yN_1AH) + (yN*LN_1AH);
YN_1BH = (LN*yN_1BH) + (yN*LN_1BH);
YN_1AN = (LN*yN_1AN) + (yN*LN_1AN);
YN_1BN = (LN*yN_1BN) + (yN*LN_1BN);

KH_1PN = (LH*kH_1PN) + (kH*LH_1PN);
KH_1PH = (LH*kH_1PH) + (kH*LH_1PH);
KH_1K  = (LH*kH_1K) + (kH*LH_1K);
KH_uKH = (LH*kH_uKH) + (kH*LH_uKH);
KH_uKN = (LH*kH_uKN) + (kH*LH_uKN);
KH_uZH = (LH*kH_uZH) + (kH*LH_uZH);
KH_uZN = (LH*kH_uZN) + (kH*LH_uZN);
KH_1AH = (LH*kH_1AH) + (kH*LH_1AH);             
KH_1BH = (LH*kH_1BH) + (kH*LH_1BH);             
KH_1AN = (LH*kH_1AN) + (kH*LH_1AN);             
KH_1BN = (LH*kH_1BN) + (kH*LH_1BN);              

KN_1PN = (LN*kN_1PN) + (kN*LN_1PN);
KN_1PH = (LN*kN_1PH) + (kN*LN_1PH);
KN_1K  = (LN*kN_1K) + (kN*LN_1K);
KN_uKH = (LN*kN_uKH) + (kN*LN_uKH);
KN_uKN = (LN*kN_uKN) + (kN*LN_uKN);
KN_uZH = (LN*kN_uZH) + (kN*LN_uZH);
KN_uZN = (LN*kN_uZN) + (kN*LN_uZN);
KN_1AH = (LN*kN_1AH) + (kN*LN_1AH);                   
KN_1BH = (LN*kN_1BH) + (kN*LN_1BH);                   
KN_1AN = (LN*kN_1AN) + (kN*LN_1AN);                   
KN_1BN = (LN*kN_1BN) + (kN*LN_1BN);   

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_K  = deltaK; 
J_Q  = K*v_1Q; 
J_PN = K*v_PN; 
J_PH = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q)
I      = deltaK*K; 
JN_PN  = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH  = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K  = (IN/I)*J_K; 
JN_1Q  = (IN/I)*J_Q; 

JH_PN  =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH  = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_K; 
JH_1Q  = (IH/I)*J_Q; 

JF_PN  = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH  = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_K; 
JF_1Q  = (IF/I)*J_Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH  = -(XH/PH)*nuX; 

% Solving for capital and technology utilization rates: uKH, uKN, uZH, uZN, uKj,uZj(PN,PH,K)
f11 = ((xi2H/xi1H) + (sLH/sigmaH)) + (sLH/sigmaH)*(kH_uKH/kH);
f12 = (sLH/sigmaH)*(kH_uKN/kH);
f13 = ((sLH/sigmaH)*(kH_uZH/kH)-1);
f14 = (sLH/sigmaH)*(kH_uZN/kH);
f21 = (sLN/sigmaN)*(kN_uKH/kN);
f22 = ((xi2N/xi1N) + (sLN/sigmaN)) + (sLN/sigmaN)*(kN_uKN/kN);
f23 = (sLN/sigmaN)*(kN_uZH/kN);
f24 = ((sLN/sigmaN)*(kN_uZN/kN)-1);
f31 = -(YH_uKH/YH);
f32 = -(YH_uKN/YH);
f33 = ((chi2H/chi1H)-(YH_uZH/YH));
f34 = -(YH_uZN/YH);
f41 = -(YN_uKH/YN);
f42 = -(YN_uKN/YN);
f43 = -(YN_uZH/YN);
f44 = ((chi2N/chi1N)-(YN_uZN/YN));

% PN, PH, K, AH, BH, AN, BN
g11 = -(sLH/sigmaH)*(kH_1PN/kH);
g12 = -(sLH/sigmaH)*(kH_1PH/kH);
g13 = -(sLH/sigmaH)*(kH_1K/kH);
g14 = (sLH/sigmaH)*( (1/AH) - (kH_1AH/kH) ); 
g15 = (1/sigmaH)*( ((sigmaH-sLH)/BH) - sLH*(kH_1BH/kH) );
g16 = -(sLH/sigmaH)*(kH_1AN/kH);
g17 = -(sLH/sigmaH)*(kH_1BN/kH);

g21 = -(sLN/sigmaN)*(kN_1PN/kN);
g22 = -(sLN/sigmaN)*(kN_1PH/kN);
g23 = -(sLN/sigmaN)*(kN_1K/kN);
g24 = -(sLN/sigmaN)*(kN_1AH/kN);
g25 = -(sLN/sigmaN)*(kN_1BH/kN);
g26 = (sLN/sigmaN)*( (1/AN) - (kN_1AN/kN) ); 
g27 = (1/sigmaN)*( ((sigmaN-sLN)/BN) - sLN*(kN_1BN/kN) );

g31 = (YH_1PN/YH);
g32 = (YH_1PH/YH);
g33 = (YH_1K/YH);
g34 = (YH_1AH/YH);
g35 = (YH_1BH/YH);
g36 = (YH_1AN/YH);
g37 = (YH_1BN/YH);

g41 = (YN_1PN/YN);
g42 = (YN_1PH/YN);
g43 = (YN_1K/YN);
g44 = (YN_1AH/YN);
g45 = (YN_1BH/YN);
g46 = (YN_1AN/YN);
g47 = (YN_1BN/YN);

M2 = [f11 f12 f13 f14; f21 f22 f23 f24; f31 f32 f33 f34; f41 f42 f43 f44];
X2 = [g11 g12 g13 g14 g15 g16 g17; g21 g22 g23 g24 g25 g26 g27; g31 g32 g33 g34 g35 g36 g37; g41 g42 g43 g44 g45 g46 g47];
JST2 = inv(M2);
MST2 = JST2*X2;
uKH_PN = MST2(1,1); uKH_PH = MST2(1,2); uKH_1K = MST2(1,3); uKH_1AH = MST2(1,4); uKH_1BH = MST2(1,5); uKH_1AN = MST2(1,6); uKH_1BN = MST2(1,7); 
uKN_PN = MST2(2,1); uKN_PH = MST2(2,2); uKN_1K = MST2(2,3); uKN_1AH = MST2(2,4); uKN_1BH = MST2(2,5); uKN_1AN = MST2(2,6); uKN_1BN = MST2(2,7); 
uZH_PN = MST2(3,1); uZH_PH = MST2(3,2); uZH_1K = MST2(3,3); uZH_1AH = MST2(3,4); uZH_1BH = MST2(3,5); uZH_1AN = MST2(3,6); uZH_1BN = MST2(3,7); 
uZN_PN = MST2(4,1); uZN_PH = MST2(4,2); uZN_1K = MST2(4,3); uZN_1AH = MST2(4,4); uZN_1BH = MST2(4,5); uZN_1AN = MST2(4,6); uZN_1BN = MST2(4,7);  

% Solving for sectoral labor and sectoral output - kj,Wj,Lj,yj,Yj,Kj(lambda,K,PH,PN,AH,BH,AN,BN) 
kH_2K  = kH_1K + (kH_uKH*uKH_1K) + (kH_uKN*uKN_1K) + (kH_uZH*uZH_1K) + (kH_uZN*uZN_1K); 
kH_PH  = kH_1PH + (kH_uKH*uKH_PH) + (kH_uKN*uKN_PH) + (kH_uZH*uZH_PH) + (kH_uZN*uZN_PH);
kH_PN  = kH_1PN + (kH_uKH*uKH_PN) + (kH_uKN*uKN_PN) + (kH_uZH*uZH_PN) + (kH_uZN*uZN_PN);
kH_2AH = kH_1AH + (kH_uKH*uKH_1AH) + (kH_uKN*uKN_1AH) + (kH_uZH*uZH_1AH) + (kH_uZN*uZN_1AH); 
kH_2BH = kH_1BH + (kH_uKH*uKH_1BH) + (kH_uKN*uKN_1BH) + (kH_uZH*uZH_1BH) + (kH_uZN*uZN_1BH); 
kH_2AN = kH_1AN + (kH_uKH*uKH_1AN) + (kH_uKN*uKN_1AN) + (kH_uZH*uZH_1AN) + (kH_uZN*uZN_1AN); 
kH_2BN = kH_1BN + (kH_uKH*uKH_1BN) + (kH_uKN*uKN_1BN) + (kH_uZH*uZH_1BN) + (kH_uZN*uZN_1BN); 

kN_2K  = kN_1K + (kN_uKH*uKH_1K) + (kN_uKN*uKN_1K) + (kN_uZH*uZH_1K) + (kN_uZN*uZN_1K);     
kN_PH  = kN_1PH + (kN_uKH*uKH_PH) + (kN_uKN*uKN_PH) + (kN_uZH*uZH_PH) + (kN_uZN*uZN_PH);
kN_PN  = kN_1PN + (kN_uKH*uKH_PN) + (kN_uKN*uKN_PN) + (kN_uZH*uZH_PN) + (kN_uZN*uZN_PN);
kN_2AH = kN_1AH + (kN_uKH*uKH_1AH) + (kN_uKN*uKN_1AH) + (kN_uZH*uZH_1AH) + (kN_uZN*uZN_1AH); 
kN_2BH = kN_1BH + (kN_uKH*uKH_1BH) + (kN_uKN*uKN_1BH) + (kN_uZH*uZH_1BH) + (kN_uZN*uZN_1BH); 
kN_2AN = kN_1AN + (kN_uKH*uKH_1AN) + (kN_uKN*uKN_1AN) + (kN_uZH*uZH_1AN) + (kN_uZN*uZN_1AN); 
kN_2BN = kN_1BN + (kN_uKH*uKH_1BN) + (kN_uKN*uKN_1BN) + (kN_uZH*uZH_1BN) + (kN_uZN*uZN_1BN); 

WH_2K  = WH_1K + (WH_uKH*uKH_1K) + (WH_uKN*uKN_1K) + (WH_uZH*uZH_1K) + (WH_uZN*uZN_1K);  
WH_PH  = WH_1PH + (WH_uKH*uKH_PH) + (WH_uKN*uKN_PH) + (WH_uZH*uZH_PH) + (WH_uZN*uZN_PH); 
WH_PN  = WH_1PN + (WH_uKH*uKH_PN) + (WH_uKN*uKN_PN) + (WH_uZH*uZH_PN) + (WH_uZN*uZN_PN);
WH_2AH = WH_1AH + (WH_uKH*uKH_1AH) + (WH_uKN*uKN_1AH) + (WH_uZH*uZH_1AH) + (WH_uZN*uZN_1AH);
WH_2BH = WH_1BH + (WH_uKH*uKH_1BH) + (WH_uKN*uKN_1BH) + (WH_uZH*uZH_1BH) + (WH_uZN*uZN_1BH);
WH_2AN = WH_1AN + (WH_uKH*uKH_1AN) + (WH_uKN*uKN_1AN) + (WH_uZH*uZH_1AN) + (WH_uZN*uZN_1AN);
WH_2BN = WH_1BN + (WH_uKH*uKH_1BN) + (WH_uKN*uKN_1BN) + (WH_uZH*uZH_1BN) + (WH_uZN*uZN_1BN);

WN_2K = WN_1K + (WN_uKH*uKH_1K) + (WN_uKN*uKN_1K) + (WN_uZH*uZH_1K) + (WN_uZN*uZN_1K);  
WN_PH = WN_1PH + (WN_uKH*uKH_PH) + (WN_uKN*uKN_PH) + (WN_uZH*uZH_PH) + (WN_uZN*uZN_PH); 
WN_PN = WN_1PN + (WN_uKH*uKH_PN) + (WN_uKN*uKN_PN) + (WN_uZH*uZH_PN) + (WN_uZN*uZN_PN);
WN_2AH = WN_1AH + (WN_uKH*uKH_1AH) + (WN_uKN*uKN_1AH) + (WN_uZH*uZH_1AH) + (WN_uZN*uZN_1AH);                          
WN_2BH = WN_1BH + (WN_uKH*uKH_1BH) + (WN_uKN*uKN_1BH) + (WN_uZH*uZH_1BH) + (WN_uZN*uZN_1BH);                          
WN_2AN = WN_1AN + (WN_uKH*uKH_1AN) + (WN_uKN*uKN_1AN) + (WN_uZH*uZH_1AN) + (WN_uZN*uZN_1AN);                          
WN_2BN = WN_1BN + (WN_uKH*uKH_1BN) + (WN_uKN*uKN_1BN) + (WN_uZH*uZH_1BN) + (WN_uZN*uZN_1BN);                           

LH_2K = LH_1K + (LH_uKH*uKH_1K) + (LH_uKN*uKN_1K) + (LH_uZH*uZH_1K) + (LH_uZN*uZN_1K);  
LH_PH = LH_1PH + (LH_uKH*uKH_PH) + (LH_uKN*uKN_PH) + (LH_uZH*uZH_PH) + (LH_uZN*uZN_PH); 
LH_PN = LH_1PN + (LH_uKH*uKH_PN) + (LH_uKN*uKN_PN) + (LH_uZH*uZH_PN) + (LH_uZN*uZN_PN);   
LH_2AH = LH_1AH + (LH_uKH*uKH_1AH) + (LH_uKN*uKN_1AH) + (LH_uZH*uZH_1AH) + (LH_uZN*uZN_1AH);                          
LH_2BH = LH_1BH + (LH_uKH*uKH_1BH) + (LH_uKN*uKN_1BH) + (LH_uZH*uZH_1BH) + (LH_uZN*uZN_1BH);                          
LH_2AN = LH_1AN + (LH_uKH*uKH_1AN) + (LH_uKN*uKN_1AN) + (LH_uZH*uZH_1AN) + (LH_uZN*uZN_1AN);                          
LH_2BN = LH_1BN + (LH_uKH*uKH_1BN) + (LH_uKN*uKN_1BN) + (LH_uZH*uZH_1BN) + (LH_uZN*uZN_1BN);                           

LN_2K = LN_1K + (LN_uKH*uKH_1K) + (LN_uKN*uKN_1K) + (LN_uZH*uZH_1K) + (LN_uZN*uZN_1K);  
LN_PH = LN_1PH + (LN_uKH*uKH_PH) + (LN_uKN*uKN_PH) + (LN_uZH*uZH_PH) + (LN_uZN*uZN_PH); 
LN_PN = LN_1PN + (LN_uKH*uKH_PN) + (LN_uKN*uKN_PN) + (LN_uZH*uZH_PN) + (LN_uZN*uZN_PN);
LN_2AH = LN_1AH + (LN_uKH*uKH_1AH) + (LN_uKN*uKN_1AH) + (LN_uZH*uZH_1AH) + (LN_uZN*uZN_1AH);                         
LN_2BH = LN_1BH + (LN_uKH*uKH_1BH) + (LN_uKN*uKN_1BH) + (LN_uZH*uZH_1BH) + (LN_uZN*uZN_1BH);                         
LN_2AN = LN_1AN + (LN_uKH*uKH_1AN) + (LN_uKN*uKN_1AN) + (LN_uZH*uZH_1AN) + (LN_uZN*uZN_1AN);                         
LN_2BN = LN_1BN + (LN_uKH*uKH_1BN) + (LN_uKN*uKN_1BN) + (LN_uZH*uZH_1BN) + (LN_uZN*uZN_1BN);   

yH_2K = yH_1K + (yH_uKH*uKH_1K) + (yH_uKN*uKN_1K) + (yH_uZH*uZH_1K) + (yH_uZN*uZN_1K);             
yH_PH = yH_1PH + (yH_uKH*uKH_PH) + (yH_uKN*uKN_PH) + (yH_uZH*uZH_PH) + (yH_uZN*uZN_PH);            
yH_PN = yH_1PN + (yH_uKH*uKH_PN) + (yH_uKN*uKN_PN) + (yH_uZH*uZH_PN) + (yH_uZN*uZN_PN);            
yH_2AH = yH_1AH + (yH_uKH*uKH_1AH) + (yH_uKN*uKN_1AH) + (yH_uZH*uZH_1AH) + (yH_uZN*uZN_1AH);       
yH_2BH = yH_1BH + (yH_uKH*uKH_1BH) + (yH_uKN*uKN_1BH) + (yH_uZH*uZH_1BH) + (yH_uZN*uZN_1BH);       
yH_2AN = yH_1AN + (yH_uKH*uKH_1AN) + (yH_uKN*uKN_1AN) + (yH_uZH*uZH_1AN) + (yH_uZN*uZN_1AN);       
yH_2BN = yH_1BN + (yH_uKH*uKH_1BN) + (yH_uKN*uKN_1BN) + (yH_uZH*uZH_1BN) + (yH_uZN*uZN_1BN);       
                                                                                                   
yN_2K = yN_1K + (yN_uKH*uKH_1K) + (yN_uKN*uKN_1K) + (yN_uZH*uZH_1K) + (yN_uZN*uZN_1K);             
yN_PH = yN_1PH + (yN_uKH*uKH_PH) + (yN_uKN*uKN_PH) + (yN_uZH*uZH_PH) + (yN_uZN*uZN_PH);            
yN_PN = yN_1PN + (yN_uKH*uKH_PN) + (yN_uKN*uKN_PN) + (yN_uZH*uZH_PN) + (yN_uZN*uZN_PN);            
yN_2AH = yN_1AH + (yN_uKH*uKH_1AH) + (yN_uKN*uKN_1AH) + (yN_uZH*uZH_1AH) + (yN_uZN*uZN_1AH);       
yN_2BH = yN_1BH + (yN_uKH*uKH_1BH) + (yN_uKN*uKN_1BH) + (yN_uZH*uZH_1BH) + (yN_uZN*uZN_1BH);       
yN_2AN = yN_1AN + (yN_uKH*uKH_1AN) + (yN_uKN*uKN_1AN) + (yN_uZH*uZH_1AN) + (yN_uZN*uZN_1AN);       
yN_2BN = yN_1BN + (yN_uKH*uKH_1BN) + (yN_uKN*uKN_1BN) + (yN_uZH*uZH_1BN) + (yN_uZN*uZN_1BN);       

YH_2K = YH_1K + (YH_uKH*uKH_1K) + (YH_uKN*uKN_1K) + (YH_uZH*uZH_1K) + (YH_uZN*uZN_1K);   
YH_PH = YH_1PH + (YH_uKH*uKH_PH) + (YH_uKN*uKN_PH) + (YH_uZH*uZH_PH) + (YH_uZN*uZN_PH);  
YH_PN = YH_1PN + (YH_uKH*uKH_PN) + (YH_uKN*uKN_PN) + (YH_uZH*uZH_PN) + (YH_uZN*uZN_PN); 
YH_2AH = YH_1AH + (YH_uKH*uKH_1AH) + (YH_uKN*uKN_1AH) + (YH_uZH*uZH_1AH) + (YH_uZN*uZN_1AH);                         
YH_2BH = YH_1BH + (YH_uKH*uKH_1BH) + (YH_uKN*uKN_1BH) + (YH_uZH*uZH_1BH) + (YH_uZN*uZN_1BH);                         
YH_2AN = YH_1AN + (YH_uKH*uKH_1AN) + (YH_uKN*uKN_1AN) + (YH_uZH*uZH_1AN) + (YH_uZN*uZN_1AN);                         
YH_2BN = YH_1BN + (YH_uKH*uKH_1BN) + (YH_uKN*uKN_1BN) + (YH_uZH*uZH_1BN) + (YH_uZN*uZN_1BN);                          

YN_2K = YN_1K + (YN_uKH*uKH_1K) + (YN_uKN*uKN_1K) + (YN_uZH*uZH_1K) + (YN_uZN*uZN_1K);   
YN_PH = YN_1PH + (YN_uKH*uKH_PH) + (YN_uKN*uKN_PH) + (YN_uZH*uZH_PH) + (YN_uZN*uZN_PH);  
YN_PN = YN_1PN + (YN_uKH*uKH_PN) + (YN_uKN*uKN_PN) + (YN_uZH*uZH_PN) + (YN_uZN*uZN_PN); 
YN_2AH = YN_1AH + (YN_uKH*uKH_1AH) + (YN_uKN*uKN_1AH) + (YN_uZH*uZH_1AH) + (YN_uZN*uZN_1AH);                        
YN_2BH = YN_1BH + (YN_uKH*uKH_1BH) + (YN_uKN*uKN_1BH) + (YN_uZH*uZH_1BH) + (YN_uZN*uZN_1BH);                        
YN_2AN = YN_1AN + (YN_uKH*uKH_1AN) + (YN_uKN*uKN_1AN) + (YN_uZH*uZH_1AN) + (YN_uZN*uZN_1AN);                        
YN_2BN = YN_1BN + (YN_uKH*uKH_1BN) + (YN_uKN*uKN_1BN) + (YN_uZH*uZH_1BN) + (YN_uZN*uZN_1BN);     

KH_2K = KH_1K + (KH_uKH*uKH_1K) + (KH_uKN*uKN_1K) + (KH_uZH*uZH_1K) + (KH_uZN*uZN_1K);  
KH_PH = KH_1PH + (KH_uKH*uKH_PH) + (KH_uKN*uKN_PH) + (KH_uZH*uZH_PH) + (KH_uZN*uZN_PH); 
KH_PN = KH_1PN + (KH_uKH*uKH_PN) + (KH_uKN*uKN_PN) + (KH_uZH*uZH_PN) + (KH_uZN*uZN_PN);   
KH_2AH = KH_1AH + (KH_uKH*uKH_1AH) + (KH_uKN*uKN_1AH) + (KH_uZH*uZH_1AH) + (KH_uZN*uZN_1AH);                        
KH_2BH = KH_1BH + (KH_uKH*uKH_1BH) + (KH_uKN*uKN_1BH) + (KH_uZH*uZH_1BH) + (KH_uZN*uZN_1BH);                        
KH_2AN = KH_1AN + (KH_uKH*uKH_1AN) + (KH_uKN*uKN_1AN) + (KH_uZH*uZH_1AN) + (KH_uZN*uZN_1AN);                        
KH_2BN = KH_1BN + (KH_uKH*uKH_1BN) + (KH_uKN*uKN_1BN) + (KH_uZH*uZH_1BN) + (KH_uZN*uZN_1BN);                        

KN_2K = KN_1K + (KN_uKH*uKH_1K) + (KN_uKN*uKN_1K) + (KN_uZH*uZH_1K) + (KN_uZN*uZN_1K);  
KN_PH = KN_1PH + (KN_uKH*uKH_PH) + (KN_uKN*uKN_PH) + (KN_uZH*uZH_PH) + (KN_uZN*uZN_PH); 
KN_PN = KN_1PN + (KN_uKH*uKH_PN) + (KN_uKN*uKN_PN) + (KN_uZH*uZH_PN) + (KN_uZN*uZN_PN); 
KN_2AH = KN_1AH + (KN_uKH*uKH_1AH) + (KN_uKN*uKN_1AH) + (KN_uZH*uZH_1AH) + (KN_uZN*uZN_1AH);                        
KN_2BH = KN_1BH + (KN_uKH*uKH_1BH) + (KN_uKN*uKN_1BH) + (KN_uZH*uZH_1BH) + (KN_uZN*uZN_1BH);                        
KN_2AN = KN_1AN + (KN_uKH*uKH_1AN) + (KN_uKN*uKN_1AN) + (KN_uZH*uZH_1AN) + (KN_uZN*uZN_1AN);                        
KN_2BN = KN_1BN + (KN_uKH*uKH_1BN) + (KN_uKN*uKN_1BN) + (KN_uZH*uZH_1BN) + (KN_uZN*uZN_1BN);                        

% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH)
CN_PN = - (CN/PN)*( (alphaC*phi) + sigmaC*(1-alphaC) ); 
CN_PH = (CN/PH)*alphaC*alphaH*(phi-sigmaC); 
CH_PN = (CH/PN)*(phi-sigmaC)*(1-alphaC); 
CH_PH = -(CH/PH)*( rho*(1-alphaH) + alphaH*( phi*(1-alphaC) + (sigmaC*alphaC) ) ); 
CF_PN = (CF/PN)*(1-alphaC)*(phi-sigmaC); 
CF_PH = (CF/PH)*alphaH*(rho - (phi*(1-alphaC)+(sigmaC*alphaC))); 

% Partial Derivatives Gj=Gj(G) 
GN_G   = omegaGN/PN; 
GH_G   = (1-omegaGN)*(omegaGH/PH);
GF_G   = (1-omegaGN)*(1-omegaGH);

% Solving for traded and non-traded prices: PH,PN(K,Q,G,AH,BH,AN,BN,lambda)     
h11 = (YN_PH - CN_PH - JN_PH) - (KN*xi1N*uKN_PH);           
h12 = (YN_PN - CN_PN - JN_PN) - (KN*xi1N*uKN_PN);           
h21 = (YH_PH - CH_PH - JH_PH - XH_PH) - (KH*xi1H*uKH_PH);   
h22 = (YH_PN - CH_PN - JH_PN) - (KH*xi1H*uKH_PN);           
                                                            
% K,Q,G,AH,BH,AN,BN,lambda                                                       
k11 = -(YN_2K - JN_1K - (KN*xi1N*uKN_1K));                  
k12 = JN_1Q;    
k13 = GN_G;
k14 = -(YN_2AH - (KN*xi1N*uKN_1AH));                        
k15 = -(YN_2BH - (KN*xi1N*uKN_1BH));                        
k16 = -(YN_2AN - (KN*xi1N*uKN_1AN));                        
k17 = -(YN_2BN - (KN*xi1N*uKN_1BN));                        

k21 = -(YH_2K - JH_1K - (KH*xi1H*uKH_1K));                  
k22 = JH_1Q;  
k23 = GH_G;
k24 = -(YH_2AH - (KH*xi1H*uKH_1AH));                         
k25 = -(YH_2BH - (KH*xi1H*uKH_1BH));                         
k26 = -(YH_2AN - (KH*xi1H*uKH_1AN));                         
k27 = -(YH_2BN - (KH*xi1H*uKH_1BN));                         
                                                            
M3 = [h11 h12; h21 h22];                                    
X3 = [k11 k12 k13 k14 k15 k16 k17; k21 k22 k23 k24 k25 k26 k27];                                    
JST3 = inv(M3);                                             
MST3 = JST3*X3;                                             
                                                            
PH_K = MST3(1,1); PH_Q = MST3(1,2); PH_G = MST3(1,3); PH_AH = MST3(1,4); PH_BH = MST3(1,5); PH_AN = MST3(1,6); PH_BN = MST3(1,7);
PN_K = MST3(2,1); PN_Q = MST3(2,2); PN_G = MST3(2,3); PN_AH = MST3(2,4); PN_BH = MST3(2,5); PN_AN = MST3(2,6); PN_BN = MST3(2,7);                         

% Solving for capital-labor ratios kj=kj(K,Q,G,Aj,Bj) - 
% sectoral labor Lj=Lj(K,Q,G,Aj,Bj) - sectoral output 
% Yj=Yj(K,Q,G,Aj,Bj) - Final Solutions
kH_K = kH_2K + (kH_PH*PH_K) + (kH_PN*PN_K); 
kH_Q = (kH_PH*PH_Q) + (kH_PN*PN_Q);
kH_G = (kH_PH*PH_G) + (kH_PN*PN_G);
kH_AH = kH_2AH + (kH_PH*PH_AH) + (kH_PN*PN_AH);
kH_BH = kH_2BH + (kH_PH*PH_BH) + (kH_PN*PN_BH);
kH_AN = kH_2AN + (kH_PH*PH_AN) + (kH_PN*PN_AN);
kH_BN = kH_2BN + (kH_PH*PH_BN) + (kH_PN*PN_BN);

kN_K = kN_2K + (kN_PH*PH_K) + (kN_PN*PN_K);
kN_Q = (kN_PH*PH_Q) + (kN_PN*PN_Q); 
kN_G = (kN_PH*PH_G) + (kN_PN*PN_G);
kN_AH = kN_2AH + (kN_PH*PH_AH) + (kN_PN*PN_AH);
kN_BH = kN_2BH + (kN_PH*PH_BH) + (kN_PN*PN_BH);
kN_AN = kN_2AN + (kN_PH*PH_AN) + (kN_PN*PN_AN); 
kN_BN = kN_2BN + (kN_PH*PH_BN) + (kN_PN*PN_BN); 

LH_K  = LH_2K + (LH_PH*PH_K) + (LH_PN*PN_K); 
LH_Q  = (LH_PH*PH_Q) + (LH_PN*PN_Q); 
LH_G  = (LH_PH*PH_G) + (LH_PN*PN_G);
LH_AH = LH_2AH + (LH_PH*PH_AH) + (LH_PN*PN_AH); 
LH_BH = LH_2BH + (LH_PH*PH_BH) + (LH_PN*PN_BH);
LH_AN = LH_2AN + (LH_PH*PH_AN) + (LH_PN*PN_AN); 
LH_BN = LH_2BN + (LH_PH*PH_BN) + (LH_PN*PN_BN);

LN_K = LN_2K + (LN_PH*PH_K) + (LN_PN*PN_K);
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);
LN_G = (LN_PH*PH_G) + (LN_PN*PN_G); 
LN_AH = LN_2AH + (LN_PH*PH_AH) + (LN_PN*PN_AH); 
LN_BH = LN_2BH + (LN_PH*PH_BH) + (LN_PN*PN_BH);
LN_AN = LN_2AN + (LN_PH*PH_AN) + (LN_PN*PN_AN); 
LN_BN = LN_2BN + (LN_PH*PH_BN) + (LN_PN*PN_BN);

yH_K = yH_2K + (yH_PH*PH_K) + (yH_PN*PN_K);           
yH_Q = (yH_PH*PH_Q) + (yH_PN*PN_Q);                   
yH_G = (yH_PH*PH_G) + (yH_PN*PN_G);                   
yH_AH = yH_2AH + (yH_PH*PH_AH) + (yH_PN*PN_AH);       
yH_BH = yH_2BH + (yH_PH*PH_BH) + (yH_PN*PN_BH);       
yH_AN = yH_2AN + (yH_PH*PH_AN) + (yH_PN*PN_AN);       
yH_BN = yH_2BN + (yH_PH*PH_BN) + (yH_PN*PN_BN);       
                                                      
yN_K = yN_2K + (yN_PH*PH_K) + (yN_PN*PN_K);           
yN_Q = (yN_PH*PH_Q) + (yN_PN*PN_Q);                   
yN_G = (yN_PH*PH_G) + (yN_PN*PN_G);                   
yN_AH = yN_2AH + (yN_PH*PH_AH) + (yN_PN*PN_AH);       
yN_BH = yN_2BH + (yN_PH*PH_BH) + (yN_PN*PN_BH);       
yN_AN = yN_2AN + (yN_PH*PH_AN) + (yN_PN*PN_AN);       
yN_BN = yN_2BN + (yN_PH*PH_BN) + (yN_PN*PN_BN);       

YH_K = YH_2K + (YH_PH*PH_K) + (YH_PN*PN_K); 
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q); 
YH_G = (YH_PH*PH_G) + (YH_PN*PN_G);
YH_AH = YH_2AH + (YH_PH*PH_AH) + (YH_PN*PN_AH);
YH_BH = YH_2BH + (YH_PH*PH_BH) + (YH_PN*PN_BH);
YH_AN = YH_2AN + (YH_PH*PH_AN) + (YH_PN*PN_AN);
YH_BN = YH_2BN + (YH_PH*PH_BN) + (YH_PN*PN_BN);

YN_K = YN_2K + (YN_PH*PH_K) + (YN_PN*PN_K);
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);
YN_G = (YN_PH*PH_G) + (YN_PN*PN_G);
YN_AH = YN_2AH + (YN_PH*PH_AH) + (YN_PN*PN_AH);
YN_BH = YN_2BH + (YN_PH*PH_BH) + (YN_PN*PN_BH);
YN_AN = YN_2AN + (YN_PH*PH_AN) + (YN_PN*PN_AN);
YN_BN = YN_2BN + (YN_PH*PH_BN) + (YN_PN*PN_BN); 

KH_K  = KH_2K + (KH_PH*PH_K) + (KH_PN*PN_K);                     
KH_Q  = (KH_PH*PH_Q) + (KH_PN*PN_Q);                             
KH_G  = (KH_PH*PH_G) + (KH_PN*PN_G);                             
KH_AH = KH_2AH + (KH_PH*PH_AH) + (KH_PN*PN_AH);                  
KH_BH = KH_2BH + (KH_PH*PH_BH) + (KH_PN*PN_BH);                  
KH_AN = KH_2AN + (KH_PH*PH_AN) + (KH_PN*PN_AN);                  
KH_BN = KH_2BN + (KH_PH*PH_BN) + (KH_PN*PN_BN);                   
                                                                 
KN_K = KN_2K + (KN_PH*PH_K) + (KN_PN*PN_K);                      
KN_Q = (KN_PH*PH_Q) + (KN_PN*PN_Q);                              
KN_G = (KN_PH*PH_G) + (KN_PN*PN_G);                              
KN_AH = KN_2AH + (KN_PH*PH_AH) + (KN_PN*PN_AH);                  
KN_BH = KN_2BH + (KN_PH*PH_BH) + (KN_PN*PN_BH);                  
KN_AN = KN_2AN + (KN_PH*PH_AN) + (KN_PN*PN_AN);                  
KN_BN = KN_2BN + (KN_PH*PH_BN) + (KN_PN*PN_BN);                   

uKH_K  = uKH_1K + (uKH_PH*PH_K) + (uKH_PN*PN_K);                     
uKH_Q  = (uKH_PH*PH_Q) + (uKH_PN*PN_Q);                              
uKH_G  = (uKH_PH*PH_G) + (uKH_PN*PN_G);                              
uKH_AH = uKH_1AH + (uKH_PH*PH_AH) + (uKH_PN*PN_AH);                  
uKH_BH = uKH_1BH + (uKH_PH*PH_BH) + (uKH_PN*PN_BH);                  
uKH_AN = uKH_1AN + (uKH_PH*PH_AN) + (uKH_PN*PN_AN);                  
uKH_BN = uKH_1BN + (uKH_PH*PH_BN) + (uKH_PN*PN_BN);                   
                                                                     
uKN_K = uKN_1K + (uKN_PH*PH_K) + (uKN_PN*PN_K);                      
uKN_Q = (uKN_PH*PH_Q) + (uKN_PN*PN_Q);                               
uKN_G = (uKN_PH*PH_G) + (uKN_PN*PN_G);                               
uKN_AH = uKN_1AH + (uKN_PH*PH_AH) + (uKN_PN*PN_AH);                  
uKN_BH = uKN_1BH + (uKN_PH*PH_BH) + (uKN_PN*PN_BH);                  
uKN_AN = uKN_1AN + (uKN_PH*PH_AN) + (uKN_PN*PN_AN);                  
uKN_BN = uKN_1BN + (uKN_PH*PH_BN) + (uKN_PN*PN_BN);                    

uZH_K  = uZH_1K + (uZH_PH*PH_K) + (uZH_PN*PN_K);                         
uZH_Q  = (uZH_PH*PH_Q) + (uZH_PN*PN_Q);                                  
uZH_G  = (uZH_PH*PH_G) + (uZH_PN*PN_G);                                  
uZH_AH = uZH_1AH + (uZH_PH*PH_AH) + (uZH_PN*PN_AH);                      
uZH_BH = uZH_1BH + (uZH_PH*PH_BH) + (uZH_PN*PN_BH);                      
uZH_AN = uZH_1AN + (uZH_PH*PH_AN) + (uZH_PN*PN_AN);                      
uZH_BN = uZH_1BN + (uZH_PH*PH_BN) + (uZH_PN*PN_BN);                            
                                                                         
uZN_K = uZN_1K + (uZN_PH*PH_K) + (uZN_PN*PN_K);                          
uZN_Q = (uZN_PH*PH_Q) + (uZN_PN*PN_Q);                                   
uZN_G = (uZN_PH*PH_G) + (uZN_PN*PN_G);                                   
uZN_AH = uZN_1AH + (uZN_PH*PH_AH) + (uZN_PN*PN_AH);                      
uZN_BH = uZN_1BH + (uZN_PH*PH_BH) + (uZN_PN*PN_BH);                      
uZN_AN = uZN_1AN + (uZN_PH*PH_AN) + (uZN_PN*PN_AN);                      
uZN_BN = uZN_1BN + (uZN_PH*PH_BN) + (uZN_PN*PN_BN);  

% Check
YH_K_check  = (YH_K/YH_0) - (LH_K/LH_0) - (1-sLH_0)*(uKH_K + (kH_K/kH_0));                     
YH_Q_check  = (YH_Q/YH_0) - (LH_Q/LH_0) - (1-sLH_0)*(uKH_Q + (kH_Q/kH_0));                     
YH_G_check  = (YH_G/YH_0) - (LH_G/LH_0) - (1-sLH_0)*(uKH_G + (kH_G/kH_0));                     
YH_AH_check = (YH_AH/YH_0) - (LH_AH/LH_0) - (sLH_0/AH_0) - (1-sLH_0)*(uKH_AH + (kH_AH/kH_0));  
YH_BH_check = (YH_BH/YH_0) - (LH_BH/LH_0) - (1-sLH_0)*(uKH_BH + (1/BH_0) + (kH_BH/kH_0));     
YH_AN_check = (YH_AN/YH_0) - (LH_AN/LH_0) - (1-sLH_0)*(uKH_AN + (kH_AN/kH_0));                 
YH_BN_check = (YH_BN/YH_0) - (LH_BN/LH_0) - (1-sLH_0)*(uKH_BN + (kH_BN/kH_0));                 
                                                                                              
YN_K_check  = (YN_K/YN_0) - (LN_K/LN_0) - (1-sLN_0)*(uKN_K + (kN_K/kN_0));                     
YN_Q_check  = (YN_Q/YN_0) - (LN_Q/LN_0) - (1-sLN_0)*(uKN_Q + (kN_Q/kN_0));                     
YN_G_check  = (YN_G/YN_0) - (LN_G/LN_0) - (1-sLN_0)*(uKN_G + (kN_G/kN_0));                     
YN_AH_check = (YN_AH/YN_0) - (LN_AH/LN_0) - (1-sLN_0)*(uKN_AH + (kN_AH/kN_0));                 
YN_BH_check = (YN_BH/YN_0) - (LN_BH/LN_0) - (1-sLN_0)*(uKN_BH + (kN_BH/kN_0));                 
YN_AN_check = (YN_AN/YN_0) - (LN_AN/LN_0) - (sLN_0/AN_0) - (1-sLN_0)*(uKN_AN + (kN_AN/kN_0));  
YN_BN_check = (YN_BN/YN_0) - (LN_BN/LN_0) - (1-sLN_0)*(uKN_BN + (1/BN_0) + (kN_BN/kN_0));      

% Solving for consumption Cj=Cj(lambda,K,Q,G,Aj,Bj), investment inputs 
% Jj=Jj(K,Q,GH,GN), imports MF=MF(lambda,K,Q,G,Aj,Bj), exports 
%XH=XH(K,Q,G,Aj,Bj)- Final Solutions
CH_K      = (CH_PH*PH_K) + (CH_PN*PN_K);
CH_Q      = (CH_PH*PH_Q) + (CH_PN*PN_Q);
CH_G      = (CH_PH*PH_G) + (CH_PN*PN_G);
CH_AH     = (CH_PH*PH_AH) + (CH_PN*PN_AH);
CH_BH     = (CH_PH*PH_BH) + (CH_PN*PN_BH);
CH_AN     = (CH_PH*PH_AN) + (CH_PN*PN_AN);
CH_BN     = (CH_PH*PH_BN) + (CH_PN*PN_BN);

CN_K      = (CN_PH*PH_K) + (CN_PN*PN_K);
CN_Q      = (CN_PH*PH_Q) + (CN_PN*PN_Q);
CN_G      = (CN_PH*PH_G) + (CN_PN*PN_G);
CN_AH     = (CN_PH*PH_AH) + (CN_PN*PN_AH);
CN_BH     = (CN_PH*PH_BH) + (CN_PN*PN_BH);
CN_AN     = (CN_PH*PH_AN) + (CN_PN*PN_AN);   
CN_BN     = (CN_PH*PH_BN) + (CN_PN*PN_BN);

CF_K      = (CF_PH*PH_K) + (CF_PN*PN_K);
CF_Q      = (CF_PH*PH_Q) + (CF_PN*PN_Q);
CF_G      = (CF_PH*PH_G) + (CF_PN*PN_G);
CF_AH     = (CF_PH*PH_AH) + (CF_PN*PN_AH);
CF_BH     = (CF_PH*PH_BH) + (CF_PN*PN_BH);
CF_AN     = (CF_PH*PH_AN) + (CF_PN*PN_AN); 
CF_BN     = (CF_PH*PH_BN) + (CF_PN*PN_BN);

JH_K       = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K);
JH_Q       = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q);
JH_G       = (JH_PH*PH_G) + (JH_PN*PN_G);
JH_AH      = (JH_PH*PH_AH) + (JH_PN*PN_AH);
JH_BH      = (JH_PH*PH_BH) + (JH_PN*PN_BH);
JH_AN      = (JH_PH*PH_AN) + (JH_PN*PN_AN);
JH_BN      = (JH_PH*PH_BN) + (JH_PN*PN_BN);

JN_K       = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K);
JN_Q       = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q);
JN_G       = (JN_PH*PH_G) + (JN_PN*PN_G);
JN_AH      = (JN_PH*PH_AH) + (JN_PN*PN_AH); 
JN_BH      = (JN_PH*PH_BH) + (JN_PN*PN_BH);
JN_AN      = (JN_PH*PH_AN) + (JN_PN*PN_AN);   
JN_BN      = (JN_PH*PH_BN) + (JN_PN*PN_BN);

JF_K       = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K);
JF_Q       = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q);
JF_G       = (JF_PH*PH_G) + (JF_PN*PN_G);
JF_AH      = (JF_PH*PH_AH) + (JF_PN*PN_AH);   
JF_BH      = (JF_PH*PH_BH) + (JF_PN*PN_BH);
JF_AN      = (JF_PH*PH_AN) + (JF_PN*PN_AN);   
JF_BN      = (JF_PH*PH_BN) + (JF_PN*PN_BN); 

XH_K      = XH_PH*PH_K;
XH_Q      = XH_PH*PH_Q;
XH_G      = XH_PH*PH_G;
XH_AH     = XH_PH*PH_AH;
XH_BH     = XH_PH*PH_BH;
XH_AN     = XH_PH*PH_AN;
XH_BN     = XH_PH*PH_BN;

MF_K      = (CF_K + JF_K);
MF_Q      = (CF_Q + JF_Q);
MF_G      = (CF_G + JF_G);
MF_AH     = (CF_AH + JF_AH);
MF_BH     = (CF_BH + JF_BH);
MF_AN     = (CF_AN + JF_AN); 
MF_BN     = (CF_BN + JF_BN);

% Solving for sectoral wages - Wj=Wj(K,Q,G,Aj,Bj)
WH_K = WH_2K + (WH_PH*PH_K) + (WH_PN*PN_K);                       
WH_Q = (WH_PH*PH_Q) + (WH_PN*PN_Q);                               
WH_G = (WH_PH*PH_G) + (WH_PN*PN_G);                               
WH_AH = WH_2AH + (WH_PH*PH_AH) + (WH_PN*PN_AH);                   
WH_BH = WH_2BH + (WH_PH*PH_BH) + (WH_PN*PN_BH);                   
WH_AN = WH_2AN + (WH_PH*PH_AN) + (WH_PN*PN_AN);                   
WH_BN = WH_2BN + (WH_PH*PH_BN) + (WH_PN*PN_BN);                     
                                                                  
WN_K = WN_2K + (WN_PH*PH_K) + (WN_PN*PN_K);                       
WN_Q = (WN_PH*PH_Q) + (WN_PN*PN_Q);                               
WN_G = (WN_PH*PH_G) + (WN_PN*PN_G);                               
WN_AH = WN_2AH + (WN_PH*PH_AH) + (WN_PN*PN_AH);                   
WN_BH = WN_2BH + (WN_PH*PH_BH) + (WN_PN*PN_BH);                   
WN_AN = WN_2AN + (WN_PH*PH_AN) + (WN_PN*PN_AN);                   
WN_BN = WN_2BN + (WN_PH*PH_BN) + (WN_PN*PN_BN);                      

% Solution for W as function W=W(K,Q,G,Aj,Bj) 
W_WH      = (W/WH)*alphaL; 
W_WN      = (W/WN)*(1-alphaL); 
W_K       = (W_WH*WH_K) + (W_WN*WN_K); 
W_Q       = (W_WH*WH_Q) + (W_WN*WN_Q);
W_G       = (W_WH*WH_G) + (W_WN*WN_G); 
W_AH      = (W_WH*WH_AH) + (W_WN*WN_AH); 
W_BH      = (W_WH*WH_BH) + (W_WN*WN_BH);
W_AN      = (W_WH*WH_AN) + (W_WN*WN_AN);
W_BN      = (W_WH*WH_BN) + (W_WN*WN_BN);  

% Solutions for the relative wages Wj/W: WjW=WjW(K,Q,G,Aj,Bj); 
% Solution for Omega = WN(K,Q,G,Aj,Bj)/WH(K,Q,G,Aj,Bj) 
WHW_K = (WH_0/W_0)*( (WH_K/WH_0) - (W_K/W_0) );                      
WHW_Q = (WH_0/W_0)*( (WH_Q/WH_0) - (W_Q/W_0) );                      
WHW_G = (WH_0/W_0)*( (WH_G/WH_0) - (W_G/W_0) );                      
WHW_AH = (WH_0/W_0)*( (WH_AH/WH_0) - (W_AH/W_0) );                   
WHW_BH = (WH_0/W_0)*( (WH_BH/WH_0) - (W_BH/W_0) );                   
WHW_AN = (WH_0/W_0)*( (WH_AN/WH_0) - (W_AN/W_0) );                   
WHW_BN = (WH_0/W_0)*( (WH_BN/WH_0) - (W_BN/W_0) );                   
                                                                     
WNW_K = (WN_0/W_0)*( (WN_K/WN_0) - (W_K/W_0) );                      
WNW_Q = (WN_0/W_0)*( (WN_Q/WN_0) - (W_Q/W_0) );                      
WNW_G = (WN_0/W_0)*( (WN_G/WN_0) - (W_G/W_0) );                      
WNW_AH = (WN_0/W_0)*( (WN_AH/WN_0) - (W_AH/W_0) );                   
WNW_BH = (WN_0/W_0)*( (WN_BH/WN_0) - (W_BH/W_0) );                   
WNW_AN = (WN_0/W_0)*( (WN_AN/WN_0) - (W_AN/W_0) );                   
WNW_BN = (WN_0/W_0)*( (WN_BN/WN_0) - (W_BN/W_0) );                   
                                                                     
Omega_K  = Omega_0*( (WN_K/WN_0) - (WH_K/WH_0) );       
Omega_Q  = Omega_0*( (WN_Q/WN_0) - (WH_Q/WH_0) );       
Omega_G  = Omega_0*( (WN_G/WN_0) - (WH_G/WH_0) );       
Omega_AH  = Omega_0*( (WN_AH/WN_0) - (WH_AH/WH_0) );    
Omega_BH  = Omega_0*( (WN_BH/WN_0) - (WH_BH/WH_0) );    
Omega_AN  = Omega_0*( (WN_AN/WN_0) - (WH_AN/WH_0) );    
Omega_BN  = Omega_0*( (WN_BN/WN_0) - (WH_BN/WH_0) );                   

% Solution for C as function C=C(K,Q,G,Aj,Bj) 
% Solution for C as function C=C(lambda,K,Q,AH,BH,AN,BN) 
C_1lambda  = -sigmaC*(C/lambda); 
C_PH       = -sigmaC*alphaC*alphaH*(C/PH); 
C_PN       = -sigmaC*(1-alphaC)*(C/PN); 
C_K        = (C_PH*PH_K) + (C_PN*PN_K); 
C_Q        = (C_PH*PH_Q) + (C_PN*PN_Q);
C_G        = (C_PH*PH_G) + (C_PN*PN_G); 
C_AH       = (C_PH*PH_AH) + (C_PN*PN_AH);
C_BH       = (C_PH*PH_BH) + (C_PN*PN_BH);
C_AN       = (C_PH*PH_AN) + (C_PN*PN_AN);
C_BN       = (C_PH*PH_BN) + (C_PN*PN_BN);

% Solution for PC=PC(PH,PN) - PC = PC(K,Q,G,Aj,Bj)
PC_K       = (PC/PH)*alphaC*alphaH*PH_K + (PC/PN)*(1-alphaC)*PN_K; 
PC_Q       = (PC/PH)*alphaC*alphaH*PH_Q + (PC/PN)*(1-alphaC)*PN_Q;
PC_G       = (PC/PH)*alphaC*alphaH*PH_G + (PC/PN)*(1-alphaC)*PN_G;
PC_AH      = (PC/PH)*alphaC*alphaH*PH_AH + (PC/PN)*(1-alphaC)*PN_AH;
PC_BH      = (PC/PH)*alphaC*alphaH*PH_BH + (PC/PN)*(1-alphaC)*PN_BH;
PC_AN      = (PC/PH)*alphaC*alphaH*PH_AN + (PC/PN)*(1-alphaC)*PN_AN;
PC_BN      = (PC/PH)*alphaC*alphaH*PH_BN + (PC/PN)*(1-alphaC)*PN_BN;

% Solution for Wj/PC,W/PC(K,Q,G,Aj,Bj)
WHPC_K  = WHPC_0*( (WH_K/WH_0) - (PC_K/PC_0) );   
WHPC_Q  = WHPC_0*( (WH_Q/WH_0) - (PC_Q/PC_0) );   
WHPC_G  = WHPC_0*( (WH_G/WH_0) - (PC_G/PC_0) );   
WHPC_AH = WHPC_0*( (WH_AH/WH_0) - (PC_AH/PC_0) ); 
WHPC_BH = WHPC_0*( (WH_BH/WH_0) - (PC_BH/PC_0) ); 
WHPC_AN = WHPC_0*( (WH_AN/WH_0) - (PC_AN/PC_0) ); 
WHPC_BN = WHPC_0*( (WH_BN/WH_0) - (PC_BN/PC_0) ); 
                                                  
WNPC_K  = WNPC_0*( (WN_K/WN_0) - (PC_K/PC_0) );   
WNPC_Q  = WNPC_0*( (WN_Q/WN_0) - (PC_Q/PC_0) );   
WNPC_G  = WNPC_0*( (WN_G/WN_0) - (PC_G/PC_0) );   
WNPC_AH = WNPC_0*( (WN_AH/WN_0) - (PC_AH/PC_0) ); 
WNPC_BH = WNPC_0*( (WN_BH/WN_0) - (PC_BH/PC_0) ); 
WNPC_AN = WNPC_0*( (WN_AN/WN_0) - (PC_AN/PC_0) ); 
WNPC_BN = WNPC_0*( (WN_BN/WN_0) - (PC_BN/PC_0) ); 

WPC_K  = WPC_0*( (W_K/W_0) - (PC_K/PC_0) );    
WPC_Q  = WPC_0*( (W_Q/W_0) - (PC_Q/PC_0) );    
WPC_G  = WPC_0*( (W_G/W_0) - (PC_G/PC_0) );    
WPC_AH = WPC_0*( (W_AH/W_0) - (PC_AH/PC_0) );  
WPC_BH = WPC_0*( (W_BH/W_0) - (PC_BH/PC_0) );  
WPC_AN = WPC_0*( (W_AN/W_0) - (PC_AN/PC_0) );  
WPC_BN = WPC_0*( (W_BN/W_0) - (PC_BN/PC_0) );

% Solution for PI=PI(PH,PN) - PI = PI(K,Q,G,Aj,Bj)
PI_K       = (PI/PH)*alphaI*alphaIH*PH_K + (PI/PN)*(1-alphaI)*PN_K; 
PI_Q       = (PI/PH)*alphaI*alphaIH*PH_Q + (PI/PN)*(1-alphaI)*PN_Q;
PI_G       = (PI/PH)*alphaI*alphaIH*PH_G + (PI/PN)*(1-alphaI)*PN_G;  
PI_AH      = (PI/PH)*alphaI*alphaIH*PH_AH + (PI/PN)*(1-alphaI)*PN_AH;
PI_BH      = (PI/PH)*alphaI*alphaIH*PH_BH + (PI/PN)*(1-alphaI)*PN_BH;
PI_AN      = (PI/PH)*alphaI*alphaIH*PH_AN + (PI/PN)*(1-alphaI)*PN_AN;
PI_BN      = (PI/PH)*alphaI*alphaIH*PH_BN + (PI/PN)*(1-alphaI)*PN_BN;

% Solution for GE=PH*GH + PN*GN + GF - G = G(K,Q,G,Aj,Bj)
G_K        = (PH_K*GH) + (PN_K*GN); 
G_Q        = (PH_Q*GH) + (PN_Q*GN);
G_G        = (PH_G*GH) + (PN_G*GN) + (PH*GH_G) + (PN*GN_G); %+ GF_G;   
G_AH       = (PH_AH*GH) + (PN_AH*GN);
G_BH       = (PH_BH*GH) + (PN_BH*GN);
G_AN       = (PH_AN*GH) + (PN_AN*GN);
G_BN       = (PH_BN*GH) + (PN_BN*GN);

% Solution for the price of non traded goods in terms of home traded goods
% - P = P(K,Q,G,Aj,Bj); 
P    = PN/PH; 
P_K  = (P/PN)*PN_K - (P/PH)*PH_K; 
P_Q  = (P/PN)*PN_Q - (P/PH)*PH_Q;
P_G  = (P/PN)*PN_G - (P/PH)*PH_G; 
P_AH = (P/PN)*PN_AH - (P/PH)*PH_AH;
P_BH = (P/PN)*PN_BH - (P/PH)*PH_BH;
P_AN = (P/PN)*PN_AN - (P/PH)*PH_AN;
P_BN = (P/PN)*PN_BN - (P/PH)*PH_BN;

% GDP and output shares in real terms
Y   = (PH*YH) +(PN*YN);

% Solution for Y as function Y=Y(K,Q,lambda,GH,GN) 
Y_K       = (PH_K*YH) + (PH*YH_K) + (PN_K*YN) + (PN*YN_K); 
Y_Q       = (PH_Q*YH) + (PH*YH_Q) + (PN_Q*YN) + (PN*YN_Q);
Y_G       = (PH_G*YH) + (PH*YH_G) + (PN_G*YN) + (PN*YN_G);
Y_AH      = (PH_AH*YH) + (PH*YH_AH) + (PN_AH*YN) + (PN*YN_AH);
Y_BH      = (PH_BH*YH) + (PH*YH_BH) + (PN_BH*YN) + (PN*YN_BH);
Y_AN      = (PH_AN*YH) + (PH*YH_AN) + (PN_AN*YN) + (PN*YN_AN);
Y_BN      = (PH_BN*YH) + (PH*YH_BN) + (PN_BN*YN) + (PN*YN_BN);

% Solution for Real GDP as function YR=YR(K,Q,lambda,GH,GN)
YR_K   = (PH_0*YH_K) + (PN_0*YN_K);                            
YR_Q   = (PH_0*YH_Q) + (PN_0*YN_Q);
YR_G   = (PH_0*YH_G) + (PN_0*YN_G); 
YR_AH  = (PH_0*YH_AH) + (PN_0*YN_AH);
YR_BH  = (PH_0*YH_BH) + (PN_0*YN_BH);
YR_AN  = (PH_0*YH_AN) + (PN_0*YN_AN);
YR_BN  = (PH_0*YH_BN) + (PN_0*YN_BN);

% Marginal revenue of capital R = PH*partial YH/partial KH.
% R=R(K,Q,G,Aj,Bj,lambda)
RK   = PI*(r+deltaK); 
R_K  = (RK/PH)*PH_K - (RK/kH)*(sLH/sigmaH)*kH_K - RK*(sLH/sigmaH)*uKH_K; 
R_Q  = (RK/PH)*PH_Q - (RK/kH)*(sLH/sigmaH)*kH_Q - RK*(sLH/sigmaH)*uKH_Q;
R_G  = (RK/PH)*PH_G - (RK/kH)*(sLH/sigmaH)*kH_G - RK*(sLH/sigmaH)*uKH_G;
R_AH = (RK/PH)*PH_AH - (RK/kH)*(sLH/sigmaH)*kH_AH - RK*(sLH/sigmaH)*uKH_AH + (RK/AH)*(sLH/sigmaH);
R_BH = (RK/PH)*PH_BH - (RK/kH)*(sLH/sigmaH)*kH_BH - RK*(sLH/sigmaH)*uKH_BH + (RK/BH)*((sigmaH-sLH)/sigmaH);
R_AN = (RK/PH)*PH_AN - (RK/kH)*(sLH/sigmaH)*kH_AN - RK*(sLH/sigmaH)*uKH_AN; 
R_BN = (RK/PH)*PH_BN - (RK/kH)*(sLH/sigmaH)*kH_BN - RK*(sLH/sigmaH)*uKH_BN;

% Solving for investment function I/K = v(Q/PI)+delta_K - 
% v=v(K,Q,G,Aj,Bj,lambda) final solution
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q); 
v_K  = (v_PN*PN_K) + (v_PH*PH_K); 
v_G  = (v_PN*PN_G) + (v_PH*PH_G); 
v_AH = (v_PN*PN_AH) + (v_PH*PH_AH); 
v_BH = (v_PN*PN_BH) + (v_PH*PH_BH); 
v_AN = (v_PN*PN_AN) + (v_PH*PH_AN);
v_BN = (v_PN*PN_BN) + (v_PH*PH_BN);

% Elements of the Jacobian Matrix 
Upsilon_K = (I/IN)*(YN_K-CN_K-(KN*xi1N*uKN_K)) - deltaK + alphaI*phiI*I*( (PN_K/PN) - (alphaIH/PH)*PH_K );                                                                        
Upsilon_Q = (I/IN)*(YN_Q-CN_Q-(KN*xi1N*uKN_Q)) + alphaI*phiI*I*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );
Sigma_K   = -(R_K-(RK/K)+(RK/K)*((KH*uKH_K)+(KN*uKN_K)+(KH*uZH_K)+(KN*uZN_K)+(KH_K+KN_K))-(PH*KH/K)*xi1H*uKH_K-(PN*KN/K)*xi1N*uKN_K + (PI*kappa*v_K*deltaK) ); 
Sigma_Q   = (r+deltaK)-( R_Q+(RK/K)*((KH*uKH_Q)+(KN*uKN_Q)+(KH*uZH_Q)+(KN*uZN_Q)+(KH_Q+KN_Q))-(PH*KH/K)*xi1H*uKH_Q-(PN*KN/K)*xi1N*uKN_Q + (PI*kappa*v_Q*deltaK) ); 

x11   = Upsilon_K;                                                                         
x12   = Upsilon_Q;     
x21   = Sigma_K;                        
x22   = Sigma_Q;
J = [x11 x12; x21 x22];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[mu order] = sort(diag(mu),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1); 
nu_2 = nu_sorted(2,2); 
omega_11 = V_sorted(1,1)/V_sorted(1,1); 
omega_21 = V_sorted(2,1)/V_sorted(1,1); 
omega_12 = V_sorted(1,2)/V_sorted(1,2); 
omega_22 = V_sorted(2,2)/V_sorted(1,2); 

TrJ = trace(J); 
DetJ = det(J); 

% Elements of general solutions for capital K(t) and the relative price P(t)
% K(t) -K = X1(t)+X2(t); P(t)-P = omega21*X1(t)+omega22*X2(t)
% X1(t) = (K0-K)*exp(nu1*t)+Gamma2*exp(nu1*t) - Gamma1*(exp(nu1*t)-exp(-xi*t)); 
% X2(t) = -Gamma2*exp(-xi*t); 
Upsilon_G  = (I/IN)*(YN_G-CN_G-GN_G-(KN*xi1N*uKN_G)) + (alphaI*phiI*I)*( (PN_G/PN) - (alphaIH/PH)*PH_G );
Upsilon_AH = (I/IN)*(YN_AH-CN_AH-(KN*xi1N*uKN_AH)) + (alphaI*phiI*I)*( (PN_AH/PN) - (alphaIH/PH)*PH_AH );
Upsilon_BH = (I/IN)*(YN_BH-CN_BH-(KN*xi1N*uKN_BH)) + (alphaI*phiI*I)*( (PN_BH/PN) - (alphaIH/PH)*PH_BH );
Upsilon_AN = (I/IN)*(YN_AN-CN_AN-(KN*xi1N*uKN_AN)) + (alphaI*phiI*I)*( (PN_AN/PN) - (alphaIH/PH)*PH_AN );
Upsilon_BN = (I/IN)*(YN_BN-CN_BN-(KN*xi1N*uKN_BN)) + (alphaI*phiI*I)*( (PN_BN/PN) - (alphaIH/PH)*PH_BN );
Sigma_G    = -( R_G+(RK/K)*((KH*uKH_G)+(KN*uKN_G)+(KH*uZH_G)+(KN*uZN_G)+(KH_G+KN_G))-(PH*KH/K)*xi1H*uKH_G-(PN*KN/K)*xi1N*uKN_G + (PI*kappa*v_G*deltaK) ); 
Sigma_AH    = -( R_AH+(RK/K)*((KH*uKH_AH)+(KN*uKN_AH)+(KH*uZH_AH)+(KN*uZN_AH)+(KH_AH+KN_AH))-(PH*KH/K)*xi1H*uKH_AH-(PN*KN/K)*xi1N*uKN_AH + (PI*kappa*v_AH*deltaK) );
Sigma_BH    = -( R_BH+(RK/K)*((KH*uKH_BH)+(KN*uKN_BH)+(KH*uZH_BH)+(KN*uZN_BH)+(KH_BH+KN_BH))-(PH*KH/K)*xi1H*uKH_BH-(PN*KN/K)*xi1N*uKN_BH + (PI*kappa*v_BH*deltaK) );
Sigma_AN    = -( R_AN+(RK/K)*((KH*uKH_AN)+(KN*uKN_AN)+(KH*uZH_AN)+(KN*uZN_AN)+(KH_AN+KN_AN))-(PH*KH/K)*xi1H*uKH_AN-(PN*KN/K)*xi1N*uKN_AN + (PI*kappa*v_AN*deltaK) );
Sigma_BN    = -( R_BN+(RK/K)*((KH*uKH_BN)+(KN*uKN_BN)+(KH*uZH_BN)+(KN*uZN_BN)+(KH_BN+KN_BN))-(PH*KH/K)*xi1H*uKH_BN-(PN*KN/K)*xi1N*uKN_BN + (PI*kappa*v_BN*deltaK) );

PhiG_1     = (x11-nu_2)*Upsilon_G + (x12*Sigma_G); 
PhiG_2     = (x11-nu_1)*Upsilon_G + (x12*Sigma_G);
ThetaG_1   = (1-barg)*((nu_1+xi)/(nu_1+chi)); 
ThetaG_2   = (1-barg)*((nu_2+xi)/(nu_2+chi));
GammaG_1   = -((PhiG_1*Y_0)/(nu_1-nu_2))*(1/(nu_1+xi)) ;
GammaG_2   = -((PhiG_2*Y_0)/(nu_1-nu_2))*(1/(nu_2+xi));  

PhiAH_1     = (x11-nu_2)*Upsilon_AH + (x12*Sigma_AH); 
PhiAH_2     = (x11-nu_1)*Upsilon_AH + (x12*Sigma_AH);
ThetaAH_1   = (1-baraH)*((nu_1+xiAH)/(nu_1+chiAH)); 
ThetaAH_2   = (1-baraH)*((nu_2+xiAH)/(nu_2+chiAH));
GammaAH_1   = -((PhiAH_1*AH_0)/(nu_1-nu_2))*(1/(nu_1+xiAH));
GammaAH_2   = -((PhiAH_2*AH_0)/(nu_1-nu_2))*(1/(nu_2+xiAH)); 

PhiBH_1     = (x11-nu_2)*Upsilon_BH + (x12*Sigma_BH);        
PhiBH_2     = (x11-nu_1)*Upsilon_BH + (x12*Sigma_BH);       
ThetaBH_1   = (1-barbH)*((nu_1+xiBH)/(nu_1+chiBH));           
ThetaBH_2   = (1-barbH)*((nu_2+xiBH)/(nu_2+chiBH));           
GammaBH_1   = -((PhiBH_1*BH_0)/(nu_1-nu_2))*(1/(nu_1+xiBH));
GammaBH_2   = -((PhiBH_2*BH_0)/(nu_1-nu_2))*(1/(nu_2+xiBH)); 

PhiAN_1     = (x11-nu_2)*Upsilon_AN + (x12*Sigma_AN);       
PhiAN_2     = (x11-nu_1)*Upsilon_AN + (x12*Sigma_AN);      
ThetaAN_1   = (1-baraN)*((nu_1+xiAN)/(nu_1+chiAN));          
ThetaAN_2   = (1-baraN)*((nu_2+xiAN)/(nu_2+chiAN));          
GammaAN_1   = -((PhiAN_1*AN_0)/(nu_1-nu_2))*(1/(nu_1+xiAN));
GammaAN_2   = -((PhiAN_2*AN_0)/(nu_1-nu_2))*(1/(nu_2+xiAN));

PhiBN_1     = (x11-nu_2)*Upsilon_BN + (x12*Sigma_BN);         
PhiBN_2     = (x11-nu_1)*Upsilon_BN + (x12*Sigma_BN);        
ThetaBN_1   = (1-barbN)*((nu_1+xiBN)/(nu_1+chiBN));            
ThetaBN_2   = (1-barbN)*((nu_2+xiBN)/(nu_2+chiBN));            
GammaBN_1   = -((PhiBN_1*BN_0)/(nu_1-nu_2))*(1/(nu_1+xiBN));  
GammaBN_2   = -((PhiBN_2*BN_0)/(nu_1-nu_2))*(1/(nu_2+xiBN));   

X20       = -GammaG_2*(1-ThetaG_2) - GammaAH_2*(1-ThetaAH_2) - GammaBH_2*(1-ThetaBH_2) - GammaAN_2*(1-ThetaAN_2) - GammaBN_2*(1-ThetaBN_2); 
X10       = (K0-K) - X20; 

% Intertemporal solvency condition - lambda 
B_K          = (PH_K*XH) + (PH*XH_K) - MF_K; 
B_Q          = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
B_G          = (PH_G*XH) + (PH*XH_G) - MF_G; 
B_AH         = (PH_AH*XH) + (PH*XH_AH) - MF_AH; 
B_BH         = (PH_BH*XH) + (PH*XH_BH) - MF_BH; 
B_AN         = (PH_AN*XH) + (PH*XH_AN) - MF_AN;
B_BN         = (PH_BN*XH) + (PH*XH_BN) - MF_BN;
N1           = (B_K + (B_Q*omega_21));
N2           = (B_K + (B_Q*omega_22)); 
ThetaG_prime  = (1-barg)*((xi+r)/(chi+r)); 
ThetaG_1prime = ThetaG_1*((xi+r)/(chi+r));
ThetaG_2prime = ThetaG_2*((xi+r)/(chi+r));
ThetaAH_prime  = (1-baraH)*((xiAH+r)/(chiAH+r)); 
ThetaAH_1prime = ThetaAH_1*((xiAH+r)/(chiAH+r));
ThetaAH_2prime = ThetaAH_2*((xiAH+r)/(chiAH+r));
ThetaBH_prime  = (1-barbH)*((xiBH+r)/(chiBH+r)); 
ThetaBH_1prime = ThetaBH_1*((xiBH+r)/(chiBH+r));
ThetaBH_2prime = ThetaBH_2*((xiBH+r)/(chiBH+r));
ThetaAN_prime  = (1-baraN)*((xiAN+r)/(chiAN+r)); 
ThetaAN_1prime = ThetaAN_1*((xiAN+r)/(chiAN+r));
ThetaAN_2prime = ThetaAN_2*((xiAN+r)/(chiAN+r));
ThetaBN_prime  = (1-barbN)*((xiBN+r)/(chiBN+r)); 
ThetaBN_1prime = ThetaBN_1*((xiBN+r)/(chiBN+r));
ThetaBN_2prime = ThetaBN_2*((xiBN+r)/(chiBN+r));
wB1           = N1*((K0-K) + GammaG_2*(1-ThetaG_2)- GammaG_1*(1-ThetaG_1) + GammaAH_2*(1-ThetaAH_2)- GammaAH_1*(1-ThetaAH_1) + GammaBH_2*(1-ThetaBH_2)- GammaBH_1*(1-ThetaBH_1) + GammaAN_2*(1-ThetaAN_2)- GammaAN_1*(1-ThetaAN_1) + GammaBN_2*(1-ThetaBN_2)- GammaBN_1*(1-ThetaBN_1)); 
wBG2          = B_G*Y_0*(1-ThetaG_prime) + N1*GammaG_1*(1-ThetaG_1prime) - N2*GammaG_2*(1-ThetaG_2prime);  
wBAH2         = B_AH*AH_0*(1-ThetaAH_prime) + N1*GammaAH_1*(1-ThetaAH_1prime) - N2*GammaAH_2*(1-ThetaAH_2prime);  
wBBH2         = B_BH*BH_0*(1-ThetaBH_prime) + N1*GammaBH_1*(1-ThetaBH_1prime) - N2*GammaBH_2*(1-ThetaBH_2prime);  
wBAN2         = B_AN*AN_0*(1-ThetaAN_prime) + N1*GammaAN_1*(1-ThetaAN_1prime) - N2*GammaAN_2*(1-ThetaAN_2prime);  
wBBN2         = B_BN*BN_0*(1-ThetaBN_prime) + N1*GammaBN_1*(1-ThetaBN_1prime) - N2*GammaBN_2*(1-ThetaBN_2prime);   

% Solution for the stock of financial wealth
A0        = B0 + (PI*K0); 
A_K       = ((WH_K*LH)+(WN_K*LN))+((WH*LH_K)+(WN*LN_K))+((WH*LH*uZH_K)+(WN*LN*uZN_K))-G_K-((PC_K*C)+(PC*C_K))-((PH*chi1H*uZH_K)+(PN*chi1N*uZN_K)); 
A_Q       = ((WH_Q*LH)+(WN_Q*LN))+((WH*LH_Q)+(WN*LN_Q))+((WH*LH*uZH_Q)+(WN*LN*uZN_Q))-G_Q-((PC_Q*C)+(PC*C_Q))-((PH*chi1H*uZH_Q)+(PN*chi1N*uZN_Q));  
A_G       = ((WH_G*LH)+(WN_G*LN))+((WH*LH_G)+(WN*LN_G))+((WH*LH*uZH_G)+(WN*LN*uZN_G))-G_G-((PC_G*C)+(PC*C_G))-((PH*chi1H*uZH_G)+(PN*chi1N*uZN_G));           
A_AH      = ((WH_AH*LH)+(WN_AH*LN))+((WH*LH_AH)+(WN*LN_AH))+((WH*LH*uZH_AH)+(WN*LN*uZN_AH))-G_AH-((PC_AH*C)+(PC*C_AH))-((PH*chi1H*uZH_AH)+(PN*chi1N*uZN_AH));
A_BH      = ((WH_BH*LH)+(WN_BH*LN))+((WH*LH_BH)+(WN*LN_BH))+((WH*LH*uZH_BH)+(WN*LN*uZN_BH))-G_BH-((PC_BH*C)+(PC*C_BH))-((PH*chi1H*uZH_BH)+(PN*chi1N*uZN_BH));
A_AN      = ((WH_AN*LH)+(WN_AN*LN))+((WH*LH_AN)+(WN*LN_AN))+((WH*LH*uZH_AN)+(WN*LN*uZN_AN))-G_AN-((PC_AN*C)+(PC*C_AN))-((PH*chi1H*uZH_AN)+(PN*chi1N*uZN_AN));
A_BN      = ((WH_BN*LH)+(WN_BN*LN))+((WH*LH_BN)+(WN*LN_BN))+((WH*LH*uZH_BN)+(WN*LN*uZN_BN))-G_BN-((PC_BN*C)+(PC*C_BN))-((PH*chi1H*uZH_BN)+(PN*chi1N*uZN_BN));
M1        = A_K + (A_Q*omega_21); 
M2        = A_K + (A_Q*omega_22);
wA1           = M1*((K0-K) + GammaG_2*(1-ThetaG_2)- GammaG_1*(1-ThetaG_1) + GammaAH_2*(1-ThetaAH_2)-  GammaAH_1*(1-ThetaAH_1) + GammaBH_2*(1-ThetaBH_2)- GammaBH_1*(1-ThetaBH_1) + GammaAN_2*(1-ThetaAN_2)- GammaAN_1*(1-ThetaAN_1) + GammaBN_2*(1-ThetaBN_2)- GammaBN_1*(1-ThetaBN_1)); 
wAG2          = A_G*Y_0*(1-ThetaG_prime) + M1*GammaG_1*(1-ThetaG_1prime) - M2*GammaG_2*(1-ThetaG_2prime);  
wAAH2         = A_AH*AH_0*(1-ThetaAH_prime) + M1*GammaAH_1*(1-ThetaAH_1prime) - M2*GammaAH_2*(1-ThetaAH_2prime);  
wABH2         = A_BH*BH_0*(1-ThetaBH_prime) + M1*GammaBH_1*(1-ThetaBH_1prime) - M2*GammaBH_2*(1-ThetaBH_2prime);  
wAAN2         = A_AN*AN_0*(1-ThetaAN_prime) + M1*GammaAN_1*(1-ThetaAN_1prime) - M2*GammaAN_2*(1-ThetaAN_2prime);  
wABN2         = A_BN*BN_0*(1-ThetaBN_prime) + M1*GammaBN_1*(1-ThetaBN_1prime) - M2*GammaBN_2*(1-ThetaBN_2prime); 
dA_tech  = (wA1/(r-nu_1)) + (wAG2/(xi+r))  + (wAAH2/(xiAH+r)) + (wABH2/(xiBH+r)) + (wAAN2/(xiAN+r)) + (wABN2/(xiBN+r)); 

% RPj=Rj/Pj=Rj(K,Q,G,Aj,Bj);
RPH_K  = (RK_0/PH_0)*((R_K/RK_0) - (PH_K/PH_0));     
RPH_Q  = (RK_0/PH_0)*((R_Q/RK_0) - (PH_Q/PH_0));     
RPH_G  = (RK_0/PH_0)*((R_G/RK_0) - (PH_G/PH_0));     
RPH_AH = (RK_0/PH_0)*((R_AH/RK_0) - (PH_AH/PH_0));   
RPH_BH = (RK_0/PH_0)*((R_BH/RK_0) - (PH_BH/PH_0));   
RPH_AN = (RK_0/PH_0)*((R_AN/RK_0) - (PH_AN/PH_0));   
RPH_BN = (RK_0/PH_0)*((R_BN/RK_0) - (PH_BN/PH_0));   
                                                     
RPN_K  = (RK_0/PN_0)*((R_K/RK_0) - (PN_K/PN_0));     
RPN_Q  = (RK_0/PN_0)*((R_Q/RK_0) - (PN_Q/PN_0));     
RPN_G  = (RK_0/PN_0)*((R_G/RK_0) - (PN_G/PN_0));     
RPN_AH = (RK_0/PN_0)*((R_AH/RK_0) - (PN_AH/PN_0));   
RPN_BH = (RK_0/PN_0)*((R_BH/RK_0) - (PN_BH/PN_0));   
RPN_AN = (RK_0/PN_0)*((R_AN/RK_0) - (PN_AN/PN_0));   
RPN_BN = (RK_0/PN_0)*((R_BN/RK_0) - (PN_BN/PN_0));  

tildeRPH_K  = RPH_K + (RK_0/PH_0)*uZH_K;   
tildeRPH_Q  = RPH_Q + (RK_0/PH_0)*uZH_Q;   
tildeRPH_G  = RPH_G + (RK_0/PH_0)*uZH_G;   
tildeRPH_AH = RPH_AH + (RK_0/PH_0)*uZH_AH; 
tildeRPH_BH = RPH_BH + (RK_0/PH_0)*uZH_BH; 
tildeRPH_AN = RPH_AN + (RK_0/PH_0)*uZH_AN; 
tildeRPH_BN = RPH_BN + (RK_0/PH_0)*uZH_BN; 
                                           
tildeRPN_K  = RPN_K + (RK_0/PN_0)*uZN_K;   
tildeRPN_Q  = RPN_Q + (RK_0/PN_0)*uZN_Q;   
tildeRPN_G  = RPN_G + (RK_0/PN_0)*uZN_G;   
tildeRPN_AH = RPN_AH + (RK_0/PN_0)*uZN_AH; 
tildeRPN_BH = RPN_BH + (RK_0/PN_0)*uZN_BH; 
tildeRPN_AN = RPN_AN + (RK_0/PN_0)*uZN_AN; 
tildeRPN_BN = RPN_BN + (RK_0/PN_0)*uZN_BN; 

% Solutions tildeWj(K,Q,G,Aj,Bj); tildeWj=uZj*Wj; 
tildeWH_K  = WH_K + (WH*uZH_K); 
tildeWH_Q  = WH_Q + (WH*uZH_Q);
tildeWH_G  = WH_G + (WH*uZH_G);
tildeWH_AH = WH_AH + (WH*uZH_AH);
tildeWH_BH = WH_BH + (WH*uZH_BH);
tildeWH_AN = WH_AN + (WH*uZH_AN);
tildeWH_BN = WH_BN + (WH*uZH_BN);

tildeWN_K  = WN_K + (WN*uZN_K);    
tildeWN_Q  = WN_Q + (WN*uZN_Q);    
tildeWN_G  = WN_G + (WN*uZN_G);    
tildeWN_AH = WN_AH + (WN*uZN_AH);  
tildeWN_BH = WN_BH + (WN*uZN_BH);  
tildeWN_AN = WN_AN + (WN*uZN_AN);  
tildeWN_BN = WN_BN + (WN*uZN_BN); 

% Solution for tildeW(K,Q,G,Aj,Bj) - tildeW(tildeWH,tildeWN)
tildeW_WH      = (W/WH)*alphaL;                                            
tildeW_WN      = (W/WN)*(1-alphaL);                                        
tildeW_K       = (tildeW_WH*tildeWH_K)  + (tildeW_WN*tildeWN_K);           
tildeW_Q       = (tildeW_WH*tildeWH_Q)  + (tildeW_WN*tildeWN_Q);           
tildeW_G       = (tildeW_WH*tildeWH_G)  + (tildeW_WN*tildeWN_G);           
tildeW_AH      = (tildeW_WH*tildeWH_AH) + (tildeW_WN*tildeWN_AH);          
tildeW_BH      = (tildeW_WH*tildeWH_BH) + (tildeW_WN*tildeWN_BH);          
tildeW_AN      = (tildeW_WH*tildeWH_AN) + (tildeW_WN*tildeWN_AN);          
tildeW_BN      = (tildeW_WH*tildeWH_BN) + (tildeW_WN*tildeWN_BN);            
 
% Solution for L as function L=L(K,Q,G,Aj,Bj) - L=L(tildeWH,tildeWN)

L_W  = sigmaL*(L/W); 
L_WH = sigmaL*L*alphaL/WH; 
L_WN = sigmaL*L*(1-alphaL)/WN; 
L_K  = (L_WH*tildeWH_K)  + (L_WN*tildeWN_K);                            
L_Q  = (L_WH*tildeWH_Q)  + (L_WN*tildeWN_Q);                            
L_G  = (L_WH*tildeWH_G)  + (L_WN*tildeWN_G);                            
L_AH = (L_WH*tildeWH_AH) + (L_WN*tildeWN_AH);                           
L_BH = (L_WH*tildeWH_BH) + (L_WN*tildeWN_BH);                           
L_AN = (L_WH*tildeWH_AN) + (L_WN*tildeWN_AN);                           
L_BN = (L_WH*tildeWH_BN) + (L_WN*tildeWN_BN);                           

% Solution for the labor income share sLj=LISj(K,Q,G,Aj,Bj)=Wj*Lj/Pj*Yj             
LISH_K  = sLH_0*( (WH_K/WH_0) + (LH_K/LH_0) - (PH_K/PH_0) - (YH_K/YH_0) );          
LISH_Q  = sLH_0*( (WH_Q/WH_0) + (LH_Q/LH_0) - (PH_Q/PH_0) - (YH_Q/YH_0) );          
LISH_G  = sLH_0*( (WH_G/WH_0) + (LH_G/LH_0) - (PH_G/PH_0) - (YH_G/YH_0) );          
LISH_AH = sLH_0*( (WH_AH/WH_0) + (LH_AH/LH_0) - (PH_AH/PH_0) - (YH_AH/YH_0) );      
LISH_BH = sLH_0*( (WH_BH/WH_0) + (LH_BH/LH_0) - (PH_BH/PH_0) - (YH_BH/YH_0) );      
LISH_AN = sLH_0*( (WH_AN/WH_0) + (LH_AN/LH_0) - (PH_AN/PH_0) - (YH_AN/YH_0) );      
LISH_BN = sLH_0*( (WH_BN/WH_0) + (LH_BN/LH_0) - (PH_BN/PH_0) - (YH_BN/YH_0) );      
                                                                                    
LISN_K  = sLN_0*( (WN_K/WN_0) + (LN_K/LN_0) - (PN_K/PN_0) - (YN_K/YN_0) );          
LISN_Q  = sLN_0*( (WN_Q/WN_0) + (LN_Q/LN_0) - (PN_Q/PN_0) - (YN_Q/YN_0) );          
LISN_G  = sLN_0*( (WN_G/WN_0) + (LN_G/LN_0) - (PN_G/PN_0) - (YN_G/YN_0) );          
LISN_AH = sLN_0*( (WN_AH/WN_0) + (LN_AH/LN_0) - (PN_AH/PN_0) - (YN_AH/YN_0) );      
LISN_BH = sLN_0*( (WN_BH/WN_0) + (LN_BH/LN_0) - (PN_BH/PN_0) - (YN_BH/YN_0) );      
LISN_AN = sLN_0*( (WN_AN/WN_0) + (LN_AN/LN_0) - (PN_AN/PN_0) - (YN_AN/YN_0) );      
LISN_BN = sLN_0*( (WN_BN/WN_0) + (LN_BN/LN_0) - (PN_BN/PN_0) - (YN_BN/YN_0) );         

% Solution for LH(K,Q,G,Aj,Bj)/LN(K,Q,G,Aj,Bj)                                
LHLN_K = (LH_0/LN_0)*( (LH_K/LH_0) - (LN_K/LN_0) );                           
LHLN_Q = (LH_0/LN_0)*( (LH_Q/LH_0) - (LN_Q/LN_0) );                           
LHLN_G = (LH_0/LN_0)*( (LH_G/LH_0) - (LN_G/LN_0) );                           
LHLN_AH = (LH_0/LN_0)*( (LH_AH/LH_0) - (LN_AH/LN_0) );                        
LHLN_BH = (LH_0/LN_0)*( (LH_BH/LH_0) - (LN_BH/LN_0) );                        
LHLN_AN = (LH_0/LN_0)*( (LH_AN/LH_0) - (LN_AN/LN_0) );                        
LHLN_BN = (LH_0/LN_0)*( (LH_BN/LH_0) - (LN_BN/LN_0) );                        
                                                                              
% Solution for YH(K,Q,G,Aj,Bj)/YN(K,Q,G,Aj,Bj)                                
YHYN_K = (YH_0/YN_0)*( (YH_K/YH_0) - (YN_K/YN_0) );                           
YHYN_Q = (YH_0/YN_0)*( (YH_Q/YH_0) - (YN_Q/YN_0) );                           
YHYN_G = (YH_0/YN_0)*( (YH_G/YH_0) - (YN_G/YN_0) );                           
YHYN_AH = (YH_0/YN_0)*( (YH_AH/YH_0) - (YN_AH/YN_0) );                        
YHYN_BH = (YH_0/YN_0)*( (YH_BH/YH_0) - (YN_BH/YN_0) );                        
YHYN_AN = (YH_0/YN_0)*( (YH_AN/YH_0) - (YN_AN/YN_0) );                        
YHYN_BN = (YH_0/YN_0)*( (YH_BN/YH_0) - (YN_BN/YN_0) );                        
                                                                              
% Solutions for the employment shares Lj/L=(Lj/L)(K,Q,G,Aj,Bj)                
LHS_K  = (LH_0/L_0)*((LH_K/LH_0)-(L_K/L_0));                                  
LHS_Q  = (LH_0/L_0)*((LH_Q/LH_0)-(L_Q/L_0));                                  
LHS_G  = (LH_0/L_0)*((LH_G/LH_0)-(L_G/L_0));                                  
LHS_AH  = (LH_0/L_0)*((LH_AH/LH_0)-(L_AH/L_0));                               
LHS_BH  = (LH_0/L_0)*((LH_BH/LH_0)-(L_BH/L_0));                               
LHS_AN  = (LH_0/L_0)*((LH_AN/LH_0)-(L_AN/L_0));                               
LHS_BN  = (LH_0/L_0)*((LH_BN/LH_0)-(L_BN/L_0));                               
                                                                              
LNS_K  = (LN_0/L_0)*((LN_K/LN_0)-(L_K/L_0));                                  
LNS_Q  = (LN_0/L_0)*((LN_Q/LN_0)-(L_Q/L_0));                                  
LNS_G  = (LN_0/L_0)*((LN_G/LN_0)-(L_G/L_0));                                  
LNS_AH  = (LN_0/L_0)*((LN_AH/LN_0)-(L_AH/L_0));                               
LNS_BH  = (LN_0/L_0)*((LN_BH/LN_0)-(L_BH/L_0));                               
LNS_AN  = (LN_0/L_0)*((LN_AN/LN_0)-(L_AN/L_0));                               
LNS_BN  = (LN_0/L_0)*((LN_BN/LN_0)-(L_BN/L_0));                               
                                                                              
% Solutions for the Real Sectoral Output Yj/YR=(Yj/YR)(K,Q,G,Aj,Bj)           
YHS_K  = (YH_0/YR_0)*( (YH_K/YH_0) - (YR_K/YR_0) );                           
YHS_Q  = (YH_0/YR_0)*( (YH_Q/YH_0) - (YR_Q/YR_0) );                           
YHS_G  = (YH_0/YR_0)*( (YH_G/YH_0) - (YR_G/YR_0) );                           
YHS_AH  = (YH_0/YR_0)*( (YH_AH/YH_0) - (YR_AH/YR_0) );                        
YHS_BH  = (YH_0/YR_0)*( (YH_BH/YH_0) - (YR_BH/YR_0) );                        
YHS_AN  = (YH_0/YR_0)*( (YH_AN/YH_0) - (YR_AN/YR_0) );                        
YHS_BN  = (YH_0/YR_0)*( (YH_BN/YH_0) - (YR_BN/YR_0) );                        
                                                                              
YNS_K  = (YN_0/YR_0)*( (YN_K/YN_0) - (YR_K/YR_0) );                           
YNS_Q  = (YN_0/YR_0)*( (YN_Q/YN_0) - (YR_Q/YR_0) );                           
YNS_G  = (YN_0/YR_0)*( (YN_G/YN_0) - (YR_G/YR_0) );                           
YNS_AH  = (YN_0/YR_0)*( (YN_AH/YN_0) - (YR_AH/YR_0) );                        
YNS_BH  = (YN_0/YR_0)*( (YN_BH/YN_0) - (YR_BH/YR_0) );                        
YNS_AN  = (YN_0/YR_0)*( (YN_AN/YN_0) - (YR_AN/YR_0) );                        
YNS_BN  = (YN_0/YR_0)*( (YN_BN/YN_0) - (YR_BN/YR_0) );

% Solutions for the Kj/K: Kj/K=Kj/K(lambda,K,Q,AH,BH,AN,BN) -
% aggregate capital utilization rate uK =(KH/K)*uKH + (KN/K)*uKN
KHK_K  = (KH_0/K_0)*( (KH_K/KH_0) - (1/K_0) );    
KHK_Q  = (KH_0/K_0)*(KH_Q/KH_0);                   
KHK_G  = (KH_0/K_0)*(KH_G/KH_0);                  
KHK_AH = (KH_0/K_0)*(KH_AH/KH_0);                 
KHK_BH = (KH_0/K_0)*(KH_BH/KH_0);                 
KHK_AN = (KH_0/K_0)*(KH_AN/KH_0);                 
KHK_BN = (KH_0/K_0)*(KH_BN/KH_0);                 
                                                  
KNK_K  = (KN_0/K_0)*( (KN_K/KN_0) - (1/K_0) );    
KNK_Q  = (KN_0/K_0)*(KN_Q/KN_0);                   
KNK_G  = (KN_0/K_0)*(KN_G/KN_0);                  
KNK_AH = (KN_0/K_0)*(KN_AH/KN_0);                 
KNK_BH = (KN_0/K_0)*(KN_BH/KN_0);                 
KNK_AN = (KN_0/K_0)*(KN_AN/KN_0);                 
KNK_BN = (KN_0/K_0)*(KN_BN/KN_0);    

uK_K   = KHK_K + KNK_K + (KH_0/K_0)*uKH_K + (KN_0/K_0)*uKN_K;      
uK_Q   = KHK_Q + KNK_Q + (KH_0/K_0)*uKH_Q + (KN_0/K_0)*uKN_Q;      
uK_G   = KHK_G + KNK_G + (KH_0/K_0)*uKH_G + (KN_0/K_0)*uKN_G;      
uK_AH  = KHK_AH + KNK_AH + (KH_0/K_0)*uKH_AH + (KN_0/K_0)*uKN_AH; 
uK_BH  = KHK_BH + KNK_BH + (KH_0/K_0)*uKH_BH + (KN_0/K_0)*uKN_BH; 
uK_AN  = KHK_AN + KNK_AN + (KH_0/K_0)*uKH_AN + (KN_0/K_0)*uKN_AN; 
uK_BN  = KHK_BN + KNK_BN + (KH_0/K_0)*uKH_BN + (KN_0/K_0)*uKN_BN; 

% Solutions tildeZj,tildeZ(K,Q,G,Aj,Bj);
tildeZH_K   = ZH_0*uZH_K;   
tildeZH_Q   = ZH_0*uZH_Q;   
tildeZH_G   = ZH_0*uZH_G;   
tildeZH_AH  = ZH_0*uZH_AH;  
tildeZH_BH  = ZH_0*uZH_BH;  
tildeZH_AN  = ZH_0*uZH_AN;  
tildeZH_BN  = ZH_0*uZH_BN;  
                            
tildeZN_K   = ZN_0*uZN_K;   
tildeZN_Q   = ZN_0*uZN_Q;   
tildeZN_G   = ZN_0*uZN_G;   
tildeZN_AH  = ZN_0*uZN_AH;  
tildeZN_BH  = ZN_0*uZN_BH;  
tildeZN_AN  = ZN_0*uZN_AN;  
tildeZN_BN  = ZN_0*uZN_BN;  

tildeZ_K    = omegaYH_0*(Z_0/ZH_0)*tildeZH_K  + (1-omegaYH_0)*(Z_0/ZN_0)*tildeZN_K;     
tildeZ_Q    = omegaYH_0*(Z_0/ZH_0)*tildeZH_Q  + (1-omegaYH_0)*(Z_0/ZN_0)*tildeZN_Q;     
tildeZ_G    = omegaYH_0*(Z_0/ZH_0)*tildeZH_G  + (1-omegaYH_0)*(Z_0/ZN_0)*tildeZN_G;     
tildeZ_AH   = omegaYH_0*(Z_0/ZH_0)*tildeZH_AH + (1-omegaYH_0)*(Z_0/ZN_0)*tildeZN_AH;    
tildeZ_BH   = omegaYH_0*(Z_0/ZH_0)*tildeZH_BH + (1-omegaYH_0)*(Z_0/ZN_0)*tildeZN_BH;    
tildeZ_AN   = omegaYH_0*(Z_0/ZH_0)*tildeZH_AN + (1-omegaYH_0)*(Z_0/ZN_0)*tildeZN_AN;    
tildeZ_BN   = omegaYH_0*(Z_0/ZH_0)*tildeZH_BN + (1-omegaYH_0)*(Z_0/ZN_0)*tildeZN_BN;    
                                                                              
% Solutions tildeWj,tildeRj,tildeKj,tildeYj(K,Q,G,Aj,Bj); tildeWj=uZj*Wj;
% tildeRj=RK*uZj; tildeKj=uKj*Kj; tildeYj=uZj*Yj; 
tildeWH_K  = WH_K + (WH*uZH_K); 
tildeWH_Q  = WH_Q + (WH*uZH_Q);
tildeWH_G  = WH_G + (WH*uZH_G);
tildeWH_AH = WH_AH + (WH*uZH_AH);
tildeWH_BH = WH_BH + (WH*uZH_BH);
tildeWH_AN = WH_AN + (WH*uZH_AN);
tildeWH_BN = WH_BN + (WH*uZH_BN);

tildeWN_K  = WN_K + (WN*uZN_K);    
tildeWN_Q  = WN_Q + (WN*uZN_Q);    
tildeWN_G  = WN_G + (WN*uZN_G);    
tildeWN_AH = WN_AH + (WN*uZN_AH);  
tildeWN_BH = WN_BH + (WN*uZN_BH);  
tildeWN_AN = WN_AN + (WN*uZN_AN);  
tildeWN_BN = WN_BN + (WN*uZN_BN);   

tildeWHPC_K  = WHPC_0*( (tildeWH_K/WH_0) - (PC_K/PC_0) );   
tildeWHPC_Q  = WHPC_0*( (tildeWH_Q/WH_0) - (PC_Q/PC_0) );   
tildeWHPC_G  = WHPC_0*( (tildeWH_G/WH_0) - (PC_G/PC_0) );   
tildeWHPC_AH = WHPC_0*( (tildeWH_AH/WH_0) - (PC_AH/PC_0) ); 
tildeWHPC_BH = WHPC_0*( (tildeWH_BH/WH_0) - (PC_BH/PC_0) ); 
tildeWHPC_AN = WHPC_0*( (tildeWH_AN/WH_0) - (PC_AN/PC_0) ); 
tildeWHPC_BN = WHPC_0*( (tildeWH_BN/WH_0) - (PC_BN/PC_0) ); 
                                                            
tildeWNPC_K  = WNPC_0*( (tildeWN_K/WN_0) - (PC_K/PC_0) );   
tildeWNPC_Q  = WNPC_0*( (tildeWN_Q/WN_0) - (PC_Q/PC_0) );   
tildeWNPC_G  = WNPC_0*( (tildeWN_G/WN_0) - (PC_G/PC_0) );   
tildeWNPC_AH = WNPC_0*( (tildeWN_AH/WN_0) - (PC_AH/PC_0) ); 
tildeWNPC_BH = WNPC_0*( (tildeWN_BH/WN_0) - (PC_BH/PC_0) ); 
tildeWNPC_AN = WNPC_0*( (tildeWN_AN/WN_0) - (PC_AN/PC_0) ); 
tildeWNPC_BN = WNPC_0*( (tildeWN_BN/WN_0) - (PC_BN/PC_0) );         
                                                                           
tildeRH_K  = R_K + (RK*uZH_K);    
tildeRH_Q  = R_Q + (RK*uZH_Q);    
tildeRH_G  = R_G + (RK*uZH_G);    
tildeRH_AH = R_AH + (RK*uZH_AH);  
tildeRH_BH = R_BH + (RK*uZH_BH);  
tildeRH_AN = R_AN + (RK*uZH_AN);  
tildeRH_BN = R_BN + (RK*uZH_BN);  
                                  
tildeRN_K  = R_K + (RK*uZN_K);    
tildeRN_Q  = R_Q + (RK*uZN_Q);    
tildeRN_G  = R_G + (RK*uZN_G);    
tildeRN_AH = R_AH + (RK*uZN_AH);  
tildeRN_BH = R_BH + (RK*uZN_BH);  
tildeRN_AN = R_AN + (RK*uZN_AN);  
tildeRN_BN = R_BN + (RK*uZN_BN);  

tildeKH_K  = KH_K + (KH*uKH_K);   
tildeKH_Q  = KH_Q + (KH*uKH_Q);   
tildeKH_G  = KH_G + (KH*uKH_G);   
tildeKH_AH = KH_AH + (KH*uKH_AH); 
tildeKH_BH = KH_BH + (KH*uKH_BH); 
tildeKH_AN = KH_AN + (KH*uKH_AN); 
tildeKH_BN = KH_BN + (KH*uKH_BN); 
                                  
tildeKN_K  = KN_K + (KN*uKN_K);   
tildeKN_Q  = KN_Q + (KN*uKN_Q);   
tildeKN_G  = KN_G + (KN*uKN_G);   
tildeKN_AH = KN_AH + (KN*uKN_AH); 
tildeKN_BH = KN_BH + (KN*uKN_BH); 
tildeKN_AN = KN_AN + (KN*uKN_AN); 
tildeKN_BN = KN_BN + (KN*uKN_BN);  

tildekH_K  = kH*( (tildeKH_K/KH) - (LH_K/LH) );   
tildekH_Q  = kH*( (tildeKH_Q/KH) - (LH_Q/LH) );   
tildekH_G  = kH*( (tildeKH_G/KH) - (LH_G/LH) );   
tildekH_AH = kH*( (tildeKH_AH/KH) - (LH_AH/LH) ); 
tildekH_BH = kH*( (tildeKH_BH/KH) - (LH_BH/LH) ); 
tildekH_AN = kH*( (tildeKH_AN/KH) - (LH_AN/LH) ); 
tildekH_BN = kH*( (tildeKH_BN/KH) - (LH_BN/LH) ); 
                                                  
tildekN_K  = kN*( (tildeKN_K/KN) - (LN_K/LN) );   
tildekN_Q  = kN*( (tildeKN_Q/KN) - (LN_Q/LN) );   
tildekN_G  = kN*( (tildeKN_G/KN) - (LN_G/LN) );   
tildekN_AH = kN*( (tildeKN_AH/KN) - (LN_AH/LN) ); 
tildekN_BH = kN*( (tildeKN_BH/KN) - (LN_BH/LN) ); 
tildekN_AN = kN*( (tildeKN_AN/KN) - (LN_AN/LN) ); 
tildekN_BN = kN*( (tildeKN_BN/KN) - (LN_BN/LN) ); 

tildeyH_K  = yH_K + (yH_0*uZH_K);         
tildeyH_Q  = yH_Q + (yH_0*uZH_Q);         
tildeyH_G  = yH_G + (yH_0*uZH_G);         
tildeyH_AH = yH_AH + (yH_0*uZH_AH);       
tildeyH_BH = yH_BH + (yH_0*uZH_BH);       
tildeyH_AN = yH_AN + (yH_0*uZH_AN);       
tildeyH_BN = yH_BN + (yH_0*uZH_BN);       
                                          
tildeyN_K  = yN_K + (yN_0*uZN_K);         
tildeyN_Q  = yN_Q + (yN_0*uZN_Q);         
tildeyN_G  = yN_G + (yN_0*uZN_G);         
tildeyN_AH = yN_AH + (yN_0*uZN_AH);       
tildeyN_BH = yN_BH + (yN_0*uZN_BH);       
tildeyN_AN = yN_AN + (yN_0*uZN_AN);       
tildeyN_BN = yN_BN + (yN_0*uZN_BN);       

tildeYH_K  = YH_K + (YH_0*uZH_K);    
tildeYH_Q  = YH_Q + (YH_0*uZH_Q);    
tildeYH_G  = YH_G + (YH_0*uZH_G);    
tildeYH_AH = YH_AH + (YH_0*uZH_AH);  
tildeYH_BH = YH_BH + (YH_0*uZH_BH);  
tildeYH_AN = YH_AN + (YH_0*uZH_AN);  
tildeYH_BN = YH_BN + (YH_0*uZH_BN);  
                                   
tildeYN_K  = YN_K + (YN_0*uZN_K);     
tildeYN_Q  = YN_Q + (YN_0*uZN_Q);     
tildeYN_G  = YN_G + (YN_0*uZN_G);     
tildeYN_AH = YN_AH + (YN_0*uZN_AH);   
tildeYN_BH = YN_BH + (YN_0*uZN_BH);   
tildeYN_AN = YN_AN + (YN_0*uZN_AN);   
tildeYN_BN = YN_BN + (YN_0*uZN_BN);   

tildeYR_K   = YR_K + (PH_0*YH*uZH_K) + (PN_0*YN*uZN_K);       
tildeYR_Q   = YR_Q + (PH_0*YH*uZH_Q) + (PN_0*YN*uZN_Q);       
tildeYR_G   = YR_G + (PH_0*YH*uZH_G) + (PN_0*YN*uZN_G);       
tildeYR_AH  = YR_AH + (PH_0*YH*uZH_AH) + (PN_0*YN*uZN_AH);    
tildeYR_BH  = YR_BH + (PH_0*YH*uZH_BH) + (PN_0*YN*uZN_BH);    
tildeYR_AN  = YR_AN + (PH_0*YH*uZH_AN) + (PN_0*YN*uZN_AN);    
tildeYR_BN  = YR_BN + (PH_0*YH*uZH_BN) + (PN_0*YN*uZN_BN);

tildeK_K  = 1 + (K*uK_K);   
tildeK_Q  = (K*uK_Q);       
tildeK_G  = (K*uK_G);       
tildeK_AH = (K*uK_AH);     
tildeK_BH = (K*uK_BH);     
tildeK_AN = (K*uK_AN);     
tildeK_BN = (K*uK_BN);     

W_uZH          = W*alphaL;                                   
W_uZN          = W*(1-alphaL);                               
tildeW_K       = W_K + (W_uZH*uZH_K) + (W_uZN*uZN_K);   
tildeW_Q       = W_Q + (W_uZH*uZH_Q) + (W_uZN*uZN_Q);   
tildeW_G       = W_G + (W_uZH*uZH_G) + (W_uZN*uZN_G);   
tildeW_AH      = W_AH + (W_uZH*uZH_AH) + (W_uZN*uZN_AH);
tildeW_BH      = W_BH + (W_uZH*uZH_BH) + (W_uZN*uZN_BH);
tildeW_AN      = W_AN + (W_uZH*uZH_AN) + (W_uZN*uZN_AN);
tildeW_BN      = W_BN + (W_uZH*uZH_BN) + (W_uZN*uZN_BN);

tildeWPC_K  = WPC_0*( (tildeW_K/W_0) - (PC_K/PC_0) );
tildeWPC_Q  = WPC_0*( (tildeW_Q/W_0) - (PC_Q/PC_0) );
tildeWPC_G  = WPC_0*( (tildeW_G/W_0) - (PC_G/PC_0) );  
tildeWPC_AH = WPC_0*( (tildeW_AH/W_0) - (PC_AH/PC_0) );
tildeWPC_BH = WPC_0*( (tildeW_BH/W_0) - (PC_BH/PC_0) );
tildeWPC_AN = WPC_0*( (tildeW_AN/W_0) - (PC_AN/PC_0) );
tildeWPC_BN = WPC_0*( (tildeW_BN/W_0) - (PC_BN/PC_0) );

tildeOmega_K  = Omega_0*( (tildeWN_K/WN_0) - (tildeWH_K/WH_0) );     
tildeOmega_Q  = Omega_0*( (tildeWN_Q/WN_0) - (tildeWH_Q/WH_0) );     
tildeOmega_G  = Omega_0*( (tildeWN_G/WN_0) - (tildeWH_G/WH_0) );     
tildeOmega_AH  = Omega_0*( (tildeWN_AH/WN_0) - (tildeWH_AH/WH_0) );  
tildeOmega_BH  = Omega_0*( (tildeWN_BH/WN_0) - (tildeWH_BH/WH_0) );  
tildeOmega_AN  = Omega_0*( (tildeWN_AN/WN_0) - (tildeWH_AN/WH_0) );  
tildeOmega_BN  = Omega_0*( (tildeWN_BN/WN_0) - (tildeWH_BN/WH_0) );  

% Solution for tildeWH/wtildeW = tildeWj(K,Q,G,Aj,Bj)/tildeW(K,Q,G,Aj,Bj)  
tildeWHW_K = (WH_0/W_0)*( (tildeWH_K/WH_0) - (tildeW_K/W_0) );             
tildeWHW_Q = (WH_0/W_0)*( (tildeWH_Q/WH_0) - (tildeW_Q/W_0) );             
tildeWHW_G = (WH_0/W_0)*( (tildeWH_G/WH_0) - (tildeW_G/W_0) );             
tildeWHW_AH = (WH_0/W_0)*( (tildeWH_AH/WH_0) - (tildeW_AH/W_0) );          
tildeWHW_BH = (WH_0/W_0)*( (tildeWH_BH/WH_0) - (tildeW_BH/W_0) );          
tildeWHW_AN = (WH_0/W_0)*( (tildeWH_AN/WH_0) - (tildeW_AN/W_0) );          
tildeWHW_BN = (WH_0/W_0)*( (tildeWH_BN/WH_0) - (tildeW_BN/W_0) );          
                                                                           
tildeWNW_K = (WN_0/W_0)*( (tildeWN_K/WN_0) - (tildeW_K/W_0) );             
tildeWNW_Q = (WN_0/W_0)*( (tildeWN_Q/WN_0) - (tildeW_Q/W_0) );             
tildeWNW_G = (WN_0/W_0)*( (tildeWN_G/WN_0) - (tildeW_G/W_0) );             
tildeWNW_AH = (WN_0/W_0)*( (tildeWN_AH/WN_0) - (tildeW_AH/W_0) );          
tildeWNW_BH = (WN_0/W_0)*( (tildeWN_BH/WN_0) - (tildeW_BH/W_0) );          
tildeWNW_AN = (WN_0/W_0)*( (tildeWN_AN/WN_0) - (tildeW_AN/W_0) );          
tildeWNW_BN = (WN_0/W_0)*( (tildeWN_BN/WN_0) - (tildeW_BN/W_0) );  

% Solutions for the tildeKj/tildeK,tildeR(lambda,K,Q,AH,BH,AN,BN) - tildeK = uK*K; tildeKj = uKj*Kj        
tildeKHK_K  = (KH_0/K_0)*( (tildeKH_K/KH_0) - (tildeK_K/K_0) );      
tildeKHK_Q  = (KH_0/K_0)*( (tildeKH_Q/KH_0) - (tildeK_Q/K_0) );      
tildeKHK_G  = (KH_0/K_0)*( (tildeKH_G/KH_0) - (tildeK_G/K_0) );      
tildeKHK_AH = (KH_0/K_0)*( (tildeKH_AH/KH_0) - (tildeK_AH/K_0) );    
tildeKHK_BH = (KH_0/K_0)*( (tildeKH_BH/KH_0) - (tildeK_BH/K_0) );    
tildeKHK_AN = (KH_0/K_0)*( (tildeKH_AN/KH_0) - (tildeK_AN/K_0) );    
tildeKHK_BN = (KH_0/K_0)*( (tildeKH_BN/KH_0) - (tildeK_BN/K_0) );    
                                                                     
tildeKNK_K  = (KN_0/K_0)*( (tildeKN_K/KN_0) - (tildeK_K/K_0) );      
tildeKNK_Q  = (KN_0/K_0)*( (tildeKN_Q/KN_0) - (tildeK_Q/K_0) );      
tildeKNK_G  = (KN_0/K_0)*( (tildeKN_G/KN_0) - (tildeK_G/K_0) );      
tildeKNK_AH = (KN_0/K_0)*( (tildeKN_AH/KN_0) - (tildeK_AH/K_0) );    
tildeKNK_BH = (KN_0/K_0)*( (tildeKN_BH/KN_0) - (tildeK_BH/K_0) );    
tildeKNK_AN = (KN_0/K_0)*( (tildeKN_AN/KN_0) - (tildeK_AN/K_0) );    
tildeKNK_BN = (KN_0/K_0)*( (tildeKN_BN/KN_0) - (tildeK_BN/K_0) ); 

tildeR_K     = (RK*tildeKHK_K) + (KH_0/K_0)*tildeRH_K + (RK*tildeKNK_K) + (KN_0/K_0)*tildeRN_K;     
tildeR_Q     = (RK*tildeKHK_Q) + (KH_0/K_0)*tildeRH_Q + (RK*tildeKNK_Q) + (KN_0/K_0)*tildeRN_Q;     
tildeR_G     = (RK*tildeKHK_G) + (KH_0/K_0)*tildeRH_G + (RK*tildeKNK_G) + (KN_0/K_0)*tildeRN_G;     
tildeR_AH    = (RK*tildeKHK_AH) + (KH_0/K_0)*tildeRH_AH + (RK*tildeKNK_AH) + (KN_0/K_0)*tildeRN_AH; 
tildeR_BH    = (RK*tildeKHK_BH) + (KH_0/K_0)*tildeRH_BH + (RK*tildeKNK_BH) + (KN_0/K_0)*tildeRN_BH; 
tildeR_AN    = (RK*tildeKHK_AN) + (KH_0/K_0)*tildeRH_AN + (RK*tildeKNK_AN) + (KN_0/K_0)*tildeRN_AN; 
tildeR_BN    = (RK*tildeKHK_BN) + (KH_0/K_0)*tildeRH_BN + (RK*tildeKNK_BN) + (KN_0/K_0)*tildeRN_BN; 

% Solution for tildeYH(K,Q,G,Aj,Bj)/tildeYN(K,Q,G,Aj,Bj); 
% Solutions for the Real Sectoral Output tildeYj/tildeYR=(tildeYj/tildeYR)(K,Q,G,Aj,Bj)                           
tildeYHYN_K = (YH_0/YN_0)*( (tildeYH_K/YH_0) - (tildeYN_K/YN_0) );      
tildeYHYN_Q = (YH_0/YN_0)*( (tildeYH_Q/YH_0) - (tildeYN_Q/YN_0) );      
tildeYHYN_G = (YH_0/YN_0)*( (tildeYH_G/YH_0) - (tildeYN_G/YN_0) );      
tildeYHYN_AH = (YH_0/YN_0)*( (tildeYH_AH/YH_0) - (tildeYN_AH/YN_0) );   
tildeYHYN_BH = (YH_0/YN_0)*( (tildeYH_BH/YH_0) - (tildeYN_BH/YN_0) );   
tildeYHYN_AN = (YH_0/YN_0)*( (tildeYH_AN/YH_0) - (tildeYN_AN/YN_0) );   
tildeYHYN_BN = (YH_0/YN_0)*( (tildeYH_BN/YH_0) - (tildeYN_BN/YN_0) );   
                                                                            
tildeYHS_K  = (YH_0/YR_0)*( (tildeYH_K/YH_0) - (tildeYR_K/YR_0) );      
tildeYHS_Q  = (YH_0/YR_0)*( (tildeYH_Q/YH_0) - (tildeYR_Q/YR_0) );      
tildeYHS_G  = (YH_0/YR_0)*( (tildeYH_G/YH_0) - (tildeYR_G/YR_0) );      
tildeYHS_AH  = (YH_0/YR_0)*( (tildeYH_AH/YH_0) - (tildeYR_AH/YR_0) );   
tildeYHS_BH  = (YH_0/YR_0)*( (tildeYH_BH/YH_0) - (tildeYR_BH/YR_0) );   
tildeYHS_AN  = (YH_0/YR_0)*( (tildeYH_AN/YH_0) - (tildeYR_AN/YR_0) );   
tildeYHS_BN  = (YH_0/YR_0)*( (tildeYH_BN/YH_0) - (tildeYR_BN/YR_0) );   
                                                                        
tildeYNS_K  = (YN_0/YR_0)*( (tildeYN_K/YN_0) - (tildeYR_K/YR_0) );      
tildeYNS_Q  = (YN_0/YR_0)*( (tildeYN_Q/YN_0) - (tildeYR_Q/YR_0) );      
tildeYNS_G  = (YN_0/YR_0)*( (tildeYN_G/YN_0) - (tildeYR_G/YR_0) );      
tildeYNS_AH  = (YN_0/YR_0)*( (tildeYN_AH/YN_0) - (tildeYR_AH/YR_0) );   
tildeYNS_BH  = (YN_0/YR_0)*( (tildeYN_BH/YN_0) - (tildeYR_BH/YR_0) );   
tildeYNS_AN  = (YN_0/YR_0)*( (tildeYN_AN/YN_0) - (tildeYR_AN/YR_0) );   
tildeYNS_BN  = (YN_0/YR_0)*( (tildeYN_BN/YN_0) - (tildeYR_BN/YR_0) );

% Solutions TFPj(K,Q,G,Aj,Bj);
TFPH_K      = (ZH_0/yH_0)*tildeyH_K - (1-sLH_0)*(ZH_0/kH_0)*kH_K;
TFPH_Q      = (ZH_0/yH_0)*tildeyH_Q - (1-sLH_0)*(ZH_0/kH_0)*kH_Q;
TFPH_G      = (ZH_0/yH_0)*tildeyH_G - (1-sLH_0)*(ZH_0/kH_0)*kH_G;
TFPH_AH     = (ZH_0/yH_0)*tildeyH_AH - sLH_0*(ZH_0/AH_0) - (1-sLH_0)*(ZH_0/kH_0)*kH_AH;
TFPH_BH     = (ZH_0/yH_0)*tildeyH_BH - (1-sLH_0)*(ZH_0/BH_0) - (1-sLH_0)*(ZH_0/kH_0)*kH_BH;
TFPH_AN     = (ZH_0/yH_0)*tildeyH_AN - (1-sLH_0)*(ZH_0/kH_0)*kH_AN;
TFPH_BN     = (ZH_0/yH_0)*tildeyH_BN - (1-sLH_0)*(ZH_0/kH_0)*kH_BN;

TFPN_K      = (ZN_0/yN_0)*tildeyN_K  - (1-sLN_0)*(ZN_0/kN_0)*kN_K;
TFPN_Q      = (ZN_0/yN_0)*tildeyN_Q  - (1-sLN_0)*(ZN_0/kN_0)*kN_Q;
TFPN_G      = (ZN_0/yN_0)*tildeyN_G  - (1-sLN_0)*(ZN_0/kN_0)*kN_G;
TFPN_AH     = (ZN_0/yN_0)*tildeyN_AH  - (1-sLN_0)*(ZN_0/kN_0)*kN_AH;
TFPN_BH     = (ZN_0/yN_0)*tildeyN_BH  - (1-sLN_0)*(ZN_0/kN_0)*kN_BH;
TFPN_AN     = (ZN_0/yN_0)*tildeyN_AN  - sLN_0*(ZN_0/AN_0) - (1-sLN_0)*(ZN_0/kN_0)*kN_AN;
TFPN_BN     = (ZN_0/yN_0)*tildeyN_BN  - (1-sLN_0)*(ZN_0/BN_0) - (1-sLN_0)*(ZN_0/kN_0)*kN_BN;

TFP_K      =  omegaYH_0*(Z_0/ZH_0)*TFPH_K + (1-omegaYH_0)*(Z_0/ZN_0)*TFPN_K;     
TFP_Q      =  omegaYH_0*(Z_0/ZH_0)*TFPH_Q + (1-omegaYH_0)*(Z_0/ZN_0)*TFPN_Q;     
TFP_G      =  omegaYH_0*(Z_0/ZH_0)*TFPH_G + (1-omegaYH_0)*(Z_0/ZN_0)*TFPN_G;     
TFP_AH     =  omegaYH_0*(Z_0/ZH_0)*TFPH_AH + (1-omegaYH_0)*(Z_0/ZN_0)*TFPN_AH;   
TFP_BH     =  omegaYH_0*(Z_0/ZH_0)*TFPH_BH + (1-omegaYH_0)*(Z_0/ZN_0)*TFPN_BH;   
TFP_AN     =  omegaYH_0*(Z_0/ZH_0)*TFPH_AN + (1-omegaYH_0)*(Z_0/ZN_0)*TFPN_AN;   
TFP_BN     =  omegaYH_0*(Z_0/ZH_0)*TFPH_BN + (1-omegaYH_0)*(Z_0/ZN_0)*TFPN_BN;   

TFPH_K_check      = ZH_0*uZH_K + (1-sLH_0)*ZH_0*uKH_K;
TFPH_Q_check      = ZH_0*uZH_Q + (1-sLH_0)*ZH_0*uKH_Q;
TFPH_G_check      = ZH_0*uZH_G + (1-sLH_0)*ZH_0*uKH_G;
TFPH_AH_check     = ZH_0*uZH_AH + (1-sLH_0)*ZH_0*uKH_AH;
TFPH_BH_check     = ZH_0*uZH_BH + (1-sLH_0)*ZH_0*uKH_BH;
TFPH_AN_check     = ZH_0*uZH_AN + (1-sLH_0)*ZH_0*uKH_AN;
TFPH_BN_check     = ZH_0*uZH_BN + (1-sLH_0)*ZH_0*uKH_BN;

TFPN_K_check      = ZN_0*uZN_K + (1-sLN_0)*ZN_0*uKN_K;
TFPN_Q_check      = ZN_0*uZN_Q + (1-sLN_0)*ZN_0*uKN_Q;
TFPN_G_check      = ZN_0*uZN_G + (1-sLN_0)*ZN_0*uKN_G;
TFPN_AH_check     = ZN_0*uZN_AH + (1-sLN_0)*ZN_0*uKN_AH;
TFPN_BH_check     = ZN_0*uZN_BH + (1-sLN_0)*ZN_0*uKN_BH;
TFPN_AN_check     = ZN_0*uZN_AN + (1-sLN_0)*ZN_0*uKN_AN;
TFPN_BN_check     = ZN_0*uZN_BN + (1-sLN_0)*ZN_0*uKN_BN;

% Ratio of traded to non-traded TFP
TFPR_K  = (ZH_0/ZN_0)*( (TFPH_K/ZH_0) - (TFPN_K/ZN_0) );        
TFPR_Q  = (ZH_0/ZN_0)*( (TFPH_Q/ZH_0) - (TFPN_Q/ZN_0) );        
TFPR_G  = (ZH_0/ZN_0)*( (TFPH_G/ZH_0) - (TFPN_G/ZN_0) );        
TFPR_AH = (ZH_0/ZN_0)*( (TFPH_AH/ZH_0) - (TFPN_AH/ZN_0) );      
TFPR_BH = (ZH_0/ZN_0)*( (TFPH_BH/ZH_0) - (TFPN_BH/ZN_0) );      
TFPR_AN = (ZH_0/ZN_0)*( (TFPH_AN/ZH_0) - (TFPN_AN/ZN_0) );      
TFPR_BN = (ZH_0/ZN_0)*( (TFPH_BN/ZH_0) - (TFPN_BN/ZN_0) ); 

uZR_K  = uZH_K - uZN_K;
uZR_Q  = uZH_Q - uZN_Q;
uZR_G  = uZH_G - uZN_G;
uZR_AH = uZH_AH - uZN_AH;
uZR_BH = uZH_BH - uZN_BH;
uZR_AN = uZH_AN - uZN_AN;
uZR_BN = uZH_BN - uZN_BN; 

% Aggregate capital labor ratio k = K/L 
k_K  = k_0*( (1/K_0) - (L_K/L_0) ); 
k_Q  = -k_0*(L_Q/L_0); 
k_G  = -k_0*(L_G/L_0); 
k_AH = -k_0*(L_AH/L_0); 
k_BH = -k_0*(L_BH/L_0); 
k_AN = -k_0*(L_AN/L_0); 
k_BN = -k_0*(L_BN/L_0); 

% Aggregate LIS
LIS_K  = sL_0*( (W_K/W_0) + (L_K/L_0)  - (Y_K/Y_0) );     
LIS_Q  = sL_0*( (W_Q/W_0) + (L_Q/L_0)  - (Y_Q/Y_0) );     
LIS_G  = sL_0*( (W_G/W_0) + (L_G/L_0)  - (Y_G/Y_0) );     
LIS_AH = sL_0*( (W_AH/W_0) + (L_AH/L_0) - (Y_AH/Y_0) );   
LIS_BH = sL_0*( (W_BH/W_0) + (L_BH/L_0) - (Y_BH/Y_0) );   
LIS_AN = sL_0*( (W_AN/W_0) + (L_AN/L_0) - (Y_AN/Y_0) );   
LIS_BN = sL_0*( (W_BN/W_0) + (L_BN/L_0) - (Y_BN/Y_0) ); 

% Output share of non-tradables at current prices
tildeY_K   = Y_K + (PH_0*YH_0*uZH_K) + (PN_0*YN_0*uZN_K);    
tildeY_Q   = Y_Q + (PH_0*YH_0*uZH_Q) + (PN_0*YN_0*uZN_Q);    
tildeY_G   = Y_G + (PH_0*YH_0*uZH_G) + (PN_0*YN_0*uZN_G);    
tildeY_AH  = Y_AH + (PH_0*YH_0*uZH_AH) + (PN_0*YN_0*uZN_AH); 
tildeY_BH  = Y_BH + (PH_0*YH_0*uZH_BH) + (PN_0*YN_0*uZN_BH); 
tildeY_AN  = Y_AN + (PH_0*YH_0*uZH_AN) + (PN_0*YN_0*uZN_AN); 
tildeY_BN  = Y_BN + (PH_0*YH_0*uZH_BN) + (PN_0*YN_0*uZN_BN); 

omegaYN_K  = omegaYN_0*( (PN_K/PN_0) + (tildeYN_K/YN_0) - (tildeY_K/Y_0) );      
omegaYN_Q  = omegaYN_0*( (PN_Q/PN_0) + (tildeYN_Q/YN_0) - (tildeY_Q/Y_0) );      
omegaYN_G  = omegaYN_0*( (PN_G/PN_0) + (tildeYN_G/YN_0) - (tildeY_G/Y_0) );      
omegaYN_AH = omegaYN_0*( (PN_AH/PN_0) + (tildeYN_AH/YN_0) - (tildeY_AH/Y_0) );   
omegaYN_BH = omegaYN_0*( (PN_BH/PN_0) + (tildeYN_BH/YN_0) - (tildeY_BH/Y_0) );   
omegaYN_AN = omegaYN_0*( (PN_AN/PN_0) + (tildeYN_AN/YN_0) - (tildeY_AN/Y_0) );   
omegaYN_BN = omegaYN_0*( (PN_BN/PN_0) + (tildeYN_BN/YN_0) - (tildeY_BN/Y_0) );   

% Aggregate LIS
LIS_K  = sL_0*( (tildeW_K/W_0) + (L_K/L_0)  - (tildeY_K/Y_0) );     
LIS_Q  = sL_0*( (tildeW_Q/W_0) + (L_Q/L_0)  - (tildeY_Q/Y_0) );     
LIS_G  = sL_0*( (tildeW_G/W_0) + (L_G/L_0)  - (tildeY_G/Y_0) );     
LIS_AH = sL_0*( (tildeW_AH/W_0) + (L_AH/L_0) - (tildeY_AH/Y_0) );   
LIS_BH = sL_0*( (tildeW_BH/W_0) + (L_BH/L_0) - (tildeY_BH/Y_0) );   
LIS_AN = sL_0*( (tildeW_AN/W_0) + (L_AN/L_0) - (tildeY_AN/Y_0) );   
LIS_BN = sL_0*( (tildeW_BN/W_0) + (L_BN/L_0) - (tildeY_BN/Y_0) ); 

% Capital rental rates
RKH = PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((YH/KH)^(1/sigmaH)); 
RKN = PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((YN/KN)^(1/sigmaN)); 

% GDP and shares in real terms
Y  = (PH*YH) + (PN*YN); 
YR = (PH_0*YH) + (PN_0*YN);
omegaYHR = (PH_0*YH)/YR; 
omegaYNR = (PN_0*YN)/YR; 

% Government spending 
G       = (PH*GH) + (PN*GN) + GF;   
GT      = GF + (PH*GH); 

% Consumption 
CT       = C*varphi*((PT/PC)^(-phi));
C_check  = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1)); 
CT_check = ( (varphiH^(1/rho))*(CH^((rho-1)/rho)) + ((1-varphiH)^(1/rho))*(CF^((rho-1)/rho)) )^(rho/(rho-1));
omegaCH  = (PH*CH)/(PC*C); 
omegaCF  = (CF)/(PC*C);

% L_H, L_N and FOC for LH and LN 
Vut     = ( (vartheta^(-1/epsilon))*(LH^((epsilon+1)/epsilon)) + ((1-vartheta)^(-1/epsilon))*(LN^((epsilon+1)/epsilon)) ); 
L_check = Vut^(epsilon/(epsilon+1)); 
L_H     = ((vartheta)^(-1/epsilon))*(LH/L)^(1/epsilon); 
L_N     = ((1-vartheta)^(-1/epsilon))*(LN/L)^(1/epsilon);

% Investment 
I        = deltaK*K; 
IT       = deltaK*K*iota*((PIT/PI)^(-phiI));
I_check  = ( (iota^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-iota)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1)); 
IT_check = ( (iotaH^(1/rhoI))*(IH^((rhoI-1)/rhoI)) + ((1-iotaH)^(1/rhoI))*(IF^((rhoI-1)/rhoI)) )^(rhoI/(rhoI-1));  
I        = deltaK*K; 
EI       = PI*I; 
EIT      = (PH*IH) + IF; 
omegaI   = PI*I/Y;
omegaIH  = (PH*IH)/(PI*I);
omegaIF  = (IF)/(PI*I);

% Net exports, current account and saving
NX  = (PH*XH) - MF; 
CA  = (r*B) + (PH*XH) - MF; 
A   = B + (PI*K); 
Tax = G; 
Sav = (r*A) + (W*L) - (PC*C) - Tax; 

% Real Aggregate Wage 
WPC  = W/PC;
WHPC = WH/PC;
WNPC = WN/PC;

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WH); 
YHYN  = (YH/YN); 
LHLN  = (LH/LN);
                                                                         
% Sectoral ratios
omegaINYN = IN/YN; 
omegaIHYH = IH /YH; 
omegaIFYH = IF/YH;
omegaGHYH = GH / YH;
omegaGFYH = GF / (PH*YH);
omegaGNYN = GN / YN;
omegaGN   = (PN*GN) / G;
omegaYH   = (PH*YH) / Y;
omegaYN   = (PN*YN) /Y; 
omegaLH   = LH / L;
omegaLN   = LN / L;

% Targeted ratios
omegaC    = (PC*C) / Y;
omegaNX   =  NX / Y; 
omegaG    = (GH+PN*GN)/Y;
omegaB    = (r*B)/Y; 
omegaKY   = K/Y; 

% Confirmation
% Check the closure of the model
cond1  = PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((YH/KH)^(1/sigmaH))-RK;                               
cond2  = PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((YN/KN)^(1/sigmaN))-RK;                             
cond3  = PH*gammaH*(AH^((sigmaH-1)/sigmaH))*(yH^(1/sigmaH))-WH;                                   
cond4  = PN*gammaN*(AN^((sigmaN-1)/sigmaN))*(yN^(1/sigmaN))-WN;                                 
cond5  = (LH*kH)+(LN*kN)-K;                                   
cond6  = RK-(deltaK+r)*PI;                                    
cond7  = YN-CN-GN-IN;                                         
cond8  = YH-CH-GH-IH-XH;                                   
cond9  = (B-B0) - ( (wB1/(r-nu_1)) + (wBG2/(xi+r)) + (wBAH2/(xiAH+r)) + (wBBH2/(xiBH+r)) + (wBAN2/(xiAN+r)) + (wBBN2/(xiBN+r)) );    
cond10  = DetJ - (nu_1*nu_2);                                   
cond11 = TrJ - (nu_1+nu_2);                                     
cond12 = (LH/LN) - (vartheta/(1-vartheta))*Omega^(-epsilon);  
cond13 = (CT/CN) - (varphi/(1-varphi))*(PN/PT)^(phi);               
cond14 = (PC*C) - ((PT*CT)+(PN*CN));                                
cond15 = (W*L) - ((WH*LH)+(WN*LN));                           
cond16 = gammaL*(L^(1/sigmaL))*L_H - (lambda*WH);               
cond17 = gammaL*(L^(1/sigmaL))*L_N - (lambda*WN);               
cond18 = Y - (PC*C) - G - (PI*I) + (r*B);                     
cond19 = Sav;                                                 
cond20 = (PC*C) - (CF+(PH*CH)+(PN*CN));                                
cond21 = (IT/IN) - (iota/(1-iota))*(PN/PIT)^(phiI);            
cond22 = (PI*I) - ((PIT*IT)+(PN*IN));                                
cond23 = (RK*K) - ((RKH*KH)+(RKN*KN));                        
cond24 = 1 - (omegaK + omegaL);    
cond25 = (CH/CF) - (varphiH/(1-varphiH))*(PH)^(-rho);    
cond26 = (PT*CT) - ((PH*CH)+CF); 
cond27 = (IH/IF) - (iotaH/(1-iotaH))*(PH)^(-rhoI);    
cond28 = (PIT*IT) - ((PH*IH)+IF); 
cond29 = r*B + (PH*XH) - MF; 
cond30 = r*B + (RK*K) + (W*L) - G - (PC*C) - (PI*I); 
 
% Define New steady-state values
kH_tech = kH; kN_tech = kN; PN_tech = PN; LH_tech = LH; K_tech = K; C_tech = C;  
LN_tech = LN; L_tech  = L; W_tech = W; P_tech = P; 
YH_tech = YH; YN_tech = YN; Y_tech = Y; KH_tech  = KH; KN_tech  = KN; G_tech = G;     
PC_tech = PC; alphaC_tech = alphaC; CN_tech = CN; CH_tech = CH;  
GH_tech = GH; GN_tech = GN; ZH_tech = ZH; ZN_tech = ZN; Z_tech = Z; 
AH_tech = AH; BH_tech = BH; AN_tech = AN; BN_tech = BN;
LH_tech = LH; LN_tech = LN; KH_tech = KH; KN_tech = KN; WH_tech = WH; WN_tech = WN; 
Omega_tech = Omega; WPC_tech = WPC; WHPC_tech = WHPC; WNPC_tech = WNPC;
IF_tech = IF; CF_tech = CF; XH_tech = XH; MF_tech = MF; GF_tech = GF; PH_tech = PH; 
PT_tech = PT; PIT_tech = PIT; CT_tech = CT; IT_tech = IT; GT_tech = GT; 

YHYN_tech = YHYN; LHLN_tech = LHLN; IH_tech = IH; IN_tech = IN; PI_tech = PI; 
EI_tech = EI; CA_tech = CA; Sav_tech = Sav; NX_tech = NX; I_tech = I; A_tech = A; 
B_tech = B; lambda_tech  = lambda; RK_tech = RK; YR_tech = YR; 
yH_tech = yH; yN_tech = yN; 

omegaL_tech = omegaL; omegaK_tech = omegaK; omegaI_tech = omegaI; omegaINYN_tech = omegaINYN;
omegaIHYH_tech = omegaIHYH; omega_IFYH_tech = omegaIFYH; omegaGHYH_tech = omegaGHYH; 
omegaGFYH_tech = omegaGFYH; omegaGNYN_tech = omegaGNYN; omegaGN_tech = omegaGN;
omegaYH_tech = omegaYH; omegaYN_tech = omegaYN; omegaLH_tech = omegaLH; omegaLN_tech = omegaLN; 
omegaC_tech =omegaC; omegaNX_tech =omegaNX; omegaG_tech =omegaG; omegaB_tech =omegaB; 
omegaKY_tech = omegaKY; omegaIH_tech = omegaIH; omegaIF_tech = omegaIF; 
omegaGT_tech = omegaGT; omegaGH_tech = omegaGH; omegaGF_tech = omegaGF;
alphaL_tech = alphaL; alphaK_tech = alphaK; alphaC_tech = alphaC; 
alphaI_tech = alphaI; alphaH_tech = alphaH; alphaIH_tech = alphaIH;
omegaYHR_tech = omegaYHR; omegaYNR_tech = omegaYNR;
sLH_tech = sLH; sLN_tech = sLN; TFPH_tech = TFPH; TFPN_tech = TFPN; 
TFP_tech = TFP; sL_tech = sL; k_tech = k; 

% Steady-State Changes
dC       = C_tech - C_0; % Steady-state change of real consumption 
dK       = K_tech - K_0; % Steady-state change of real capital 
dL       = L_tech - L_0; % Steady-state change of employment 
dPN      = PN_tech - PN_0; % Steady-state change of non traded good prices
dPH      = PH_tech - PH_0; % Steady-state change of terms of trade (price of exports in terms if imports)
dP       = P_tech - P_0; % Steady-state change of non traded goods prices relative to tradable home goods prices
dB       = B_tech - B_0; % Steady-state change of traded bonds holding 
dlambda  = lambda_tech - lambda_0; % Steady-state change of marginal utility of wealth 
dY       = Y_tech - Y_0; % Steady-state change of GDP 
dYR      = YR_tech - Y_0; % Steady-state change of real GDP 
dA       = A_tech - A_0; % Steady-state change of financial wealth 
dW       = W_tech - W_0; % Steady-state change of the wage rate 
dWPC     = WPC_tech - WPC_0; % Steady-state change of the real aggregate wage W/PC 
dOmega   = Omega_tech - Omega_0; % Steady-state change of the sector wage ratio

dCH   = CH_tech - CH_0; % Steady-state change of CH
dCN   = CN_tech - CN_0; % Steady-state change of CN
dLH   = LH_tech - LH_0; % Steady-state change of real capital 
dLN   = LN_tech - LN_0; % Steady-state change of employment 
dKH   = KH_tech - KH_0; % Steady-state change of real capital 
dKN   = KN_tech - KN_0; % Steady-state change of employment 
dYH   = YH_tech - YH_0; % Steady-state change of YH
dYN   = YN_tech - YN_0; % Steady-state change of YN
dWH   = WH_tech - WH_0; % Steady-state change of WH
dWN   = WN_tech - WN_0; % Steady-state change of WN
dWHPC = WHPC_tech - WHPC_0; % Steady-state change of WH/PC
dWNPC = WNPC_tech - WNPC_0; % Steady-state change of WN/PC
dkH   = kH_tech - kH_0; % Steady-state change of kH 
dkN   = kN_tech - kN_0; % Steady-state change of kN
dLHLN = LHLN_tech - LHLN_0; % Steady-state change of LH/LN
dYHYN = YHYN_tech - YHYN_0; % Steady-state change of LH/LN
dsLH  = sLH_tech - sLH_0; % Steady-state change of labor income share in the home traded good sector
dsLN  = sLN_tech - sLN_0; % Steady-state change of labor income share in the non traded good sector

dGH   = GH_tech - GH_0; 
dGN   = GN_tech - GN_0; 
dGF   = GF_tech - GF_0; 
dG    = G_tech - G_0;
dTFPH = TFPH_tech - TFPH_0; 
dTFPN = TFPN_tech - TFPN_0; 
dTFP  = TFP_tech - TFP_0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Solution for investment Q(t)*K(t), 
EK1   = PI + (K*omega_21); % Q(t)*K(t) - Q*K = EK1*X1(t) + EK2*X2(t)
EK2   = PI + (K*omega_22);

% Solution for investment I(t)=dotK(t)-delta*K(t)

 
% Solution for the Relative Price of Non tradables P=P(K,Q,G,Aj,Bj)
wP_1   = P_K + (P_Q*omega_21); 
wP_2   = P_K + (P_Q*omega_22); 

% Solution for the Price of Non tradables PN=PN(K,Q,G,Aj,Bj);                                
wPN_1  =  PN_K + (PN_Q*omega_21);                                                                    
wPN_2  =  PN_K + (PN_Q*omega_22);  

% Solution for the TOT PH=PH(K,Q,G,Aj,Bj)
wPH_1  = PH_K + (PH_Q*omega_21); 
wPH_2  = PH_K + (PH_Q*omega_22);
                                                                                                  
% Solution for the Consumption Price index PC=PC(K,Q,G,Aj,Bj)                                         
wPC_1  =  PC_K + (PC_Q*omega_21);                                                                     
wPC_2  =  PC_K + (PC_Q*omega_22); 

% Solution for the Investment Price index PI=PI(K,Q,G,Aj,Bj)                                          
wPI_1  =  PI_K + (PI_Q*omega_21);                                                                     
wPI_2  =  PI_K + (PI_Q*omega_22); 

% Solution for capital and technology utilization rates uKj,uZj(K,Q,G,Aj,Bj)
wuKH_1  =  uKH_K + (uKH_Q*omega_21);
wuKH_2  =  uKH_K + (uKH_Q*omega_22);
wuKN_1  =  uKN_K + (uKN_Q*omega_21);
wuKN_2  =  uKN_K + (uKN_Q*omega_22);

wuK_1   =  uK_K + (uK_Q*omega_21);  
wuK_2   =  uK_K + (uK_Q*omega_22);  

wuZH_1  =  uZH_K + (uZH_Q*omega_21);
wuZH_2  =  uZH_K + (uZH_Q*omega_22);
wuZN_1  =  uZN_K + (uZN_Q*omega_21);
wuZN_2  =  uZN_K + (uZN_Q*omega_22);
                                                                                                                                                                                                                                                                                                                  
% Solution for Q(t)/PI(P(t))                                                                           
wQPI_1  = (omega_21/PI_0) - (wPI_1/PI_0);                                                                  
wQPI_2  = (omega_22/PI_0) - (wPI_2/PI_0); 
wQPI_G  = - (PI_G/PI_0);
wQPI_AH = - (PI_AH/PI_0);
wQPI_BH = - (PI_BH/PI_0);
wQPI_AN = - (PI_AN/PI_0);
wQPI_BN = - (PI_BN/PI_0);
                                                                                                       
% Solution for Consumption C=C(K,Q,G,Aj,Bj)                                                               
wC_1   = C_K + (C_Q*omega_21);                                                                          
wC_2   = C_K + (C_Q*omega_22);                                                           
                                                                                                       
% Solution for the Aggregate Wage Index W=W(K,Q,G,Aj,Bj)                                           
wW_1  =  W_K + (W_Q*omega_21);                                                                         
wW_2  =  W_K + (W_Q*omega_22);   

wtildeW_1  =  tildeW_K + (tildeW_Q*omega_21);                                                                         
wtildeW_2  =  tildeW_K + (tildeW_Q*omega_22);
                                                                                                       
% Solution for the Capital Rental Rate RK=R(K,Q,G,Aj,Bj)                                           
wR_1  =  R_K + (R_Q*omega_21);                                                                         
wR_2  =  R_K + (R_Q*omega_22);         

wtildeRH_1  =  tildeRH_K + (tildeRH_Q*omega_21);                                                                         
wtildeRH_2  =  tildeRH_K + (tildeRH_Q*omega_22);
wtildeRN_1  =  tildeRN_K + (tildeRN_Q*omega_21);                                                                         
wtildeRN_2  =  tildeRN_K + (tildeRN_Q*omega_22);

wtildeR_1  =  tildeR_K + (tildeR_Q*omega_21);                                                                         
wtildeR_2  =  tildeR_K + (tildeR_Q*omega_22);
                                                                                                       
% Solution for the Real Consumption Wage W(K,Q,G,Aj,Bj)/PC(P)                                      
wWPC_1  = WPC_K + (WPC_Q*omega_21);                                                               
wWPC_2  = WPC_K + (WPC_Q*omega_22);  

wtildeWPC_1  = tildeWPC_K + (tildeWPC_Q*omega_21);     
wtildeWPC_2  = tildeWPC_K + (tildeWPC_Q*omega_22);    
                                                                                                         
% Solution for Labor L=L(lambda,W)=L(K,Q,G,Aj,Bj)                                                     
wL_1  =  L_K + (L_Q*omega_21);                                                                         
wL_2  =  L_K + (L_Q*omega_22);      
                                                                                                     
% Solutions for the Sectoral Labor kj,K(K,Q,G,Aj,Bj)                                                 
wkH_1  =  kH_K + (kH_Q*omega_21);                                                                     
wkH_2  =  kH_K + (kH_Q*omega_22);                                                                                                                                                             
wkN_1  =  kN_K + (kN_Q*omega_21);                                                                     
wkN_2  =  kN_K + (kN_Q*omega_22);  

wtildekH_1  =  tildekH_K + (tildekH_Q*omega_21);  
wtildekH_2  =  tildekH_K + (tildekH_Q*omega_22);                                             
wtildekN_1  =  tildekN_K + (tildekN_Q*omega_21);  
wtildekN_2  =  tildekN_K + (tildekN_Q*omega_22);  

wtildeK_1  =  tildeK_K + (tildeK_Q*omega_21);                                                                     
wtildeK_2  =  tildeK_K + (tildeK_Q*omega_22);
                                                                                                       
% Solutions for the Sectoral Labor Lj=Lj(K,Q,G,Aj,Bj)                                                 
wLH_1  =  LH_K + (LH_Q*omega_21);                                                                     
wLH_2  =  LH_K + (LH_Q*omega_22);                                                     
                                                                                                       
wLN_1  =  LN_K + (LN_Q*omega_21);                                                                     
wLN_2  =  LN_K + (LN_Q*omega_22);                                                     
                                                                                                       
% Solution for Real GDP YR=YR(K,Q,G,Aj,Bj)                                                                                                                                                                                                                              
wYR_1  = YR_K + (YR_Q*omega_21);                            
wYR_2  = YR_K + (YR_Q*omega_22);

wtildeYR_1  = tildeYR_K + (tildeYR_Q*omega_21);                            
wtildeYR_2  = tildeYR_K + (tildeYR_Q*omega_22);

% Solutions for the Sectoral Output Yj=Yj(K,Q,G,Aj,Bj)                                                
wYH_1  = YH_K + (YH_Q*omega_21);                                                                      
wYH_2  = YH_K + (YH_Q*omega_22);                                                                                                                                                        
wYN_1  = YN_K + (YN_Q*omega_21);                                                                      
wYN_2  = YN_K + (YN_Q*omega_22);

wtildeYH_1  = tildeYH_K + (tildeYH_Q*omega_21);
wtildeYH_2  = tildeYH_K + (tildeYH_Q*omega_22);       

wtildeYN_1  = tildeYN_K + (tildeYN_Q*omega_21);
wtildeYN_2  = tildeYN_K + (tildeYN_Q*omega_22);

% Solutions for YH/YN,LH/LN,tildeYH/tildeYN(K,Q,G,Aj,Bj)
wYHYN_1  = YHYN_K + (YHYN_Q*omega_21);                                                                      
wYHYN_2  = YHYN_K + (YHYN_Q*omega_22);                                                                                                                                                       
wLHLN_1  = LHLN_K + (LHLN_Q*omega_21);                                                                      
wLHLN_2  = LHLN_K + (LHLN_Q*omega_22);

wtildeYHYN_1  = tildeYHYN_K + (tildeYHYN_Q*omega_21);                                                                      
wtildeYHYN_2  = tildeYHYN_K + (tildeYHYN_Q*omega_22); 

% Solutions for the Sectoral Wages Wj=Wj(K,Q,G,Aj,Bj)                                              
wWH_1  = WH_K + (WH_Q*omega_21);                                                                      
wWH_2  = WH_K + (WH_Q*omega_22);  
wWN_1  = WN_K + (WN_Q*omega_21);                                                                      
wWN_2  = WN_K + (WN_Q*omega_22);

wtildeWH_1  = tildeWH_K + (tildeWH_Q*omega_21);
wtildeWH_2  = tildeWH_K + (tildeWH_Q*omega_22);
wtildeWN_1  = tildeWN_K + (tildeWN_Q*omega_21);
wtildeWN_2  = tildeWN_K + (tildeWN_Q*omega_22);

% Solutions for the Real Sectoral Wages Wj(K,Q,G,Aj,Bj)/PC(K,Q,G,Aj,Bj)     
wWHPC_1  = WHPC_K + (WHPC_Q*omega_21);                 
wWHPC_2  = WHPC_K + (WHPC_Q*omega_22);                 
wWNPC_1  = WNPC_K + (WNPC_Q*omega_21);                 
wWNPC_2  = WNPC_K + (WNPC_Q*omega_22);                 
                                                       
wtildeWHPC_1  = tildeWHPC_K + (tildeWHPC_Q*omega_21);  
wtildeWHPC_2  = tildeWHPC_K + (tildeWHPC_Q*omega_22);  
wtildeWNPC_1  = tildeWNPC_K + (tildeWNPC_Q*omega_21);  
wtildeWNPC_2  = tildeWNPC_K + (tildeWNPC_Q*omega_22);       

% Solutions for the relative wages Wj/W: WjW=WjW(K,Q,G,Aj,Bj) -     
% Solution for Omega = WN(K,Q,G,Aj,Bj)/WH(K,Q,G,Aj,Bj) 
wWHW_1  = WHW_K + (WHW_Q*omega_21);                
wWHW_2  = WHW_K + (WHW_Q*omega_22);                
wWNW_1  = WNW_K + (WNW_Q*omega_21);                
wWNW_2  = WNW_K + (WNW_Q*omega_22);                
                                                   
wtildeWHW_1  = tildeWHW_K + (tildeWHW_Q*omega_21); 
wtildeWHW_2  = tildeWHW_K + (tildeWHW_Q*omega_22); 
wtildeWNW_1  = tildeWNW_K + (tildeWNW_Q*omega_21); 
wtildeWNW_2  = tildeWNW_K + (tildeWNW_Q*omega_22);                        
                                                                                             
wOmega_1  =  Omega_K + (Omega_Q*omega_21);                       
wOmega_2  =  Omega_K + (Omega_Q*omega_22);     

wtildeOmega_1  =  tildeOmega_K + (tildeOmega_Q*omega_21);  
wtildeOmega_2  =  tildeOmega_K + (tildeOmega_Q*omega_22);  
                                                                                                                                               
% Solution for YH(K,Q,G,Aj,Bj)/YN(K,Q,G,Aj,Bj), Solution for LH(K,Q,G,Aj,Bj)/LN(K,Q,G,Aj,Bj)                               
% Solutions for the Real Sectoral Output Yj/YR=(Yj/YR)(K,Q,G,Aj,Bj)          
% Solutions for the employment shares Lj/L=(Lj/L)(K,Q,G,Aj,Bj)               
% Solutions for the employment shares sLj=LISj(K,Q,G,Aj,Bj) -  

wLHLN_1  = LHLN_K + (LHLN_Q*omega_21);
wLHLN_2  = LHLN_K + (LHLN_Q*omega_22);
wYHYN_1  = YHYN_K + (YHYN_Q*omega_21);
wYHYN_2  = YHYN_K + (YHYN_Q*omega_22);
                                      
wLHS_1  = LHS_K + (LHS_Q*omega_21);   
wLHS_2  = LHS_K + (LHS_Q*omega_22);   
wLNS_1  = LNS_K + (LNS_Q*omega_21);   
wLNS_2  = LNS_K + (LNS_Q*omega_22);   
                                      
wYHS_1  = YHS_K + (YHS_Q*omega_21);   
wYHS_2  = YHS_K + (YHS_Q*omega_22);   
wYNS_1  = YNS_K + (YNS_Q*omega_21);   
wYNS_2  = YNS_K + (YNS_Q*omega_22);   

wtildeYHS_1  = tildeYHS_K + (tildeYHS_Q*omega_21); 
wtildeYHS_2  = tildeYHS_K + (tildeYHS_Q*omega_22); 
wtildeYNS_1  = tildeYNS_K + (tildeYNS_Q*omega_21); 
wtildeYNS_2  = tildeYNS_K + (tildeYNS_Q*omega_22); 

% sLj = Wj*Lj/(Pj*Yj) -                                                                                
wLISH_1  = LISH_K + (LISH_Q*omega_21);                                    
wLISH_2  = LISH_K + (LISH_Q*omega_22);                                                                                                                                                                
wLISN_1  = LISN_K + (LISN_Q*omega_21); 
wLISN_2  = LISN_K + (LISN_Q*omega_22);                                                      
                                                                                                 
% Solutions for the Kj/K: Kj/K=Kj/K(lambda,K,Q,AH,BH,AN,BN) -                                    
wKHK_1  = KHK_K + (KHK_Q*omega_21);  
wKHK_2  = KHK_K + (KHK_Q*omega_22);  
wKNK_1  = KNK_K + (KNK_Q*omega_21);  
wKNK_2  = KNK_K + (KNK_Q*omega_22); 

wtildeKHK_1  = tildeKHK_K + (tildeKHK_Q*omega_21);  
wtildeKHK_2  = tildeKHK_K + (tildeKHK_Q*omega_22);  
wtildeKNK_1  = tildeKNK_K + (tildeKNK_Q*omega_21);  
wtildeKNK_2  = tildeKNK_K + (tildeKNK_Q*omega_22);  

% Solutions for tildeZj,tildeZ(lambda,K,Q,AH,BH,AN,BN) -
wtildeZH_1  = tildeZH_K + (tildeZH_Q*omega_21);   
wtildeZH_2  = tildeZH_K + (tildeZH_Q*omega_22);                                                     
wtildeZN_1  = tildeZN_K + (tildeZN_Q*omega_21);   
wtildeZN_2  = tildeZN_K + (tildeZN_Q*omega_22);

wtildeZ_1   = tildeZ_K + (tildeZ_Q*omega_21); 
wtildeZ_2   = tildeZ_K + (tildeZ_Q*omega_22); 

% Solutions for TFPj,TFP(lambda,K,Q,AH,BH,AN,BN) -
wTFPH_1  = TFPH_K + (TFPH_Q*omega_21);
wTFPH_2  = TFPH_K + (TFPH_Q*omega_22);
wTFPN_1  = TFPN_K + (TFPN_Q*omega_21);
wTFPN_2  = TFPN_K + (TFPN_Q*omega_22);

wTFPH_1_check  = TFPH_K_check + (TFPH_Q_check*omega_21);
wTFPH_2_check  = TFPH_K_check + (TFPH_Q_check*omega_22);
wTFPN_1_check  = TFPN_K_check + (TFPN_Q_check*omega_21);
wTFPN_2_check  = TFPN_K_check + (TFPN_Q_check*omega_22);

wTFP_1   = TFP_K + (TFP_Q*omega_21);
wTFP_2   = TFP_K + (TFP_Q*omega_22);

wTFP_1   = TFP_K + (TFP_Q*omega_21);
wTFP_2   = TFP_K + (TFP_Q*omega_22);

wTFPR_1  = TFPR_K + (TFPR_Q*omega_21);  
wTFPR_2  = TFPR_K + (TFPR_Q*omega_22);  
wuZR_1   = uZR_K + (uZR_Q*omega_21);    
wuZR_2   = uZR_K + (uZR_Q*omega_22); 

% Solutions for the relative return on capiral Rj/Pj(K,Q,G,Aj,Bj) -     
wRPH_1  = RPH_K + (RPH_Q*omega_21);                 
wRPH_2  = RPH_K + (RPH_Q*omega_22);                 
wRPN_1  = RPN_K + (RPN_Q*omega_21);                 
wRPN_2  = RPN_K + (RPN_Q*omega_22);                 
                                                    
wtildeRPH_1  = tildeRPH_K + (tildeRPH_Q*omega_21);  
wtildeRPH_2  = tildeRPH_K + (tildeRPH_Q*omega_22);  
wtildeRPN_1  = tildeRPN_K + (tildeRPN_Q*omega_21);  
wtildeRPN_2  = tildeRPN_K + (tildeRPN_Q*omega_22);

% Solutions for aggregate capital-labor ratio k, aggregate LIS sL, output
% share of non-tradables at current prices omegaYN
wk_1   =  k_K + (k_Q*omega_21);                                                                     
wk_2   =  k_K + (k_Q*omega_22); 

wLIS_1   =  LIS_K + (LIS_Q*omega_21); 
wLIS_2   =  LIS_K + (LIS_Q*omega_22); 

womegaYN_1   =  omegaYN_K + (omegaYN_Q*omega_21); 
womegaYN_2   =  omegaYN_K + (omegaYN_Q*omega_22); 
                                                                                                                                                                                                                                                                                            
% Transitional Paths 
time0 = [Tm:Tu:0]; % Span of time t= [-20..0[ 
pathdGY0    = (omegaG_0 - omegaG_0) + 0*time0;
pathCY0     = (C_0 - C_0) + 0*time0;
pathdP0     = (P_0 - P_0) + 0*time0;
pathdPH0    = (PH_0 - PH_0) + 0*time0;
pathdPN0    = (PN_0 - PN_0) + 0*time0;
pathdZ0     = (Z_0 - Z_0) + 0*time0;
pathdZH0    = (ZH_0 - ZH_0) + 0*time0;
pathdZN0    = (ZN_0 - ZN_0) + 0*time0;
pathCAY0    = CA_0 + 0*time0;
pathdL0     = (L_0 - L_0) + 0*time0;
pathdK0     = (K_0 - K_0) + 0*time0;
pathdLH0    = (LH_0 - LH_0) + 0*time0;
pathdLN0    = (LN_0 - LN_0) + 0*time0;
pathdkH0    = (kH_0 - kH_0) + 0*time0;
pathdkN0    = (kN_0 - kN_0) + 0*time0;
pathdYH0    = (YH_0 - YH_0) + 0*time0;
pathdYN0    = (YN_0 - YN_0) + 0*time0;
pathIY0     = (I_0 - I_0) + 0*time0;
pathSY0     = CA_0 + 0*time0;
pathdW0     = (W_0 - W_0) + 0*time0;
pathdY0     = (Y_0 - Y_0) + 0*time0;
pathdWH0    = (WH_0 - WH_0) + 0*time0;
pathdWN0    = (WN_0 - WN_0) + 0*time0;
pathdOmega0 = (Omega_0 - Omega_0) + 0*time0;
pathdYHYN0  = (YHYN_0 - YHYN_0) + 0*time0;
pathdLHLN0  = (LHLN_0 - LHLN_0) + 0*time0;
pathdWPC0   = (WPC_0 - WPC_0) + 0*time0;
pathdQ0     = (PI_0 - PI_0) + 0*time0;  
pathdR0     = (RK_0 - RK_0) + 0*time0; 
pathdLISH0  = (sLH_0 - sLH_0) + 0*time0;
pathdLISN0  = (sLN_0 - sLN_0) + 0*time0;

time1        = [0:Tu:Tg]; % span of time t = [0..100]
VG           = exp(-xi*time1) - (1-barg)*exp(-chi*time1);
VG1          = exp(-xi*time1) - ThetaG_1*exp(-chi*time1); 
VG2          = exp(-xi*time1) - ThetaG_2*exp(-chi*time1);
VAH          = exp(-xiAH*time1) - (1-baraH)*exp(-chiAH*time1);
VBH          = exp(-xiBH*time1) - (1-barbH)*exp(-chiBH*time1);
VAN          = exp(-xiAN*time1) - (1-baraN)*exp(-chiAN*time1);
VBN          = exp(-xiBN*time1) - (1-barbN)*exp(-chiBN*time1);
VAH1          = exp(-xiAH*time1) - ThetaAH_1*exp(-chiAH*time1);
VAH2          = exp(-xiAH*time1) - ThetaAH_2*exp(-chiAH*time1);
VBH1          = exp(-xiBH*time1) - ThetaBH_1*exp(-chiBH*time1);
VBH2          = exp(-xiBH*time1) - ThetaBH_2*exp(-chiBH*time1);
VAN1          = exp(-xiAN*time1) - ThetaAN_1*exp(-chiAN*time1);
VAN2          = exp(-xiAN*time1) - ThetaAN_2*exp(-chiAN*time1);
VBN1          = exp(-xiBN*time1) - ThetaBN_1*exp(-chiBN*time1);
VBN2          = exp(-xiBN*time1) - ThetaBN_2*exp(-chiBN*time1);
VG1prime      = xi*exp(-xi*time1) - chi*ThetaG_1*exp(-chi*time1);
VG2prime      = xi*exp(-xi*time1) - chi*ThetaG_2*exp(-chi*time1);
VGprime       = xi*exp(-xi*time1) - chi*(1-barg)*exp(-chi*time1);
VAH1prime     = xiAH*exp(-xiAH*time1) - chiAH*ThetaAH_1*exp(-chiAH*time1);
VAH2prime     = xiAH*exp(-xiAH*time1) - chiAH*ThetaAH_2*exp(-chiAH*time1);
VBH1prime     = xiBH*exp(-xiBH*time1) - chiBH*ThetaBH_1*exp(-chiBH*time1);
VBH2prime     = xiBH*exp(-xiBH*time1) - chiBH*ThetaBH_2*exp(-chiBH*time1);
VAN1prime     = xiAN*exp(-xiAN*time1) - chiAN*ThetaAN_1*exp(-chiAN*time1);
VAN2prime     = xiAN*exp(-xiAN*time1) - chiAN*ThetaAN_2*exp(-chiAN*time1);
VBN1prime     = xiBN*exp(-xiBN*time1) - chiBN*ThetaBN_1*exp(-chiBN*time1);
VBN2prime     = xiBN*exp(-xiBN*time1) - chiBN*ThetaBN_2*exp(-chiBN*time1);

VBG1prime     = xi*exp(-xi*time1) - chi*ThetaG_1prime*exp(-chi*time1);
VBG2prime     = xi*exp(-xi*time1) - chi*ThetaG_2prime*exp(-chi*time1);
VBGprime      = xi*exp(-xi*time1) - chi*ThetaG_prime*exp(-chi*time1);

VBAH1prime     = xiAH*exp(-xiAH*time1) - chiAH*ThetaAH_1prime*exp(-chiAH*time1);
VBAH2prime     = xiAH*exp(-xiAH*time1) - chiAH*ThetaAH_2prime*exp(-chiAH*time1);
VBBH1prime     = xiBH*exp(-xiBH*time1) - chiBH*ThetaBH_1prime*exp(-chiBH*time1);
VBBH2prime     = xiBH*exp(-xiBH*time1) - chiBH*ThetaBH_2prime*exp(-chiBH*time1);
VBAN1prime     = xiAN*exp(-xiAN*time1) - chiAN*ThetaAN_1prime*exp(-chiAN*time1);
VBAN2prime     = xiAN*exp(-xiAN*time1) - chiAN*ThetaAN_2prime*exp(-chiAN*time1);
VBBN1prime     = xiBN*exp(-xiBN*time1) - chiBN*ThetaBN_1prime*exp(-chiBN*time1);
VBBN2prime     = xiBN*exp(-xiBN*time1) - chiBN*ThetaBN_2prime*exp(-chiBN*time1);

VBAHprime      = xiAH*exp(-xiAH*time1) - chiAH*ThetaAH_prime*exp(-chiAH*time1); 
VBBHprime      = xiBH*exp(-xiBH*time1) - chiBH*ThetaBH_prime*exp(-chiBH*time1); 
VBANprime      = xiAN*exp(-xiAN*time1) - chiAN*ThetaAN_prime*exp(-chiAN*time1); 
VBBNprime      = xiBN*exp(-xiBN*time1) - chiBN*ThetaBN_prime*exp(-chiBN*time1); 

X11  = (K0-K_tech) + GammaG_2*(1-ThetaG_2) - GammaG_1*(1-ThetaG_1) + GammaAH_2*(1-ThetaAH_2) - GammaAH_1*(1-ThetaAH_1) + GammaBH_2*(1-ThetaBH_2) - GammaBH_1*(1-ThetaBH_1) + GammaAN_2*(1-ThetaAN_2) - GammaAN_1*(1-ThetaAN_1) + GammaBN_2*(1-ThetaBN_2) - GammaBN_1*(1-ThetaBN_1);
X1   = X11*exp(nu_1*time1) + (GammaG_1*VG1) + (GammaAH_1*VAH1) + (GammaBH_1*VBH1) + (GammaAN_1*VAN1) + (GammaBN_1*VBN1);
X2   = -(GammaG_2*VG2) - (GammaAH_2*VAH2) - (GammaBH_2*VBH2) - (GammaAN_2*VAN2) - (GammaBN_2*VBN2); 
%%%%%%%%% Transitional paths %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pathdGHY1    = ( PH_0*( (GH_0-GH_0) +  (GH_G*Y_0*VG) )/Y_0)*100;
pathdGNY1    = ( PN_0*( (GN_0-GN_0) +  (GN_G*Y_0*VG) )/Y_0)*100;
pathdGFY1    = ( ( (GF_0-GF_0) +  (GF_G*Y_0*VG) )/Y_0)*100;
pathdGY1     = ( ( (G_0-G_0) +  (VG*Y_0) )/Y_0)*100;
pathdAH1     = (( (AH_tech-AH_0) +  (VAH*AH_0) )/AH_0)*100;
pathdBH1     = (( (BH_tech-BH_0) +  (VBH*BH_0) )/BH_0)*100;
pathdAN1     = (( (AN_tech-AN_0) +  (VAN*AN_0) )/AN_0)*100;
pathdBN1     = (( (BN_tech-BN_0) +  (VBN*BN_0) )/BN_0)*100;
pathdZH1     = (sLH_0*(( (AH_tech-AH_0) +  (VAH*AH_0) )/AH_0) + (1-sLH_0)*(( (BH_tech-BH_0) +  (VBH*BH_0) )/BH_0) )*100;
pathdZN1     = (sLN_0*(( (AN_tech-AN_0) +  (VAN*AN_0) )/AN_0) + (1-sLN_0)*(( (BN_tech-BN_0) +  (VBN*BN_0) )/BN_0) )*100;
pathdFBTCH1  = ((1-sigmaH)/sigmaH)*( (( (BH_tech-BH_0) +  (VBH*BH_0) )/BH_0) - (( (AH_tech-AH_0) +  (VAH*AH_0) )/AH_0) )*100; 
pathdFBTCN1  = ((1-sigmaN)/sigmaN)*( (( (BN_tech-BN_0) +  (VBN*BH_0) )/BN_0) - (( (AN_tech-AN_0) +  (VAN*AN_0) )/AN_0) )*100; 
 
pathdK1      = (((K_tech-K_0) + (X1 + X2) )/K_0)*100;
pathdQ1      = (((PI_tech-PI_0) + (omega_21*X1) + (omega_22*X2) )/PI_0)*100;
pathdP1      = (((P_tech-P_0) + (wP_1*X1) + (wP_2*X2) + (P_G*Y_0*VG) + (P_AH*AH_0*VAH) + (P_BH*BH_0*VBH) + (P_AN*AN_0*VAN) + (P_BN*BN_0*VBN) )/P_0)*100;
pathdPH1     = (((PH_tech-PH_0) + (wPH_1*X1) + (wPH_2*X2) + (PH_G*Y_0*VG) + (PH_AH*AH_0*VAH) + (PH_BH*BH_0*VBH) + (PH_AN*AN_0*VAN) + (PH_BN*BN_0*VBN) )/PH_0)*100;
pathdPN1     = (((PN_tech-PN_0) + (wPN_1*X1) + (wPN_2*X2) + (PN_G*Y_0*VG) + (PN_AH*AH_0*VAH) + (PN_BH*BH_0*VBH) + (PN_AN*AN_0*VAN) + (PN_BN*BN_0*VBN) )/PN_0)*100;
pathdCY1     = ( PC_0*((C_tech-C_0) + (wC_1*X1) + (wC_2*X2) + (C_G*Y_0*VG) + (C_AH*AH_0*VAH) + (C_BH*BH_0*VBH) + (C_AN*AN_0*VAN) + (C_BN*BN_0*VBN) )/Y_0 )*100;
pathdQPI1    = ( (wQPI_1*X1) + (wQPI_2*X2) + (wQPI_G*Y_0*VG) + (wQPI_AH*AH_0*VAH) + (wQPI_BH*BH_0*VBH) + (wQPI_AN*AN_0*VAN) + (wQPI_BN*BN_0*VBN) )*100;                                
pathdL1      = (((L_tech-L_0)  + (wL_1*X1) + (wL_2*X2) + (L_G*Y_0*VG) + (L_AH*AH_0*VAH) + (L_BH*BH_0*VBH) + (L_AN*AN_0*VAN) + (L_BN*BN_0*VBN) )/L_0)*100;                
pathdLH1     = ( (WH_0/W_0)*( (LH_tech-LH_0) + (wLH_1*X1) + (wLH_2*X2) + (LH_G*Y_0*VG) + (LH_AH*AH_0*VAH) + (LH_BH*BH_0*VBH) + (LH_AN*AN_0*VAN) + (LH_BN*BN_0*VBN) )/L_0)*100; 
pathdLN1     = ( (WN_0/W_0)*( (LN_tech-LN_0) + (wLN_1*X1) + (wLN_2*X2) + (LN_G*Y_0*VG) + (LN_AH*AH_0*VAH) + (LN_BH*BH_0*VBH) + (LN_AN*AN_0*VAN) + (LN_BN*BN_0*VBN) )/L_0)*100; 
pathdW1      = (((W_tech-W_0) + (wW_1*X1) + (wW_2*X2) + (W_G*Y_0*VG) + (W_AH*AH_0*VAH) + (W_BH*BH_0*VBH) + (W_AN*AN_0*VAN) + (W_BN*BN_0*VBN) )/W_0)*100;     
pathdR1      = (((RK_tech-RK_0) + (wR_1*X1) + (wR_2*X2) + (R_G*Y_0*VG) + (R_AH*AH_0*VAH) + (R_BH*BH_0*VBH) + (R_AN*AN_0*VAN) + (R_BN*BN_0*VBN) )/RK_0)*100;
pathdWPC1    = (((WPC_tech-WPC_0) + (wWPC_1*X1) + (wWPC_2*X2) + (WPC_G*Y_0*VG)  + (WPC_AH*AH_0*VAH) + (WPC_BH*BH_0*VBH) + (WPC_AN*AN_0*VAN) + (WPC_BN*BN_0*VBN) )/WPC_0)*100;                      
pathdYR1     = (((YR_tech-Y_0) + (wYR_1*X1) + (wYR_2*X2) + (YR_G*Y_0*VG) + (YR_AH*AH_0*VAH) + (YR_BH*BH_0*VBH) + (YR_AN*AN_0*VAN) + (YR_BN*BN_0*VBN) )/Y_0)*100;             
pathdYH1     = ( PH_0*((YH_tech-YH_0) + (wYH_1*X1) + (wYH_2*X2) + (YH_G*Y_0*VG) + (YH_AH*AH_0*VAH) + (YH_BH*BH_0*VBH) + (YH_AN*AN_0*VAN) + (YH_BN*BN_0*VBN) )/Y_0)*100;            
pathdYN1     = ( PN_0*((YN_tech-YN_0) + (wYN_1*X1) + (wYN_2*X2) + (YN_G*Y_0*VG) + (YN_AH*AH_0*VAH) + (YN_BH*BH_0*VBH) + (YN_AN*AN_0*VAN) + (YN_BN*BN_0*VBN) )/Y_0)*100;   
pathdWH1     = (((WH_tech-WH_0) + (wWH_1*X1) + (wWH_2*X2) + (WH_G*Y_0*VG) + (WH_AH*AH_0*VAH) + (WH_BH*BH_0*VBH) + (WH_AN*AN_0*VAN) + (WH_BN*BN_0*VBN) )/WH_0)*100;           
pathdWN1     = (((WN_tech-WN_0) + (wWN_1*X1) + (wWN_2*X2) + (WN_G*Y_0*VG) + (WN_AH*AH_0*VAH) + (WN_BH*BH_0*VBH) + (WN_AN*AN_0*VAN) + (WN_BN*BN_0*VBN) )/WN_0)*100;           
pathdWHPC1   = (((WHPC_tech-WHPC_0) + (wWHPC_1*X1) + (wWHPC_2*X2) + (WHPC_G*Y_0*VG)  + (WHPC_AH*AH_0*VAH) + (WHPC_BH*BH_0*VBH) + (WHPC_AN*AN_0*VAN) + (WHPC_BN*BN_0*VBN) )/WHPC_0)*100;
pathdWNPC1   = (((WNPC_tech-WNPC_0) + (wWNPC_1*X1) + (wWNPC_2*X2) + (WNPC_G*Y_0*VG)  + (WNPC_AH*AH_0*VAH) + (WNPC_BH*BH_0*VBH) + (WNPC_AN*AN_0*VAN) + (WNPC_BN*BN_0*VBN) )/WNPC_0)*100;
pathdRPH1     = ((((RK_tech/PH_tech)-(RK_0/PH_0)) + (wRPH_1*X1) + (wRPH_2*X2) + (RPH_G*Y_0*VG) + (RPH_AH*AH_0*VAH) + (RPH_BH*BH_0*VBH) + (RPH_AN*AN_0*VAN) + (RPH_BN*BN_0*VBN) )/(RK_0/PH_0))*100;
pathdRPN1     = ((((RK_tech/PN_tech)-(RK_0/PN_0)) + (wRPN_1*X1) + (wRPN_2*X2) + (RPN_G*Y_0*VG) + (RPN_AH*AH_0*VAH) + (RPN_BH*BH_0*VBH) + (RPN_AN*AN_0*VAN) + (RPN_BN*BN_0*VBN) )/(RK_0/PN_0))*100;

pathdOmega1  = (((Omega_tech-Omega_0) + (wOmega_1*X1) + (wOmega_2*X2) + (Omega_G*Y_0*VG) + (Omega_AH*AH_0*VAH) + (Omega_BH*BH_0*VBH) + (Omega_AN*AN_0*VAN) + (Omega_BN*BN_0*VBN) )/Omega_0)*100;
pathdYHYN1   = (PH_0/PN_0)*( ((YH_tech/YN_tech)-(YH_0/YN_0)) + (wYHYN_1*X1) + (wYHYN_2*X2) + (YHYN_G*Y_0*VG) + (YHYN_AH*AH_0*VAH) + (YHYN_BH*BH_0*VBH) + (YHYN_AN*AN_0*VAN) + (YHYN_BN*BN_0*VBN) )*100;
pathdLHLN1   = (WH_0/WN_0)*( ((LH_tech/LN_tech)-(LH_0/LN_0)) + (wLHLN_1*X1) + (wLHLN_2*X2) + (LHLN_G*Y_0*VG) + (LHLN_AH*AH_0*VAH) + (LHLN_BH*BH_0*VBH) + (LHLN_AN*AN_0*VAN) + (LHLN_BN*BN_0*VBN) )*100;
pathdLHS1    = (WH_0/W_0)*( ((LH_tech/L_tech)- (LH_0/L_0)) + (wLHS_1*X1) + (wLHS_2*X2) + (LHS_G*Y_0*VG) + (LHS_AH*AH_0*VAH) + (LHS_BH*BH_0*VBH) + (LHS_AN*AN_0*VAN) + (LHS_BN*BN_0*VBN) )*100;
pathdLNS1    = (WN_0/W_0)*( ((LN_tech/L_tech)- (LN_0/L_0)) + (wLNS_1*X1) + (wLNS_2*X2) + (LNS_G*Y_0*VG) + (LNS_AH*AH_0*VAH)  + (LNS_BH*BH_0*VBH) + (LNS_AN*AN_0*VAN) + (LNS_BN*BN_0*VBN) )*100;
pathdYHS1    = PH_0*( ((YH_tech/YR_tech)- (YH_0/YR_0)) + (wYHS_1*X1) + (wYHS_2*X2) + (YHS_G*Y_0*VG) + (YHS_AH*AH_0*VAH) + (YHS_BH*BH_0*VBH) + (YHS_AN*AN_0*VAN) + (YHS_BN*BN_0*VBN) )*100;
pathdYNS1    = PN_0*( ((YN_tech/YR_tech)- (YN_0/YR_0)) + (wYNS_1*X1) + (wYNS_2*X2) + (YNS_G*Y_0*VG) + (YNS_AH*AH_0*VAH) + (YNS_BH*BH_0*VBH) + (YNS_AN*AN_0*VAN) + (YNS_BN*BN_0*VBN) )*100;
pathdWHW1    = (( ((WH_tech/W_tech)-(WH_0/W_0)) + (wWHW_1*X1) + (wWHW_2*X2) + (WHW_G*Y_0*VG) + (WHW_AH*AH_0*VAH) + (WHW_BH*BH_0*VBH) + (WHW_AN*AN_0*VAN) + (WHW_BN*BN_0*VBN) )/(WH_0/W_0) )*100; 
pathdWNW1    = (( ((WN_tech/W_tech)-(WN_0/W_0)) + (wWNW_1*X1) + (wWNW_2*X2) + (WNW_G*Y_0*VG) + (WNW_AH*AH_0*VAH) + (WNW_BH*BH_0*VBH) + (WNW_AN*AN_0*VAN) + (WNW_BN*BN_0*VBN) )/(WN_0/W_0) )*100; 
pathdKHK1    =  ( ((KH_tech/K_tech)-(KH_0/K_0)) + (wKHK_1*X1) + (wKHK_2*X2) + (KHK_G*Y_0*VG) + (KHK_AH*AH_0*VAH) + (KHK_BH*BH_0*VBH) + (KHK_AN*AN_0*VAN) + (KHK_BN*BN_0*VBN) )*100;              
pathdKNK1    =  ( ((KN_tech/K_tech)-(KN_0/K_0)) + (wKNK_1*X1) + (wKNK_2*X2) + (KNK_G*Y_0*VG) + (KNK_AH*AH_0*VAH) + (KNK_BH*BH_0*VBH) + (KNK_AN*AN_0*VAN) + (KNK_BN*BN_0*VBN) )*100;              

pathdkH1     = ( LH_0*((kH_tech-kH_0) + (wkH_1*X1) + (wkH_2*X2) + (kH_G*Y_0*VG) + (kH_AH*AH_0*VAH) + (kH_BH*BH_0*VBH) + (kH_AN*AN_0*VAN) + (kH_BN*BN_0*VBN) )/K_0)*100;
pathdkN1     = ( LN_0*((kN_tech-kN_0) + (wkN_1*X1) + (wkN_2*X2) + (kN_G*Y_0*VG) + (kN_AH*AH_0*VAH) + (kN_BH*BH_0*VBH) + (kN_AN*AN_0*VAN) + (kN_BN*BN_0*VBN) )/K_0)*100;
pathdLISH1   = ( (sLH_tech-sLH_0) + (wLISH_1*X1) + (wLISH_2*X2) + (LISH_G*Y_0*VG) + (LISH_AH*AH_0*VAH) + (LISH_BH*BH_0*VBH) + (LISH_AN*AN_0*VAN) + (LISH_BN*BN_0*VBN) )*100;
pathdLISN1   = ( (sLN_tech-sLN_0) + (wLISN_1*X1) + (wLISN_2*X2) + (LISN_G*Y_0*VG) + (LISN_AH*AH_0*VAH) + (LISN_BH*BH_0*VBH) + (LISN_AN*AN_0*VAN) + (LISN_BN*BN_0*VBN) )*100;

pathCAY1     = (( -nu_1*(wB1/(r-nu_1))*exp(nu_1*time1) + (N1*GammaG_1/(xi+r))*VBG1prime - (N2*GammaG_2/(xi+r))*VBG2prime + (B_G*Y_0/(xi+r))*VBGprime + (N1*GammaAH_1/(xiAH+r))*VBAH1prime - (N2*GammaAH_2/(xiAH+r))*VBAH2prime + (B_AH*AH_0/(xiAH+r))*VBAHprime + (N1*GammaBH_1/(xiBH+r))*VBBH1prime - (N2*GammaBH_2/(xiBH+r))*VBBH2prime + (B_BH*BH_0/(xiBH+r))*VBBHprime + (N1*GammaAN_1/(xiAN+r))*VBAN1prime - (N2*GammaAN_2/(xiAN+r))*VBAN2prime + (B_AN*AN_0/(xiAN+r))*VBANprime + (N1*GammaBN_1/(xiBN+r))*VBBN1prime - (N2*GammaBN_2/(xiBN+r))*VBBN2prime + (B_BN*BN_0/(xiBN+r))*VBBNprime )/Y_0 )*100;
pathSY1      = (( -nu_1*(wA1/(r-nu_1))*exp(nu_1*time1) + (M1*GammaG_1/(xi+r))*VBG1prime - (M2*GammaG_2/(xi+r))*VBG2prime + (A_G*Y_0/(xi+r))*VBGprime + (M1*GammaAH_1/(xiAH+r))*VBAH1prime - (M2*GammaAH_2/(xiAH+r))*VBAH2prime + (A_AH*AH_0/(xiAH+r))*VBAHprime + (M1*GammaBH_1/(xiBH+r))*VBBH1prime - (M2*GammaBH_2/(xiBH+r))*VBBH2prime + (A_BH*BH_0/(xiBH+r))*VBBHprime + (M1*GammaAN_1/(xiAN+r))*VBAN1prime - (M2*GammaAN_2/(xiAN+r))*VBAN2prime + (A_AN*AN_0/(xiAN+r))*VBANprime + (M1*GammaBN_1/(xiBN+r))*VBBN1prime - (M2*GammaBN_2/(xiBN+r))*VBBN2prime + (A_BN*BN_0/(xiBN+r))*VBBNprime )/Y_0 )*100;
pathIY1      = (( EK1*( nu_1*X11*exp(nu_1*time1) - (GammaG_1*VG1prime) - (GammaAH_1*VAH1prime) - (GammaBH_1*VBH1prime) - (GammaAN_1*VAN1prime) - (GammaBN_1*VBN1prime) ) + EK2*( (GammaG_2*VG2prime) + (GammaAH_2*VAH2prime) + (GammaBH_2*VBH2prime) + (GammaAN_2*VAN2prime) + (GammaBN_2*VBN2prime) ) )/Y_0)*100; 
pathINV1     = (PI_0/Y_0)*( (deltaK+nu_1)*X11*exp(nu_1*time1) + GammaG_1*((deltaK*VG1)-VG1prime) + GammaAH_1*((deltaK*VAH1)-VAH1prime) + GammaBH_1*((deltaK*VBH1)-VBH1prime) + GammaAN_1*((deltaK*VAN1)-VAN1prime) + GammaBN_1*((deltaK*VBN1)-VBN1prime) - GammaG_2*((deltaK*VG2)-VG2prime) - GammaG_2*((deltaK*VG2)-VG2prime) - GammaAH_2*((deltaK*VAH2)-VAH2prime) - GammaBH_2*((deltaK*VBH2)-VBH2prime) - GammaAN_2*((deltaK*VAN2)-VAN2prime) - GammaBN_2*((deltaK*VBN2)-VBN2prime) )*100;

%%%%%%%%% Transitional paths - including technology and capital utilization rates %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pathduKH1    = ( (wuKH_1*X1) + (wuKH_2*X2) + (uKH_G*Y_0*VG) + (uKH_AH*AH_0*VAH) + (uKH_BH*BH_0*VBH) + (uKH_AN*AN_0*VAN) + (uKH_BN*BN_0*VBN) )*100; 
pathduKN1    = ( (wuKN_1*X1) + (wuKN_2*X2) + (uKN_G*Y_0*VG) + (uKN_AH*AH_0*VAH) + (uKN_BH*BH_0*VBH) + (uKN_AN*AN_0*VAN) + (uKN_BN*BN_0*VBN) )*100; 
pathduK1     = ( (wuK_1*X1) + (wuK_2*X2) + (uK_G*Y_0*VG) + (uK_AH*AH_0*VAH) + (uK_BH*BH_0*VBH) + (uK_AN*AN_0*VAN) + (uK_BN*BN_0*VBN) )*100; 
pathduZH1    = ( (wuZH_1*X1) + (wuZH_2*X2) + (uZH_G*Y_0*VG) + (uZH_AH*AH_0*VAH) + (uZH_BH*BH_0*VBH) + (uZH_AN*AN_0*VAN) + (uZH_BN*BN_0*VBN) )*100;
pathduZN1    = ( (wuZN_1*X1) + (wuZN_2*X2) + (uZN_G*Y_0*VG) + (uZN_AH*AH_0*VAH) + (uZN_BH*BH_0*VBH) + (uZN_AN*AN_0*VAN) + (uZN_BN*BN_0*VBN) )*100;
pathdtildeZH1 = (( (ZH_tech-ZH_0) + (wtildeZH_1*X1) + (wtildeZH_2*X2) + (tildeZH_G*Y_0*VG) + (tildeZH_AH*AH_0*VAH) + (tildeZH_BH*BH_0*VBH) + (tildeZH_AN*AN_0*VAN) + (tildeZH_BN*BN_0*VBN) )/ZH_0)*100;
pathdtildeZN1 = (( (ZN_tech-ZN_0) + (wtildeZN_1*X1) + (wtildeZN_2*X2) + (tildeZN_G*Y_0*VG) + (tildeZN_AH*AH_0*VAH) + (tildeZN_BH*BH_0*VBH) + (tildeZN_AN*AN_0*VAN) + (tildeZN_BN*BN_0*VBN) )/ZN_0)*100;
pathdtildeZ1  = (( (Z_tech-Z_0) + (wtildeZ_1*X1) + (wtildeZ_2*X2) + (tildeZ_G*Y_0*VG) + (tildeZ_AH*AH_0*VAH) + (tildeZ_BH*BH_0*VBH) + (tildeZ_AN*AN_0*VAN) + (tildeZ_BN*BN_0*VBN) )/Z_0)*100;

pathdTFPH1   = (( (ZH_tech-ZH_0) + (wTFPH_1*X1) + (wTFPH_2*X2) + (TFPH_G*Y_0*VG) + (TFPH_AH*AH_0*VAH) + (TFPH_BH*BH_0*VBH) + (TFPH_AN*AN_0*VAN) + (TFPH_BN*BN_0*VBN) )/ZH_0)*100;
pathdTFPN1   = (( (ZN_tech-ZN_0) + (wTFPN_1*X1) + (wTFPN_2*X2) + (TFPN_G*Y_0*VG) + (TFPN_AH*AH_0*VAH) + (TFPN_BH*BH_0*VBH) + (TFPN_AN*AN_0*VAN) + (TFPN_BN*BN_0*VBN) )/ZN_0)*100;
pathdTFP1    = (( (Z_tech-Z_0) + (wTFP_1*X1) + (wTFP_2*X2) + (TFP_G*Y_0*VG) + (TFP_AH*AH_0*VAH) + (TFP_BH*BH_0*VBH) + (TFP_AN*AN_0*VAN) + (TFP_BN*BN_0*VBN) )/Z_0)*100;
pathdTFPH1_check   = (( (ZH_tech-ZH_0) + (wTFPH_1_check*X1) + (wTFPH_2_check*X2) + (TFPH_G_check*Y_0*VG) + (TFPH_AH_check*AH_0*VAH) + (TFPH_BH_check*BH_0*VBH) + (TFPH_AN_check*AN_0*VAN) + (TFPH_BN_check*BN_0*VBN) )/ZH_0)*100;
pathdTFPN1_check   = (( (ZN_tech-ZN_0) + (wTFPN_1_check*X1) + (wTFPN_2_check*X2) + (TFPN_G_check*Y_0*VG) + (TFPN_AH_check*AH_0*VAH) + (TFPN_BH_check*BH_0*VBH) + (TFPN_AN_check*AN_0*VAN) + (TFPN_BN_check*BN_0*VBN) )/ZN_0)*100;
pathdTFPR1   = (( ((ZH_tech/ZN_tech)-(ZH_0/ZN_0)) + (wTFPR_1*X1) + (wTFPR_2*X2) + (TFPR_G*Y_0*VG) + (TFPR_AH*AH_0*VAH) + (TFPR_BH*BH_0*VBH) + (TFPR_AN*AN_0*VAN) + (TFPR_BN*BN_0*VBN) )/(ZH_0/ZN_0))*100;
pathduZR1    = ( (wuZR_1*X1) + (wuZR_2*X2) + (uZR_G*Y_0*VG) + (uZR_AH*AH_0*VAH) + (uZR_BH*BH_0*VBH) + (uZR_AN*AN_0*VAN) + (uZR_BN*BN_0*VBN) )*100;

pathdtildeK1    = (( (K_tech-K_0) + (wtildeK_1*X1) + (wtildeK_2*X2) + (tildeK_G*Y_0*VG) + (tildeK_AH*AH_0*VAH) + (tildeK_BH*BH_0*VBH) + (tildeK_AN*AN_0*VAN) + (tildeK_BN*BN_0*VBN) )/K_0)*100;  
pathdtildeW1    = (((W_tech-W_0) + (wtildeW_1*X1) + (wtildeW_2*X2) + (tildeW_G*Y_0*VG) + (tildeW_AH*AH_0*VAH) + (tildeW_BH*BH_0*VBH) + (tildeW_AN*AN_0*VAN) + (tildeW_BN*BN_0*VBN) )/W_0)*100;
pathdtildeR1    = (((RK_tech-RK_0) + (wtildeR_1*X1) + (wtildeR_2*X2) + (tildeR_G*Y_0*VG) + (tildeR_AH*AH_0*VAH) + (tildeR_BH*BH_0*VBH) + (tildeR_AN*AN_0*VAN) + (tildeR_BN*BN_0*VBN) )/RK_0)*100;
pathdtildeWPC1  = (((WPC_tech-WPC_0) + (wtildeWPC_1*X1) + (wtildeWPC_2*X2) + (tildeWPC_G*Y_0*VG)  + (tildeWPC_AH*AH_0*VAH) + (tildeWPC_BH*BH_0*VBH) + (tildeWPC_AN*AN_0*VAN) + (tildeWPC_BN*BN_0*VBN) )/WPC_0)*100;
pathdtildeYR1   = (((YR_tech-Y_0) + (wtildeYR_1*X1) + (wtildeYR_2*X2) + (tildeYR_G*Y_0*VG) + (tildeYR_AH*AH_0*VAH) + (tildeYR_BH*BH_0*VBH) + (tildeYR_AN*AN_0*VAN) + (tildeYR_BN*BN_0*VBN) )/Y_0)*100;
pathdtildeYH1   = ( PH_0*((YH_tech-YH_0) + (wtildeYH_1*X1) + (wtildeYH_2*X2) + (tildeYH_G*Y_0*VG) + (tildeYH_AH*AH_0*VAH) + (tildeYH_BH*BH_0*VBH) + (tildeYH_AN*AN_0*VAN) + (tildeYH_BN*BN_0*VBN) )/Y_0)*100;
pathdtildeYN1   = ( PN_0*((YN_tech-YN_0) + (wtildeYN_1*X1) + (wtildeYN_2*X2) + (tildeYN_G*Y_0*VG) + (tildeYN_AH*AH_0*VAH) + (tildeYN_BH*BH_0*VBH) + (tildeYN_AN*AN_0*VAN) + (tildeYN_BN*BN_0*VBN) )/Y_0)*100;
pathdtildeWH1   = (((WH_tech-WH_0) + (wtildeWH_1*X1) + (wtildeWH_2*X2) + (tildeWH_G*Y_0*VG) + (tildeWH_AH*AH_0*VAH) + (tildeWH_BH*BH_0*VBH) + (tildeWH_AN*AN_0*VAN) + (tildeWH_BN*BN_0*VBN) )/WH_0)*100;
pathdtildeWN1   = (((WN_tech-WN_0) + (wtildeWN_1*X1) + (wtildeWN_2*X2) + (tildeWN_G*Y_0*VG) + (tildeWN_AH*AH_0*VAH) + (tildeWN_BH*BH_0*VBH) + (tildeWN_AN*AN_0*VAN) + (tildeWN_BN*BN_0*VBN) )/WN_0)*100;
pathdtildeWHPC1 = (((WHPC_tech-WHPC_0) + (wtildeWHPC_1*X1) + (wtildeWHPC_2*X2) + (tildeWHPC_G*Y_0*VG)  + (tildeWHPC_AH*AH_0*VAH) + (tildeWHPC_BH*BH_0*VBH) + (tildeWHPC_AN*AN_0*VAN) + (tildeWHPC_BN*BN_0*VBN) )/WHPC_0)*100;
pathdtildeWNPC1 = (((WNPC_tech-WNPC_0) + (wtildeWNPC_1*X1) + (wtildeWNPC_2*X2) + (tildeWNPC_G*Y_0*VG)  + (tildeWNPC_AH*AH_0*VAH) + (tildeWNPC_BH*BH_0*VBH) + (tildeWNPC_AN*AN_0*VAN) + (tildeWNPC_BN*BN_0*VBN) )/WNPC_0)*100;
pathdtildekH1   = ( LH_0*((kH_tech-kH_0) + (wtildekH_1*X1) + (wtildekH_2*X2) + (tildekH_G*Y_0*VG) + (tildekH_AH*AH_0*VAH) + (tildekH_BH*BH_0*VBH) + (tildekH_AN*AN_0*VAN) + (tildekH_BN*BN_0*VBN) )/K_0)*100; 
pathdtildekN1   = ( LN_0*((kN_tech-kN_0) + (wtildekN_1*X1) + (wtildekN_2*X2) + (tildekN_G*Y_0*VG) + (tildekN_AH*AH_0*VAH) + (tildekN_BH*BH_0*VBH) + (tildekN_AN*AN_0*VAN) + (tildekN_BN*BN_0*VBN) )/K_0)*100;
pathdtildeRPH1  = ((((RK_tech/PH_tech)-(RK_0/PH_0)) + (wtildeRPH_1*X1) + (wtildeRPH_2*X2) + (tildeRPH_G*Y_0*VG) + (tildeRPH_AH*AH_0*VAH) + (tildeRPH_BH*BH_0*VBH) + (tildeRPH_AN*AN_0*VAN) + (tildeRPH_BN*BN_0*VBN) )/(RK_0/PH_0))*100;
pathdtildeRPN1  = ((((RK_tech/PN_tech)-(RK_0/PN_0)) + (wtildeRPN_1*X1) + (wtildeRPN_2*X2) + (tildeRPN_G*Y_0*VG) + (tildeRPN_AH*AH_0*VAH) + (tildeRPN_BH*BH_0*VBH) + (tildeRPN_AN*AN_0*VAN) + (tildeRPN_BN*BN_0*VBN) )/(RK_0/PN_0))*100;

pathdtildeOmega1 = (((Omega_tech-Omega_0) + (wtildeOmega_1*X1) + (wtildeOmega_2*X2) + (tildeOmega_G*Y_0*VG) + (tildeOmega_AH*AH_0*VAH) + (tildeOmega_BH*BH_0*VBH) + (tildeOmega_AN*AN_0*VAN) + (tildeOmega_BN*BN_0*VBN) )/Omega_0)*100;
pathdtildeYHYN1  = (PH_0/PN_0)*( ((YH_tech/YN_tech)-(YH_0/YN_0)) + (wtildeYHYN_1*X1) + (wtildeYHYN_2*X2) + (tildeYHYN_G*Y_0*VG) + (tildeYHYN_AH*AH_0*VAH) + (tildeYHYN_BH*BH_0*VBH) + (tildeYHYN_AN*AN_0*VAN) + (tildeYHYN_BN*BN_0*VBN) )*100;
pathdtildeYHS1   = PH_0*( ((YH_tech/YR_tech)- (YH_0/YR_0)) + (wtildeYHS_1*X1) + (wtildeYHS_2*X2) + (tildeYHS_G*Y_0*VG) + (tildeYHS_AH*AH_0*VAH) + (tildeYHS_BH*BH_0*VBH) + (tildeYHS_AN*AN_0*VAN) + (tildeYHS_BN*BN_0*VBN) )*100;
pathdtildeYNS1   = PN_0*( ((YN_tech/YR_tech)- (YN_0/YR_0)) + (wtildeYNS_1*X1) + (wtildeYNS_2*X2) + (tildeYNS_G*Y_0*VG) + (tildeYNS_AH*AH_0*VAH) + (tildeYNS_BH*BH_0*VBH) + (tildeYNS_AN*AN_0*VAN) + (tildeYNS_BN*BN_0*VBN) )*100;
pathdtildeWHW1   = (( ((WH_tech/W_tech)-(WH_0/W_0)) + (wtildeWHW_1*X1) + (wtildeWHW_2*X2) + (tildeWHW_G*Y_0*VG) + (tildeWHW_AH*AH_0*VAH) + (tildeWHW_BH*BH_0*VBH) + (tildeWHW_AN*AN_0*VAN) + (tildeWHW_BN*BN_0*VBN) )/(WH_0/W_0) )*100;
pathdtildeWNW1   = (( ((WN_tech/W_tech)-(WN_0/W_0)) + (wtildeWNW_1*X1) + (wtildeWNW_2*X2) + (tildeWNW_G*Y_0*VG) + (tildeWNW_AH*AH_0*VAH) + (tildeWNW_BH*BH_0*VBH) + (tildeWNW_AN*AN_0*VAN) + (tildeWNW_BN*BN_0*VBN) )/(WN_0/W_0) )*100;
pathdtildeKHK1   =  ( ((KH_tech/K_tech)-(KH_0/K_0)) + (wtildeKHK_1*X1) + (wtildeKHK_2*X2) + (tildeKHK_G*Y_0*VG) + (tildeKHK_AH*AH_0*VAH) + (tildeKHK_BH*BH_0*VBH) + (tildeKHK_AN*AN_0*VAN) + (tildeKHK_BN*BN_0*VBN) )*100;
pathdtildeKNK1   =  ( ((KN_tech/K_tech)-(KN_0/K_0)) + (wtildeKNK_1*X1) + (wtildeKNK_2*X2) + (tildeKNK_G*Y_0*VG) + (tildeKNK_AH*AH_0*VAH) + (tildeKNK_BH*BH_0*VBH) + (tildeKNK_AN*AN_0*VAN) + (tildeKNK_BN*BN_0*VBN) )*100;

% Decomposition: YHS, LNS, LISj
pathdYHS_TFPdiff1  = omegaYH_0*(1-omegaYH_0)*( (( (ZH_tech-ZH_0) + (wTFPH_1*X1) + (wTFPH_2*X2) + (TFPH_G*Y_0*VG) + (TFPH_AH*AH_0*VAH) + (TFPH_BH*BH_0*VBH) + (TFPH_AN*AN_0*VAN) + (TFPH_BN*BN_0*VBN) )/ZH_0) - (( (ZN_tech-ZN_0) + (wTFPN_1*X1) + (wTFPN_2*X2) + (TFPN_G*Y_0*VG) + (TFPN_AH*AH_0*VAH) + (TFPN_BH*BH_0*VBH) + (TFPN_AN*AN_0*VAN) + (TFPN_BN*BN_0*VBN) )/ZN_0) )*100 + omegaYH_0*(1-omegaYH_0)*( (sLH_0*(( (AH_tech-AH_0) +  (VAH*AH_0) )/AH_0) + (1-sLH_0)*(( (BH_tech-BH_0) +  (VBH*BH_0) )/BH_0) ) - (sLN_0*(( (AN_tech-AN_0) +  (VAN*AN_0) )/AN_0) + (1-sLN_0)*(( (BN_tech-BN_0) +  (VBN*BN_0) )/BN_0) ) )*100;
pathdYHS_labdiff1  = omegaYH_0*(1-omegaYH_0)*(( ((LH_tech/LN_tech)-(LH_0/LN_0)) + (wLHLN_1*X1) + (wLHLN_2*X2) + (LHLN_G*Y_0*VG) + (LHLN_AH*AH_0*VAH) + (LHLN_BH*BH_0*VBH) + (LHLN_AN*AN_0*VAN) + (LHLN_BN*BN_0*VBN) )/(LH_0/LN_0) )*100;
pathdYHS_capdiff1  = omegaYH_0*(1-omegaYH_0)*( (1-sLH_0)*( ((kH_tech-kH_0) + (wkH_1*X1) + (wkH_2*X2) + (kH_G*Y_0*VG) + (kH_AH*AH_0*VAH) + (kH_BH*BH_0*VBH) + (kH_AN*AN_0*VAN) + (kH_BN*BN_0*VBN) )/kH_0 )  - (1-sLN_0)*( ((kN_tech-kN_0) + (wkN_1*X1) + (wkN_2*X2) + (kN_G*Y_0*VG) + (kN_AH*AH_0*VAH) + (kN_BH*BH_0*VBH) + (kN_AN*AN_0*VAN) + (kN_BN*BN_0*VBN) )/kN_0 ) )*100;

pathdYNS_TFPdiff1  = -pathdYHS_TFPdiff1;
pathdYNS_labdiff1  = -pathdYHS_labdiff1;
pathdYNS_capdiff1  = -pathdYHS_capdiff1;

pathdLNS_LISdiff1  = (1-alphaL_0)*(epsilon/(1+epsilon))*( (((sLN_tech-sLN_0) + (wLISN_1*X1) + (wLISN_2*X2) + (LISN_G*Y_0*VG) + (LISN_AH*AH_0*VAH) + (LISN_BH*BH_0*VBH) + (LISN_AN*AN_0*VAN) + (LISN_BN*BN_0*VBN))/sLN_0) - (( (sL_tech-sL_0) + (wLIS_1*X1) + (wLIS_2*X2) + (LIS_G*Y_0*VG) + (LIS_AH*AH_0*VAH) + (LIS_BH*BH_0*VBH) + (LIS_AN*AN_0*VAN) + (LIS_BN*BN_0*VBN) )/sL_0) )*100;
pathdLNS_NTshare1  = (1-alphaL_0)*(epsilon/(1+epsilon))*(( (omegaYN_tech-omegaYN_0) + (womegaYN_1*X1) + (womegaYN_2*X2) + (omegaYN_G*Y_0*VG) + (omegaYN_AH*AH_0*VAH) + (omegaYN_BH*BH_0*VBH) + (omegaYN_AN*AN_0*VAN) + (omegaYN_BN*BN_0*VBN) )/omegaYN_0)*100; 
pathdLNS_FBTCdiff1 = (1-alphaL_0)*alphaL_0*(epsilon/(1+epsilon))*( (1-sLN_0)*((1-sigmaN)/sigmaN)*( (( (BN_tech-BN_0) +  (VBN*BH_0) )/BN_0) - (( (AN_tech-AN_0) +  (VAN*AN_0) )/AN_0) ) - (1-sLH_0)*((1-sigmaH)/sigmaH)*( (( (BH_tech-BH_0) +  (VBH*BH_0) )/BH_0) - (( (AH_tech-AH_0) +  (VAH*AH_0) )/AH_0) ) )*100; 

pathdLISH_FBTC1    = sLH_0*(1-sLH_0)*((1-sigmaH)/sigmaH)*( (( (BH_tech-BH_0) +  (VBH*BH_0) )/BH_0) - (( (AH_tech-AH_0) +  (VAH*AH_0) )/AH_0) )*100;
pathdLISH_cap1     = sLH_0*(1-sLH_0)*((1-sigmaH)/sigmaH)*(( (kH_tech-kH_0) + (wtildekH_1*X1) + (wtildekH_2*X2) + (tildekH_G*Y_0*VG) + (tildekH_AH*AH_0*VAH) + (tildekH_BH*BH_0*VBH) + (tildekH_AN*AN_0*VAN) + (tildekH_BN*BN_0*VBN) )/kH_0)*100;

pathdLISN_FBTC1    = sLN_0*(1-sLN_0)*((1-sigmaN)/sigmaN)*( (( (BN_tech-BN_0) +  (VBN*BN_0) )/BN_0) - (( (AN_tech-AN_0) +  (VAN*AN_0) )/AN_0) )*100;                                                                                             
pathdLISN_cap1     = sLN_0*(1-sLN_0)*((1-sigmaN)/sigmaN)*(( (kN_tech-kN_0) + (wtildekN_1*X1) + (wtildekN_2*X2) + (tildekN_G*Y_0*VG) + (tildekN_AH*AH_0*VAH) + (tildekN_BH*BH_0*VBH) + (tildekN_AN*AN_0*VAN) + (tildekN_BN*BN_0*VBN) )/kN_0)*100;

% IRF
timetemp = [time0 time1];
pathdGHY_tech   = [pathdGY0  pathdGHY1];
pathdGFY_tech   = [pathdGY0  pathdGFY1];
pathdGNY_tech   = [pathdGY0  pathdGNY1];
pathdGY_tech    = [pathdGY0  pathdGY1];
pathdAH_tech    = [pathdZH0  pathdAH1];
pathdBH_tech    = [pathdZH0  pathdBH1];
pathdAN_tech    = [pathdZN0  pathdAN1];
pathdBN_tech    = [pathdZN0  pathdBN1];
pathdFBTCH_tech = [pathdZH0  pathdFBTCH1];
pathdFBTCN_tech = [pathdZN0  pathdFBTCN1];
pathdZH_tech    = [pathdZH0  pathdZH1];
pathdZN_tech    = [pathdZN0  pathdZN1];
pathdQ_tech     = [pathdQ0  pathdQ1];
pathdQPI_tech   = [pathdQ0  pathdQPI1];
pathdPH_tech    = [pathdP0  pathdPH1];
pathdPN_tech    = [pathdP0  pathdPN1];
pathdP_tech     = [pathdP0  pathdP1]; 
pathdCY_tech    = [pathCY0  pathdCY1];                                             
pathdL_tech     = [pathdL0  pathdL1];
pathdK_tech     = [pathdK0  pathdK1];
pathdLH_tech    = [pathdLH0 pathdLH1];             
pathdLN_tech    = [pathdLN0 pathdLN1];  
pathdW_tech     = [pathdW0 pathdW1]; 
pathdR_tech     = [pathdR0 pathdR1]; 
pathdWPC_tech   = [pathdWPC0 pathdWPC1];  
pathdYR_tech    = [pathdY0 pathdYR1];
pathdYH_tech    = [pathdY0 pathdYH1];               
pathdYN_tech    = [pathdY0 pathdYN1];               
pathdWH_tech    = [pathdWH0  pathdWH1];              
pathdWN_tech    = [pathdWN0  pathdWN1]; 
pathdWHPC_tech  = [pathdWH0 pathdWHPC1];
pathdWNPC_tech  = [pathdWN0 pathdWNPC1];
pathdRPH_tech   = [pathdR0 pathdRPH1];
pathdRPN_tech   = [pathdR0 pathdRPN1];

pathdLHS_tech   = [pathdLH0 pathdLHS1];             
pathdLNS_tech   = [pathdLN0 pathdLNS1];
pathdYHS_tech   = [pathdY0 pathdYHS1];             
pathdYNS_tech   = [pathdY0 pathdYNS1];
pathdWHW_tech   = [pathdWH0 pathdWHW1];
pathdWNW_tech   = [pathdWN0 pathdWNW1];
pathdKHK_tech   = [pathdkH0 pathdKHK1];             
pathdKNK_tech   = [pathdkN0 pathdKNK1];

pathdkH_tech    = [pathdkH0 pathdkH1];             
pathdkN_tech    = [pathdkN0 pathdkN1];
pathdLISH_tech  = [pathdLISH0 pathdLISH1];             
pathdLISN_tech  = [pathdLISN0 pathdLISN1];

pathdOmega_tech = [pathdOmega0 pathdOmega1];         
pathdYHYN_tech  = [pathdYHYN0 pathdYHYN1];           
pathdLHLN_tech  = [pathdLHLN0 pathdLHLN1];

pathIY_tech     = [pathIY0  pathIY1];                        
pathCAY_tech    = [pathCAY0 pathCAY1];               
pathSY_tech     = [pathSY0  pathSY1];
pathINV_tech    = [pathIY0  pathINV1]; 

% IRF including technology and capital utilization rates
pathduKH_tech   = [pathdkH0 pathduKH1];             
pathduKN_tech   = [pathdkN0 pathduKN1];
pathduK_tech    = [pathdkN0 pathduK1];
pathduZH_tech   = [pathdkH0 pathduZH1];             
pathduZN_tech   = [pathdkN0 pathduZN1];
pathdtildeZH_tech  = [pathdkH0 pathdtildeZH1];             
pathdtildeZN_tech  = [pathdkN0 pathdtildeZN1];
pathdtildeZ_tech   = [pathdkN0 pathdtildeZ1];
pathdTFPH_tech  = [pathdkH0 pathdTFPH1];             
pathdTFPN_tech  = [pathdkN0 pathdTFPN1];
pathdTFP_tech   = [pathdkN0 pathdTFP1];
pathdTFPH_check_tech  = [pathdkH0 pathdTFPH1_check];             
pathdTFPN_check_tech  = [pathdkN0 pathdTFPN1_check];
pathdTFPR_tech  = [pathdkH0 pathdTFPR1];
pathduZR_tech   = [pathdkN0 pathduZR1]; 

pathdtildeK_tech     = [pathdK0  pathdtildeK1];            
pathdtildeW_tech     = [pathdW0 pathdtildeW1];           
pathdtildeR_tech     = [pathdR0 pathdtildeR1];           
pathdtildeWPC_tech   = [pathdWPC0 pathdtildeWPC1];                  
pathdtildeYR_tech    = [pathdY0 pathdtildeYR1];          
pathdtildeYH_tech    = [pathdY0 pathdtildeYH1];          
pathdtildeYN_tech    = [pathdY0 pathdtildeYN1];          
pathdtildeWH_tech    = [pathdWH0  pathdtildeWH1];        
pathdtildeWN_tech    = [pathdWN0  pathdtildeWN1];        
pathdtildeWHPC_tech  = [pathdWH0 pathdtildeWHPC1];       
pathdtildeWNPC_tech  = [pathdWN0 pathdtildeWNPC1];    
pathdtildeRPH_tech    = [pathdR0  pathdtildeRPH1];        
pathdtildeRPN_tech    = [pathdR0  pathdtildeRPN1];

pathdtildeYHS_tech   = [pathdY0 pathdtildeYHS1];             
pathdtildeYNS_tech   = [pathdY0 pathdtildeYNS1];
pathdtildeWHW_tech   = [pathdWH0 pathdtildeWHW1];          
pathdtildeWNW_tech   = [pathdWN0 pathdtildeWNW1];          
pathdtildeKHK_tech   = [pathdkH0 pathdtildeKHK1];          
pathdtildeKNK_tech   = [pathdkN0 pathdtildeKNK1];          
                                                          
pathdtildekH_tech    = [pathdkH0 pathdtildekH1];           
pathdtildekN_tech    = [pathdkN0 pathdtildekN1];           
pathdtildeOmega_tech = [pathdOmega0 pathdtildeOmega1];     
pathdtildeYHYN_tech  = [pathdYHYN0 pathdtildeYHYN1]; 

% DECOMPOSITION: IRF
pathdYHS_TFPdiff_tech  = [pathdK0 pathdYHS_TFPdiff1];    
pathdYHS_labdiff_tech  = [pathdK0 pathdYHS_labdiff1];    
pathdYHS_capdiff_tech  = [pathdK0 pathdYHS_capdiff1];    

pathdYNS_TFPdiff_tech  = [pathdK0 pathdYNS_TFPdiff1]; 
pathdYNS_labdiff_tech  = [pathdK0 pathdYNS_labdiff1]; 
pathdYNS_capdiff_tech  = [pathdK0 pathdYNS_capdiff1]; 
                                                         
pathdLNS_LISdiff_tech  = [pathdK0 pathdLNS_LISdiff1];    
pathdLNS_NTshare_tech  = [pathdK0 pathdLNS_NTshare1];    
pathdLNS_FBTCdiff_tech = [pathdK0 pathdLNS_FBTCdiff1];   
                                                         
pathdLISH_FBTC_tech    = [pathdK0 pathdLISH_FBTC1];      
pathdLISH_cap_tech     = [pathdK0 pathdLISH_cap1];       
                                                         
pathdLISN_FBTC_tech    = [pathdK0 pathdLISN_FBTC1];      
pathdLISN_cap_tech     = [pathdK0 pathdLISN_cap1];          

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% Dynamic and steadty-state effects of a Permanent increase in ZH/ZN %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Impact effects of fiscal shock: dynamic processes 
VG0            = 1 - (1-barg);                   
VG10           = 1 - ThetaG_1;                   
VG20           = 1 - ThetaG_2;                   
VAH0           = 1 - (1-baraH);                  
VBH0           = 1 - (1-barbH);                  
VAN0           = 1 - (1-baraN);                  
VBN0           = 1 - (1-barbN);                  
VAH10          = 1 - ThetaAH_1;                  
VAH20          = 1 - ThetaAH_2;                  
VBH10          = 1 - ThetaBH_1;                  
VBH20          = 1 - ThetaBH_2;                  
VAN10          = 1 - ThetaAN_1;                  
VAN20          = 1 - ThetaAN_2;                  
VBN10          = 1 - ThetaBN_1;                  
VBN20          = 1 - ThetaBN_2;                  
VG1prime0      = xi - chi*ThetaG_1;            
VG2prime0      = xi - chi*ThetaG_2;            
VGprime0       = xi - chi*(1-barg);            
VAH1prime0     = xiAH - (chiAH*ThetaAH_1);         
VAH2prime0     = xiAH - (chiAH*ThetaAH_2);         
VBH1prime0     = xiBH - (chiBH*ThetaBH_1);         
VBH2prime0     = xiBH - (chiBH*ThetaBH_2);         
VAN1prime0     = xiAN - (chiAN*ThetaAN_1);         
VAN2prime0     = xiAN - (chiAN*ThetaAN_2);         
VBN1prime0     = xiBN - (chiBN*ThetaBN_1);         
VBN2prime0     = xiBN - (chiBN*ThetaBN_2);         
                                                 
VBG1prime0     = xi - (chi*ThetaG_1prime);       
VBG2prime0     = xi - (chi*ThetaG_2prime);       
VBGprime0      = xi - (chi*ThetaG_prime);        
                                                 
VBAH1prime0     = xiAH - (chiAH*ThetaAH_1prime); 
VBAH2prime0     = xiAH - (chiAH*ThetaAH_2prime); 
VBBH1prime0     = xiBH - (chiBH*ThetaBH_1prime); 
VBBH2prime0     = xiBH - (chiBH*ThetaBH_2prime); 
VBAN1prime0     = xiAN - (chiAN*ThetaAN_1prime); 
VBAN2prime0     = xiAN - (chiAN*ThetaAN_2prime); 
VBBN1prime0     = xiBN - (chiBN*ThetaBN_1prime); 
VBBN2prime0     = xiBN - (chiBN*ThetaBN_2prime); 
VBAHprime0      = xiAH - (chiAH*ThetaAH_prime);  
VBBHprime0      = xiBH - (chiBH*ThetaBH_prime);  
VBANprime0      = xiAN - (chiAN*ThetaAN_prime);  
VBBNprime0      = xiBN - (chiBN*ThetaBN_prime);     

X10   = X11 + (GammaG_1*VG10) + (GammaAH_1*VAH10) + (GammaBH_1*VBH10) + (GammaAN_1*VAN10) + (GammaBN_1*VBN10);
X20   = -(GammaG_2*VG20) - (GammaAH_2*VAH20) - (GammaBH_2*VBH20) - (GammaAN_2*VAN20) - (GammaBN_2*VBN20); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                 
dGHYtime0_tech    = ( PH_0*( (GH_0-GH_0) +  (GH_G*Y_0*VG0) )/Y_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
dGNYtime0_tech    = ( PN_0*( (GN_0-GN_0) +  (GN_G*Y_0*VG0) )/Y_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
dGFYtime0_tech    = ( ( (GF_0-GF_0) +  (GF_G*Y_0*VG0) )/Y_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
dGYtime0_tech     = ( ( (G_0-G_0) +  (VG0*Y_0) )/Y_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
dAHtime0_tech     = (( (AH_tech-AH_0) +  (VAH0*AH_0) )/AH_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
dBHtime0_tech     = (( (BH_tech-BH_0) +  (VBH0*BH_0) )/BH_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
dANtime0_tech     = (( (AN_tech-AN_0) +  (VAN0*AN_0) )/AN_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
dBNtime0_tech     = (( (BN_tech-BN_0) +  (VBN0*BN_0) )/BN_0)*100;  
dZHtime0_tech     = (sLH_0*(( (AH_tech-AH_0) +  (VAH0*AH_0) )/AH_0) + (1-sLH_0)*(( (BH_tech-BH_0) +  (VBH0*BH_0) )/BH_0) )*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
dZNtime0_tech     = (sLN_0*(( (AN_tech-AN_0) +  (VAN0*AN_0) )/AN_0) + (1-sLN_0)*(( (BN_tech-BN_0) +  (VBN0*BN_0) )/BN_0) )*100; 
dFBTCHtime0_tech  = ((1-sigmaH)/sigmaH)*( (( (BH_tech-BH_0) +  (VBH0*BH_0) )/BH_0) - (( (AH_tech-AH_0) +  (VAH0*AH_0) )/AH_0) )*100; 
dFBTCNtime0_tech  = ((1-sigmaN)/sigmaN)*( (( (BN_tech-BN_0) +  (VBN0*BH_0) )/BN_0) - (( (AN_tech-AN_0) +  (VAN0*AN_0) )/AN_0) )*100; 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
dKtime0_tech      = (((K_tech-K_0) + (X10 + X20) )/K_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
dQtime0_tech      = (((PI_tech-PI_0) + (omega_21*X10) + (omega_22*X20) )/PI_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
dPtime0_tech      = (((P_tech-P_0) + (wP_1*X10) + (wP_2*X20) + (P_G*Y_0*VG0) + (P_AH*AH_0*VAH0) + (P_BH*BH_0*VBH0) + (P_AN*AN_0*VAN0) + (P_BN*BN_0*VBN0) )/P_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
dPHtime0_tech     = (((PH_tech-PH_0) + (wPH_1*X10) + (wPH_2*X20) + (PH_G*Y_0*VG0) + (PH_AH*AH_0*VAH0) + (PH_BH*BH_0*VBH0) + (PH_AN*AN_0*VAN0) + (PH_BN*BN_0*VBN0) )/PH_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
dPNtime0_tech     = (((PN_tech-PN_0) + (wPN_1*X10) + (wPN_2*X20) + (PN_G*Y_0*VG0) + (PN_AH*AH_0*VAH0) + (PN_BH*BH_0*VBH0) + (PN_AN*AN_0*VAN0) + (PN_BN*BN_0*VBN0) )/PN_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
dCYtime0_tech     = ( PC_0*((C_tech-C_0) + (wC_1*X10) + (wC_2*X20) + (C_G*Y_0*VG0) + (C_AH*AH_0*VAH0) + (C_BH*BH_0*VBH0) + (C_AN*AN_0*VAN0) + (C_BN*BN_0*VBN0) )/Y_0 )*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
dQPItime0_tech    = ( (wQPI_1*X10) + (wQPI_2*X20) + (wQPI_G*Y_0*VG0) + (wQPI_AH*AH_0*VAH0) + (wQPI_BH*BH_0*VBH0) + (wQPI_AN*AN_0*VAN0) + (wQPI_BN*BN_0*VBN0) )*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
dLtime0_tech      = (((L_tech-L_0)  + (wL_1*X10) + (wL_2*X20) + (L_G*Y_0*VG0) + (L_AH*AH_0*VAH0) + (L_BH*BH_0*VBH0) + (L_AN*AN_0*VAN0) + (L_BN*BN_0*VBN0) )/L_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
dLHtime0_tech     = ( (WH_0/W_0)*((LH_tech-LH_0) + (wLH_1*X10) + (wLH_2*X20) + (LH_G*Y_0*VG0) + (LH_AH*AH_0*VAH0) + (LH_BH*BH_0*VBH0) + (LH_AN*AN_0*VAN0) + (LH_BN*BN_0*VBN0) )/L_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
dLNtime0_tech     = ( (WN_0/W_0)*((LN_tech-LN_0) + (wLN_1*X10) + (wLN_2*X20) + (LN_G*Y_0*VG0) + (LN_AH*AH_0*VAH0) + (LN_BH*BH_0*VBH0) + (LN_AN*AN_0*VAN0) + (LN_BN*BN_0*VBN0) )/L_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
dWtime0_tech      = (((W_tech-W_0) + (wW_1*X10) + (wW_2*X20) + (W_G*Y_0*VG0) + (W_AH*AH_0*VAH0) + (W_BH*BH_0*VBH0) + (W_AN*AN_0*VAN0) + (W_BN*BN_0*VBN0) )/W_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
dRtime0_tech      = (((RK_tech-RK_0) + (wR_1*X10) + (wR_2*X20) + (R_G*Y_0*VG0) + (R_AH*AH_0*VAH0) + (R_BH*BH_0*VBH0) + (R_AN*AN_0*VAN0) + (R_BN*BN_0*VBN0) )/RK_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
dWPCtime0_tech    = (((WPC_tech-WPC_0) + (wWPC_1*X10) + (wWPC_2*X20) + (WPC_G*Y_0*VG0)  + (WPC_AH*AH_0*VAH0) + (WPC_BH*BH_0*VBH0) + (WPC_AN*AN_0*VAN0) + (WPC_BN*BN_0*VBN0) )/WPC_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
dYRtime0_tech     = (((YR_tech-Y_0) + (wYR_1*X10) + (wYR_2*X20) + (YR_G*Y_0*VG0) + (YR_AH*AH_0*VAH0) + (YR_BH*BH_0*VBH0) + (YR_AN*AN_0*VAN0) + (YR_BN*BN_0*VBN0) )/Y_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
dYHtime0_tech     = (PH_0*((YH_tech-YH_0) + (wYH_1*X10) + (wYH_2*X20) + (YH_G*Y_0*VG0) + (YH_AH*AH_0*VAH0) + (YH_BH*BH_0*VBH0) + (YH_AN*AN_0*VAN0) + (YH_BN*BN_0*VBN0) )/Y_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
dYNtime0_tech     = (PN_0*((YN_tech-YN_0) + (wYN_1*X10) + (wYN_2*X20) + (YN_G*Y_0*VG0) + (YN_AH*AH_0*VAH0) + (YN_BH*BH_0*VBH0) + (YN_AN*AN_0*VAN0) + (YN_BN*BN_0*VBN0) )/Y_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
dWHtime0_tech     = (((WH_tech-WH_0) + (wWH_1*X10) + (wWH_2*X20) + (WH_G*Y_0*VG0) + (WH_AH*AH_0*VAH0) + (WH_BH*BH_0*VBH0) + (WH_AN*AN_0*VAN0) + (WH_BN*BN_0*VBN0) )/WH_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
dWNtime0_tech     = (((WN_tech-WN_0) + (wWN_1*X10) + (wWN_2*X20) + (WN_G*Y_0*VG0) + (WN_AH*AH_0*VAH0) + (WN_BH*BH_0*VBH0) + (WN_AN*AN_0*VAN0) + (WN_BN*BN_0*VBN0) )/WN_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
dWHPCtime0_tech   = (((WHPC_tech-WHPC_0) + (wWHPC_1*X10) + (wWHPC_2*X20) + (WHPC_G*Y_0*VG0)  + (WHPC_AH*AH_0*VAH0) + (WHPC_BH*BH_0*VBH0) + (WHPC_AN*AN_0*VAN0) + (WHPC_BN*BN_0*VBN0) )/WHPC_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
dWNPCtime0_tech   = (((WNPC_tech-WNPC_0) + (wWNPC_1*X10) + (wWNPC_2*X20) + (WNPC_G*Y_0*VG0)  + (WNPC_AH*AH_0*VAH0) + (WNPC_BH*BH_0*VBH0) + (WNPC_AN*AN_0*VAN0) + (WNPC_BN*BN_0*VBN0) )/WNPC_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
dOmegatime0_tech  = (((Omega_tech-Omega_0) + (wOmega_1*X10) + (wOmega_2*X20) + (Omega_G*Y_0*VG0) + (Omega_AH*AH_0*VAH0) + (Omega_BH*BH_0*VBH0) + (Omega_AN*AN_0*VAN0) + (Omega_BN*BN_0*VBN0) )/Omega_0)*100;
dYHYNtime0_tech   = (PH_0/PN_0)*( ((YH_tech/YN_tech)-(YH_0/YN_0)) + (wYHYN_1*X10) + (wYHYN_2*X20) + (YHYN_G*Y_0*VG0) + (YHYN_AH*AH_0*VAH0) + (YHYN_BH*BH_0*VBH0) + (YHYN_AN*AN_0*VAN0) + (YHYN_BN*BN_0*VBN0) )*100;
dLHLNtime0_tech   = (WH_0/WN_0)*( ((LH_tech/LN_tech)-(LH_0/LN_0)) + (wLHLN_1*X10) + (wLHLN_2*X20) + (LHLN_G*Y_0*VG0) + (LHLN_AH*AH_0*VAH0) + (LHLN_BH*BH_0*VBH0) + (LHLN_AN*AN_0*VAN0) + (LHLN_BN*BN_0*VBN0) )*100;
dLHStime0_tech    = (WH_0/W_0)*( ((LH_tech/L_tech)- (LH_0/L_0)) + (wLHS_1*X10) + (wLHS_2*X20) + (LHS_G*Y_0*VG0) + (LHS_AH*AH_0*VAH0) + (LHS_BH*BH_0*VBH0) + (LHS_AN*AN_0*VAN0) + (LHS_BN*BN_0*VBN0) )*100;
dLNStime0_tech    = (WN_0/W_0)*( ((LN_tech/L_tech)- (LN_0/L_0)) + (wLNS_1*X10) + (wLNS_2*X20) + (LNS_G*Y_0*VG0) + (LNS_AH*AH_0*VAH0) + (LNS_BH*BH_0*VBH0) + (LNS_AN*AN_0*VAN0) + (LNS_BN*BN_0*VBN0) )*100;
dYHStime0_tech    = PH_0*( ((YH_tech/YR_tech)- (YH_0/YR_0)) + (wYHS_1*X10) + (wYHS_2*X20) + (YHS_G*Y_0*VG0) + (YHS_AH*AH_0*VAH0) + (YHS_BH*BH_0*VBH0) + (YHS_AN*AN_0*VAN0) + (YHS_BN*BN_0*VBN0) )*100;
dYNStime0_tech    = PN_0*( ((YN_tech/YR_tech)- (YN_0/YR_0)) + (wYNS_1*X10) + (wYNS_2*X20) + (YNS_G*Y_0*VG0) + (YNS_AH*AH_0*VAH0) + (YNS_BH*BH_0*VBH0) + (YNS_AN*AN_0*VAN0) + (YNS_BN*BN_0*VBN0) )*100;
dWHWtime0_tech    = (( ((WH_tech/W_tech)-(WH_0/W_0)) + (wWHW_1*X10) + (wWHW_2*X20) + (WHW_G*Y_0*VG0) + (WHW_AH*AH_0*VAH0) + (WHW_BH*BH_0*VBH0) + (WHW_AN*AN_0*VAN0) + (WHW_BN*BN_0*VBN0) )/(WH_0/W_0) )*100;
dWNWtime0_tech    = (( ((WN_tech/W_tech)-(WN_0/W_0)) + (wWNW_1*X10) + (wWNW_2*X20) + (WNW_G*Y_0*VG0) + (WNW_AH*AH_0*VAH0) + (WNW_BH*BH_0*VBH0) + (WNW_AN*AN_0*VAN0) + (WNW_BN*BN_0*VBN0) )/(WN_0/W_0) )*100;
dKHKtime0_tech    =  ( ((KH_tech/K_tech)-(KH_0/K_0)) + (wKHK_1*X10) + (wKHK_2*X20) + (KHK_G*Y_0*VG0) + (KHK_AH*AH_0*VAH0) + (KHK_BH*BH_0*VBH0) + (KHK_AN*AN_0*VAN0) + (KHK_BN*BN_0*VBN0) )*100;
dKNKtime0_tech    =  ( ((KN_tech/K_tech)-(KN_0/K_0)) + (wKNK_1*X10) + (wKNK_2*X20) + (KNK_G*Y_0*VG0) + (KNK_AH*AH_0*VAH0) + (KNK_BH*BH_0*VBH0) + (KNK_AN*AN_0*VAN0) + (KNK_BN*BN_0*VBN0) )*100;
dRPHtime0_tech    = ((((RK_tech/PH_tech)-(RK_0/PH_0)) + (wRPH_1*X10) + (wRPH_2*X20) + (RPH_G*Y_0*VG0) + (RPH_AH*AH_0*VAH0) + (RPH_BH*BH_0*VBH0) + (RPH_AN*AN_0*VAN0) + (RPH_BN*BN_0*VBN0) )/(RK_0/PH_0))*100;                                       
dRPNtime0_tech    = ((((RK_tech/PN_tech)-(RK_0/PN_0)) + (wRPN_1*X10) + (wRPN_2*X20) + (RPN_G*Y_0*VG0) + (RPN_AH*AH_0*VAH0) + (RPN_BH*BH_0*VBH0) + (RPN_AN*AN_0*VAN0) + (RPN_BN*BN_0*VBN0) )/(RK_0/PN_0))*100;     
dRtime0_tech      = ( ((RK_tech-RK_0) + (wR_1*X10) + (wR_2*X20) + (R_G*Y_0*VG0) + (R_AH*AH_0*VAH0) + (R_BH*BH_0*VBH0) + (R_AN*AN_0*VAN0) + (R_BN*BN_0*VBN0) )/RK_0)*100 

dkHtime0_tech     = ( LH_0*((kH_tech-kH_0) + (wkH_1*X10) + (wkH_2*X20) + (kH_G*Y_0*VG0) + (kH_AH*AH_0*VAH0) + (kH_BH*BH_0*VBH0) + (kH_AN*AN_0*VAN0) + (kH_BN*BN_0*VBN0) )/K_0)*100;
dkNtime0_tech     = ( LN_0*((kN_tech-kN_0) + (wkN_1*X10) + (wkN_2*X20) + (kN_G*Y_0*VG0) + (kN_AH*AH_0*VAH0) + (kN_BH*BH_0*VBH0) + (kN_AN*AN_0*VAN0) + (kN_BN*BN_0*VBN0) )/K_0)*100;
dLISHtime0_tech   = ( (sLH_tech-sLH_0) + (wLISH_1*X10) + (wLISH_2*X20) + (LISH_G*Y_0*VG0) + (LISH_AH*AH_0*VAH0) + (LISH_BH*BH_0*VBH0) + (LISH_AN*AN_0*VAN0) + (LISH_BN*BN_0*VBN0) )*100;
dLISNtime0_tech   = ( (sLN_tech-sLN_0) + (wLISN_1*X10) + (wLISN_2*X20) + (LISN_G*Y_0*VG0) + (LISN_AH*AH_0*VAH0) + (LISN_BH*BH_0*VBH0) + (LISN_AN*AN_0*VAN0) + (LISN_BN*BN_0*VBN0) )*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
CAYtime0_tech     = (( -nu_1*(wB1/(r-nu_1)) + (N1*GammaG_1/(xi+r))*VBG1prime0 - (N2*GammaG_2/(xi+r))*VBG2prime0 + (B_G*Y_0/(xi+r))*VBGprime0 + (N1*GammaAH_1/(xiAH+r))*VBAH1prime0 - (N2*GammaAH_2/(xiAH+r))*VBAH2prime0 + (B_AH*AH_0/(xiAH+r))*VBAHprime0 + (N1*GammaBH_1/(xiBH+r))*VBBH1prime0 - (N2*GammaBH_2/(xiBH+r))*VBBH2prime0 + (B_BH*BH_0/(xiBH+r))*VBBHprime0 + (N1*GammaAN_1/(xiAN+r))*VBAN1prime0 - (N2*GammaAN_2/(xiAN+r))*VBAN2prime0 + (B_AN*AN_0/(xiAN+r))*VBANprime0 + (N1*GammaBN_1/(xiBN+r))*VBBN1prime0 - (N2*GammaBN_2/(xiBN+r))*VBBN2prime0 + (B_BN*BN_0/(xiBN+r))*VBBNprime0 )/Y_0 )*100;                                                                                                                                                                                                                            
SYtime0_tech      = (( -nu_1*(wA1/(r-nu_1)) + (M1*GammaG_1/(xi+r))*VBG1prime0 - (M2*GammaG_2/(xi+r))*VBG2prime0 + (A_G*Y_0/(xi+r))*VBGprime0 + (M1*GammaAH_1/(xiAH+r))*VBAH1prime0 - (M2*GammaAH_2/(xiAH+r))*VBAH2prime0 + (A_AH*AH_0/(xiAH+r))*VBAHprime0 + (M1*GammaBH_1/(xiBH+r))*VBBH1prime0 - (M2*GammaBH_2/(xiBH+r))*VBBH2prime0 + (A_BH*BH_0/(xiBH+r))*VBBHprime0 + (M1*GammaAN_1/(xiAN+r))*VBAN1prime0 - (M2*GammaAN_2/(xiAN+r))*VBAN2prime0 + (A_AN*AN_0/(xiAN+r))*VBANprime0 + (M1*GammaBN_1/(xiBN+r))*VBBN1prime0 - (M2*GammaBN_2/(xiBN+r))*VBBN2prime0 + (A_BN*BN_0/(xiBN+r))*VBBNprime0 )/Y_0 )*100;                                                                                                                                                                                                                            
IYtime0_tech      = (( EK1*( (nu_1*X11) - (GammaG_1*VG1prime0) - (GammaAH_1*VAH1prime0) - (GammaBH_1*VBH1prime0) - (GammaAN_1*VAN1prime0) - (GammaBN_1*VBN1prime0) ) + EK2*( (GammaG_2*VG2prime0) + (GammaAH_2*VAH2prime0) + (GammaBH_2*VBH2prime0) + (GammaAN_2*VAN2prime0) + (GammaBN_2*VBN2prime0) ) )/Y_0)*100;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
INVtime0_tech     = (PI_0/Y_0)*( (deltaK+nu_1)*X11 + GammaG_1*((deltaK*VG10)-VG1prime0) + GammaAH_1*((deltaK*VAH10)-VAH1prime0) + GammaBH_1*((deltaK*VBH10)-VBH1prime0) + GammaAN_1*((deltaK*VAN10)-VAN1prime0) + GammaBN_1*((deltaK*VBN10)-VBN1prime0) - GammaG_2*((deltaK*VG20)-VG2prime0) - GammaG_2*((deltaK*VG20)-VG2prime0) - GammaAH_2*((deltaK*VAH20)-VAH2prime0) - GammaBH_2*((deltaK*VBH20)-VBH2prime0) - GammaAN_2*((deltaK*VAN20)-VAN2prime0) - GammaBN_2*((deltaK*VBN20)-VBN2prime0) )*100;

CAYtime0_tech_check = SYtime0_tech - IYtime0_tech;

%%%%%%%%%%%%%%%%% Including capital and technology utilization rates
%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
duKHtime0_tech        = ( (wuKH_1*X10) + (wuKH_2*X20) + (uKH_G*Y_0*VG0) + (uKH_AH*AH_0*VAH0) + (uKH_BH*BH_0*VBH0) + (uKH_AN*AN_0*VAN0) + (uKH_BN*BN_0*VBN0) )*100;                                                                                    
duKNtime0_tech        = ( (wuKN_1*X10) + (wuKN_2*X20) + (uKN_G*Y_0*VG0) + (uKN_AH*AH_0*VAH0) + (uKN_BH*BH_0*VBH0) + (uKN_AN*AN_0*VAN0) + (uKN_BN*BN_0*VBN0) )*100;                                                                                    
duKtime0_tech         = ( (wuK_1*X10) + (wuK_2*X20) + (uK_G*Y_0*VG0) + (uK_AH*AH_0*VAH0) + (uK_BH*BH_0*VBH0) + (uK_AN*AN_0*VAN0) + (uK_BN*BN_0*VBN0) )*100;                                                                                           
duZHtime0_tech        = ( (wuZH_1*X10) + (wuZH_2*X20) + (uZH_G*Y_0*VG0) + (uZH_AH*AH_0*VAH0) + (uZH_BH*BH_0*VBH0) + (uZH_AN*AN_0*VAN0) + (uZH_BN*BN_0*VBN0) )*100;                                                                                    
duZNtime0_tech        = ( (wuZN_1*X10) + (wuZN_2*X20) + (uZN_G*Y_0*VG0) + (uZN_AH*AH_0*VAH0) + (uZN_BH*BH_0*VBH0) + (uZN_AN*AN_0*VAN0) + (uZN_BN*BN_0*VBN0) )*100;                                                                                    
dtildeZHtime0_tech    = (( (ZH_tech-ZH_0) + (wtildeZH_1*X10) + (wtildeZH_2*X20) + (tildeZH_G*Y_0*VG0) + (tildeZH_AH*AH_0*VAH0) + (tildeZH_BH*BH_0*VBH0) + (tildeZH_AN*AN_0*VAN0) + (tildeZH_BN*BN_0*VBN0) )/ZH_0)*100;                                 
dtildeZNtime0_tech    = (( (ZN_tech-ZN_0) + (wtildeZN_1*X10) + (wtildeZN_2*X20) + (tildeZN_G*Y_0*VG0) + (tildeZN_AH*AH_0*VAH0) + (tildeZN_BH*BH_0*VBH0) + (tildeZN_AN*AN_0*VAN0) + (tildeZN_BN*BN_0*VBN0) )/ZN_0)*100;                                 
dtildeZtime0_tech     = (( (Z_tech-Z_0) + (wtildeZ_1*X10) + (wtildeZ_2*X20) + (tildeZ_G*Y_0*VG0) + (tildeZ_AH*AH_0*VAH0) + (tildeZ_BH*BH_0*VBH0) + (tildeZ_AN*AN_0*VAN0) + (tildeZ_BN*BN_0*VBN0) )/Z_0)*100;                                           

dTFPHtime0_tech       = (( (ZH_tech-ZH_0) + (wTFPH_1*X10) + (wTFPH_2*X20) + (TFPH_G*Y_0*VG0) + (TFPH_AH*AH_0*VAH0) + (TFPH_BH*BH_0*VBH0) + (TFPH_AN*AN_0*VAN0) + (TFPH_BN*BN_0*VBN0) )/ZH_0)*100;
dTFPNtime0_tech       = (( (ZN_tech-ZN_0) + (wTFPN_1*X10) + (wTFPN_2*X20) + (TFPN_G*Y_0*VG0) + (TFPN_AH*AH_0*VAH0) + (TFPN_BH*BH_0*VBH0) + (TFPN_AN*AN_0*VAN0) + (TFPN_BN*BN_0*VBN0) )/ZN_0)*100;
dTFPtime0_tech        = (( (Z_tech-Z_0) + (wTFP_1*X10) + (wTFP_2*X20) + (TFP_G*Y_0*VG0) + (TFP_AH*AH_0*VAH0) + (TFP_BH*BH_0*VBH0) + (TFP_AN*AN_0*VAN0) + (TFP_BN*BN_0*VBN0) )/Z_0)*100;
dTFPHtime0_check_tech   = (( (ZH_tech-ZH_0) + (wTFPH_1_check*X10) + (wTFPH_2_check*X20) + (TFPH_G_check*Y_0*VG0) + (TFPH_AH_check*AH_0*VAH0) + (TFPH_BH_check*BH_0*VBH0) + (TFPH_AN_check*AN_0*VAN0) + (TFPH_BN_check*BN_0*VBN0) )/ZH_0)*100;
dTFPNtime0_check_tech   = (( (ZN_tech-ZN_0) + (wTFPN_1_check*X10) + (wTFPN_2_check*X20) + (TFPN_G_check*Y_0*VG0) + (TFPN_AH_check*AH_0*VAH0) + (TFPN_BH_check*BH_0*VBH0) + (TFPN_AN_check*AN_0*VAN0) + (TFPN_BN_check*BN_0*VBN0) )/ZN_0)*100;
dTFPRtime0_tech       = (( ((ZH_tech/ZN_tech)-(ZH_0/ZN_0)) + (wTFPR_1*X10) + (wTFPR_2*X20) + (TFPR_G*Y_0*VG0) + (TFPR_AH*AH_0*VAH0) + (TFPR_BH*BH_0*VBH0) + (TFPR_AN*AN_0*VAN0) + (TFPR_BN*BN_0*VBN0) )/(ZH_0/ZN_0))*100;
duZRtime0_tech        = ( (wuZR_1*X10) + (wuZR_2*X20) + (uZR_G*Y_0*VG0) + (uZR_AH*AH_0*VAH0) + (uZR_BH*BH_0*VBH0) + (uZR_AN*AN_0*VAN0) + (uZR_BN*BN_0*VBN0) )*100;     

dtildeKtime0_tech     = (( (K_tech-K_0) + (wtildeK_1*X10) + (wtildeK_2*X20) + (tildeK_G*Y_0*VG0) + (tildeK_AH*AH_0*VAH0) + (tildeK_BH*BH_0*VBH0) + (tildeK_AN*AN_0*VAN0) + (tildeK_BN*BN_0*VBN0) )/K_0)*100;                                             
dtildeWtime0_tech     = (((W_tech-W_0) + (wtildeW_1*X10) + (wtildeW_2*X20) + (tildeW_G*Y_0*VG0) + (tildeW_AH*AH_0*VAH0) + (tildeW_BH*BH_0*VBH0) + (tildeW_AN*AN_0*VAN0) + (tildeW_BN*BN_0*VBN0) )/W_0)*100;                                            
dtildeRtime0_tech     = (((RK_tech-RK_0) + (wtildeR_1*X10) + (wtildeR_2*X20) + (tildeR_G*Y_0*VG0) + (tildeR_AH*AH_0*VAH0) + (tildeR_BH*BH_0*VBH0) + (tildeR_AN*AN_0*VAN0) + (tildeR_BN*BN_0*VBN0) )/RK_0)*100;                                         
dtildeWPCtime0_tech   = (((WPC_tech-WPC_0) + (wtildeWPC_1*X10) + (wtildeWPC_2*X20) + (tildeWPC_G*Y_0*VG0)  + (tildeWPC_AH*AH_0*VAH0) + (tildeWPC_BH*BH_0*VBH0) + (tildeWPC_AN*AN_0*VAN0) + (tildeWPC_BN*BN_0*VBN0) )/WPC_0)*100;                       
dtildeYRtime0_tech    = (((YR_tech-Y_0) + (wtildeYR_1*X10) + (wtildeYR_2*X20) + (tildeYR_G*Y_0*VG0) + (tildeYR_AH*AH_0*VAH0) + (tildeYR_BH*BH_0*VBH0) + (tildeYR_AN*AN_0*VAN0) + (tildeYR_BN*BN_0*VBN0) )/Y_0)*100;                                         
dtildeYHtime0_tech    = ( PH_0*((YH_tech-YH_0) + (wtildeYH_1*X10) + (wtildeYH_2*X20) + (tildeYH_G*Y_0*VG0) + (tildeYH_AH*AH_0*VAH0) + (tildeYH_BH*BH_0*VBH0) + (tildeYH_AN*AN_0*VAN0) + (tildeYH_BN*BN_0*VBN0) )/Y_0)*100;                             
dtildeYNtime0_tech    = ( PN_0*((YN_tech-YN_0) + (wtildeYN_1*X10) + (wtildeYN_2*X20) + (tildeYN_G*Y_0*VG0) + (tildeYN_AH*AH_0*VAH0) + (tildeYN_BH*BH_0*VBH0) + (tildeYN_AN*AN_0*VAN0) + (tildeYN_BN*BN_0*VBN0) )/Y_0)*100;                             
dtildeWHtime0_tech    = (((WH_tech-WH_0) + (wtildeWH_1*X10) + (wtildeWH_2*X20) + (tildeWH_G*Y_0*VG0) + (tildeWH_AH*AH_0*VAH0) + (tildeWH_BH*BH_0*VBH0) + (tildeWH_AN*AN_0*VAN0) + (tildeWH_BN*BN_0*VBN0) )/WH_0)*100;                                  
dtildeWNtime0_tech    = (((WN_tech-WN_0) + (wtildeWN_1*X10) + (wtildeWN_2*X20) + (tildeWN_G*Y_0*VG0) + (tildeWN_AH*AH_0*VAH0) + (tildeWN_BH*BH_0*VBH0) + (tildeWN_AN*AN_0*VAN0) + (tildeWN_BN*BN_0*VBN0) )/WN_0)*100;                                  
dtildeWHPCtime0_tech  = (((WHPC_tech-WHPC_0) + (wtildeWHPC_1*X10) + (wtildeWHPC_2*X20) + (tildeWHPC_G*Y_0*VG0)  + (tildeWHPC_AH*AH_0*VAH0) + (tildeWHPC_BH*BH_0*VBH0) + (tildeWHPC_AN*AN_0*VAN0) + (tildeWHPC_BN*BN_0*VBN0) )/WHPC_0)*100;             
dtildeWNPCtime0_tech  = (((WNPC_tech-WNPC_0) + (wtildeWNPC_1*X10) + (wtildeWNPC_2*X20) + (tildeWNPC_G*Y_0*VG0)  + (tildeWNPC_AH*AH_0*VAH0) + (tildeWNPC_BH*BH_0*VBH0) + (tildeWNPC_AN*AN_0*VAN0) + (tildeWNPC_BN*BN_0*VBN0) )/WNPC_0)*100;             
dtildekHtime0_tech    = ( LH_0*((kH_tech-kH_0) + (wtildekH_1*X10) + (wtildekH_2*X20) + (tildekH_G*Y_0*VG0) + (tildekH_AH*AH_0*VAH0) + (tildekH_BH*BH_0*VBH0) + (tildekH_AN*AN_0*VAN0) + (tildekH_BN*BN_0*VBN0) )/K_0)*100;
dtildekNtime0_tech    = ( LN_0*((kN_tech-kN_0) + (wtildekN_1*X10) + (wtildekN_2*X20) + (tildekN_G*Y_0*VG0) + (tildekN_AH*AH_0*VAH0) + (tildekN_BH*BH_0*VBH0) + (tildekN_AN*AN_0*VAN0) + (tildekN_BN*BN_0*VBN0) )/K_0)*100;
                                                                                                                                                                                                                                                    
dtildeOmegatime0_tech = (((Omega_tech-Omega_0) + (wtildeOmega_1*X10) + (wtildeOmega_2*X20) + (tildeOmega_G*Y_0*VG0) + (tildeOmega_AH*AH_0*VAH0) + (tildeOmega_BH*BH_0*VBH0) + (tildeOmega_AN*AN_0*VAN0) + (tildeOmega_BN*BN_0*VBN0) )/Omega_0)*100;    
dtildeYHYNtime0_tech  = (PH_0/PN_0)*( ((YH_tech/YN_tech)-(YH_0/YN_0)) + (wtildeYHYN_1*X10) + (wtildeYHYN_2*X20) + (tildeYHYN_G*Y_0*VG0) + (tildeYHYN_AH*AH_0*VAH0) + (tildeYHYN_BH*BH_0*VBH0) + (tildeYHYN_AN*AN_0*VAN0) + (tildeYHYN_BN*BN_0*VBN0) )*100;  
dtildeYHStime0_tech   = PH_0*( ((YH_tech/YR_tech)- (YH_0/YR_0)) + (wtildeYHS_1*X10) + (wtildeYHS_2*X20) + (tildeYHS_G*Y_0*VG0) + (tildeYHS_AH*AH_0*VAH0) + (tildeYHS_BH*BH_0*VBH0) + (tildeYHS_AN*AN_0*VAN0) + (tildeYHS_BN*BN_0*VBN0) )*100;                      
dtildeYNStime0_tech   = PN_0*( ((YN_tech/YR_tech)- (YN_0/YR_0)) + (wtildeYNS_1*X10) + (wtildeYNS_2*X20) + (tildeYNS_G*Y_0*VG0) + (tildeYNS_AH*AH_0*VAH0) + (tildeYNS_BH*BH_0*VBH0) + (tildeYNS_AN*AN_0*VAN0) + (tildeYNS_BN*BN_0*VBN0) )*100;                      
dtildeWHWtime0_tech   = (( ((WH_tech/W_tech)-(WH_0/W_0)) + (wtildeWHW_1*X10) + (wtildeWHW_2*X20) + (tildeWHW_G*Y_0*VG0) + (tildeWHW_AH*AH_0*VAH0) + (tildeWHW_BH*BH_0*VBH0) + (tildeWHW_AN*AN_0*VAN0) + (tildeWHW_BN*BN_0*VBN0) )/(WH_0/W_0) )*100;               
dtildeWNWtime0_tech   = (( ((WN_tech/W_tech)-(WN_0/W_0)) + (wtildeWNW_1*X10) + (wtildeWNW_2*X20) + (tildeWNW_G*Y_0*VG0) + (tildeWNW_AH*AH_0*VAH0) + (tildeWNW_BH*BH_0*VBH0) + (tildeWNW_AN*AN_0*VAN0) + (tildeWNW_BN*BN_0*VBN0) )/(WN_0/W_0) )*100;               
dtildeKHKtime0_tech   =  ( ((KH_tech/K_tech)-(KH_0/K_0)) + (wtildeKHK_1*X10) + (wtildeKHK_2*X20) + (tildeKHK_G*Y_0*VG0) + (tildeKHK_AH*AH_0*VAH0) + (tildeKHK_BH*BH_0*VBH0) + (tildeKHK_AN*AN_0*VAN0) + (tildeKHK_BN*BN_0*VBN0) )*100;                            
dtildeKNKtime0_tech   =  ( ((KN_tech/K_tech)-(KN_0/K_0)) + (wtildeKNK_1*X10) + (wtildeKNK_2*X20) + (tildeKNK_G*Y_0*VG0) + (tildeKNK_AH*AH_0*VAH0) + (tildeKNK_BH*BH_0*VBH0) + (tildeKNK_AN*AN_0*VAN0) + (tildeKNK_BN*BN_0*VBN0) )*100;                            
dtildeRPHtime0_tech   = ((((RK_tech/PH_tech)-(RK_0/PH_0)) + (wtildeRPH_1*X10) + (wtildeRPH_2*X20) + (tildeRPH_G*Y_0*VG0) + (tildeRPH_AH*AH_0*VAH0) + (tildeRPH_BH*BH_0*VBH0) + (tildeRPH_AN*AN_0*VAN0) + (tildeRPH_BN*BN_0*VBN0) )/(RK_0/PH_0))*100;  
dtildeRPNtime0_tech   = ((((RK_tech/PN_tech)-(RK_0/PN_0)) + (wtildeRPN_1*X10) + (wtildeRPN_2*X20) + (tildeRPN_G*Y_0*VG0) + (tildeRPN_AH*AH_0*VAH0) + (tildeRPN_BH*BH_0*VBH0) + (tildeRPN_AN*AN_0*VAN0) + (tildeRPN_BN*BN_0*VBN0) )/(RK_0/PN_0))*100;  

% DECOMPOSITION t=0
%dYHS_capdifftime0_tech  = omegaYH_0*( (1-sLH_0)*( ((kH_tech-kH_0) + (wkH_1*X10) + (wkH_2*X20) + (kH_G*Y_0*VG0) + (kH_AH*AH_0*VAH0) + (kH_BH*BH_0*VBH0) + (kH_AN*AN_0*VAN0) + (kH_BN*BN_0*VBN0) )/kH_0 ) - (1-sL_0)*( ((k_tech-k_0) + (wk_1*X10) + (wk_2*X20) + (k_G*Y_0*VG0) + (k_AH*AH_0*VAH0) + (k_BH*BH_0*VBH0) + (k_AN*AN_0*VAN0) + (k_BN*BN_0*VBN0) )/k_0 ) )*100;
dYHS_TFPdifftime0_tech  = omegaYH_0*(1-omegaYH_0)*(( ((ZH_tech/ZN_tech)-(ZH_0/ZN_0)) + (wTFPR_1*X10) + (wTFPR_2*X20) + (TFPR_G*Y_0*VG0) + (TFPR_AH*AH_0*VAH0) + (TFPR_BH*BH_0*VBH0) + (TFPR_AN*AN_0*VAN0) + (TFPR_BN*BN_0*VBN0) )/(ZH_0/ZN_0))*100 + omegaYH_0*(1-omegaYH_0)*( (sLH_0*(( (AH_tech-AH_0) +  (VAH0*AH_0) )/AH_0) + (1-sLH_0)*(( (BH_tech-BH_0) +  (VBH0*BH_0) )/BH_0) ) - (sLN_0*(( (AN_tech-AN_0) +  (VAN0*AN_0) )/AN_0) + (1-sLN_0)*(( (BN_tech-BN_0) +  (VBN0*BN_0) )/BN_0) ) )*100;                                                                                                                                  
dYHS_labdifftime0_tech  = omegaYH_0*(1-omegaYH_0)*(( ((LH_tech/LN_tech)-(LH_0/LN_0)) + (wLHLN_1*X10) + (wLHLN_2*X20) + (LHLN_G*Y_0*VG0) + (LHLN_AH*AH_0*VAH0) + (LHLN_BH*BH_0*VBH0) + (LHLN_AN*AN_0*VAN0) + (LHLN_BN*BN_0*VBN0) )/(LH_0/LN_0) )*100;                                                                                                                                                      
dYHS_capdifftime0_tech  = omegaYH_0*(1-omegaYH_0)*( (1-sLH_0)*( ((kH_tech-kH_0) + (wkH_1*X10) + (wkH_2*X20) + (kH_G*Y_0*VG0) + (kH_AH*AH_0*VAH0) + (kH_BH*BH_0*VBH0) + (kH_AN*AN_0*VAN0) + (kH_BN*BN_0*VBN0) )/kH_0 ) - (1-sLN_0)*( ((kN_tech-kN_0) + (wkN_1*X10) + (wkN_2*X20) + (kN_G*Y_0*VG0) + (kN_AH*AH_0*VAH0) + (kN_BH*BH_0*VBH0) + (kN_AN*AN_0*VAN0) + (kN_BN*BN_0*VBN0) )/kN_0 ) )*100; 
dYHStime0_check_tech    = dYHS_TFPdifftime0_tech + dYHS_labdifftime0_tech + dYHS_capdifftime0_tech;

dYNS_TFPdifftime0_tech  = -dYHS_TFPdifftime0_tech;                                                                                                                                  
dYNS_labdifftime0_tech  = -dYHS_labdifftime0_tech;                                                                                                                                                      
dYNS_capdifftime0_tech  = -dYHS_capdifftime0_tech; 
dYNStime0_check_tech    = dYNS_TFPdifftime0_tech + dYNS_labdifftime0_tech + dYNS_capdifftime0_tech;

dLISH_FBTCtime0_tech    = sLH_0*(1-sLH_0)*((1-sigmaH)/sigmaH)*( (( (BH_tech-BH_0) +  (VBH0*BH_0) )/BH_0) - (( (AH_tech-AH_0) +  (VAH0*AH_0) )/AH_0) )*100;
dLISH_captime0_tech     = sLH_0*(1-sLH_0)*((1-sigmaH)/sigmaH)*(( (kH_tech-kH_0) + (wtildekH_1*X10) + (wtildekH_2*X20) + (tildekH_G*Y_0*VG0) + (tildekH_AH*AH_0*VAH0) + (tildekH_BH*BH_0*VBH0) + (tildekH_AN*AN_0*VAN0) + (tildekH_BN*BN_0*VBN0) )/kH_0)*100;
dLISHtime0_check_tech   = dLISH_FBTCtime0_tech + dLISH_captime0_tech;

dLISN_FBTCtime0_tech    = sLN_0*(1-sLN_0)*((1-sigmaN)/sigmaN)*( (( (BN_tech-BN_0) +  (VBN0*BN_0) )/BN_0) - (( (AN_tech-AN_0) +  (VAN0*AN_0) )/AN_0) )*100;
dLISN_captime0_tech     = sLN_0*(1-sLN_0)*((1-sigmaN)/sigmaN)*(( (kN_tech-kN_0) + (wtildekN_1*X10) + (wtildekN_2*X20) + (tildekN_G*Y_0*VG0) + (tildekN_AH*AH_0*VAH0) + (tildekN_BH*BH_0*VBH0) + (tildekN_AN*AN_0*VAN0) + (tildekN_BN*BN_0*VBN0) )/kN_0)*100;
dLISNtime0_check_tech   = dLISN_FBTCtime0_tech + dLISN_captime0_tech; 

dLNS_LISdifftime0_tech  = (1-alphaL_0)*(epsilon/(1+epsilon))*( (((sLN_tech-sLN_0) + (wLISN_1*X10) + (wLISN_2*X20) + (LISN_G*Y_0*VG0) + (LISN_AH*AH_0*VAH0) + (LISN_BH*BH_0*VBH0) + (LISN_AN*AN_0*VAN0) + (LISN_BN*BN_0*VBN0))/sLN_0) - (( (sL_tech-sL_0) + (wLIS_1*X10) + (wLIS_2*X20) + (LIS_G*Y_0*VG0) + (LIS_AH*AH_0*VAH0) + (LIS_BH*BH_0*VBH0) + (LIS_AN*AN_0*VAN0) + (LIS_BN*BN_0*VBN0) )/sL_0) )*100;
dLNS_NTsharetime0_tech  = (1-alphaL_0)*alphaL_0*(epsilon/(1+epsilon))*(1/((1-omegaYN_0)*omegaYN_0))*( (omegaYN_tech-omegaYN_0) + (womegaYN_1*X10) + (womegaYN_2*X20) + (omegaYN_G*Y_0*VG0) + (omegaYN_AH*AH_0*VAH0) + (omegaYN_BH*BH_0*VBH0) + (omegaYN_AN*AN_0*VAN0) + (omegaYN_BN*BN_0*VBN0) )*100;
dLNS_FBTCdifftime0_tech = (1-alphaL_0)*alphaL_0*(epsilon/(1+epsilon))*( (dLISN_FBTCtime0_tech/sLN_0) -( dLISH_FBTCtime0_tech/sLH_0) ); 
dLNS_capdifftime0_tech  = (1-alphaL_0)*alphaL_0*(epsilon/(1+epsilon))*( (dLISN_captime0_tech/sLN_0) - (dLISH_captime0_tech/sLH_0) ); 
dLNStime0_check_tech    = dLNS_LISdifftime0_tech + dLNS_NTsharetime0_tech;
dLNStime0_doublecheck_tech  = dLNS_NTsharetime0_tech + dLNS_FBTCdifftime0_tech + dLNS_capdifftime0_tech;

% DECOMPOSITION t=5
% Cumulative responses t=5: 6 periods
tcumul       = 5;
t6           = [0:Tu:tcumul]; % span of time t = [0..5]
VGt6         = exp(-(xi+r)*t6) - (1-barg)*exp(-(chi+r)*t6);         
VG1t6        = exp(-(xi+r)*t6) - ThetaG_1*exp(-(chi+r)*t6);         
VG2t6        = exp(-(xi+r)*t6) - ThetaG_2*exp(-(chi+r)*t6);         
VAHt6        = exp(-(xiAH+r)*t6) - (1-baraH)*exp(-(chiAH+r)*t6);    
VBHt6        = exp(-(xiBH+r)*t6) - (1-barbH)*exp(-(chiBH+r)*t6);    
VANt6        = exp(-(xiAN+r)*t6) - (1-baraN)*exp(-(chiAN+r)*t6);    
VBNt6        = exp(-(xiBN+r)*t6) - (1-barbN)*exp(-(chiBN+r)*t6);    
VAH1t6       = exp(-(xiAH+r)*t6) - ThetaAH_1*exp(-(chiAH+r)*t6);    
VAH2t6       = exp(-(xiAH+r)*t6) - ThetaAH_2*exp(-(chiAH+r)*t6);    
VBH1t6       = exp(-(xiBH+r)*t6) - ThetaBH_1*exp(-(chiBH+r)*t6);    
VBH2t6       = exp(-(xiBH+r)*t6) - ThetaBH_2*exp(-(chiBH+r)*t6);    
VAN1t6       = exp(-(xiAN+r)*t6) - ThetaAN_1*exp(-(chiAN+r)*t6);    
VAN2t6       = exp(-(xiAN+r)*t6) - ThetaAN_2*exp(-(chiAN+r)*t6);    
VBN1t6       = exp(-(xiBN+r)*t6) - ThetaBN_1*exp(-(chiBN+r)*t6);    
VBN2t6       = exp(-(xiBN+r)*t6) - ThetaBN_2*exp(-(chiBN+r)*t6);    

X1t6   = X11*exp((nu_1-r)*t6) + (GammaG_1*VG1t6) + (GammaAH_1*VAH1t6) + (GammaBH_1*VBH1t6) + (GammaAN_1*VAN1t6) + (GammaBN_1*VBN1t6);
X2t6   = -(GammaG_2*VG2t6) - (GammaAH_2*VAH2t6) - (GammaBH_2*VBH2t6) - (GammaAN_2*VAN2t6) - (GammaBN_2*VBN2t6);

% Decomposition: YHS, LNS, LISj
dLNScum          = (WN_0/W_0)*( ((LN_tech/L_tech)- (LN_0/L_0))*exp(-r*t6) + (wLNS_1*X1t6) + (wLNS_2*X2t6) + (LNS_G*Y_0*VGt6) + (LNS_AH*AH_0*VAHt6)  + (LNS_BH*BH_0*VBHt6) + (LNS_AN*AN_0*VANt6) + (LNS_BN*BN_0*VBNt6) )*100;
dtildeYHScum     = PH_0*( ((YH_tech/YR_tech)- (YH_0/YR_0))*exp(-r*t6) + (wtildeYHS_1*X1t6) + (wtildeYHS_2*X2t6) + (tildeYHS_G*Y_0*VGt6) + (tildeYHS_AH*AH_0*VAHt6) + (tildeYHS_BH*BH_0*VBHt6) + (tildeYHS_AN*AN_0*VANt6) + (tildeYHS_BN*BN_0*VBNt6) )*100; 
dLISHcum         = ( (sLH_tech-sLH_0)*exp(-r*t6) + (wLISH_1*X1t6) + (wLISH_2*X2t6) + (LISH_G*Y_0*VGt6) + (LISH_AH*AH_0*VAHt6) + (LISH_BH*BH_0*VBHt6) + (LISH_AN*AN_0*VANt6) + (LISH_BN*BN_0*VBNt6) )*100;
dLISNcum         = ( (sLN_tech-sLN_0)*exp(-r*t6) + (wLISN_1*X1t6) + (wLISN_2*X2t6) + (LISN_G*Y_0*VGt6) + (LISN_AH*AH_0*VAHt6) + (LISN_BH*BH_0*VBHt6) + (LISN_AN*AN_0*VANt6) + (LISN_BN*BN_0*VBNt6) )*100;
dtildeYNScum     = PN_0*( ((YN_tech/YR_tech)- (YN_0/YR_0))*exp(-r*t6) + (wtildeYNS_1*X1t6) + (wtildeYNS_2*X2t6) + (tildeYNS_G*Y_0*VGt6) + (tildeYNS_AH*AH_0*VAHt6) + (tildeYNS_BH*BH_0*VBHt6) + (tildeYNS_AN*AN_0*VANt6) + (tildeYNS_BN*BN_0*VBNt6) )*100;

dYHS_TFPdiffcum  = omegaYH_0*(1-omegaYH_0)*( (( (ZH_tech-ZH_0)*exp(-r*t6) + (wTFPH_1*X1t6) + (wTFPH_2*X2t6) + (TFPH_G*Y_0*VGt6) + (TFPH_AH*AH_0*VAHt6) + (TFPH_BH*BH_0*VBHt6) + (TFPH_AN*AN_0*VANt6) + (TFPH_BN*BN_0*VBNt6) )/ZH_0) - (( (ZN_tech-ZN_0)*exp(-r*t6) + (wTFPN_1*X1t6) + (wTFPN_2*X2t6) + (TFPN_G*Y_0*VGt6) + (TFPN_AH*AH_0*VAHt6) + (TFPN_BH*BH_0*VBHt6) + (TFPN_AN*AN_0*VANt6) + (TFPN_BN*BN_0*VBNt6) )/ZN_0) )*100 + omegaYH_0*(1-omegaYH_0)*( (sLH_0*(( (AH_tech-AH_0)*exp(-r*t6) +  (VAHt6*AH_0) )/AH_0) + (1-sLH_0)*(( (BH_tech-BH_0)*exp(-r*t6) +  (VBHt6*BH_0) )/BH_0) ) - (sLN_0*(( (AN_tech-AN_0)*exp(-r*t6) +  (VANt6*AN_0) )/AN_0) + (1-sLN_0)*(( (BN_tech-BN_0)*exp(-r*t6) +  (VBNt6*BN_0) )/BN_0) ) )*100;
dYHS_labdiffcum  = omegaYH_0*(1-omegaYH_0)*(( ((LH_tech/LN_tech)-(LH_0/LN_0))*exp(-r*t6) + (wLHLN_1*X1t6) + (wLHLN_2*X2t6) + (LHLN_G*Y_0*VGt6) + (LHLN_AH*AH_0*VAHt6) + (LHLN_BH*BH_0*VBHt6) + (LHLN_AN*AN_0*VANt6) + (LHLN_BN*BN_0*VBNt6) )/(LH_0/LN_0) )*100;
dYHS_capdiffcum  = omegaYH_0*(1-omegaYH_0)*( (1-sLH_0)*( ((kH_tech-kH_0)*exp(-r*t6) + (wkH_1*X1t6) + (wkH_2*X2t6) + (kH_G*Y_0*VGt6) + (kH_AH*AH_0*VAHt6) + (kH_BH*BH_0*VBHt6) + (kH_AN*AN_0*VANt6) + (kH_BN*BN_0*VBNt6) )/kH_0 )  - (1-sLN_0)*( ((kN_tech-kN_0)*exp(-r*t6) + (wkN_1*X1t6) + (wkN_2*X2t6) + (kN_G*Y_0*VGt6) + (kN_AH*AH_0*VAHt6) + (kN_BH*BH_0*VBHt6) + (kN_AN*AN_0*VANt6) + (kN_BN*BN_0*VBNt6) )/kN_0 ) )*100;

dYNS_TFPdiffcum  = - dYHS_TFPdiffcum;
dYNS_labdiffcum  = - dYHS_labdiffcum;
dYNS_capdiffcum  = - dYHS_capdiffcum;

dLISH_FBTCcum    = sLH_0*(1-sLH_0)*((1-sigmaH)/sigmaH)*( (( (BH_tech-BH_0)*exp(-r*t6) +  (VBHt6*BH_0) )/BH_0) - (( (AH_tech-AH_0)*exp(-r*t6) +  (VAHt6*AH_0) )/AH_0) )*100;
dLISH_capcum     = sLH_0*(1-sLH_0)*((1-sigmaH)/sigmaH)*(( (kH_tech-kH_0)*exp(-r*t6) + (wtildekH_1*X1t6) + (wtildekH_2*X2t6) + (tildekH_G*Y_0*VGt6) + (tildekH_AH*AH_0*VAHt6) + (tildekH_BH*BH_0*VBHt6) + (tildekH_AN*AN_0*VANt6) + (tildekH_BN*BN_0*VBNt6) )/kH_0)*100;

dLISN_FBTCcum    = sLN_0*(1-sLN_0)*((1-sigmaN)/sigmaN)*( (( (BN_tech-BN_0)*exp(-r*t6) +  (VBNt6*BN_0) )/BN_0) - (( (AN_tech-AN_0)*exp(-r*t6) +  (VANt6*AN_0) )/AN_0) )*100;
dLISN_capcum     = sLN_0*(1-sLN_0)*((1-sigmaN)/sigmaN)*(( (kN_tech-kN_0)*exp(-r*t6) + (wtildekN_1*X1t6) + (wtildekN_2*X2t6) + (tildekN_G*Y_0*VGt6) + (tildekN_AH*AH_0*VAHt6) + (tildekN_BH*BH_0*VBHt6) + (tildekN_AN*AN_0*VANt6) + (tildekN_BN*BN_0*VBNt6) )/kN_0)*100;

dLNS_NTsharecum  = (1-alphaL_0)*alphaL_0*(epsilon/(1+epsilon))*(1/((1-omegaYN_0)*omegaYN_0))*( (omegaYN_tech-omegaYN_0)*exp(-r*t6) + (womegaYN_1*X1t6) + (womegaYN_2*X2t6) + (omegaYN_G*Y_0*VGt6) + (omegaYN_AH*AH_0*VAHt6) + (omegaYN_BH*BH_0*VBHt6) + (omegaYN_AN*AN_0*VANt6) + (omegaYN_BN*BN_0*VBNt6) )*100;
dLNS_LISdiffcum  = (1-alphaL_0)*(epsilon/(1+epsilon))*( (((sLN_tech-sLN_0)*exp(-r*t6) + (wLISN_1*X1t6) + (wLISN_2*X2t6) + (LISN_G*Y_0*VGt6) + (LISN_AH*AH_0*VAHt6) + (LISN_BH*BH_0*VBHt6) + (LISN_AN*AN_0*VANt6) + (LISN_BN*BN_0*VBNt6))/sLN_0) - (( (sL_tech-sL_0)*exp(-r*t6) + (wLIS_1*X1t6) + (wLIS_2*X2t6) + (LIS_G*Y_0*VGt6) + (LIS_AH*AH_0*VAHt6) + (LIS_BH*BH_0*VBHt6) + (LIS_AN*AN_0*VANt6) + (LIS_BN*BN_0*VBNt6) )/sL_0) )*100;
dLNS_FBTCdiffcum = (1-alphaL_0)*alphaL_0*(epsilon/(1+epsilon))*( (dLISN_FBTCcum/sLN_0) -( dLISH_FBTCcum/sLH_0) ); 
dLNS_capdiffcum  = (1-alphaL_0)*alphaL_0*(epsilon/(1+epsilon))*( (dLISN_capcum/sLN_0) - (dLISH_capcum/sLH_0) ); 

dLNScum_t         = cumsum(dLNScum);
dLNScum_tech      = dLNScum_t(6);
dtildeYHScum_t    = cumsum(dtildeYHScum);
dtildeYHScum_tech = dtildeYHScum_t(6);
dLISHcum_t        = cumsum(dLISHcum);
dLISHcum_tech     = dLISHcum_t(6);
dLISNcum_t        = cumsum(dLISNcum);
dLISNcum_tech     = dLISNcum_t(6);
dtildeYNScum_t    = cumsum(dtildeYNScum);
dtildeYNScum_tech = dtildeYNScum_t(6);   

dLISH_FBTCcum_t       = cumsum(dLISH_FBTCcum);
dLISH_FBTCcum_tech    = dLISH_FBTCcum_t(6);
dLISH_capcum_t        = cumsum(dLISH_capcum);
dLISH_capcum_tech     = dLISH_capcum_t(6);
dLISHcum_check_tech   = dLISH_FBTCcum_tech + dLISH_capcum_tech;

dLISN_FBTCcum_t       = cumsum(dLISN_FBTCcum);
dLISN_FBTCcum_tech    = dLISN_FBTCcum_t(6);
dLISN_capcum_t        = cumsum(dLISN_capcum);
dLISN_capcum_tech     = dLISN_capcum_t(6);
dLISNcum_check_tech   = dLISN_FBTCcum_tech + dLISN_capcum_tech;

dYHS_TFPdiffcum_t     = cumsum(dYHS_TFPdiffcum);
dYHS_TFPdiffcum_tech  = dYHS_TFPdiffcum_t(6);
dYHS_labdiffcum_t     = cumsum(dYHS_labdiffcum);
dYHS_labdiffcum_tech  = dYHS_labdiffcum_t(6);
dYHS_capdiffcum_t     = cumsum(dYHS_capdiffcum);
dYHS_capdiffcum_tech  = dYHS_capdiffcum_t(6);
dYHScum_check_tech    = dYHS_TFPdiffcum_tech + dYHS_labdiffcum_tech + dYHS_capdiffcum_tech;

dYNS_TFPdiffcum_t     = cumsum(dYNS_TFPdiffcum);                                            
dYNS_TFPdiffcum_tech  = dYNS_TFPdiffcum_t(6);                                               
dYNS_labdiffcum_t     = cumsum(dYNS_labdiffcum);                                            
dYNS_labdiffcum_tech  = dYNS_labdiffcum_t(6);                                               
dYNS_capdiffcum_t     = cumsum(dYNS_capdiffcum);                                            
dYNS_capdiffcum_tech  = dYNS_capdiffcum_t(6);                                               
dYNScum_check_tech    = dYNS_TFPdiffcum_tech + dYNS_labdiffcum_tech + dYNS_capdiffcum_tech; 

dLNS_LISdiffcum_t     = cumsum(dLNS_LISdiffcum);
dLNS_LISdiffcum_tech  = dLNS_LISdiffcum_t(6);
dLNS_NTsharecum_t     = cumsum(dLNS_NTsharecum);
dLNS_NTsharecum_tech  = dLNS_NTsharecum_t(6);
dLNS_FBTCdiffcum_t     = cumsum(dLNS_FBTCdiffcum);
dLNS_FBTCdiffcum_tech  = dLNS_FBTCdiffcum_t(6);
dLNScum_check_tech    = dLNS_LISdiffcum_tech + dLNS_NTsharecum_tech;
dLNS_capdiffcum_t     = cumsum(dLNS_capdiffcum);
dLNS_capdiffcum_tech  = dLNS_capdiffcum_t(6);
dLNScum_doublecheck_tech   = dLNS_NTsharecum_tech + dLNS_FBTCdiffcum_tech + dLNS_capdiffcum_tech;

dPcum      = (((P_tech-P_0)*exp(-r*t6) + (wP_1*X1t6) + (wP_2*X2t6) + (P_G*Y_0*VGt6) + (P_AH*AH_0*VAHt6) + (P_BH*BH_0*VBHt6) + (P_AN*AN_0*VANt6) + (P_BN*BN_0*VBNt6) )/P_0)*100;                                          
dPHcum     = (((PH_tech-PH_0)*exp(-r*t6) + (wPH_1*X1t6) + (wPH_2*X2t6) + (PH_G*Y_0*VGt6) + (PH_AH*AH_0*VAHt6) + (PH_BH*BH_0*VBHt6) + (PH_AN*AN_0*VANt6) + (PH_BN*BN_0*VBNt6) )/PH_0)*100;                                
dWHWcum    = (( ((WH_tech/W_tech)-(WH_0/W_0))*exp(-r*t6) + (wWHW_1*X1t6) + (wWHW_2*X2t6) + (WHW_G*Y_0*VGt6) + (WHW_AH*AH_0*VAHt6) + (WHW_BH*BH_0*VBHt6) + (WHW_AN*AN_0*VANt6) + (WHW_BN*BN_0*VBNt6) )/(WH_0/W_0) )*100;  
dWNWcum    = (( ((WN_tech/W_tech)-(WN_0/W_0))*exp(-r*t6) + (wWNW_1*X1t6) + (wWNW_2*X2t6) + (WNW_G*Y_0*VGt6) + (WNW_AH*AH_0*VAHt6) + (WNW_BH*BH_0*VBHt6) + (WNW_AN*AN_0*VANt6) + (WNW_BN*BN_0*VBNt6) )/(WN_0/W_0) )*100;  
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
dPcum_t          = cumsum(dPcum);                                                                                                                                                                             
dPcum_tech       = dPcum_t(6);                                                                                                                                                                                
dPHcum_t         = cumsum(dPHcum);                                                                                                                                                                            
dPHcum_tech      = dPHcum_t(6);                                                                                                                                                                               
dWHWcum_t        = cumsum(dWHWcum);                                                                                                                                                                           
dWHWcum_tech     = dWHWcum_t(6);                                                                                                                                                                              
dWNWcum_t        = cumsum(dWNWcum);                                                                                                                                                                           
dWNWcum_tech     = dWNWcum_t(6);   

dLcum         = (((L_tech-L_0)*exp(-r*t6)  + (wL_1*X1t6) + (wL_2*X2t6) + (L_G*Y_0*VGt6) + (L_AH*AH_0*VAHt6) + (L_BH*BH_0*VBHt6) + (L_AN*AN_0*VANt6) + (L_BN*BN_0*VBNt6) )/L_0)*100;
dLHcum        = ( (WH_0/W_0)*( (LH_tech-LH_0)*exp(-r*t6) + (wLH_1*X1t6) + (wLH_2*X2t6) + (LH_G*Y_0*VGt6) + (LH_AH*AH_0*VAHt6) + (LH_BH*BH_0*VBHt6) + (LH_AN*AN_0*VANt6) + (LH_BN*BN_0*VBNt6) )/L_0)*100;
dLNcum        = ( (WN_0/W_0)*( (LN_tech-LN_0)*exp(-r*t6) + (wLN_1*X1t6) + (wLN_2*X2t6) + (LN_G*Y_0*VGt6) + (LN_AH*AH_0*VAHt6) + (LN_BH*BH_0*VBHt6) + (LN_AN*AN_0*VANt6) + (LN_BN*BN_0*VBNt6) )/L_0)*100;
dtildeYRcum   = (((YR_tech-Y_0)*exp(-r*t6) + (wtildeYR_1*X1t6) + (wtildeYR_2*X2t6) + (tildeYR_G*Y_0*VGt6) + (tildeYR_AH*AH_0*VAHt6) + (tildeYR_BH*BH_0*VBHt6) + (tildeYR_AN*AN_0*VANt6) + (tildeYR_BN*BN_0*VBNt6) )/Y_0)*100;
dtildeYHcum   = ( PH_0*((YH_tech-YH_0)*exp(-r*t6) + (wtildeYH_1*X1t6) + (wtildeYH_2*X2t6) + (tildeYH_G*Y_0*VGt6) + (tildeYH_AH*AH_0*VAHt6) + (tildeYH_BH*BH_0*VBHt6) + (tildeYH_AN*AN_0*VANt6) + (tildeYH_BN*BN_0*VBNt6) )/Y_0)*100;
dtildeYNcum   = ( PN_0*((YN_tech-YN_0)*exp(-r*t6) + (wtildeYN_1*X1t6) + (wtildeYN_2*X2t6) + (tildeYN_G*Y_0*VGt6) + (tildeYN_AH*AH_0*VAHt6) + (tildeYN_BH*BH_0*VBHt6) + (tildeYN_AN*AN_0*VANt6) + (tildeYN_BN*BN_0*VBNt6) )/Y_0)*100;

dLcum_t          = cumsum(dLcum);
dLcum_tech       = dLcum_t(6);
dtildeYRcum_t    = cumsum(dtildeYRcum);
dtildeYRcum_tech = dtildeYRcum_t(6);
dLHcum_t         = cumsum(dLHcum);
dLHcum_tech      = dLHcum_t(6);
dtildeYHcum_t    = cumsum(dtildeYHcum);
dtildeYHcum_tech = dtildeYHcum_t(6);
dLNcum_t         = cumsum(dLNcum);
dLNcum_tech      = dLNcum_t(6);
dtildeYNcum_t    = cumsum(dtildeYNcum);
dtildeYNcum_tech = dtildeYNcum_t(6);

dGYcum      = ( ( (G_0-G_0) +  (VGt6*Y_0) )/Y_0)*100;
dtildeZHcum = (( (ZH_tech-ZH_0)*exp(-r*t6) + (wtildeZH_1*X1t6) + (wtildeZH_2*X2t6) + (tildeZH_G*Y_0*VGt6) + (tildeZH_AH*AH_0*VAHt6) + (tildeZH_BH*BH_0*VBHt6) + (tildeZH_AN*AN_0*VANt6) + (tildeZH_BN*BN_0*VBNt6) )/ZH_0)*100;
dtildeZNcum = (( (ZN_tech-ZN_0)*exp(-r*t6) + (wtildeZN_1*X1t6) + (wtildeZN_2*X2t6) + (tildeZN_G*Y_0*VGt6) + (tildeZN_AH*AH_0*VAHt6) + (tildeZN_BH*BH_0*VBHt6) + (tildeZN_AN*AN_0*VANt6) + (tildeZN_BN*BN_0*VBNt6) )/ZN_0)*100;
dTFPHcum    = (( (ZH_tech-ZH_0)*exp(-r*t6) + (wTFPH_1*X1t6) + (wTFPH_2*X2t6) + (TFPH_G*Y_0*VGt6) + (TFPH_AH*AH_0*VAHt6) + (TFPH_BH*BH_0*VBHt6) + (TFPH_AN*AN_0*VANt6) + (TFPH_BN*BN_0*VBNt6) )/ZH_0)*100;
dTFPNcum    = (( (ZN_tech-ZN_0)*exp(-r*t6) + (wTFPN_1*X1t6) + (wTFPN_2*X2t6) + (TFPN_G*Y_0*VGt6) + (TFPN_AH*AH_0*VAHt6) + (TFPN_BH*BH_0*VBHt6) + (TFPN_AN*AN_0*VANt6) + (TFPN_BN*BN_0*VBNt6) )/ZN_0)*100;
dFBTCHcum   = ((1-sigmaH)/sigmaH)*( (( (BH_tech-BH_0)*exp(-r*t6) +  (VBHt6*BH_0) )/BH_0) - (( (AH_tech-AH_0)*exp(-r*t6) +  (VAHt6*AH_0) )/AH_0) )*100;      
dFBTCNcum   = ((1-sigmaN)/sigmaN)*( (( (BN_tech-BN_0)*exp(-r*t6) +  (VBNt6*BH_0) )/BN_0) - (( (AN_tech-AN_0)*exp(-r*t6) +  (VANt6*AN_0) )/AN_0) )*100;      

dGYcum_t          = cumsum(dGYcum);
dGYcum_tech       = dGYcum_t(6);
dtildeZHcum_t     = cumsum(dtildeZHcum);
dtildeZHcum_tech  = dtildeZHcum_t(6);
dtildeZNcum_t     = cumsum(dtildeZNcum);
dtildeZNcum_tech  = dtildeZNcum_t(6);
dTFPHcum_t        = cumsum(dTFPHcum);
dTFPHcum_tech     = dTFPHcum_t(6);
dTFPNcum_t        = cumsum(dTFPNcum);
dTFPNcum_tech     = dTFPNcum_t(6);
dFBTCHcum_t       = cumsum(dFBTCHcum);
dFBTCHcum_tech    = dFBTCHcum_t(6);   
dFBTCNcum_t       = cumsum(dFBTCNcum);
dFBTCNcum_tech    = dFBTCNcum_t(6);   
                                                                                                                                                                                         
% Steady-state changes and impact effects - scaled to their initial values 
hatlambda_tech       = (dlambda/lambda_0)*100; 
dCoverY_tech         = ((PC_0*dC)/Y_0)*100; % Rate of change of the real consumption
dGNY_tech            = PN_0*(dGN/Y_0)*100; % Change in GN
dGHY_tech            = PH_0*(dGH/Y_0)*100; % Change in GH
dGFY_tech            = (dGF/Y_0)*100; % Change in GH
dGY_tech             = (dG/Y_0)*100; % Change in G
hatL_tech            = (dL/L_0)*100; % Rate of change of employment
hatK_tech            = (dK/K_0)*100; % Rate of change of the stock of foreign assets
dLHoverL_tech        = (WH_0/W_0)*(dLH/L_0)*100; % Rate of change of LH
dLNoverL_tech        = (WN_0/W_0)*(dLN/L_0)*100; % Rate of change of LN
dLHLN_tech           = (WH_0/WN_0)*((LH/LN)-(LH_0/LN_0))*100; %  Change of LH/LN
hatPH_tech           = (dPH/PH_0)*100; % Rate of change of PH
hatPN_tech           = (dPN/PN_0)*100; % Rate of change of PN
hatP_tech            = (dP/P_0)*100; % Rate of change of PN/PH
dBoverY_tech         = (dB/Y_0)*100; % Rate of change of the stock of foreign assets
dAoverY_tech         = (dA/Y_0)*100; % Rate of change of the stock of financial assets
hatW_tech            = (dW/W_0)*100; % Rate of change of wage
hatWPC_tech          = (dWPC/WPC_0)*100; % Rate of change of Real Aggregate Wage W/pc
hatY_tech            = (dY/Y_0)*100; % Rate of change of GDP
hatYR_tech           = ((YR-Y_0)/Y_0)*100; % Rate of change of Real GDP
dYHoverY_tech        = (PH_0*dYH/Y_0)*100; % Rate of change of YH
dYNoverY_tech        = (PN_0*dYN/Y_0)*100; % Rate of change of YN
dYHYN_tech           = (PH_0/PN_0)*((YH/YN)-(YH_0/YN_0))*100; % Rate of change of YH/YN
hatWH_tech           = (dWH/WH_0)*100; % Rate of change of WH
hatWN_tech           = (dWN/WN_0)*100; % Rate of change of WN
hatOmega_tech        = (dOmega/Omega_0)*100; % Rate of change of omega
hatWHPC_tech         = (dWHPC/WHPC_0)*100; % Rate of change of WH/PC
hatWNPC_tech         = (dWNPC/WNPC_0)*100; % Rate of change of WN/PC
dkH_tech             = LH_0*(dkH/K_0)*100; % Rate of change of kH
dkN_tech             = LN_0*(dkN/K_0)*100; % Rate of change of kN
dLHS_tech            = (WH_0/W_0)*((LH/L)-(LH_0/L_0))*100; % change in  the labor share of T
dLNS_tech            = (WN_0/W_0)*((LN/L)-(LN_0/L_0))*100; % change in the labor share of NT
dYHS_tech            = PH_0*((YH/YR)-(YH_0/YR_0))*100; % change in the output share of T
dYNS_tech            = PN_0*((YN/YR)-(YN_0/YR_0))*100; % change in the output share of NT
dLISH_tech           = (sLH_tech-sLH_0)*100; % Change in the labor income share H
dLISN_tech           = (sLN_tech-sLN_0)*100; % Change in the labor income share N
dWHW_tech            = (((WH/W)-(WH_0/W_0))/((WH_0/W_0)))*100; % Change in the relative wage H
dWNW_tech            = (((WN/W)-(WN_0/W_0))/((WH_0/W_0)))*100; % Change in the relative wage N
dKHK_tech            = ((KH/K)-(KH_0/K_0))*100; % Change in the capital share of H
dKNK_tech            = ((KN/K)-(KN_0/K_0))*100; % Change in the capital share of N

disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                    Final Steady State with kH > kN');
disp('                           The exomark: ');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (exomark)');
disp('The structural parameters (exomark)');
disp(sprintf('sigmaH  : %5.2f   gammaH   : %5.2f',sigmaH,gammaH));
disp(sprintf('sigmaN  : %5.2f   gammaN   : %5.2f',sigmaN,gammaN));
disp(sprintf('sLH     : %5.2f   sLN      : %5.2f',sLH,sLN));
disp(sprintf('sigmaC  : %5.2f   phi      : %5.2f  varphi : %5.2f',sigmaC,phi,varphi));
disp(sprintf('rho     : %5.2f   varphiH  : %5.2f',rho,varphiH));
disp(sprintf('phiI    : %5.2f   iota     : %5.2f',phiI,iota)); 
disp(sprintf('rhoI    : %5.2f   iotaH    : %5.2f',rhoI,iotaH))
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f',sigmaL,gammaL));
disp(sprintf('epsilon : %5.2f   vartheta : %5.2f',epsilon,vartheta));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('AH      : %5.2f   BH       : %5.2f',AH,BH));
disp(sprintf('AN      : %5.2f   BN       : %5.2f',AN,BN));
disp(sprintf('ZH      : %5.2f   ZN       : %5.2f',ZH,ZN));
disp(sprintf('TFPH    : %5.2f   TFPN     : %5.2f',TFPH,TFPN));
disp(sprintf('omegaYH : %5.2f   Z        : %5.2f TFP        : %5.2f',omegaYH,Z,TFP));
disp(sprintf('GH      : %5.2f   GN       : %5.2f',GH,GN));
disp(sprintf('GF      : %5.2f   G        : %5.2f',GF,G));
disp(' ');

disp(' ');
disp('The production side (exomark)');
disp(sprintf('kH       : %9.3f    kN   : %9.3f',kH,kN));
disp(sprintf('LH       : %9.3f    LN   : %9.3f',LH,LN));
disp(sprintf('KH       : %9.3f    KN   : %9.3f',KH,KN));
disp(sprintf('YH       : %9.3f    YN   : %9.3f',YH,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('L_check  : %9.3f   ',L_check));
disp(sprintf('alphaL   : %9.3f   ',alphaL));

disp(' ');
disp('The demand side (exomark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('CT       :   %7.3f  CT_check : %9.3f',CT,CT_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('PT       :   %7.3f    alphaH : %9.3f',PT,alphaH));
disp(sprintf('CH       :   %7.3f    CN     : %9.3f',CH,CN));
disp(sprintf('CF       :   %7.3f',CF));

disp('The demand side (exomark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('PIT      :   %7.3f   alphaIH : %9.3f',PIT,alphaIH));
disp(sprintf('IH       :   %7.3f    IN     : %9.3f IF     : %9.3f',IH,IN,IF));
disp(sprintf('EI       :   %7.3f    EIT    : %9.3f',EI,EIT));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector H');
disp(sprintf('Gross output (YH)  : %9.3f',YH));
disp(sprintf('WH                 : %9.3f',WH));
disp(sprintf('Profit             : %9.10f',PiH));

disp(' ');
disp('Wealth');
disp(sprintf('K      :   %5.3f    B  :   %5.6f',K,B));
disp(sprintf('lambda :   %5.15f   A  :   %5.3f',lambda,A));
disp(sprintf('Sav    :   %5.10f   CA :   %5.10f',Sav,CA));

disp('Linearization');
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_Q : %5.4f',Upsilon_K,Upsilon_Q));
disp(sprintf('Sigma_K   :  %5.4f  Sigma_Q   : %5.4f',Sigma_K,Sigma_Q));
disp(sprintf('Upsilon_G :  %5.4f  Sigma_G   : %5.4f',Upsilon_G,Sigma_G));
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));
disp(sprintf('B_G       :  %5.4f  A_G       : %5.4f',B_G,A_G));
disp(sprintf('A_K       :  %5.4f  A_Q       : %5.4f',A_K,A_Q));

disp(' ');
disp('Eigenvalues and Eigenvectors');
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu_1,nu_2));
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));

disp('Eigenvectors');
disp(sprintf('omega11    :   %5.6f  omega12    : %5.6f',omega_11,omega_12));

disp('Partial derivatives of Lj'); 
disp(sprintf('LN_Q       :   %7.6f  LH_Q       : %9.6f',LN_Q,LH_Q));         
disp(sprintf('LN_K       :   %7.6f  LH_K       : %9.6f',LN_K,LH_K));         
disp(sprintf('LN_G       :   %7.6f  LH_G       : %9.6f',LN_G,LH_G));         
disp(sprintf('LN_AH      :   %7.6f  LH_AH      : %9.6f',LN_AH,LH_AH));       
disp(sprintf('LN_BH      :   %7.6f  LH_BH      : %9.6f',LN_BH,LH_BH));       
disp(sprintf('LN_AN      :   %7.6f  LH_AN      : %9.6f',LN_AN,LH_AN));       
disp(sprintf('LN_BN      :   %7.6f  LH_BN      : %9.6f',LN_BN,LH_BN));       
                                                                             
disp('Partial derivatives of Lj/L');                                        
disp(sprintf('LNS_Q       :   %7.6f  LHS_Q       : %9.6f',LNS_Q,LHS_Q));     
disp(sprintf('LNS_K       :   %7.6f  LHS_K       : %9.6f',LNS_K,LHS_K));     
disp(sprintf('LNS_G       :   %7.6f  LHS_G       : %9.6f',LNS_G,LHS_G));     
disp(sprintf('LNS_AH      :   %7.6f  LHS_AH      : %9.6f',LNS_AH,LHS_AH));   
disp(sprintf('LNS_BH      :   %7.6f  LHS_BH      : %9.6f',LNS_BH,LHS_BH));   
disp(sprintf('LNS_AN      :   %7.6f  LHS_AN      : %9.6f',LNS_AN,LHS_AN));   
disp(sprintf('LNS_BN      :   %7.6f  LHS_BN      : %9.6f',LNS_BN,LHS_BN));

disp('Partial derivatives of Yj');                                                          
disp(sprintf('YN_Q       :   %7.6f  YH_Q       : %9.6f',YN_Q,YH_Q));                        
disp(sprintf('YN_K       :   %7.6f  YH_K       : %9.6f',YN_K,YH_K));                        
disp(sprintf('YN_G       :   %7.6f  YH_G       : %9.6f',YN_G,YH_G));                        
disp(sprintf('YN_AH      :   %7.6f  YH_AH      : %9.6f',YN_AH,YH_AH));                      
disp(sprintf('YN_BH      :   %7.6f  YH_BH      : %9.6f',YN_BH,YH_BH));                      
disp(sprintf('YN_AN      :   %7.6f  YH_AN      : %9.6f',YN_AN,YH_AN));                      
disp(sprintf('YN_BN      :   %7.6f  YH_BN      : %9.6f',YN_BN,YH_BN));                      
                                                                                            
disp('Partial derivatives of tildeYj');                                                     
disp(sprintf('tildeYN_Q       :   %7.6f  tildeYH_Q       : %9.6f',tildeYN_Q,tildeYH_Q));    
disp(sprintf('tildeYN_K       :   %7.6f  tildeYH_K       : %9.6f',tildeYN_K,tildeYH_K));    
disp(sprintf('tildeYN_G       :   %7.6f  tildeYH_G       : %9.6f',tildeYN_G,tildeYH_G));    
disp(sprintf('tildeYN_AH      :   %7.6f  tildeYH_AH      : %9.6f',tildeYN_AH,tildeYH_AH));  
disp(sprintf('tildeYN_BH      :   %7.6f  tildeYH_BH      : %9.6f',tildeYN_BH,tildeYH_BH));  
disp(sprintf('tildeYN_AN      :   %7.6f  tildeYH_AN      : %9.6f',tildeYN_AN,tildeYH_AN));  
disp(sprintf('tildeYN_BN      :   %7.6f  tildeYH_BN      : %9.6f',tildeYN_BN,tildeYH_BN));     

disp('Partial derivatives of Yj/YR');                                                             
disp(sprintf('YNS_Q       :   %7.6f  YHS_Q       : %9.6f',YNS_Q,YHS_Q));                          
disp(sprintf('YNS_K       :   %7.6f  YHS_K       : %9.6f',YNS_K,YHS_K));                          
disp(sprintf('YNS_G       :   %7.6f  YHS_G       : %9.6f',YNS_G,YHS_G));                          
disp(sprintf('YNS_AH      :   %7.6f  YHS_AH      : %9.6f',YNS_AH,YHS_AH));                        
disp(sprintf('YNS_BH      :   %7.6f  YHS_BH      : %9.6f',YNS_BH,YHS_BH));                        
disp(sprintf('YNS_AN      :   %7.6f  YHS_AN      : %9.6f',YNS_AN,YHS_AN));                        
disp(sprintf('YNS_BN      :   %7.6f  YHS_BN      : %9.6f',YNS_BN,YHS_BN));                        
                                                                                                  
disp('Partial derivatives of tildeYj/tildeYR');                                                   
disp(sprintf('tildeYNS_Q       :   %7.6f  tildeYHS_Q       : %9.6f',tildeYNS_Q,tildeYHS_Q));      
disp(sprintf('tildeYNS_K       :   %7.6f  tildeYHS_K       : %9.6f',tildeYNS_K,tildeYHS_K));      
disp(sprintf('tildeYNS_G       :   %7.6f  tildeYHS_G       : %9.6f',tildeYNS_G,tildeYHS_G));      
disp(sprintf('tildeYNS_AH      :   %7.6f  tildeYHS_AH      : %9.6f',tildeYNS_AH,tildeYHS_AH));    
disp(sprintf('tildeYNS_BH      :   %7.6f  tildeYHS_BH      : %9.6f',tildeYNS_BH,tildeYHS_BH));    
disp(sprintf('tildeYNS_AN      :   %7.6f  tildeYHS_AN      : %9.6f',tildeYNS_AN,tildeYHS_AN));    
disp(sprintf('tildeYNS_BN      :   %7.6f  tildeYHS_BN      : %9.6f',tildeYNS_BN,tildeYHS_BN));    

disp(' ');
disp('Steady State Equilibrium ratios (exomark)');
disp(sprintf('YH / Y    :  %5.3f      PN*YN / Y  : %5.3f',omegaYH,omegaYN));
disp(sprintf('LH / L    :  %5.3f      LN / L    : %5.3f',omegaLH,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('PN*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GH / YH     :  %5.3f  GN / YN    :  %5.3f  (PN*GN)/G  : %5.3f',omegaGHYH,omegaGNYN,omegaGN));
disp(sprintf('(PH*GH)/G   :  %5.3f  GF / G     :  %5.3f  GT/G       : %5.3f',omegaGH,omegaGF,omegaGT));
disp(sprintf('IN / YN     :  %5.3f  IH / YH    :  %5.3f  (r*B)/Y    : %5.3f',omegaINYN,omegaIHYH,omegaB));
disp(sprintf('IF / YH     :  %5.3f  GF / YH    :  %5.3f',omegaIFYH,omegaGFYH));
disp(sprintf('WN*LN/W*L   :  %5.3f RN*KN/R*K   :  %5.3f',alphaL,alphaK));
disp(sprintf('PIT*IT/PI*I :  %5.3f PT*CT/PC*C  :  %5.3f',alphaI,alphaC));
disp(sprintf('PH*IH/PT*IT :  %5.3f PH*CH/PT*CT :  %5.3f',alphaIH,alphaH));
disp(sprintf('PH*IH/PI*I  :  %5.3f PH*CH/PC*C  :  %5.3f',omegaIH,omegaCH));
disp(sprintf('IF/PI*I     :  %5.3f    CF/PC*C  :  %5.3f',omegaIF,omegaCF));
disp(sprintf('PH*XH/Y  :  %5.3f       XH / YH  :  %5.3f',omegaXHY,omegaXHYH));
disp(sprintf('W*L/Y       :  %5.3f R*K/Y       :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y         :  %5.3f',omegaKY));
disp(' ');
disp(' ');
disp(' ');
disp(sprintf('Marginal product of KH = RT       : %9.16f   ',cond1));
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));
disp(sprintf('Marginal product of LH = WH       : %9.16f   ',cond3));
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));
disp(sprintf('Resource contraint for capital    : %9.16f   ',cond5));
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));
disp(sprintf('Market clearing condition good H  : %9.16f   ',cond8));
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));
disp(sprintf('Relative labor  LH/LN             : %9.16f   ',cond12));
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));
disp(sprintf('FOC -V_L*(dL/dLH) = lambda*WH     : %9.16f   ',cond16));
disp(sprintf('FOC -V_L*(dL/dLN) = lambda*WN     : %9.16f   ',cond17));
disp(sprintf('Global market clearing condition  : %9.16f   ',cond18));
disp(sprintf('Private Savings                   : %9.16f   ',cond19));
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond20));
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond21));
disp(sprintf('Investment expenditure check      : %9.16f   ',cond22));
disp(sprintf('Capital income R*K                : %9.16f   ',cond23));
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond24));
disp(sprintf('relative consumption  CH/CF       : %9.16f   ',cond25));
disp(sprintf('Consumption expenditure in T PT*CT: %9.16f   ',cond26));
disp(sprintf('relative investment   IH/IF       : %9.16f   ',cond27));
disp(sprintf('Investment expenditure in T PIT*JT: %9.16f   ',cond28));
disp(sprintf('Current account                   : %9.16f   ',cond29));
disp(sprintf('Current account                   : %9.16f   ',cond30));


disp('-------------------------------------------------------------------------------------------------------- ');
disp('                       Increase in gN : Impact and Steady State Changes (after a rise in gN)     ');
disp('-------------------------------------------------------------------------------------------------------- ');
disp('-------------------------------------------------------------------------------------------------------- ');
disp('                               |     Temporary   |');
disp('-------------------------------------------------------------------------------------------------------- ');
disp(' ');

disp(' ');
disp(' Steady State Deviations ( = (x-x0)/x0 where x0 is the value of x at the initial steady state)  ');
disp(sprintf('hatlambda_tech        :         |           |%10.3f',hatlambda_tech));
disp(sprintf('dGY_tech              :         |           |%10.3f',dGY_tech));
disp(sprintf('dGHY_tech             :         |           |%10.3f',dGHY_tech));
disp(sprintf('dGNY_tech             :         |           |%10.3f',dGNY_tech));
disp(sprintf('dCoverY_tech          :         |           |%10.3f',dCoverY_tech));
disp(sprintf('dLoverL_tech          :         |           |%10.3f',hatL_tech));
disp(sprintf('dYRoverY_tech         :         |           |%10.3f',hatYR_tech));
disp(sprintf('dKoverK_tech          :         |           |%10.3f',hatK_tech));
disp(sprintf('dLHoverL_tech         :         |           |%10.3f',dLHoverL_tech));
disp(sprintf('dLNover_tech          :         |           |%10.3f',dLNoverL_tech));
disp(sprintf('dLHLN_tech            :         |           |%10.3f',dLHLN_tech));
disp(sprintf('dYHoverY_tech         :         |           |%10.3f',dYHoverY_tech));
disp(sprintf('dYNoverY_tech         :         |           |%10.3f',dYNoverY_tech));
disp(sprintf('dYHYN_tech            :         |           |%10.3f',dYHYN_tech));
disp(sprintf('hatPH_tech            :         |           |%10.3f',hatPH_tech));
disp(sprintf('hatPN_tech            :         |           |%10.3f',hatPN_tech));
disp(sprintf('hatP_tech             :         |           |%10.3f',hatP_tech));
disp(sprintf('dBoverY_tech          :         |           |%10.3f',dBoverY_tech));
disp(sprintf('dAoverY_tech          :         |           |%10.3f',dAoverY_tech));
disp(sprintf('dWoverW_tech          :         |           |%10.3f',hatW_tech));
disp(sprintf('dWPCoverWPC_tech      :         |           |%10.3f',hatWPC_tech));
disp(sprintf('dWHoverWH_tech        :         |           |%10.3f',hatWH_tech));
disp(sprintf('dWNoverWN_tech        :         |           |%10.3f',hatWN_tech));
disp(sprintf('hatOmega_tech         :         |           |%10.3f',hatOmega_tech));
disp(sprintf('dWHPCoverWHPC_tech    :         |           |%10.3f',hatWHPC_tech));
disp(sprintf('dWNPCoverWNPC_tech    :         |           |%10.3f',hatWNPC_tech));
disp(sprintf('dkHoverK_tech         :         |           |%10.3f',dkH_tech));
disp(sprintf('dkNoverK_tech         :         |           |%10.3f',dkN_tech));
disp(sprintf('dLHS_tech             :         |           |%10.3f',dLHS_tech));
disp(sprintf('dLNS_tech             :         |           |%10.3f',dLNS_tech));
disp(sprintf('dYHS_tech             :         |           |%10.3f',dYHS_tech));
disp(sprintf('dYNS_tech             :         |           |%10.3f',dYNS_tech));
disp(sprintf('dLISH_tech            :         |           |%10.3f',dLISH_tech));
disp(sprintf('dLISN_tech            :         |           |%10.3f',dLISN_tech));
disp(sprintf('dWHW_tech             :         |           |%10.3f',dWHW_tech));
disp(sprintf('dWNW_tech             :         |           |%10.3f',dWNW_tech));

%disp(' ');
disp('                                           Initial responses ');
disp(sprintf('dGYtime0_tech        :                |                 |%10.3f',dGYtime0_tech));
disp(sprintf('dGHYtime0_tech       :                |                 |%10.3f',dGHYtime0_tech));
disp(sprintf('dGNYtime0_tech       :                |                 |%10.3f',dGNYtime0_tech));
disp(sprintf('dZHtime0_tech        :                |                 |%10.3f',dZHtime0_tech));
disp(sprintf('dZNtime0_tech        :                |                 |%10.3f',dZNtime0_tech));
disp(sprintf('dAHtime0_tech        :                |                 |%10.3f',dAHtime0_tech));
disp(sprintf('dBHtime0_tech        :                |                 |%10.3f',dBHtime0_tech));
disp(sprintf('dANtime0_tech        :                |                 |%10.3f',dANtime0_tech));
disp(sprintf('dBNtime0_tech        :                |                 |%10.3f',dBNtime0_tech));
disp(sprintf('dFBTCHtime0_tech     :                |                 |%10.3f',dFBTCHtime0_tech));
disp(sprintf('dFBTCNtime0_tech     :                |                 |%10.3f',dFBTCNtime0_tech));

disp('                                           Initial responses ');
disp(sprintf('dCYtime0_tech        :                |                 |%10.3f',dCYtime0_tech));
disp(sprintf('dLtime0_tech         :                |                 |%10.3f',dLtime0_tech));
disp(sprintf('dLHtime0_tech        :                |                 |%10.3f',dLHtime0_tech));
disp(sprintf('dLNtime0_tech        :                |                 |%10.3f',dLNtime0_tech));
disp(sprintf('dLHLNtime0_tech      :                |                 |%10.3f',dLHLNtime0_tech));
disp(sprintf('dYRtime0_tech        :                |                 |%10.3f',dYRtime0_tech));
disp(sprintf('dYHtime0_tech        :                |                 |%10.3f',dYHtime0_tech));
disp(sprintf('dYNtime0_tech        :                |                 |%10.3f',dYNtime0_tech));
disp(sprintf('dYHYNtime0_tech      :                |                 |%10.3f',dYHYNtime0_tech));
disp(sprintf('dPHtime0_tech        :                |                 |%10.3f',dPHtime0_tech));
disp(sprintf('dPNtime0_tech        :                |                 |%10.3f',dPNtime0_tech));
disp(sprintf('dPtime0_tech         :                |                 |%10.3f',dPtime0_tech));
disp(sprintf('dSYtime0_tech        :                |                 |%10.3f',SYtime0_tech));
disp(sprintf('dIYtime0_tech        :                |                 |%10.3f',IYtime0_tech));
disp(sprintf('dCAYtime0_tech       :                |                 |%10.5f',CAYtime0_tech)); 
disp(sprintf('dCAYtime0_tech_check :                |                 |%10.5f',CAYtime0_tech_check)); 
disp(sprintf('dWtime0_tech         :                |                 |%10.3f',dWtime0_tech));
disp(sprintf('dWPCtime0_tech       :                |                 |%10.3f',dWPCtime0_tech));
disp(sprintf('dWHtime0_tech        :                |                 |%10.3f',dWHtime0_tech));
disp(sprintf('dWNtime0_tech        :                |                 |%10.3f',dWNtime0_tech));
disp(sprintf('dOmegatime0_tech     :                |                 |%10.3f',dOmegatime0_tech));
disp(sprintf('dWHPCtime0_tech      :                |                 |%10.3f',dWHPCtime0_tech));
disp(sprintf('dWNPCtime0_tech      :                |                 |%10.3f',dWNPCtime0_tech));
disp(sprintf('dkHKtime0_tech       :                |                 |%10.3f',dkHtime0_tech));
disp(sprintf('dkNKtime0_tech       :                |                 |%10.3f',dkNtime0_tech));
disp(sprintf('dLHStime0_tech       :                |                 |%10.3f',dLHStime0_tech));
disp(sprintf('dLNStime0_tech       :                |                 |%10.3f',dLNStime0_tech));
disp(sprintf('dYHStime0_tech       :                |                 |%10.3f',dYHStime0_tech));
disp(sprintf('dYNStime0_tech       :                |                 |%10.3f',dYNStime0_tech));
disp(sprintf('dWHWtime0_tech       :                |                 |%10.3f',dWHWtime0_tech));
disp(sprintf('dWNWtime0_tech       :                |                 |%10.3f',dWNWtime0_tech));
disp(sprintf('dLISHtime0_tech      :                |                 |%10.3f',dLISHtime0_tech));
disp(sprintf('dLISNtime0_tech      :                |                 |%10.3f',dLISNtime0_tech));
disp(sprintf('dKHKtime0_tech       :                |                 |%10.3f',dKHKtime0_tech));   
disp(sprintf('dKNKtime0_tech       :                |                 |%10.3f',dKNKtime0_tech));  
disp(sprintf('dRtime0_tech         :                |                 |%10.3f',dRtime0_tech));
disp(sprintf('dRPHtime0_tech       :                |                 |%10.3f',dRPHtime0_tech));   
disp(sprintf('dRPNtime0_tech       :                |                 |%10.3f',dRPNtime0_tech)); 

disp('                Initial responses including capital and technology utilization rates');
disp(sprintf('duKHtime0_tech            :                |                 |%10.3f',duKHtime0_tech));     
disp(sprintf('duKNtime0_tech            :                |                 |%10.3f',duKNtime0_tech));     
disp(sprintf('duKtime0_tech             :                |                 |%10.3f',duKtime0_tech));      
disp(sprintf('duZHtime0_tech            :                |                 |%10.3f',duZHtime0_tech));     
disp(sprintf('duZNtime0_tech            :                |                 |%10.3f',duZNtime0_tech));     
disp(sprintf('dtildeZHtime0_tech        :                |                 |%10.3f',dtildeZHtime0_tech)); 
disp(sprintf('dtildeZNtime0_tech        :                |                 |%10.3f',dtildeZNtime0_tech)); 
disp(sprintf('dtildeZtime0_tech         :                |                 |%10.3f',dtildeZtime0_tech)); 
disp(sprintf('dTFPHtime0_tech           :                |                 |%10.3f',dTFPHtime0_tech));
disp(sprintf('dTFPNtime0_tech           :                |                 |%10.3f',dTFPNtime0_tech));
disp(sprintf('dTFPHtime0_check_tech     :                |                 |%10.3f',dTFPHtime0_check_tech));
disp(sprintf('dTFPNtime0_check_tech     :                |                 |%10.3f',dTFPNtime0_check_tech));
disp(sprintf('dTFPtime0_tech            :                |                 |%10.3f',dTFPtime0_tech));
disp(sprintf('dTFPRtime0_tech           :                |                 |%10.3f',dTFPRtime0_tech));
disp(sprintf('duZRtime0_tech            :                |                 |%10.3f',duZRtime0_tech));
disp(sprintf('dtildeYRtime0_tech        :                |                 |%10.3f',dtildeYRtime0_tech));               
disp(sprintf('dtildeYHtime0_tech        :                |                 |%10.3f',dtildeYHtime0_tech));               
disp(sprintf('dtildeYNtime0_tech        :                |                 |%10.3f',dtildeYNtime0_tech));               
disp(sprintf('dtildeYHYNtime0_tech      :                |                 |%10.3f',dtildeYHYNtime0_tech));             
disp(sprintf('dtildeWtime0_tech         :                |                 |%10.3f',dtildeWtime0_tech));                
disp(sprintf('dtildeWPCtime0_tech       :                |                 |%10.3f',dtildeWPCtime0_tech));              
disp(sprintf('dtildeWHtime0_tech        :                |                 |%10.3f',dtildeWHtime0_tech));               
disp(sprintf('dtildeWNtime0_tech        :                |                 |%10.3f',dtildeWNtime0_tech));               
disp(sprintf('dtildeOmegatime0_tech     :                |                 |%10.3f',dtildeOmegatime0_tech));            
disp(sprintf('dtildeWHPCtime0_tech      :                |                 |%10.3f',dtildeWHPCtime0_tech));             
disp(sprintf('dtildeWNPCtime0_tech      :                |                 |%10.3f',dtildeWNPCtime0_tech));             
disp(sprintf('dtildekHKtime0_tech       :                |                 |%10.3f',dtildekHtime0_tech));               
disp(sprintf('dtildekNKtime0_tech       :                |                 |%10.3f',dtildekNtime0_tech));               
disp(sprintf('dtildeYHStime0_tech       :                |                 |%10.3f',dtildeYHStime0_tech));              
disp(sprintf('dtildeYNStime0_tech       :                |                 |%10.3f',dtildeYNStime0_tech));              
disp(sprintf('dtildeWHWtime0_tech       :                |                 |%10.3f',dtildeWHWtime0_tech));              
disp(sprintf('dtildeWNWtime0_tech       :                |                 |%10.3f',dtildeWNWtime0_tech));   
disp(sprintf('dtildeRPHtime0_tech       :                |                 |%10.3f',dtildeRPHtime0_tech)); 
disp(sprintf('dtildeRPNtime0_tech       :                |                 |%10.3f',dtildeRPNtime0_tech));

disp('Decomposition of sectoral shares: cumul t=0');
disp('Decomposition of tildeYH/tildeYR');                                                                                                                
disp(sprintf('dtildeYHStime0_tech       :                |                 |%10.3f',dtildeYHStime0_tech));            
disp(sprintf('dYHS_TFPdifftime0_tech    :                |                 |%10.3f',dYHS_TFPdifftime0_tech));         
disp(sprintf('dYHS_labdifftime0_tech    :                |                 |%10.3f',dYHS_labdifftime0_tech));         
disp(sprintf('dYHS_capdifftime0_tech    :                |                 |%10.3f',dYHS_capdifftime0_tech));         
disp(sprintf('dtildeYHStime0_check_tech :                |                 |%10.3f',dYHStime0_check_tech));  
disp('Decomposition of tildeYN/tildeYR');      
disp(sprintf('dtildeYNStime0_tech       :                |                 |%10.3f',dtildeYNStime0_tech));     
disp(sprintf('dYNS_TFPdifftime0_tech    :                |                 |%10.3f',dYNS_TFPdifftime0_tech));  
disp(sprintf('dYNS_labdifftime0_tech    :                |                 |%10.3f',dYNS_labdifftime0_tech));  
disp(sprintf('dYNS_capdifftime0_tech    :                |                 |%10.3f',dYNS_capdifftime0_tech));  
disp(sprintf('dtildeYNStime0_check_tech :                |                 |%10.3f',dYNStime0_check_tech));    
disp('Decomposition of LN/L');                                                                                                                    
disp(sprintf('dLNStime0_tech            :                |                 |%10.3f',dLNStime0_tech));           
disp(sprintf('dLNS_NTsharetime0_tech    :                |                 |%10.3f',dLNS_NTsharetime0_tech));   
disp(sprintf('dLNS_LISdifftime0_tech    :                |                 |%10.3f',dLNS_LISdifftime0_tech));   
disp(sprintf('dLNStime0_check_tech      :                |                 |%10.3f',dLNStime0_check_tech)); 
disp(sprintf('dLNS_FBTCdifftime0_tech   :                |                 |%10.3f',dLNS_FBTCdifftime0_tech));  
disp(sprintf('dLNS_capdifftime0_tech    :                |                 |%10.3f',dLNS_capdifftime0_tech));  
disp(sprintf('dLNStime0_doublecheck_tech:                |                 |%10.3f',dLNStime0_doublecheck_tech)); 
disp('Decomposition of LISH');                                                                                                                    
disp(sprintf('dLISHtime0_tech           :                |                 |%10.3f',dLISHtime0_tech));        
disp(sprintf('dLISH_FBTCtime0_tech      :                |                 |%10.3f',dLISH_FBTCtime0_tech));   
disp(sprintf('dLISH_captime0_tech       :                |                 |%10.3f',dLISH_captime0_tech));    
disp(sprintf('dLISHtime0_check_tech     :                |                 |%10.3f',dLISHtime0_check_tech));              
disp('Decomposition of LISH');                                                                                                                      
disp(sprintf('dLISNtime0_tech           :                |                 |%10.3f',dLISNtime0_tech));                
disp(sprintf('dLISN_FBTCtime0_tech      :                |                 |%10.3f',dLISN_FBTCtime0_tech));           
disp(sprintf('dLISN_captime0_tech       :                |                 |%10.3f',dLISN_captime0_tech));            
disp(sprintf('dLISNtime0_check_tech     :                |                 |%10.3f',dLISNtime0_check_tech));  

disp('Decomposition of sectoral shares: cumul t=0..5');  
disp('Decomposition of tildeYH/tildeYR');                                                                         
disp(sprintf('dtildeYHScum_tech       :                |                 |%10.3f',dtildeYHScum_tech));            
disp(sprintf('dYHS_TFPdiffcum_tech    :                |                 |%10.3f',dYHS_TFPdiffcum_tech));         
disp(sprintf('dYHS_labdiffcum_tech    :                |                 |%10.3f',dYHS_labdiffcum_tech));         
disp(sprintf('dYHS_capdiffcum_tech    :                |                 |%10.3f',dYHS_capdiffcum_tech));         
disp(sprintf('dtildeYHScum_check_tech :                |                 |%10.3f',dYHScum_check_tech)); 
disp('Decomposition of tildeYN/tildeYR');      
disp(sprintf('dtildeYNScum_tech       :                |                 |%10.3f',dtildeYNScum_tech));    
disp(sprintf('dYNS_TFPdiffcum_tech    :                |                 |%10.3f',dYNS_TFPdiffcum_tech)); 
disp(sprintf('dYNS_labdiffcum_tech    :                |                 |%10.3f',dYNS_labdiffcum_tech)); 
disp(sprintf('dYNS_capdiffcum_tech    :                |                 |%10.3f',dYNS_capdiffcum_tech)); 
disp(sprintf('dtildeYNScum_check_tech :                |                 |%10.3f',dYNScum_check_tech));   
disp('Decomposition of LN/L');                                                                                    
disp(sprintf('dLNScum_tech            :                |                 |%10.3f',dLNScum_tech));                 
disp(sprintf('dLNS_NTsharecum_tech    :                |                 |%10.3f',dLNS_NTsharecum_tech));         
disp(sprintf('dLNS_LISdiffcum_tech    :                |                 |%10.3f',dLNS_LISdiffcum_tech));                 
disp(sprintf('dLNScum_check_tech      :                |                 |%10.3f',dLNScum_check_tech));
disp(sprintf('dLNS_FBTCdiffcum_tech   :                |                 |%10.3f',dLNS_FBTCdiffcum_tech));
disp(sprintf('dLNS_capdiffcum_tech    :                |                 |%10.3f',dLNS_capdiffcum_tech));
disp(sprintf('dLNScum_doublecheck_tech:                |                 |%10.3f',dLNScum_doublecheck_tech));
disp('Decomposition of LISH');                                                                                    
disp(sprintf('dLISHcum_tech           :                |                 |%10.3f',dLISHcum_tech));                
disp(sprintf('dLISH_FBTCcum_tech      :                |                 |%10.3f',dLISH_FBTCcum_tech));           
disp(sprintf('dLISH_capcum_tech       :                |                 |%10.3f',dLISH_capcum_tech));            
disp(sprintf('dLISHcum_check_tech     :                |                 |%10.3f',dLISHcum_check_tech));          
disp('Decomposition of LISH');                                                                                    
disp(sprintf('dLISNcum_tech           :                |                 |%10.3f',dLISNcum_tech));                
disp(sprintf('dLISN_FBTCcum_tech      :                |                 |%10.3f',dLISN_FBTCcum_tech));           
disp(sprintf('dLISN_capcum_tech       :                |                 |%10.3f',dLISN_capcum_tech));            
disp(sprintf('dLISNcum_check_tech     :                |                 |%10.3f',dLISNcum_check_tech));  

disp('cumul t=0..5 responses of P,PH,WHW,WNW'); 
disp(sprintf('dPcum_tech             :                |                 |%10.3f',dPcum_tech));            
disp(sprintf('dPHcum_tech            :                |                 |%10.3f',dPHcum_tech));           
disp(sprintf('dWHWcum_tech           :                |                 |%10.3f',dWHWcum_tech));          
disp(sprintf('dWNWcum_tech           :                |                 |%10.3f',dWNWcum_tech));  

disp('cumul t=0..5 responses of L,tildeYR,Lj,tildeYj'); 
disp(sprintf('dLcum_tech             :                |                 |%10.3f',dLcum_tech));
disp(sprintf('dtildeYRcum_tech       :                |                 |%10.3f',dtildeYRcum_tech));
disp(sprintf('dLHcum_tech            :                |                 |%10.3f',dLHcum_tech));
disp(sprintf('dLNcum_tech            :                |                 |%10.3f',dLNcum_tech));
disp(sprintf('dtildeYHcum_tech       :                |                 |%10.3f',dtildeYHcum_tech));
disp(sprintf('dtildeYNcum_tech       :                |                 |%10.3f',dtildeYNcum_tech));

disp('cumul t=0..5 responses of G');    
disp(sprintf('dGYcum_tech            :                |                 |%10.3f',dGYcum_tech));                
disp('cumul t=0..5 responses of tildeZj,TFPj');                                                           
disp(sprintf('dtildeZHcum_tech       :                |                 |%10.3f',dtildeZHcum_tech));      
disp(sprintf('dtildeZNcum_tech       :                |                 |%10.3f',dtildeZNcum_tech));      
disp(sprintf('dTFPHcum_tech          :                |                 |%10.3f',dTFPHcum_tech));         
disp(sprintf('dTFPNcum_tech          :                |                 |%10.3f',dTFPNcum_tech)); 
disp(sprintf('dFBTCHcum_tech         :                |                 |%10.3f',dFBTCHcum_tech)); 
disp(sprintf('dFBTCNcum_tech         :                |                 |%10.3f',dFBTCNcum_tech)); 

disp(' ');
disp('Steady State Equilibrium ratios (exomark)');
disp(sprintf('sigmaH  : %5.3f   sigmaN   : %5.3f',sigmaH_0,sigmaN_0));
disp(sprintf('gammaH  : %5.3f   gammaN   : %5.3f',gammaH_0,gammaN_0));
disp(sprintf('varphi  : %5.3f   vartheta : %5.3f',varphi_0,vartheta_0));
disp(sprintf('varphiH : %5.3f   iotaH    : %5.3f',varphiH_0,iotaH_0));
disp(sprintf('YH / Y    :  %5.3f     PN*YN / Y  : %5.3f',omegaYH_0,omegaYN_0));
disp(sprintf('LH / L    :  %5.3f      LN / L    : %5.3f',omegaLH_0,omegaLN_0));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC_0,omegaNX_0));
disp(sprintf('PI*I / Y  :  %5.3f      G / Y     : %5.3f',omegaI_0,omegaG_0));
disp(' ');
disp(sprintf('GH / YH     :  %5.3f  GN / YN    :  %5.3f  (PN*GN)/G  : %5.3f',omegaGHYH_0,omegaGNYN_0,omegaGN_0));
disp(sprintf('(PH*GH)/G   :  %5.3f  GF / G     :  %5.3f    GT/G     : %5.3f',omegaGH_0,omegaGF_0,omegaGT_0));
disp(sprintf('IN / YN     :  %5.3f  IH / YH    :  %5.3f',omegaINYN_0,omegaIHYH_0));
disp(sprintf('IF / YH     :  %5.3f  GF / YH    :  %5.3f',omegaIFYH_0,omegaGFYH_0));
disp(sprintf('WH*LH/PH*YH :  %5.3f WN*LN/PN*YN :  %5.3f',sLH_0,sLN_0));
disp(sprintf('WH*LH/W*L   :  %5.3f RH*KH/R*K   :  %5.3f',alphaL_0,alphaK_0));
disp(sprintf('PT*IT/PI*I  :  %5.3f PT*CT/PC*C  :  %5.3f',alphaI_0,alphaC_0));
disp(sprintf('PH*IH/PT*IT :  %5.3f PH*CH/PT*CT :  %5.3f',alphaIH_0,alphaH_0));
disp(sprintf('PH*IH/PI*I  :  %5.3f PH*CH/PC*C  :  %5.3f',omegaIH_0,omegaCH_0));
disp(sprintf('IF/PI*I     :  %5.3f    CF/PC*C  :  %5.3f',omegaIF_0,omegaCF_0));
disp(sprintf('PH*XH/Y     :  %5.3f    XH / YH  :  %5.3f',omegaXHY_0,omegaXHYH_0));
disp(sprintf('W*L/P*Y     :  %5.3f R*K/P*Y     :  %5.3f',omegaL_0,omegaK_0));
disp(sprintf('K/Y         :  %5.3f (r*B)/Y     :  %5.3f',omegaKY_0,omegaB_0));
disp(' ');
disp(sprintf('xi1H    : %5.2f   xi2H     : %5.2f',xi1H,xi2H));
disp(sprintf('chi1H   : %5.2f   chi2H    : %5.2f',chi1H,chi2H));
disp(sprintf('xi1N    : %5.2f   xi2N     : %5.2f',xi1N,xi2N));
disp(sprintf('chi1N   : %5.2f   chi2N    : %5.2f',chi1N,chi2N));
disp(sprintf('xi     : %5.2f  chi       : %5.2f  barg      : %5.2f',xi,chi,barg));       
disp(sprintf('xiAH   : %5.2f  chiAH     : %5.2f  baraH     : %5.2f',xiAH,chiAH,baraH));  
disp(sprintf('xiBH   : %5.2f  chiBB     : %5.2f  barbH     : %5.2f',xiBH,chiBH,barbH));  
disp(sprintf('xiAN  : %5.2f   chiAN     : %5.2f  baraN     : %5.2f',xiAN,chiAN,baraN));  
disp(sprintf('xiBN  : %5.2f   chiBN     : %5.2f  barbN     : %5.2f',xiBN,chiBN,barbN));  
disp(' ');



