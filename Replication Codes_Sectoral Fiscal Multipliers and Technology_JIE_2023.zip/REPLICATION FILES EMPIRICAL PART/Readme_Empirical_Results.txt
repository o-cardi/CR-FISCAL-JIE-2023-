Data and Replication Codes for 'Sectoral Fiscal Multipliers and Technology in Open Economy' 
by Olivier Cardi and Romain Restout, June 2023.

Data: database2023.xlsx.

The software for Figure 1 is RATS Pro 10.0.

Run the code Figure1.RPF to obtain the empirical IRFs to an exogeneous increase government spending by 1% of GDP 
for the whole panel (Figure 1). Sample: 18 OECD countries, 1970-2015, annual data.
